(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const r of document.querySelectorAll('link[rel="modulepreload"]'))i(r);new MutationObserver(r=>{for(const a of r)if(a.type==="childList")for(const s of a.addedNodes)s.tagName==="LINK"&&s.rel==="modulepreload"&&i(s)}).observe(document,{childList:!0,subtree:!0});function n(r){const a={};return r.integrity&&(a.integrity=r.integrity),r.referrerPolicy&&(a.referrerPolicy=r.referrerPolicy),r.crossOrigin==="use-credentials"?a.credentials="include":r.crossOrigin==="anonymous"?a.credentials="omit":a.credentials="same-origin",a}function i(r){if(r.ep)return;r.ep=!0;const a=n(r);fetch(r.href,a)}})();var gg={exports:{}},nc={},_g={exports:{}},He={};/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Js=Symbol.for("react.element"),Yx=Symbol.for("react.portal"),Kx=Symbol.for("react.fragment"),Zx=Symbol.for("react.strict_mode"),Qx=Symbol.for("react.profiler"),Jx=Symbol.for("react.provider"),ev=Symbol.for("react.context"),tv=Symbol.for("react.forward_ref"),nv=Symbol.for("react.suspense"),iv=Symbol.for("react.memo"),rv=Symbol.for("react.lazy"),Kh=Symbol.iterator;function av(t){return t===null||typeof t!="object"?null:(t=Kh&&t[Kh]||t["@@iterator"],typeof t=="function"?t:null)}var xg={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},vg=Object.assign,yg={};function Ka(t,e,n){this.props=t,this.context=e,this.refs=yg,this.updater=n||xg}Ka.prototype.isReactComponent={};Ka.prototype.setState=function(t,e){if(typeof t!="object"&&typeof t!="function"&&t!=null)throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,t,e,"setState")};Ka.prototype.forceUpdate=function(t){this.updater.enqueueForceUpdate(this,t,"forceUpdate")};function Sg(){}Sg.prototype=Ka.prototype;function Sf(t,e,n){this.props=t,this.context=e,this.refs=yg,this.updater=n||xg}var Mf=Sf.prototype=new Sg;Mf.constructor=Sf;vg(Mf,Ka.prototype);Mf.isPureReactComponent=!0;var Zh=Array.isArray,Mg=Object.prototype.hasOwnProperty,Ef={current:null},Eg={key:!0,ref:!0,__self:!0,__source:!0};function bg(t,e,n){var i,r={},a=null,s=null;if(e!=null)for(i in e.ref!==void 0&&(s=e.ref),e.key!==void 0&&(a=""+e.key),e)Mg.call(e,i)&&!Eg.hasOwnProperty(i)&&(r[i]=e[i]);var o=arguments.length-2;if(o===1)r.children=n;else if(1<o){for(var l=Array(o),c=0;c<o;c++)l[c]=arguments[c+2];r.children=l}if(t&&t.defaultProps)for(i in o=t.defaultProps,o)r[i]===void 0&&(r[i]=o[i]);return{$$typeof:Js,type:t,key:a,ref:s,props:r,_owner:Ef.current}}function sv(t,e){return{$$typeof:Js,type:t.type,key:e,ref:t.ref,props:t.props,_owner:t._owner}}function bf(t){return typeof t=="object"&&t!==null&&t.$$typeof===Js}function ov(t){var e={"=":"=0",":":"=2"};return"$"+t.replace(/[=:]/g,function(n){return e[n]})}var Qh=/\/+/g;function Cc(t,e){return typeof t=="object"&&t!==null&&t.key!=null?ov(""+t.key):e.toString(36)}function nl(t,e,n,i,r){var a=typeof t;(a==="undefined"||a==="boolean")&&(t=null);var s=!1;if(t===null)s=!0;else switch(a){case"string":case"number":s=!0;break;case"object":switch(t.$$typeof){case Js:case Yx:s=!0}}if(s)return s=t,r=r(s),t=i===""?"."+Cc(s,0):i,Zh(r)?(n="",t!=null&&(n=t.replace(Qh,"$&/")+"/"),nl(r,e,n,"",function(c){return c})):r!=null&&(bf(r)&&(r=sv(r,n+(!r.key||s&&s.key===r.key?"":(""+r.key).replace(Qh,"$&/")+"/")+t)),e.push(r)),1;if(s=0,i=i===""?".":i+":",Zh(t))for(var o=0;o<t.length;o++){a=t[o];var l=i+Cc(a,o);s+=nl(a,e,n,l,r)}else if(l=av(t),typeof l=="function")for(t=l.call(t),o=0;!(a=t.next()).done;)a=a.value,l=i+Cc(a,o++),s+=nl(a,e,n,l,r);else if(a==="object")throw e=String(t),Error("Objects are not valid as a React child (found: "+(e==="[object Object]"?"object with keys {"+Object.keys(t).join(", ")+"}":e)+"). If you meant to render a collection of children, use an array instead.");return s}function po(t,e,n){if(t==null)return t;var i=[],r=0;return nl(t,i,"","",function(a){return e.call(n,a,r++)}),i}function lv(t){if(t._status===-1){var e=t._result;e=e(),e.then(function(n){(t._status===0||t._status===-1)&&(t._status=1,t._result=n)},function(n){(t._status===0||t._status===-1)&&(t._status=2,t._result=n)}),t._status===-1&&(t._status=0,t._result=e)}if(t._status===1)return t._result.default;throw t._result}var sn={current:null},il={transition:null},cv={ReactCurrentDispatcher:sn,ReactCurrentBatchConfig:il,ReactCurrentOwner:Ef};function wg(){throw Error("act(...) is not supported in production builds of React.")}He.Children={map:po,forEach:function(t,e,n){po(t,function(){e.apply(this,arguments)},n)},count:function(t){var e=0;return po(t,function(){e++}),e},toArray:function(t){return po(t,function(e){return e})||[]},only:function(t){if(!bf(t))throw Error("React.Children.only expected to receive a single React element child.");return t}};He.Component=Ka;He.Fragment=Kx;He.Profiler=Qx;He.PureComponent=Sf;He.StrictMode=Zx;He.Suspense=nv;He.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=cv;He.act=wg;He.cloneElement=function(t,e,n){if(t==null)throw Error("React.cloneElement(...): The argument must be a React element, but you passed "+t+".");var i=vg({},t.props),r=t.key,a=t.ref,s=t._owner;if(e!=null){if(e.ref!==void 0&&(a=e.ref,s=Ef.current),e.key!==void 0&&(r=""+e.key),t.type&&t.type.defaultProps)var o=t.type.defaultProps;for(l in e)Mg.call(e,l)&&!Eg.hasOwnProperty(l)&&(i[l]=e[l]===void 0&&o!==void 0?o[l]:e[l])}var l=arguments.length-2;if(l===1)i.children=n;else if(1<l){o=Array(l);for(var c=0;c<l;c++)o[c]=arguments[c+2];i.children=o}return{$$typeof:Js,type:t.type,key:r,ref:a,props:i,_owner:s}};He.createContext=function(t){return t={$$typeof:ev,_currentValue:t,_currentValue2:t,_threadCount:0,Provider:null,Consumer:null,_defaultValue:null,_globalName:null},t.Provider={$$typeof:Jx,_context:t},t.Consumer=t};He.createElement=bg;He.createFactory=function(t){var e=bg.bind(null,t);return e.type=t,e};He.createRef=function(){return{current:null}};He.forwardRef=function(t){return{$$typeof:tv,render:t}};He.isValidElement=bf;He.lazy=function(t){return{$$typeof:rv,_payload:{_status:-1,_result:t},_init:lv}};He.memo=function(t,e){return{$$typeof:iv,type:t,compare:e===void 0?null:e}};He.startTransition=function(t){var e=il.transition;il.transition={};try{t()}finally{il.transition=e}};He.unstable_act=wg;He.useCallback=function(t,e){return sn.current.useCallback(t,e)};He.useContext=function(t){return sn.current.useContext(t)};He.useDebugValue=function(){};He.useDeferredValue=function(t){return sn.current.useDeferredValue(t)};He.useEffect=function(t,e){return sn.current.useEffect(t,e)};He.useId=function(){return sn.current.useId()};He.useImperativeHandle=function(t,e,n){return sn.current.useImperativeHandle(t,e,n)};He.useInsertionEffect=function(t,e){return sn.current.useInsertionEffect(t,e)};He.useLayoutEffect=function(t,e){return sn.current.useLayoutEffect(t,e)};He.useMemo=function(t,e){return sn.current.useMemo(t,e)};He.useReducer=function(t,e,n){return sn.current.useReducer(t,e,n)};He.useRef=function(t){return sn.current.useRef(t)};He.useState=function(t){return sn.current.useState(t)};He.useSyncExternalStore=function(t,e,n){return sn.current.useSyncExternalStore(t,e,n)};He.useTransition=function(){return sn.current.useTransition()};He.version="18.3.1";_g.exports=He;var z=_g.exports;/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var uv=z,dv=Symbol.for("react.element"),fv=Symbol.for("react.fragment"),hv=Object.prototype.hasOwnProperty,pv=uv.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,mv={key:!0,ref:!0,__self:!0,__source:!0};function Tg(t,e,n){var i,r={},a=null,s=null;n!==void 0&&(a=""+n),e.key!==void 0&&(a=""+e.key),e.ref!==void 0&&(s=e.ref);for(i in e)hv.call(e,i)&&!mv.hasOwnProperty(i)&&(r[i]=e[i]);if(t&&t.defaultProps)for(i in e=t.defaultProps,e)r[i]===void 0&&(r[i]=e[i]);return{$$typeof:dv,type:t,key:a,ref:s,props:r,_owner:pv.current}}nc.Fragment=fv;nc.jsx=Tg;nc.jsxs=Tg;gg.exports=nc;var p=gg.exports,Ag={exports:{}},bn={},Cg={exports:{}},Rg={};/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */(function(t){function e(O,I){var J=O.length;O.push(I);e:for(;0<J;){var ae=J-1>>>1,le=O[ae];if(0<r(le,I))O[ae]=I,O[J]=le,J=ae;else break e}}function n(O){return O.length===0?null:O[0]}function i(O){if(O.length===0)return null;var I=O[0],J=O.pop();if(J!==I){O[0]=J;e:for(var ae=0,le=O.length,Be=le>>>1;ae<Be;){var Xe=2*(ae+1)-1,ze=O[Xe],Q=Xe+1,oe=O[Q];if(0>r(ze,J))Q<le&&0>r(oe,ze)?(O[ae]=oe,O[Q]=J,ae=Q):(O[ae]=ze,O[Xe]=J,ae=Xe);else if(Q<le&&0>r(oe,J))O[ae]=oe,O[Q]=J,ae=Q;else break e}}return I}function r(O,I){var J=O.sortIndex-I.sortIndex;return J!==0?J:O.id-I.id}if(typeof performance=="object"&&typeof performance.now=="function"){var a=performance;t.unstable_now=function(){return a.now()}}else{var s=Date,o=s.now();t.unstable_now=function(){return s.now()-o}}var l=[],c=[],f=1,h=null,u=3,m=!1,x=!1,E=!1,g=typeof setTimeout=="function"?setTimeout:null,d=typeof clearTimeout=="function"?clearTimeout:null,v=typeof setImmediate<"u"?setImmediate:null;typeof navigator<"u"&&navigator.scheduling!==void 0&&navigator.scheduling.isInputPending!==void 0&&navigator.scheduling.isInputPending.bind(navigator.scheduling);function S(O){for(var I=n(c);I!==null;){if(I.callback===null)i(c);else if(I.startTime<=O)i(c),I.sortIndex=I.expirationTime,e(l,I);else break;I=n(c)}}function M(O){if(E=!1,S(O),!x)if(n(l)!==null)x=!0,X(A);else{var I=n(c);I!==null&&V(M,I.startTime-O)}}function A(O,I){x=!1,E&&(E=!1,d(_),_=-1),m=!0;var J=u;try{for(S(I),h=n(l);h!==null&&(!(h.expirationTime>I)||O&&!N());){var ae=h.callback;if(typeof ae=="function"){h.callback=null,u=h.priorityLevel;var le=ae(h.expirationTime<=I);I=t.unstable_now(),typeof le=="function"?h.callback=le:h===n(l)&&i(l),S(I)}else i(l);h=n(l)}if(h!==null)var Be=!0;else{var Xe=n(c);Xe!==null&&V(M,Xe.startTime-I),Be=!1}return Be}finally{h=null,u=J,m=!1}}var T=!1,w=null,_=-1,C=5,P=-1;function N(){return!(t.unstable_now()-P<C)}function F(){if(w!==null){var O=t.unstable_now();P=O;var I=!0;try{I=w(!0,O)}finally{I?q():(T=!1,w=null)}}else T=!1}var q;if(typeof v=="function")q=function(){v(F)};else if(typeof MessageChannel<"u"){var ie=new MessageChannel,k=ie.port2;ie.port1.onmessage=F,q=function(){k.postMessage(null)}}else q=function(){g(F,0)};function X(O){w=O,T||(T=!0,q())}function V(O,I){_=g(function(){O(t.unstable_now())},I)}t.unstable_IdlePriority=5,t.unstable_ImmediatePriority=1,t.unstable_LowPriority=4,t.unstable_NormalPriority=3,t.unstable_Profiling=null,t.unstable_UserBlockingPriority=2,t.unstable_cancelCallback=function(O){O.callback=null},t.unstable_continueExecution=function(){x||m||(x=!0,X(A))},t.unstable_forceFrameRate=function(O){0>O||125<O?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):C=0<O?Math.floor(1e3/O):5},t.unstable_getCurrentPriorityLevel=function(){return u},t.unstable_getFirstCallbackNode=function(){return n(l)},t.unstable_next=function(O){switch(u){case 1:case 2:case 3:var I=3;break;default:I=u}var J=u;u=I;try{return O()}finally{u=J}},t.unstable_pauseExecution=function(){},t.unstable_requestPaint=function(){},t.unstable_runWithPriority=function(O,I){switch(O){case 1:case 2:case 3:case 4:case 5:break;default:O=3}var J=u;u=O;try{return I()}finally{u=J}},t.unstable_scheduleCallback=function(O,I,J){var ae=t.unstable_now();switch(typeof J=="object"&&J!==null?(J=J.delay,J=typeof J=="number"&&0<J?ae+J:ae):J=ae,O){case 1:var le=-1;break;case 2:le=250;break;case 5:le=1073741823;break;case 4:le=1e4;break;default:le=5e3}return le=J+le,O={id:f++,callback:I,priorityLevel:O,startTime:J,expirationTime:le,sortIndex:-1},J>ae?(O.sortIndex=J,e(c,O),n(l)===null&&O===n(c)&&(E?(d(_),_=-1):E=!0,V(M,J-ae))):(O.sortIndex=le,e(l,O),x||m||(x=!0,X(A))),O},t.unstable_shouldYield=N,t.unstable_wrapCallback=function(O){var I=u;return function(){var J=u;u=I;try{return O.apply(this,arguments)}finally{u=J}}}})(Rg);Cg.exports=Rg;var gv=Cg.exports;/**
 * @license React
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var _v=z,En=gv;function se(t){for(var e="https://reactjs.org/docs/error-decoder.html?invariant="+t,n=1;n<arguments.length;n++)e+="&args[]="+encodeURIComponent(arguments[n]);return"Minified React error #"+t+"; visit "+e+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}var Pg=new Set,Ds={};function Zr(t,e){Ba(t,e),Ba(t+"Capture",e)}function Ba(t,e){for(Ds[t]=e,t=0;t<e.length;t++)Pg.add(e[t])}var Ui=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),Fu=Object.prototype.hasOwnProperty,xv=/^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,Jh={},ep={};function vv(t){return Fu.call(ep,t)?!0:Fu.call(Jh,t)?!1:xv.test(t)?ep[t]=!0:(Jh[t]=!0,!1)}function yv(t,e,n,i){if(n!==null&&n.type===0)return!1;switch(typeof e){case"function":case"symbol":return!0;case"boolean":return i?!1:n!==null?!n.acceptsBooleans:(t=t.toLowerCase().slice(0,5),t!=="data-"&&t!=="aria-");default:return!1}}function Sv(t,e,n,i){if(e===null||typeof e>"u"||yv(t,e,n,i))return!0;if(i)return!1;if(n!==null)switch(n.type){case 3:return!e;case 4:return e===!1;case 5:return isNaN(e);case 6:return isNaN(e)||1>e}return!1}function on(t,e,n,i,r,a,s){this.acceptsBooleans=e===2||e===3||e===4,this.attributeName=i,this.attributeNamespace=r,this.mustUseProperty=n,this.propertyName=t,this.type=e,this.sanitizeURL=a,this.removeEmptyString=s}var jt={};"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(t){jt[t]=new on(t,0,!1,t,null,!1,!1)});[["acceptCharset","accept-charset"],["className","class"],["htmlFor","for"],["httpEquiv","http-equiv"]].forEach(function(t){var e=t[0];jt[e]=new on(e,1,!1,t[1],null,!1,!1)});["contentEditable","draggable","spellCheck","value"].forEach(function(t){jt[t]=new on(t,2,!1,t.toLowerCase(),null,!1,!1)});["autoReverse","externalResourcesRequired","focusable","preserveAlpha"].forEach(function(t){jt[t]=new on(t,2,!1,t,null,!1,!1)});"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(t){jt[t]=new on(t,3,!1,t.toLowerCase(),null,!1,!1)});["checked","multiple","muted","selected"].forEach(function(t){jt[t]=new on(t,3,!0,t,null,!1,!1)});["capture","download"].forEach(function(t){jt[t]=new on(t,4,!1,t,null,!1,!1)});["cols","rows","size","span"].forEach(function(t){jt[t]=new on(t,6,!1,t,null,!1,!1)});["rowSpan","start"].forEach(function(t){jt[t]=new on(t,5,!1,t.toLowerCase(),null,!1,!1)});var wf=/[\-:]([a-z])/g;function Tf(t){return t[1].toUpperCase()}"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(t){var e=t.replace(wf,Tf);jt[e]=new on(e,1,!1,t,null,!1,!1)});"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(t){var e=t.replace(wf,Tf);jt[e]=new on(e,1,!1,t,"http://www.w3.org/1999/xlink",!1,!1)});["xml:base","xml:lang","xml:space"].forEach(function(t){var e=t.replace(wf,Tf);jt[e]=new on(e,1,!1,t,"http://www.w3.org/XML/1998/namespace",!1,!1)});["tabIndex","crossOrigin"].forEach(function(t){jt[t]=new on(t,1,!1,t.toLowerCase(),null,!1,!1)});jt.xlinkHref=new on("xlinkHref",1,!1,"xlink:href","http://www.w3.org/1999/xlink",!0,!1);["src","href","action","formAction"].forEach(function(t){jt[t]=new on(t,1,!1,t.toLowerCase(),null,!0,!0)});function Af(t,e,n,i){var r=jt.hasOwnProperty(e)?jt[e]:null;(r!==null?r.type!==0:i||!(2<e.length)||e[0]!=="o"&&e[0]!=="O"||e[1]!=="n"&&e[1]!=="N")&&(Sv(e,n,r,i)&&(n=null),i||r===null?vv(e)&&(n===null?t.removeAttribute(e):t.setAttribute(e,""+n)):r.mustUseProperty?t[r.propertyName]=n===null?r.type===3?!1:"":n:(e=r.attributeName,i=r.attributeNamespace,n===null?t.removeAttribute(e):(r=r.type,n=r===3||r===4&&n===!0?"":""+n,i?t.setAttributeNS(i,e,n):t.setAttribute(e,n))))}var Hi=_v.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,mo=Symbol.for("react.element"),xa=Symbol.for("react.portal"),va=Symbol.for("react.fragment"),Cf=Symbol.for("react.strict_mode"),Ou=Symbol.for("react.profiler"),Ng=Symbol.for("react.provider"),Lg=Symbol.for("react.context"),Rf=Symbol.for("react.forward_ref"),ku=Symbol.for("react.suspense"),Bu=Symbol.for("react.suspense_list"),Pf=Symbol.for("react.memo"),tr=Symbol.for("react.lazy"),Dg=Symbol.for("react.offscreen"),tp=Symbol.iterator;function ns(t){return t===null||typeof t!="object"?null:(t=tp&&t[tp]||t["@@iterator"],typeof t=="function"?t:null)}var _t=Object.assign,Rc;function xs(t){if(Rc===void 0)try{throw Error()}catch(n){var e=n.stack.trim().match(/\n( *(at )?)/);Rc=e&&e[1]||""}return`
`+Rc+t}var Pc=!1;function Nc(t,e){if(!t||Pc)return"";Pc=!0;var n=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{if(e)if(e=function(){throw Error()},Object.defineProperty(e.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(e,[])}catch(c){var i=c}Reflect.construct(t,[],e)}else{try{e.call()}catch(c){i=c}t.call(e.prototype)}else{try{throw Error()}catch(c){i=c}t()}}catch(c){if(c&&i&&typeof c.stack=="string"){for(var r=c.stack.split(`
`),a=i.stack.split(`
`),s=r.length-1,o=a.length-1;1<=s&&0<=o&&r[s]!==a[o];)o--;for(;1<=s&&0<=o;s--,o--)if(r[s]!==a[o]){if(s!==1||o!==1)do if(s--,o--,0>o||r[s]!==a[o]){var l=`
`+r[s].replace(" at new "," at ");return t.displayName&&l.includes("<anonymous>")&&(l=l.replace("<anonymous>",t.displayName)),l}while(1<=s&&0<=o);break}}}finally{Pc=!1,Error.prepareStackTrace=n}return(t=t?t.displayName||t.name:"")?xs(t):""}function Mv(t){switch(t.tag){case 5:return xs(t.type);case 16:return xs("Lazy");case 13:return xs("Suspense");case 19:return xs("SuspenseList");case 0:case 2:case 15:return t=Nc(t.type,!1),t;case 11:return t=Nc(t.type.render,!1),t;case 1:return t=Nc(t.type,!0),t;default:return""}}function zu(t){if(t==null)return null;if(typeof t=="function")return t.displayName||t.name||null;if(typeof t=="string")return t;switch(t){case va:return"Fragment";case xa:return"Portal";case Ou:return"Profiler";case Cf:return"StrictMode";case ku:return"Suspense";case Bu:return"SuspenseList"}if(typeof t=="object")switch(t.$$typeof){case Lg:return(t.displayName||"Context")+".Consumer";case Ng:return(t._context.displayName||"Context")+".Provider";case Rf:var e=t.render;return t=t.displayName,t||(t=e.displayName||e.name||"",t=t!==""?"ForwardRef("+t+")":"ForwardRef"),t;case Pf:return e=t.displayName||null,e!==null?e:zu(t.type)||"Memo";case tr:e=t._payload,t=t._init;try{return zu(t(e))}catch{}}return null}function Ev(t){var e=t.type;switch(t.tag){case 24:return"Cache";case 9:return(e.displayName||"Context")+".Consumer";case 10:return(e._context.displayName||"Context")+".Provider";case 18:return"DehydratedFragment";case 11:return t=e.render,t=t.displayName||t.name||"",e.displayName||(t!==""?"ForwardRef("+t+")":"ForwardRef");case 7:return"Fragment";case 5:return e;case 4:return"Portal";case 3:return"Root";case 6:return"Text";case 16:return zu(e);case 8:return e===Cf?"StrictMode":"Mode";case 22:return"Offscreen";case 12:return"Profiler";case 21:return"Scope";case 13:return"Suspense";case 19:return"SuspenseList";case 25:return"TracingMarker";case 1:case 0:case 17:case 2:case 14:case 15:if(typeof e=="function")return e.displayName||e.name||null;if(typeof e=="string")return e}return null}function xr(t){switch(typeof t){case"boolean":case"number":case"string":case"undefined":return t;case"object":return t;default:return""}}function Ig(t){var e=t.type;return(t=t.nodeName)&&t.toLowerCase()==="input"&&(e==="checkbox"||e==="radio")}function bv(t){var e=Ig(t)?"checked":"value",n=Object.getOwnPropertyDescriptor(t.constructor.prototype,e),i=""+t[e];if(!t.hasOwnProperty(e)&&typeof n<"u"&&typeof n.get=="function"&&typeof n.set=="function"){var r=n.get,a=n.set;return Object.defineProperty(t,e,{configurable:!0,get:function(){return r.call(this)},set:function(s){i=""+s,a.call(this,s)}}),Object.defineProperty(t,e,{enumerable:n.enumerable}),{getValue:function(){return i},setValue:function(s){i=""+s},stopTracking:function(){t._valueTracker=null,delete t[e]}}}}function go(t){t._valueTracker||(t._valueTracker=bv(t))}function Ug(t){if(!t)return!1;var e=t._valueTracker;if(!e)return!0;var n=e.getValue(),i="";return t&&(i=Ig(t)?t.checked?"true":"false":t.value),t=i,t!==n?(e.setValue(t),!0):!1}function Ml(t){if(t=t||(typeof document<"u"?document:void 0),typeof t>"u")return null;try{return t.activeElement||t.body}catch{return t.body}}function Vu(t,e){var n=e.checked;return _t({},e,{defaultChecked:void 0,defaultValue:void 0,value:void 0,checked:n??t._wrapperState.initialChecked})}function np(t,e){var n=e.defaultValue==null?"":e.defaultValue,i=e.checked!=null?e.checked:e.defaultChecked;n=xr(e.value!=null?e.value:n),t._wrapperState={initialChecked:i,initialValue:n,controlled:e.type==="checkbox"||e.type==="radio"?e.checked!=null:e.value!=null}}function Fg(t,e){e=e.checked,e!=null&&Af(t,"checked",e,!1)}function Hu(t,e){Fg(t,e);var n=xr(e.value),i=e.type;if(n!=null)i==="number"?(n===0&&t.value===""||t.value!=n)&&(t.value=""+n):t.value!==""+n&&(t.value=""+n);else if(i==="submit"||i==="reset"){t.removeAttribute("value");return}e.hasOwnProperty("value")?Gu(t,e.type,n):e.hasOwnProperty("defaultValue")&&Gu(t,e.type,xr(e.defaultValue)),e.checked==null&&e.defaultChecked!=null&&(t.defaultChecked=!!e.defaultChecked)}function ip(t,e,n){if(e.hasOwnProperty("value")||e.hasOwnProperty("defaultValue")){var i=e.type;if(!(i!=="submit"&&i!=="reset"||e.value!==void 0&&e.value!==null))return;e=""+t._wrapperState.initialValue,n||e===t.value||(t.value=e),t.defaultValue=e}n=t.name,n!==""&&(t.name=""),t.defaultChecked=!!t._wrapperState.initialChecked,n!==""&&(t.name=n)}function Gu(t,e,n){(e!=="number"||Ml(t.ownerDocument)!==t)&&(n==null?t.defaultValue=""+t._wrapperState.initialValue:t.defaultValue!==""+n&&(t.defaultValue=""+n))}var vs=Array.isArray;function Pa(t,e,n,i){if(t=t.options,e){e={};for(var r=0;r<n.length;r++)e["$"+n[r]]=!0;for(n=0;n<t.length;n++)r=e.hasOwnProperty("$"+t[n].value),t[n].selected!==r&&(t[n].selected=r),r&&i&&(t[n].defaultSelected=!0)}else{for(n=""+xr(n),e=null,r=0;r<t.length;r++){if(t[r].value===n){t[r].selected=!0,i&&(t[r].defaultSelected=!0);return}e!==null||t[r].disabled||(e=t[r])}e!==null&&(e.selected=!0)}}function Wu(t,e){if(e.dangerouslySetInnerHTML!=null)throw Error(se(91));return _t({},e,{value:void 0,defaultValue:void 0,children:""+t._wrapperState.initialValue})}function rp(t,e){var n=e.value;if(n==null){if(n=e.children,e=e.defaultValue,n!=null){if(e!=null)throw Error(se(92));if(vs(n)){if(1<n.length)throw Error(se(93));n=n[0]}e=n}e==null&&(e=""),n=e}t._wrapperState={initialValue:xr(n)}}function Og(t,e){var n=xr(e.value),i=xr(e.defaultValue);n!=null&&(n=""+n,n!==t.value&&(t.value=n),e.defaultValue==null&&t.defaultValue!==n&&(t.defaultValue=n)),i!=null&&(t.defaultValue=""+i)}function ap(t){var e=t.textContent;e===t._wrapperState.initialValue&&e!==""&&e!==null&&(t.value=e)}function kg(t){switch(t){case"svg":return"http://www.w3.org/2000/svg";case"math":return"http://www.w3.org/1998/Math/MathML";default:return"http://www.w3.org/1999/xhtml"}}function ju(t,e){return t==null||t==="http://www.w3.org/1999/xhtml"?kg(e):t==="http://www.w3.org/2000/svg"&&e==="foreignObject"?"http://www.w3.org/1999/xhtml":t}var _o,Bg=function(t){return typeof MSApp<"u"&&MSApp.execUnsafeLocalFunction?function(e,n,i,r){MSApp.execUnsafeLocalFunction(function(){return t(e,n,i,r)})}:t}(function(t,e){if(t.namespaceURI!=="http://www.w3.org/2000/svg"||"innerHTML"in t)t.innerHTML=e;else{for(_o=_o||document.createElement("div"),_o.innerHTML="<svg>"+e.valueOf().toString()+"</svg>",e=_o.firstChild;t.firstChild;)t.removeChild(t.firstChild);for(;e.firstChild;)t.appendChild(e.firstChild)}});function Is(t,e){if(e){var n=t.firstChild;if(n&&n===t.lastChild&&n.nodeType===3){n.nodeValue=e;return}}t.textContent=e}var bs={animationIterationCount:!0,aspectRatio:!0,borderImageOutset:!0,borderImageSlice:!0,borderImageWidth:!0,boxFlex:!0,boxFlexGroup:!0,boxOrdinalGroup:!0,columnCount:!0,columns:!0,flex:!0,flexGrow:!0,flexPositive:!0,flexShrink:!0,flexNegative:!0,flexOrder:!0,gridArea:!0,gridRow:!0,gridRowEnd:!0,gridRowSpan:!0,gridRowStart:!0,gridColumn:!0,gridColumnEnd:!0,gridColumnSpan:!0,gridColumnStart:!0,fontWeight:!0,lineClamp:!0,lineHeight:!0,opacity:!0,order:!0,orphans:!0,tabSize:!0,widows:!0,zIndex:!0,zoom:!0,fillOpacity:!0,floodOpacity:!0,stopOpacity:!0,strokeDasharray:!0,strokeDashoffset:!0,strokeMiterlimit:!0,strokeOpacity:!0,strokeWidth:!0},wv=["Webkit","ms","Moz","O"];Object.keys(bs).forEach(function(t){wv.forEach(function(e){e=e+t.charAt(0).toUpperCase()+t.substring(1),bs[e]=bs[t]})});function zg(t,e,n){return e==null||typeof e=="boolean"||e===""?"":n||typeof e!="number"||e===0||bs.hasOwnProperty(t)&&bs[t]?(""+e).trim():e+"px"}function Vg(t,e){t=t.style;for(var n in e)if(e.hasOwnProperty(n)){var i=n.indexOf("--")===0,r=zg(n,e[n],i);n==="float"&&(n="cssFloat"),i?t.setProperty(n,r):t[n]=r}}var Tv=_t({menuitem:!0},{area:!0,base:!0,br:!0,col:!0,embed:!0,hr:!0,img:!0,input:!0,keygen:!0,link:!0,meta:!0,param:!0,source:!0,track:!0,wbr:!0});function Xu(t,e){if(e){if(Tv[t]&&(e.children!=null||e.dangerouslySetInnerHTML!=null))throw Error(se(137,t));if(e.dangerouslySetInnerHTML!=null){if(e.children!=null)throw Error(se(60));if(typeof e.dangerouslySetInnerHTML!="object"||!("__html"in e.dangerouslySetInnerHTML))throw Error(se(61))}if(e.style!=null&&typeof e.style!="object")throw Error(se(62))}}function $u(t,e){if(t.indexOf("-")===-1)return typeof e.is=="string";switch(t){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var qu=null;function Nf(t){return t=t.target||t.srcElement||window,t.correspondingUseElement&&(t=t.correspondingUseElement),t.nodeType===3?t.parentNode:t}var Yu=null,Na=null,La=null;function sp(t){if(t=no(t)){if(typeof Yu!="function")throw Error(se(280));var e=t.stateNode;e&&(e=oc(e),Yu(t.stateNode,t.type,e))}}function Hg(t){Na?La?La.push(t):La=[t]:Na=t}function Gg(){if(Na){var t=Na,e=La;if(La=Na=null,sp(t),e)for(t=0;t<e.length;t++)sp(e[t])}}function Wg(t,e){return t(e)}function jg(){}var Lc=!1;function Xg(t,e,n){if(Lc)return t(e,n);Lc=!0;try{return Wg(t,e,n)}finally{Lc=!1,(Na!==null||La!==null)&&(jg(),Gg())}}function Us(t,e){var n=t.stateNode;if(n===null)return null;var i=oc(n);if(i===null)return null;n=i[e];e:switch(e){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(i=!i.disabled)||(t=t.type,i=!(t==="button"||t==="input"||t==="select"||t==="textarea")),t=!i;break e;default:t=!1}if(t)return null;if(n&&typeof n!="function")throw Error(se(231,e,typeof n));return n}var Ku=!1;if(Ui)try{var is={};Object.defineProperty(is,"passive",{get:function(){Ku=!0}}),window.addEventListener("test",is,is),window.removeEventListener("test",is,is)}catch{Ku=!1}function Av(t,e,n,i,r,a,s,o,l){var c=Array.prototype.slice.call(arguments,3);try{e.apply(n,c)}catch(f){this.onError(f)}}var ws=!1,El=null,bl=!1,Zu=null,Cv={onError:function(t){ws=!0,El=t}};function Rv(t,e,n,i,r,a,s,o,l){ws=!1,El=null,Av.apply(Cv,arguments)}function Pv(t,e,n,i,r,a,s,o,l){if(Rv.apply(this,arguments),ws){if(ws){var c=El;ws=!1,El=null}else throw Error(se(198));bl||(bl=!0,Zu=c)}}function Qr(t){var e=t,n=t;if(t.alternate)for(;e.return;)e=e.return;else{t=e;do e=t,e.flags&4098&&(n=e.return),t=e.return;while(t)}return e.tag===3?n:null}function $g(t){if(t.tag===13){var e=t.memoizedState;if(e===null&&(t=t.alternate,t!==null&&(e=t.memoizedState)),e!==null)return e.dehydrated}return null}function op(t){if(Qr(t)!==t)throw Error(se(188))}function Nv(t){var e=t.alternate;if(!e){if(e=Qr(t),e===null)throw Error(se(188));return e!==t?null:t}for(var n=t,i=e;;){var r=n.return;if(r===null)break;var a=r.alternate;if(a===null){if(i=r.return,i!==null){n=i;continue}break}if(r.child===a.child){for(a=r.child;a;){if(a===n)return op(r),t;if(a===i)return op(r),e;a=a.sibling}throw Error(se(188))}if(n.return!==i.return)n=r,i=a;else{for(var s=!1,o=r.child;o;){if(o===n){s=!0,n=r,i=a;break}if(o===i){s=!0,i=r,n=a;break}o=o.sibling}if(!s){for(o=a.child;o;){if(o===n){s=!0,n=a,i=r;break}if(o===i){s=!0,i=a,n=r;break}o=o.sibling}if(!s)throw Error(se(189))}}if(n.alternate!==i)throw Error(se(190))}if(n.tag!==3)throw Error(se(188));return n.stateNode.current===n?t:e}function qg(t){return t=Nv(t),t!==null?Yg(t):null}function Yg(t){if(t.tag===5||t.tag===6)return t;for(t=t.child;t!==null;){var e=Yg(t);if(e!==null)return e;t=t.sibling}return null}var Kg=En.unstable_scheduleCallback,lp=En.unstable_cancelCallback,Lv=En.unstable_shouldYield,Dv=En.unstable_requestPaint,Tt=En.unstable_now,Iv=En.unstable_getCurrentPriorityLevel,Lf=En.unstable_ImmediatePriority,Zg=En.unstable_UserBlockingPriority,wl=En.unstable_NormalPriority,Uv=En.unstable_LowPriority,Qg=En.unstable_IdlePriority,ic=null,di=null;function Fv(t){if(di&&typeof di.onCommitFiberRoot=="function")try{di.onCommitFiberRoot(ic,t,void 0,(t.current.flags&128)===128)}catch{}}var $n=Math.clz32?Math.clz32:Bv,Ov=Math.log,kv=Math.LN2;function Bv(t){return t>>>=0,t===0?32:31-(Ov(t)/kv|0)|0}var xo=64,vo=4194304;function ys(t){switch(t&-t){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return t&4194240;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return t&130023424;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 1073741824;default:return t}}function Tl(t,e){var n=t.pendingLanes;if(n===0)return 0;var i=0,r=t.suspendedLanes,a=t.pingedLanes,s=n&268435455;if(s!==0){var o=s&~r;o!==0?i=ys(o):(a&=s,a!==0&&(i=ys(a)))}else s=n&~r,s!==0?i=ys(s):a!==0&&(i=ys(a));if(i===0)return 0;if(e!==0&&e!==i&&!(e&r)&&(r=i&-i,a=e&-e,r>=a||r===16&&(a&4194240)!==0))return e;if(i&4&&(i|=n&16),e=t.entangledLanes,e!==0)for(t=t.entanglements,e&=i;0<e;)n=31-$n(e),r=1<<n,i|=t[n],e&=~r;return i}function zv(t,e){switch(t){case 1:case 2:case 4:return e+250;case 8:case 16:case 32:case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return e+5e3;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return-1;case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function Vv(t,e){for(var n=t.suspendedLanes,i=t.pingedLanes,r=t.expirationTimes,a=t.pendingLanes;0<a;){var s=31-$n(a),o=1<<s,l=r[s];l===-1?(!(o&n)||o&i)&&(r[s]=zv(o,e)):l<=e&&(t.expiredLanes|=o),a&=~o}}function Qu(t){return t=t.pendingLanes&-1073741825,t!==0?t:t&1073741824?1073741824:0}function Jg(){var t=xo;return xo<<=1,!(xo&4194240)&&(xo=64),t}function Dc(t){for(var e=[],n=0;31>n;n++)e.push(t);return e}function eo(t,e,n){t.pendingLanes|=e,e!==536870912&&(t.suspendedLanes=0,t.pingedLanes=0),t=t.eventTimes,e=31-$n(e),t[e]=n}function Hv(t,e){var n=t.pendingLanes&~e;t.pendingLanes=e,t.suspendedLanes=0,t.pingedLanes=0,t.expiredLanes&=e,t.mutableReadLanes&=e,t.entangledLanes&=e,e=t.entanglements;var i=t.eventTimes;for(t=t.expirationTimes;0<n;){var r=31-$n(n),a=1<<r;e[r]=0,i[r]=-1,t[r]=-1,n&=~a}}function Df(t,e){var n=t.entangledLanes|=e;for(t=t.entanglements;n;){var i=31-$n(n),r=1<<i;r&e|t[i]&e&&(t[i]|=e),n&=~r}}var nt=0;function e0(t){return t&=-t,1<t?4<t?t&268435455?16:536870912:4:1}var t0,If,n0,i0,r0,Ju=!1,yo=[],ur=null,dr=null,fr=null,Fs=new Map,Os=new Map,ir=[],Gv="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");function cp(t,e){switch(t){case"focusin":case"focusout":ur=null;break;case"dragenter":case"dragleave":dr=null;break;case"mouseover":case"mouseout":fr=null;break;case"pointerover":case"pointerout":Fs.delete(e.pointerId);break;case"gotpointercapture":case"lostpointercapture":Os.delete(e.pointerId)}}function rs(t,e,n,i,r,a){return t===null||t.nativeEvent!==a?(t={blockedOn:e,domEventName:n,eventSystemFlags:i,nativeEvent:a,targetContainers:[r]},e!==null&&(e=no(e),e!==null&&If(e)),t):(t.eventSystemFlags|=i,e=t.targetContainers,r!==null&&e.indexOf(r)===-1&&e.push(r),t)}function Wv(t,e,n,i,r){switch(e){case"focusin":return ur=rs(ur,t,e,n,i,r),!0;case"dragenter":return dr=rs(dr,t,e,n,i,r),!0;case"mouseover":return fr=rs(fr,t,e,n,i,r),!0;case"pointerover":var a=r.pointerId;return Fs.set(a,rs(Fs.get(a)||null,t,e,n,i,r)),!0;case"gotpointercapture":return a=r.pointerId,Os.set(a,rs(Os.get(a)||null,t,e,n,i,r)),!0}return!1}function a0(t){var e=Fr(t.target);if(e!==null){var n=Qr(e);if(n!==null){if(e=n.tag,e===13){if(e=$g(n),e!==null){t.blockedOn=e,r0(t.priority,function(){n0(n)});return}}else if(e===3&&n.stateNode.current.memoizedState.isDehydrated){t.blockedOn=n.tag===3?n.stateNode.containerInfo:null;return}}}t.blockedOn=null}function rl(t){if(t.blockedOn!==null)return!1;for(var e=t.targetContainers;0<e.length;){var n=ed(t.domEventName,t.eventSystemFlags,e[0],t.nativeEvent);if(n===null){n=t.nativeEvent;var i=new n.constructor(n.type,n);qu=i,n.target.dispatchEvent(i),qu=null}else return e=no(n),e!==null&&If(e),t.blockedOn=n,!1;e.shift()}return!0}function up(t,e,n){rl(t)&&n.delete(e)}function jv(){Ju=!1,ur!==null&&rl(ur)&&(ur=null),dr!==null&&rl(dr)&&(dr=null),fr!==null&&rl(fr)&&(fr=null),Fs.forEach(up),Os.forEach(up)}function as(t,e){t.blockedOn===e&&(t.blockedOn=null,Ju||(Ju=!0,En.unstable_scheduleCallback(En.unstable_NormalPriority,jv)))}function ks(t){function e(r){return as(r,t)}if(0<yo.length){as(yo[0],t);for(var n=1;n<yo.length;n++){var i=yo[n];i.blockedOn===t&&(i.blockedOn=null)}}for(ur!==null&&as(ur,t),dr!==null&&as(dr,t),fr!==null&&as(fr,t),Fs.forEach(e),Os.forEach(e),n=0;n<ir.length;n++)i=ir[n],i.blockedOn===t&&(i.blockedOn=null);for(;0<ir.length&&(n=ir[0],n.blockedOn===null);)a0(n),n.blockedOn===null&&ir.shift()}var Da=Hi.ReactCurrentBatchConfig,Al=!0;function Xv(t,e,n,i){var r=nt,a=Da.transition;Da.transition=null;try{nt=1,Uf(t,e,n,i)}finally{nt=r,Da.transition=a}}function $v(t,e,n,i){var r=nt,a=Da.transition;Da.transition=null;try{nt=4,Uf(t,e,n,i)}finally{nt=r,Da.transition=a}}function Uf(t,e,n,i){if(Al){var r=ed(t,e,n,i);if(r===null)Gc(t,e,i,Cl,n),cp(t,i);else if(Wv(r,t,e,n,i))i.stopPropagation();else if(cp(t,i),e&4&&-1<Gv.indexOf(t)){for(;r!==null;){var a=no(r);if(a!==null&&t0(a),a=ed(t,e,n,i),a===null&&Gc(t,e,i,Cl,n),a===r)break;r=a}r!==null&&i.stopPropagation()}else Gc(t,e,i,null,n)}}var Cl=null;function ed(t,e,n,i){if(Cl=null,t=Nf(i),t=Fr(t),t!==null)if(e=Qr(t),e===null)t=null;else if(n=e.tag,n===13){if(t=$g(e),t!==null)return t;t=null}else if(n===3){if(e.stateNode.current.memoizedState.isDehydrated)return e.tag===3?e.stateNode.containerInfo:null;t=null}else e!==t&&(t=null);return Cl=t,null}function s0(t){switch(t){case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 1;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"toggle":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 4;case"message":switch(Iv()){case Lf:return 1;case Zg:return 4;case wl:case Uv:return 16;case Qg:return 536870912;default:return 16}default:return 16}}var or=null,Ff=null,al=null;function o0(){if(al)return al;var t,e=Ff,n=e.length,i,r="value"in or?or.value:or.textContent,a=r.length;for(t=0;t<n&&e[t]===r[t];t++);var s=n-t;for(i=1;i<=s&&e[n-i]===r[a-i];i++);return al=r.slice(t,1<i?1-i:void 0)}function sl(t){var e=t.keyCode;return"charCode"in t?(t=t.charCode,t===0&&e===13&&(t=13)):t=e,t===10&&(t=13),32<=t||t===13?t:0}function So(){return!0}function dp(){return!1}function wn(t){function e(n,i,r,a,s){this._reactName=n,this._targetInst=r,this.type=i,this.nativeEvent=a,this.target=s,this.currentTarget=null;for(var o in t)t.hasOwnProperty(o)&&(n=t[o],this[o]=n?n(a):a[o]);return this.isDefaultPrevented=(a.defaultPrevented!=null?a.defaultPrevented:a.returnValue===!1)?So:dp,this.isPropagationStopped=dp,this}return _t(e.prototype,{preventDefault:function(){this.defaultPrevented=!0;var n=this.nativeEvent;n&&(n.preventDefault?n.preventDefault():typeof n.returnValue!="unknown"&&(n.returnValue=!1),this.isDefaultPrevented=So)},stopPropagation:function(){var n=this.nativeEvent;n&&(n.stopPropagation?n.stopPropagation():typeof n.cancelBubble!="unknown"&&(n.cancelBubble=!0),this.isPropagationStopped=So)},persist:function(){},isPersistent:So}),e}var Za={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(t){return t.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},Of=wn(Za),to=_t({},Za,{view:0,detail:0}),qv=wn(to),Ic,Uc,ss,rc=_t({},to,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:kf,button:0,buttons:0,relatedTarget:function(t){return t.relatedTarget===void 0?t.fromElement===t.srcElement?t.toElement:t.fromElement:t.relatedTarget},movementX:function(t){return"movementX"in t?t.movementX:(t!==ss&&(ss&&t.type==="mousemove"?(Ic=t.screenX-ss.screenX,Uc=t.screenY-ss.screenY):Uc=Ic=0,ss=t),Ic)},movementY:function(t){return"movementY"in t?t.movementY:Uc}}),fp=wn(rc),Yv=_t({},rc,{dataTransfer:0}),Kv=wn(Yv),Zv=_t({},to,{relatedTarget:0}),Fc=wn(Zv),Qv=_t({},Za,{animationName:0,elapsedTime:0,pseudoElement:0}),Jv=wn(Qv),ey=_t({},Za,{clipboardData:function(t){return"clipboardData"in t?t.clipboardData:window.clipboardData}}),ty=wn(ey),ny=_t({},Za,{data:0}),hp=wn(ny),iy={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},ry={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},ay={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function sy(t){var e=this.nativeEvent;return e.getModifierState?e.getModifierState(t):(t=ay[t])?!!e[t]:!1}function kf(){return sy}var oy=_t({},to,{key:function(t){if(t.key){var e=iy[t.key]||t.key;if(e!=="Unidentified")return e}return t.type==="keypress"?(t=sl(t),t===13?"Enter":String.fromCharCode(t)):t.type==="keydown"||t.type==="keyup"?ry[t.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:kf,charCode:function(t){return t.type==="keypress"?sl(t):0},keyCode:function(t){return t.type==="keydown"||t.type==="keyup"?t.keyCode:0},which:function(t){return t.type==="keypress"?sl(t):t.type==="keydown"||t.type==="keyup"?t.keyCode:0}}),ly=wn(oy),cy=_t({},rc,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),pp=wn(cy),uy=_t({},to,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:kf}),dy=wn(uy),fy=_t({},Za,{propertyName:0,elapsedTime:0,pseudoElement:0}),hy=wn(fy),py=_t({},rc,{deltaX:function(t){return"deltaX"in t?t.deltaX:"wheelDeltaX"in t?-t.wheelDeltaX:0},deltaY:function(t){return"deltaY"in t?t.deltaY:"wheelDeltaY"in t?-t.wheelDeltaY:"wheelDelta"in t?-t.wheelDelta:0},deltaZ:0,deltaMode:0}),my=wn(py),gy=[9,13,27,32],Bf=Ui&&"CompositionEvent"in window,Ts=null;Ui&&"documentMode"in document&&(Ts=document.documentMode);var _y=Ui&&"TextEvent"in window&&!Ts,l0=Ui&&(!Bf||Ts&&8<Ts&&11>=Ts),mp=" ",gp=!1;function c0(t,e){switch(t){case"keyup":return gy.indexOf(e.keyCode)!==-1;case"keydown":return e.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function u0(t){return t=t.detail,typeof t=="object"&&"data"in t?t.data:null}var ya=!1;function xy(t,e){switch(t){case"compositionend":return u0(e);case"keypress":return e.which!==32?null:(gp=!0,mp);case"textInput":return t=e.data,t===mp&&gp?null:t;default:return null}}function vy(t,e){if(ya)return t==="compositionend"||!Bf&&c0(t,e)?(t=o0(),al=Ff=or=null,ya=!1,t):null;switch(t){case"paste":return null;case"keypress":if(!(e.ctrlKey||e.altKey||e.metaKey)||e.ctrlKey&&e.altKey){if(e.char&&1<e.char.length)return e.char;if(e.which)return String.fromCharCode(e.which)}return null;case"compositionend":return l0&&e.locale!=="ko"?null:e.data;default:return null}}var yy={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function _p(t){var e=t&&t.nodeName&&t.nodeName.toLowerCase();return e==="input"?!!yy[t.type]:e==="textarea"}function d0(t,e,n,i){Hg(i),e=Rl(e,"onChange"),0<e.length&&(n=new Of("onChange","change",null,n,i),t.push({event:n,listeners:e}))}var As=null,Bs=null;function Sy(t){M0(t,0)}function ac(t){var e=Ea(t);if(Ug(e))return t}function My(t,e){if(t==="change")return e}var f0=!1;if(Ui){var Oc;if(Ui){var kc="oninput"in document;if(!kc){var xp=document.createElement("div");xp.setAttribute("oninput","return;"),kc=typeof xp.oninput=="function"}Oc=kc}else Oc=!1;f0=Oc&&(!document.documentMode||9<document.documentMode)}function vp(){As&&(As.detachEvent("onpropertychange",h0),Bs=As=null)}function h0(t){if(t.propertyName==="value"&&ac(Bs)){var e=[];d0(e,Bs,t,Nf(t)),Xg(Sy,e)}}function Ey(t,e,n){t==="focusin"?(vp(),As=e,Bs=n,As.attachEvent("onpropertychange",h0)):t==="focusout"&&vp()}function by(t){if(t==="selectionchange"||t==="keyup"||t==="keydown")return ac(Bs)}function wy(t,e){if(t==="click")return ac(e)}function Ty(t,e){if(t==="input"||t==="change")return ac(e)}function Ay(t,e){return t===e&&(t!==0||1/t===1/e)||t!==t&&e!==e}var Kn=typeof Object.is=="function"?Object.is:Ay;function zs(t,e){if(Kn(t,e))return!0;if(typeof t!="object"||t===null||typeof e!="object"||e===null)return!1;var n=Object.keys(t),i=Object.keys(e);if(n.length!==i.length)return!1;for(i=0;i<n.length;i++){var r=n[i];if(!Fu.call(e,r)||!Kn(t[r],e[r]))return!1}return!0}function yp(t){for(;t&&t.firstChild;)t=t.firstChild;return t}function Sp(t,e){var n=yp(t);t=0;for(var i;n;){if(n.nodeType===3){if(i=t+n.textContent.length,t<=e&&i>=e)return{node:n,offset:e-t};t=i}e:{for(;n;){if(n.nextSibling){n=n.nextSibling;break e}n=n.parentNode}n=void 0}n=yp(n)}}function p0(t,e){return t&&e?t===e?!0:t&&t.nodeType===3?!1:e&&e.nodeType===3?p0(t,e.parentNode):"contains"in t?t.contains(e):t.compareDocumentPosition?!!(t.compareDocumentPosition(e)&16):!1:!1}function m0(){for(var t=window,e=Ml();e instanceof t.HTMLIFrameElement;){try{var n=typeof e.contentWindow.location.href=="string"}catch{n=!1}if(n)t=e.contentWindow;else break;e=Ml(t.document)}return e}function zf(t){var e=t&&t.nodeName&&t.nodeName.toLowerCase();return e&&(e==="input"&&(t.type==="text"||t.type==="search"||t.type==="tel"||t.type==="url"||t.type==="password")||e==="textarea"||t.contentEditable==="true")}function Cy(t){var e=m0(),n=t.focusedElem,i=t.selectionRange;if(e!==n&&n&&n.ownerDocument&&p0(n.ownerDocument.documentElement,n)){if(i!==null&&zf(n)){if(e=i.start,t=i.end,t===void 0&&(t=e),"selectionStart"in n)n.selectionStart=e,n.selectionEnd=Math.min(t,n.value.length);else if(t=(e=n.ownerDocument||document)&&e.defaultView||window,t.getSelection){t=t.getSelection();var r=n.textContent.length,a=Math.min(i.start,r);i=i.end===void 0?a:Math.min(i.end,r),!t.extend&&a>i&&(r=i,i=a,a=r),r=Sp(n,a);var s=Sp(n,i);r&&s&&(t.rangeCount!==1||t.anchorNode!==r.node||t.anchorOffset!==r.offset||t.focusNode!==s.node||t.focusOffset!==s.offset)&&(e=e.createRange(),e.setStart(r.node,r.offset),t.removeAllRanges(),a>i?(t.addRange(e),t.extend(s.node,s.offset)):(e.setEnd(s.node,s.offset),t.addRange(e)))}}for(e=[],t=n;t=t.parentNode;)t.nodeType===1&&e.push({element:t,left:t.scrollLeft,top:t.scrollTop});for(typeof n.focus=="function"&&n.focus(),n=0;n<e.length;n++)t=e[n],t.element.scrollLeft=t.left,t.element.scrollTop=t.top}}var Ry=Ui&&"documentMode"in document&&11>=document.documentMode,Sa=null,td=null,Cs=null,nd=!1;function Mp(t,e,n){var i=n.window===n?n.document:n.nodeType===9?n:n.ownerDocument;nd||Sa==null||Sa!==Ml(i)||(i=Sa,"selectionStart"in i&&zf(i)?i={start:i.selectionStart,end:i.selectionEnd}:(i=(i.ownerDocument&&i.ownerDocument.defaultView||window).getSelection(),i={anchorNode:i.anchorNode,anchorOffset:i.anchorOffset,focusNode:i.focusNode,focusOffset:i.focusOffset}),Cs&&zs(Cs,i)||(Cs=i,i=Rl(td,"onSelect"),0<i.length&&(e=new Of("onSelect","select",null,e,n),t.push({event:e,listeners:i}),e.target=Sa)))}function Mo(t,e){var n={};return n[t.toLowerCase()]=e.toLowerCase(),n["Webkit"+t]="webkit"+e,n["Moz"+t]="moz"+e,n}var Ma={animationend:Mo("Animation","AnimationEnd"),animationiteration:Mo("Animation","AnimationIteration"),animationstart:Mo("Animation","AnimationStart"),transitionend:Mo("Transition","TransitionEnd")},Bc={},g0={};Ui&&(g0=document.createElement("div").style,"AnimationEvent"in window||(delete Ma.animationend.animation,delete Ma.animationiteration.animation,delete Ma.animationstart.animation),"TransitionEvent"in window||delete Ma.transitionend.transition);function sc(t){if(Bc[t])return Bc[t];if(!Ma[t])return t;var e=Ma[t],n;for(n in e)if(e.hasOwnProperty(n)&&n in g0)return Bc[t]=e[n];return t}var _0=sc("animationend"),x0=sc("animationiteration"),v0=sc("animationstart"),y0=sc("transitionend"),S0=new Map,Ep="abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");function Sr(t,e){S0.set(t,e),Zr(e,[t])}for(var zc=0;zc<Ep.length;zc++){var Vc=Ep[zc],Py=Vc.toLowerCase(),Ny=Vc[0].toUpperCase()+Vc.slice(1);Sr(Py,"on"+Ny)}Sr(_0,"onAnimationEnd");Sr(x0,"onAnimationIteration");Sr(v0,"onAnimationStart");Sr("dblclick","onDoubleClick");Sr("focusin","onFocus");Sr("focusout","onBlur");Sr(y0,"onTransitionEnd");Ba("onMouseEnter",["mouseout","mouseover"]);Ba("onMouseLeave",["mouseout","mouseover"]);Ba("onPointerEnter",["pointerout","pointerover"]);Ba("onPointerLeave",["pointerout","pointerover"]);Zr("onChange","change click focusin focusout input keydown keyup selectionchange".split(" "));Zr("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));Zr("onBeforeInput",["compositionend","keypress","textInput","paste"]);Zr("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" "));Zr("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" "));Zr("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var Ss="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),Ly=new Set("cancel close invalid load scroll toggle".split(" ").concat(Ss));function bp(t,e,n){var i=t.type||"unknown-event";t.currentTarget=n,Pv(i,e,void 0,t),t.currentTarget=null}function M0(t,e){e=(e&4)!==0;for(var n=0;n<t.length;n++){var i=t[n],r=i.event;i=i.listeners;e:{var a=void 0;if(e)for(var s=i.length-1;0<=s;s--){var o=i[s],l=o.instance,c=o.currentTarget;if(o=o.listener,l!==a&&r.isPropagationStopped())break e;bp(r,o,c),a=l}else for(s=0;s<i.length;s++){if(o=i[s],l=o.instance,c=o.currentTarget,o=o.listener,l!==a&&r.isPropagationStopped())break e;bp(r,o,c),a=l}}}if(bl)throw t=Zu,bl=!1,Zu=null,t}function ut(t,e){var n=e[od];n===void 0&&(n=e[od]=new Set);var i=t+"__bubble";n.has(i)||(E0(e,t,2,!1),n.add(i))}function Hc(t,e,n){var i=0;e&&(i|=4),E0(n,t,i,e)}var Eo="_reactListening"+Math.random().toString(36).slice(2);function Vs(t){if(!t[Eo]){t[Eo]=!0,Pg.forEach(function(n){n!=="selectionchange"&&(Ly.has(n)||Hc(n,!1,t),Hc(n,!0,t))});var e=t.nodeType===9?t:t.ownerDocument;e===null||e[Eo]||(e[Eo]=!0,Hc("selectionchange",!1,e))}}function E0(t,e,n,i){switch(s0(e)){case 1:var r=Xv;break;case 4:r=$v;break;default:r=Uf}n=r.bind(null,e,n,t),r=void 0,!Ku||e!=="touchstart"&&e!=="touchmove"&&e!=="wheel"||(r=!0),i?r!==void 0?t.addEventListener(e,n,{capture:!0,passive:r}):t.addEventListener(e,n,!0):r!==void 0?t.addEventListener(e,n,{passive:r}):t.addEventListener(e,n,!1)}function Gc(t,e,n,i,r){var a=i;if(!(e&1)&&!(e&2)&&i!==null)e:for(;;){if(i===null)return;var s=i.tag;if(s===3||s===4){var o=i.stateNode.containerInfo;if(o===r||o.nodeType===8&&o.parentNode===r)break;if(s===4)for(s=i.return;s!==null;){var l=s.tag;if((l===3||l===4)&&(l=s.stateNode.containerInfo,l===r||l.nodeType===8&&l.parentNode===r))return;s=s.return}for(;o!==null;){if(s=Fr(o),s===null)return;if(l=s.tag,l===5||l===6){i=a=s;continue e}o=o.parentNode}}i=i.return}Xg(function(){var c=a,f=Nf(n),h=[];e:{var u=S0.get(t);if(u!==void 0){var m=Of,x=t;switch(t){case"keypress":if(sl(n)===0)break e;case"keydown":case"keyup":m=ly;break;case"focusin":x="focus",m=Fc;break;case"focusout":x="blur",m=Fc;break;case"beforeblur":case"afterblur":m=Fc;break;case"click":if(n.button===2)break e;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":m=fp;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":m=Kv;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":m=dy;break;case _0:case x0:case v0:m=Jv;break;case y0:m=hy;break;case"scroll":m=qv;break;case"wheel":m=my;break;case"copy":case"cut":case"paste":m=ty;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":m=pp}var E=(e&4)!==0,g=!E&&t==="scroll",d=E?u!==null?u+"Capture":null:u;E=[];for(var v=c,S;v!==null;){S=v;var M=S.stateNode;if(S.tag===5&&M!==null&&(S=M,d!==null&&(M=Us(v,d),M!=null&&E.push(Hs(v,M,S)))),g)break;v=v.return}0<E.length&&(u=new m(u,x,null,n,f),h.push({event:u,listeners:E}))}}if(!(e&7)){e:{if(u=t==="mouseover"||t==="pointerover",m=t==="mouseout"||t==="pointerout",u&&n!==qu&&(x=n.relatedTarget||n.fromElement)&&(Fr(x)||x[Fi]))break e;if((m||u)&&(u=f.window===f?f:(u=f.ownerDocument)?u.defaultView||u.parentWindow:window,m?(x=n.relatedTarget||n.toElement,m=c,x=x?Fr(x):null,x!==null&&(g=Qr(x),x!==g||x.tag!==5&&x.tag!==6)&&(x=null)):(m=null,x=c),m!==x)){if(E=fp,M="onMouseLeave",d="onMouseEnter",v="mouse",(t==="pointerout"||t==="pointerover")&&(E=pp,M="onPointerLeave",d="onPointerEnter",v="pointer"),g=m==null?u:Ea(m),S=x==null?u:Ea(x),u=new E(M,v+"leave",m,n,f),u.target=g,u.relatedTarget=S,M=null,Fr(f)===c&&(E=new E(d,v+"enter",x,n,f),E.target=S,E.relatedTarget=g,M=E),g=M,m&&x)t:{for(E=m,d=x,v=0,S=E;S;S=ia(S))v++;for(S=0,M=d;M;M=ia(M))S++;for(;0<v-S;)E=ia(E),v--;for(;0<S-v;)d=ia(d),S--;for(;v--;){if(E===d||d!==null&&E===d.alternate)break t;E=ia(E),d=ia(d)}E=null}else E=null;m!==null&&wp(h,u,m,E,!1),x!==null&&g!==null&&wp(h,g,x,E,!0)}}e:{if(u=c?Ea(c):window,m=u.nodeName&&u.nodeName.toLowerCase(),m==="select"||m==="input"&&u.type==="file")var A=My;else if(_p(u))if(f0)A=Ty;else{A=by;var T=Ey}else(m=u.nodeName)&&m.toLowerCase()==="input"&&(u.type==="checkbox"||u.type==="radio")&&(A=wy);if(A&&(A=A(t,c))){d0(h,A,n,f);break e}T&&T(t,u,c),t==="focusout"&&(T=u._wrapperState)&&T.controlled&&u.type==="number"&&Gu(u,"number",u.value)}switch(T=c?Ea(c):window,t){case"focusin":(_p(T)||T.contentEditable==="true")&&(Sa=T,td=c,Cs=null);break;case"focusout":Cs=td=Sa=null;break;case"mousedown":nd=!0;break;case"contextmenu":case"mouseup":case"dragend":nd=!1,Mp(h,n,f);break;case"selectionchange":if(Ry)break;case"keydown":case"keyup":Mp(h,n,f)}var w;if(Bf)e:{switch(t){case"compositionstart":var _="onCompositionStart";break e;case"compositionend":_="onCompositionEnd";break e;case"compositionupdate":_="onCompositionUpdate";break e}_=void 0}else ya?c0(t,n)&&(_="onCompositionEnd"):t==="keydown"&&n.keyCode===229&&(_="onCompositionStart");_&&(l0&&n.locale!=="ko"&&(ya||_!=="onCompositionStart"?_==="onCompositionEnd"&&ya&&(w=o0()):(or=f,Ff="value"in or?or.value:or.textContent,ya=!0)),T=Rl(c,_),0<T.length&&(_=new hp(_,t,null,n,f),h.push({event:_,listeners:T}),w?_.data=w:(w=u0(n),w!==null&&(_.data=w)))),(w=_y?xy(t,n):vy(t,n))&&(c=Rl(c,"onBeforeInput"),0<c.length&&(f=new hp("onBeforeInput","beforeinput",null,n,f),h.push({event:f,listeners:c}),f.data=w))}M0(h,e)})}function Hs(t,e,n){return{instance:t,listener:e,currentTarget:n}}function Rl(t,e){for(var n=e+"Capture",i=[];t!==null;){var r=t,a=r.stateNode;r.tag===5&&a!==null&&(r=a,a=Us(t,n),a!=null&&i.unshift(Hs(t,a,r)),a=Us(t,e),a!=null&&i.push(Hs(t,a,r))),t=t.return}return i}function ia(t){if(t===null)return null;do t=t.return;while(t&&t.tag!==5);return t||null}function wp(t,e,n,i,r){for(var a=e._reactName,s=[];n!==null&&n!==i;){var o=n,l=o.alternate,c=o.stateNode;if(l!==null&&l===i)break;o.tag===5&&c!==null&&(o=c,r?(l=Us(n,a),l!=null&&s.unshift(Hs(n,l,o))):r||(l=Us(n,a),l!=null&&s.push(Hs(n,l,o)))),n=n.return}s.length!==0&&t.push({event:e,listeners:s})}var Dy=/\r\n?/g,Iy=/\u0000|\uFFFD/g;function Tp(t){return(typeof t=="string"?t:""+t).replace(Dy,`
`).replace(Iy,"")}function bo(t,e,n){if(e=Tp(e),Tp(t)!==e&&n)throw Error(se(425))}function Pl(){}var id=null,rd=null;function ad(t,e){return t==="textarea"||t==="noscript"||typeof e.children=="string"||typeof e.children=="number"||typeof e.dangerouslySetInnerHTML=="object"&&e.dangerouslySetInnerHTML!==null&&e.dangerouslySetInnerHTML.__html!=null}var sd=typeof setTimeout=="function"?setTimeout:void 0,Uy=typeof clearTimeout=="function"?clearTimeout:void 0,Ap=typeof Promise=="function"?Promise:void 0,Fy=typeof queueMicrotask=="function"?queueMicrotask:typeof Ap<"u"?function(t){return Ap.resolve(null).then(t).catch(Oy)}:sd;function Oy(t){setTimeout(function(){throw t})}function Wc(t,e){var n=e,i=0;do{var r=n.nextSibling;if(t.removeChild(n),r&&r.nodeType===8)if(n=r.data,n==="/$"){if(i===0){t.removeChild(r),ks(e);return}i--}else n!=="$"&&n!=="$?"&&n!=="$!"||i++;n=r}while(n);ks(e)}function hr(t){for(;t!=null;t=t.nextSibling){var e=t.nodeType;if(e===1||e===3)break;if(e===8){if(e=t.data,e==="$"||e==="$!"||e==="$?")break;if(e==="/$")return null}}return t}function Cp(t){t=t.previousSibling;for(var e=0;t;){if(t.nodeType===8){var n=t.data;if(n==="$"||n==="$!"||n==="$?"){if(e===0)return t;e--}else n==="/$"&&e++}t=t.previousSibling}return null}var Qa=Math.random().toString(36).slice(2),oi="__reactFiber$"+Qa,Gs="__reactProps$"+Qa,Fi="__reactContainer$"+Qa,od="__reactEvents$"+Qa,ky="__reactListeners$"+Qa,By="__reactHandles$"+Qa;function Fr(t){var e=t[oi];if(e)return e;for(var n=t.parentNode;n;){if(e=n[Fi]||n[oi]){if(n=e.alternate,e.child!==null||n!==null&&n.child!==null)for(t=Cp(t);t!==null;){if(n=t[oi])return n;t=Cp(t)}return e}t=n,n=t.parentNode}return null}function no(t){return t=t[oi]||t[Fi],!t||t.tag!==5&&t.tag!==6&&t.tag!==13&&t.tag!==3?null:t}function Ea(t){if(t.tag===5||t.tag===6)return t.stateNode;throw Error(se(33))}function oc(t){return t[Gs]||null}var ld=[],ba=-1;function Mr(t){return{current:t}}function dt(t){0>ba||(t.current=ld[ba],ld[ba]=null,ba--)}function ct(t,e){ba++,ld[ba]=t.current,t.current=e}var vr={},en=Mr(vr),fn=Mr(!1),Gr=vr;function za(t,e){var n=t.type.contextTypes;if(!n)return vr;var i=t.stateNode;if(i&&i.__reactInternalMemoizedUnmaskedChildContext===e)return i.__reactInternalMemoizedMaskedChildContext;var r={},a;for(a in n)r[a]=e[a];return i&&(t=t.stateNode,t.__reactInternalMemoizedUnmaskedChildContext=e,t.__reactInternalMemoizedMaskedChildContext=r),r}function hn(t){return t=t.childContextTypes,t!=null}function Nl(){dt(fn),dt(en)}function Rp(t,e,n){if(en.current!==vr)throw Error(se(168));ct(en,e),ct(fn,n)}function b0(t,e,n){var i=t.stateNode;if(e=e.childContextTypes,typeof i.getChildContext!="function")return n;i=i.getChildContext();for(var r in i)if(!(r in e))throw Error(se(108,Ev(t)||"Unknown",r));return _t({},n,i)}function Ll(t){return t=(t=t.stateNode)&&t.__reactInternalMemoizedMergedChildContext||vr,Gr=en.current,ct(en,t),ct(fn,fn.current),!0}function Pp(t,e,n){var i=t.stateNode;if(!i)throw Error(se(169));n?(t=b0(t,e,Gr),i.__reactInternalMemoizedMergedChildContext=t,dt(fn),dt(en),ct(en,t)):dt(fn),ct(fn,n)}var wi=null,lc=!1,jc=!1;function w0(t){wi===null?wi=[t]:wi.push(t)}function zy(t){lc=!0,w0(t)}function Er(){if(!jc&&wi!==null){jc=!0;var t=0,e=nt;try{var n=wi;for(nt=1;t<n.length;t++){var i=n[t];do i=i(!0);while(i!==null)}wi=null,lc=!1}catch(r){throw wi!==null&&(wi=wi.slice(t+1)),Kg(Lf,Er),r}finally{nt=e,jc=!1}}return null}var wa=[],Ta=0,Dl=null,Il=0,Rn=[],Pn=0,Wr=null,Ci=1,Ri="";function Pr(t,e){wa[Ta++]=Il,wa[Ta++]=Dl,Dl=t,Il=e}function T0(t,e,n){Rn[Pn++]=Ci,Rn[Pn++]=Ri,Rn[Pn++]=Wr,Wr=t;var i=Ci;t=Ri;var r=32-$n(i)-1;i&=~(1<<r),n+=1;var a=32-$n(e)+r;if(30<a){var s=r-r%5;a=(i&(1<<s)-1).toString(32),i>>=s,r-=s,Ci=1<<32-$n(e)+r|n<<r|i,Ri=a+t}else Ci=1<<a|n<<r|i,Ri=t}function Vf(t){t.return!==null&&(Pr(t,1),T0(t,1,0))}function Hf(t){for(;t===Dl;)Dl=wa[--Ta],wa[Ta]=null,Il=wa[--Ta],wa[Ta]=null;for(;t===Wr;)Wr=Rn[--Pn],Rn[Pn]=null,Ri=Rn[--Pn],Rn[Pn]=null,Ci=Rn[--Pn],Rn[Pn]=null}var Sn=null,yn=null,ht=!1,Gn=null;function A0(t,e){var n=Ln(5,null,null,0);n.elementType="DELETED",n.stateNode=e,n.return=t,e=t.deletions,e===null?(t.deletions=[n],t.flags|=16):e.push(n)}function Np(t,e){switch(t.tag){case 5:var n=t.type;return e=e.nodeType!==1||n.toLowerCase()!==e.nodeName.toLowerCase()?null:e,e!==null?(t.stateNode=e,Sn=t,yn=hr(e.firstChild),!0):!1;case 6:return e=t.pendingProps===""||e.nodeType!==3?null:e,e!==null?(t.stateNode=e,Sn=t,yn=null,!0):!1;case 13:return e=e.nodeType!==8?null:e,e!==null?(n=Wr!==null?{id:Ci,overflow:Ri}:null,t.memoizedState={dehydrated:e,treeContext:n,retryLane:1073741824},n=Ln(18,null,null,0),n.stateNode=e,n.return=t,t.child=n,Sn=t,yn=null,!0):!1;default:return!1}}function cd(t){return(t.mode&1)!==0&&(t.flags&128)===0}function ud(t){if(ht){var e=yn;if(e){var n=e;if(!Np(t,e)){if(cd(t))throw Error(se(418));e=hr(n.nextSibling);var i=Sn;e&&Np(t,e)?A0(i,n):(t.flags=t.flags&-4097|2,ht=!1,Sn=t)}}else{if(cd(t))throw Error(se(418));t.flags=t.flags&-4097|2,ht=!1,Sn=t}}}function Lp(t){for(t=t.return;t!==null&&t.tag!==5&&t.tag!==3&&t.tag!==13;)t=t.return;Sn=t}function wo(t){if(t!==Sn)return!1;if(!ht)return Lp(t),ht=!0,!1;var e;if((e=t.tag!==3)&&!(e=t.tag!==5)&&(e=t.type,e=e!=="head"&&e!=="body"&&!ad(t.type,t.memoizedProps)),e&&(e=yn)){if(cd(t))throw C0(),Error(se(418));for(;e;)A0(t,e),e=hr(e.nextSibling)}if(Lp(t),t.tag===13){if(t=t.memoizedState,t=t!==null?t.dehydrated:null,!t)throw Error(se(317));e:{for(t=t.nextSibling,e=0;t;){if(t.nodeType===8){var n=t.data;if(n==="/$"){if(e===0){yn=hr(t.nextSibling);break e}e--}else n!=="$"&&n!=="$!"&&n!=="$?"||e++}t=t.nextSibling}yn=null}}else yn=Sn?hr(t.stateNode.nextSibling):null;return!0}function C0(){for(var t=yn;t;)t=hr(t.nextSibling)}function Va(){yn=Sn=null,ht=!1}function Gf(t){Gn===null?Gn=[t]:Gn.push(t)}var Vy=Hi.ReactCurrentBatchConfig;function os(t,e,n){if(t=n.ref,t!==null&&typeof t!="function"&&typeof t!="object"){if(n._owner){if(n=n._owner,n){if(n.tag!==1)throw Error(se(309));var i=n.stateNode}if(!i)throw Error(se(147,t));var r=i,a=""+t;return e!==null&&e.ref!==null&&typeof e.ref=="function"&&e.ref._stringRef===a?e.ref:(e=function(s){var o=r.refs;s===null?delete o[a]:o[a]=s},e._stringRef=a,e)}if(typeof t!="string")throw Error(se(284));if(!n._owner)throw Error(se(290,t))}return t}function To(t,e){throw t=Object.prototype.toString.call(e),Error(se(31,t==="[object Object]"?"object with keys {"+Object.keys(e).join(", ")+"}":t))}function Dp(t){var e=t._init;return e(t._payload)}function R0(t){function e(d,v){if(t){var S=d.deletions;S===null?(d.deletions=[v],d.flags|=16):S.push(v)}}function n(d,v){if(!t)return null;for(;v!==null;)e(d,v),v=v.sibling;return null}function i(d,v){for(d=new Map;v!==null;)v.key!==null?d.set(v.key,v):d.set(v.index,v),v=v.sibling;return d}function r(d,v){return d=_r(d,v),d.index=0,d.sibling=null,d}function a(d,v,S){return d.index=S,t?(S=d.alternate,S!==null?(S=S.index,S<v?(d.flags|=2,v):S):(d.flags|=2,v)):(d.flags|=1048576,v)}function s(d){return t&&d.alternate===null&&(d.flags|=2),d}function o(d,v,S,M){return v===null||v.tag!==6?(v=Qc(S,d.mode,M),v.return=d,v):(v=r(v,S),v.return=d,v)}function l(d,v,S,M){var A=S.type;return A===va?f(d,v,S.props.children,M,S.key):v!==null&&(v.elementType===A||typeof A=="object"&&A!==null&&A.$$typeof===tr&&Dp(A)===v.type)?(M=r(v,S.props),M.ref=os(d,v,S),M.return=d,M):(M=hl(S.type,S.key,S.props,null,d.mode,M),M.ref=os(d,v,S),M.return=d,M)}function c(d,v,S,M){return v===null||v.tag!==4||v.stateNode.containerInfo!==S.containerInfo||v.stateNode.implementation!==S.implementation?(v=Jc(S,d.mode,M),v.return=d,v):(v=r(v,S.children||[]),v.return=d,v)}function f(d,v,S,M,A){return v===null||v.tag!==7?(v=Hr(S,d.mode,M,A),v.return=d,v):(v=r(v,S),v.return=d,v)}function h(d,v,S){if(typeof v=="string"&&v!==""||typeof v=="number")return v=Qc(""+v,d.mode,S),v.return=d,v;if(typeof v=="object"&&v!==null){switch(v.$$typeof){case mo:return S=hl(v.type,v.key,v.props,null,d.mode,S),S.ref=os(d,null,v),S.return=d,S;case xa:return v=Jc(v,d.mode,S),v.return=d,v;case tr:var M=v._init;return h(d,M(v._payload),S)}if(vs(v)||ns(v))return v=Hr(v,d.mode,S,null),v.return=d,v;To(d,v)}return null}function u(d,v,S,M){var A=v!==null?v.key:null;if(typeof S=="string"&&S!==""||typeof S=="number")return A!==null?null:o(d,v,""+S,M);if(typeof S=="object"&&S!==null){switch(S.$$typeof){case mo:return S.key===A?l(d,v,S,M):null;case xa:return S.key===A?c(d,v,S,M):null;case tr:return A=S._init,u(d,v,A(S._payload),M)}if(vs(S)||ns(S))return A!==null?null:f(d,v,S,M,null);To(d,S)}return null}function m(d,v,S,M,A){if(typeof M=="string"&&M!==""||typeof M=="number")return d=d.get(S)||null,o(v,d,""+M,A);if(typeof M=="object"&&M!==null){switch(M.$$typeof){case mo:return d=d.get(M.key===null?S:M.key)||null,l(v,d,M,A);case xa:return d=d.get(M.key===null?S:M.key)||null,c(v,d,M,A);case tr:var T=M._init;return m(d,v,S,T(M._payload),A)}if(vs(M)||ns(M))return d=d.get(S)||null,f(v,d,M,A,null);To(v,M)}return null}function x(d,v,S,M){for(var A=null,T=null,w=v,_=v=0,C=null;w!==null&&_<S.length;_++){w.index>_?(C=w,w=null):C=w.sibling;var P=u(d,w,S[_],M);if(P===null){w===null&&(w=C);break}t&&w&&P.alternate===null&&e(d,w),v=a(P,v,_),T===null?A=P:T.sibling=P,T=P,w=C}if(_===S.length)return n(d,w),ht&&Pr(d,_),A;if(w===null){for(;_<S.length;_++)w=h(d,S[_],M),w!==null&&(v=a(w,v,_),T===null?A=w:T.sibling=w,T=w);return ht&&Pr(d,_),A}for(w=i(d,w);_<S.length;_++)C=m(w,d,_,S[_],M),C!==null&&(t&&C.alternate!==null&&w.delete(C.key===null?_:C.key),v=a(C,v,_),T===null?A=C:T.sibling=C,T=C);return t&&w.forEach(function(N){return e(d,N)}),ht&&Pr(d,_),A}function E(d,v,S,M){var A=ns(S);if(typeof A!="function")throw Error(se(150));if(S=A.call(S),S==null)throw Error(se(151));for(var T=A=null,w=v,_=v=0,C=null,P=S.next();w!==null&&!P.done;_++,P=S.next()){w.index>_?(C=w,w=null):C=w.sibling;var N=u(d,w,P.value,M);if(N===null){w===null&&(w=C);break}t&&w&&N.alternate===null&&e(d,w),v=a(N,v,_),T===null?A=N:T.sibling=N,T=N,w=C}if(P.done)return n(d,w),ht&&Pr(d,_),A;if(w===null){for(;!P.done;_++,P=S.next())P=h(d,P.value,M),P!==null&&(v=a(P,v,_),T===null?A=P:T.sibling=P,T=P);return ht&&Pr(d,_),A}for(w=i(d,w);!P.done;_++,P=S.next())P=m(w,d,_,P.value,M),P!==null&&(t&&P.alternate!==null&&w.delete(P.key===null?_:P.key),v=a(P,v,_),T===null?A=P:T.sibling=P,T=P);return t&&w.forEach(function(F){return e(d,F)}),ht&&Pr(d,_),A}function g(d,v,S,M){if(typeof S=="object"&&S!==null&&S.type===va&&S.key===null&&(S=S.props.children),typeof S=="object"&&S!==null){switch(S.$$typeof){case mo:e:{for(var A=S.key,T=v;T!==null;){if(T.key===A){if(A=S.type,A===va){if(T.tag===7){n(d,T.sibling),v=r(T,S.props.children),v.return=d,d=v;break e}}else if(T.elementType===A||typeof A=="object"&&A!==null&&A.$$typeof===tr&&Dp(A)===T.type){n(d,T.sibling),v=r(T,S.props),v.ref=os(d,T,S),v.return=d,d=v;break e}n(d,T);break}else e(d,T);T=T.sibling}S.type===va?(v=Hr(S.props.children,d.mode,M,S.key),v.return=d,d=v):(M=hl(S.type,S.key,S.props,null,d.mode,M),M.ref=os(d,v,S),M.return=d,d=M)}return s(d);case xa:e:{for(T=S.key;v!==null;){if(v.key===T)if(v.tag===4&&v.stateNode.containerInfo===S.containerInfo&&v.stateNode.implementation===S.implementation){n(d,v.sibling),v=r(v,S.children||[]),v.return=d,d=v;break e}else{n(d,v);break}else e(d,v);v=v.sibling}v=Jc(S,d.mode,M),v.return=d,d=v}return s(d);case tr:return T=S._init,g(d,v,T(S._payload),M)}if(vs(S))return x(d,v,S,M);if(ns(S))return E(d,v,S,M);To(d,S)}return typeof S=="string"&&S!==""||typeof S=="number"?(S=""+S,v!==null&&v.tag===6?(n(d,v.sibling),v=r(v,S),v.return=d,d=v):(n(d,v),v=Qc(S,d.mode,M),v.return=d,d=v),s(d)):n(d,v)}return g}var Ha=R0(!0),P0=R0(!1),Ul=Mr(null),Fl=null,Aa=null,Wf=null;function jf(){Wf=Aa=Fl=null}function Xf(t){var e=Ul.current;dt(Ul),t._currentValue=e}function dd(t,e,n){for(;t!==null;){var i=t.alternate;if((t.childLanes&e)!==e?(t.childLanes|=e,i!==null&&(i.childLanes|=e)):i!==null&&(i.childLanes&e)!==e&&(i.childLanes|=e),t===n)break;t=t.return}}function Ia(t,e){Fl=t,Wf=Aa=null,t=t.dependencies,t!==null&&t.firstContext!==null&&(t.lanes&e&&(dn=!0),t.firstContext=null)}function In(t){var e=t._currentValue;if(Wf!==t)if(t={context:t,memoizedValue:e,next:null},Aa===null){if(Fl===null)throw Error(se(308));Aa=t,Fl.dependencies={lanes:0,firstContext:t}}else Aa=Aa.next=t;return e}var Or=null;function $f(t){Or===null?Or=[t]:Or.push(t)}function N0(t,e,n,i){var r=e.interleaved;return r===null?(n.next=n,$f(e)):(n.next=r.next,r.next=n),e.interleaved=n,Oi(t,i)}function Oi(t,e){t.lanes|=e;var n=t.alternate;for(n!==null&&(n.lanes|=e),n=t,t=t.return;t!==null;)t.childLanes|=e,n=t.alternate,n!==null&&(n.childLanes|=e),n=t,t=t.return;return n.tag===3?n.stateNode:null}var nr=!1;function qf(t){t.updateQueue={baseState:t.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,interleaved:null,lanes:0},effects:null}}function L0(t,e){t=t.updateQueue,e.updateQueue===t&&(e.updateQueue={baseState:t.baseState,firstBaseUpdate:t.firstBaseUpdate,lastBaseUpdate:t.lastBaseUpdate,shared:t.shared,effects:t.effects})}function Ni(t,e){return{eventTime:t,lane:e,tag:0,payload:null,callback:null,next:null}}function pr(t,e,n){var i=t.updateQueue;if(i===null)return null;if(i=i.shared,Ke&2){var r=i.pending;return r===null?e.next=e:(e.next=r.next,r.next=e),i.pending=e,Oi(t,n)}return r=i.interleaved,r===null?(e.next=e,$f(i)):(e.next=r.next,r.next=e),i.interleaved=e,Oi(t,n)}function ol(t,e,n){if(e=e.updateQueue,e!==null&&(e=e.shared,(n&4194240)!==0)){var i=e.lanes;i&=t.pendingLanes,n|=i,e.lanes=n,Df(t,n)}}function Ip(t,e){var n=t.updateQueue,i=t.alternate;if(i!==null&&(i=i.updateQueue,n===i)){var r=null,a=null;if(n=n.firstBaseUpdate,n!==null){do{var s={eventTime:n.eventTime,lane:n.lane,tag:n.tag,payload:n.payload,callback:n.callback,next:null};a===null?r=a=s:a=a.next=s,n=n.next}while(n!==null);a===null?r=a=e:a=a.next=e}else r=a=e;n={baseState:i.baseState,firstBaseUpdate:r,lastBaseUpdate:a,shared:i.shared,effects:i.effects},t.updateQueue=n;return}t=n.lastBaseUpdate,t===null?n.firstBaseUpdate=e:t.next=e,n.lastBaseUpdate=e}function Ol(t,e,n,i){var r=t.updateQueue;nr=!1;var a=r.firstBaseUpdate,s=r.lastBaseUpdate,o=r.shared.pending;if(o!==null){r.shared.pending=null;var l=o,c=l.next;l.next=null,s===null?a=c:s.next=c,s=l;var f=t.alternate;f!==null&&(f=f.updateQueue,o=f.lastBaseUpdate,o!==s&&(o===null?f.firstBaseUpdate=c:o.next=c,f.lastBaseUpdate=l))}if(a!==null){var h=r.baseState;s=0,f=c=l=null,o=a;do{var u=o.lane,m=o.eventTime;if((i&u)===u){f!==null&&(f=f.next={eventTime:m,lane:0,tag:o.tag,payload:o.payload,callback:o.callback,next:null});e:{var x=t,E=o;switch(u=e,m=n,E.tag){case 1:if(x=E.payload,typeof x=="function"){h=x.call(m,h,u);break e}h=x;break e;case 3:x.flags=x.flags&-65537|128;case 0:if(x=E.payload,u=typeof x=="function"?x.call(m,h,u):x,u==null)break e;h=_t({},h,u);break e;case 2:nr=!0}}o.callback!==null&&o.lane!==0&&(t.flags|=64,u=r.effects,u===null?r.effects=[o]:u.push(o))}else m={eventTime:m,lane:u,tag:o.tag,payload:o.payload,callback:o.callback,next:null},f===null?(c=f=m,l=h):f=f.next=m,s|=u;if(o=o.next,o===null){if(o=r.shared.pending,o===null)break;u=o,o=u.next,u.next=null,r.lastBaseUpdate=u,r.shared.pending=null}}while(!0);if(f===null&&(l=h),r.baseState=l,r.firstBaseUpdate=c,r.lastBaseUpdate=f,e=r.shared.interleaved,e!==null){r=e;do s|=r.lane,r=r.next;while(r!==e)}else a===null&&(r.shared.lanes=0);Xr|=s,t.lanes=s,t.memoizedState=h}}function Up(t,e,n){if(t=e.effects,e.effects=null,t!==null)for(e=0;e<t.length;e++){var i=t[e],r=i.callback;if(r!==null){if(i.callback=null,i=n,typeof r!="function")throw Error(se(191,r));r.call(i)}}}var io={},fi=Mr(io),Ws=Mr(io),js=Mr(io);function kr(t){if(t===io)throw Error(se(174));return t}function Yf(t,e){switch(ct(js,e),ct(Ws,t),ct(fi,io),t=e.nodeType,t){case 9:case 11:e=(e=e.documentElement)?e.namespaceURI:ju(null,"");break;default:t=t===8?e.parentNode:e,e=t.namespaceURI||null,t=t.tagName,e=ju(e,t)}dt(fi),ct(fi,e)}function Ga(){dt(fi),dt(Ws),dt(js)}function D0(t){kr(js.current);var e=kr(fi.current),n=ju(e,t.type);e!==n&&(ct(Ws,t),ct(fi,n))}function Kf(t){Ws.current===t&&(dt(fi),dt(Ws))}var pt=Mr(0);function kl(t){for(var e=t;e!==null;){if(e.tag===13){var n=e.memoizedState;if(n!==null&&(n=n.dehydrated,n===null||n.data==="$?"||n.data==="$!"))return e}else if(e.tag===19&&e.memoizedProps.revealOrder!==void 0){if(e.flags&128)return e}else if(e.child!==null){e.child.return=e,e=e.child;continue}if(e===t)break;for(;e.sibling===null;){if(e.return===null||e.return===t)return null;e=e.return}e.sibling.return=e.return,e=e.sibling}return null}var Xc=[];function Zf(){for(var t=0;t<Xc.length;t++)Xc[t]._workInProgressVersionPrimary=null;Xc.length=0}var ll=Hi.ReactCurrentDispatcher,$c=Hi.ReactCurrentBatchConfig,jr=0,mt=null,Dt=null,Bt=null,Bl=!1,Rs=!1,Xs=0,Hy=0;function $t(){throw Error(se(321))}function Qf(t,e){if(e===null)return!1;for(var n=0;n<e.length&&n<t.length;n++)if(!Kn(t[n],e[n]))return!1;return!0}function Jf(t,e,n,i,r,a){if(jr=a,mt=e,e.memoizedState=null,e.updateQueue=null,e.lanes=0,ll.current=t===null||t.memoizedState===null?Xy:$y,t=n(i,r),Rs){a=0;do{if(Rs=!1,Xs=0,25<=a)throw Error(se(301));a+=1,Bt=Dt=null,e.updateQueue=null,ll.current=qy,t=n(i,r)}while(Rs)}if(ll.current=zl,e=Dt!==null&&Dt.next!==null,jr=0,Bt=Dt=mt=null,Bl=!1,e)throw Error(se(300));return t}function eh(){var t=Xs!==0;return Xs=0,t}function ai(){var t={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return Bt===null?mt.memoizedState=Bt=t:Bt=Bt.next=t,Bt}function Un(){if(Dt===null){var t=mt.alternate;t=t!==null?t.memoizedState:null}else t=Dt.next;var e=Bt===null?mt.memoizedState:Bt.next;if(e!==null)Bt=e,Dt=t;else{if(t===null)throw Error(se(310));Dt=t,t={memoizedState:Dt.memoizedState,baseState:Dt.baseState,baseQueue:Dt.baseQueue,queue:Dt.queue,next:null},Bt===null?mt.memoizedState=Bt=t:Bt=Bt.next=t}return Bt}function $s(t,e){return typeof e=="function"?e(t):e}function qc(t){var e=Un(),n=e.queue;if(n===null)throw Error(se(311));n.lastRenderedReducer=t;var i=Dt,r=i.baseQueue,a=n.pending;if(a!==null){if(r!==null){var s=r.next;r.next=a.next,a.next=s}i.baseQueue=r=a,n.pending=null}if(r!==null){a=r.next,i=i.baseState;var o=s=null,l=null,c=a;do{var f=c.lane;if((jr&f)===f)l!==null&&(l=l.next={lane:0,action:c.action,hasEagerState:c.hasEagerState,eagerState:c.eagerState,next:null}),i=c.hasEagerState?c.eagerState:t(i,c.action);else{var h={lane:f,action:c.action,hasEagerState:c.hasEagerState,eagerState:c.eagerState,next:null};l===null?(o=l=h,s=i):l=l.next=h,mt.lanes|=f,Xr|=f}c=c.next}while(c!==null&&c!==a);l===null?s=i:l.next=o,Kn(i,e.memoizedState)||(dn=!0),e.memoizedState=i,e.baseState=s,e.baseQueue=l,n.lastRenderedState=i}if(t=n.interleaved,t!==null){r=t;do a=r.lane,mt.lanes|=a,Xr|=a,r=r.next;while(r!==t)}else r===null&&(n.lanes=0);return[e.memoizedState,n.dispatch]}function Yc(t){var e=Un(),n=e.queue;if(n===null)throw Error(se(311));n.lastRenderedReducer=t;var i=n.dispatch,r=n.pending,a=e.memoizedState;if(r!==null){n.pending=null;var s=r=r.next;do a=t(a,s.action),s=s.next;while(s!==r);Kn(a,e.memoizedState)||(dn=!0),e.memoizedState=a,e.baseQueue===null&&(e.baseState=a),n.lastRenderedState=a}return[a,i]}function I0(){}function U0(t,e){var n=mt,i=Un(),r=e(),a=!Kn(i.memoizedState,r);if(a&&(i.memoizedState=r,dn=!0),i=i.queue,th(k0.bind(null,n,i,t),[t]),i.getSnapshot!==e||a||Bt!==null&&Bt.memoizedState.tag&1){if(n.flags|=2048,qs(9,O0.bind(null,n,i,r,e),void 0,null),zt===null)throw Error(se(349));jr&30||F0(n,e,r)}return r}function F0(t,e,n){t.flags|=16384,t={getSnapshot:e,value:n},e=mt.updateQueue,e===null?(e={lastEffect:null,stores:null},mt.updateQueue=e,e.stores=[t]):(n=e.stores,n===null?e.stores=[t]:n.push(t))}function O0(t,e,n,i){e.value=n,e.getSnapshot=i,B0(e)&&z0(t)}function k0(t,e,n){return n(function(){B0(e)&&z0(t)})}function B0(t){var e=t.getSnapshot;t=t.value;try{var n=e();return!Kn(t,n)}catch{return!0}}function z0(t){var e=Oi(t,1);e!==null&&qn(e,t,1,-1)}function Fp(t){var e=ai();return typeof t=="function"&&(t=t()),e.memoizedState=e.baseState=t,t={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:$s,lastRenderedState:t},e.queue=t,t=t.dispatch=jy.bind(null,mt,t),[e.memoizedState,t]}function qs(t,e,n,i){return t={tag:t,create:e,destroy:n,deps:i,next:null},e=mt.updateQueue,e===null?(e={lastEffect:null,stores:null},mt.updateQueue=e,e.lastEffect=t.next=t):(n=e.lastEffect,n===null?e.lastEffect=t.next=t:(i=n.next,n.next=t,t.next=i,e.lastEffect=t)),t}function V0(){return Un().memoizedState}function cl(t,e,n,i){var r=ai();mt.flags|=t,r.memoizedState=qs(1|e,n,void 0,i===void 0?null:i)}function cc(t,e,n,i){var r=Un();i=i===void 0?null:i;var a=void 0;if(Dt!==null){var s=Dt.memoizedState;if(a=s.destroy,i!==null&&Qf(i,s.deps)){r.memoizedState=qs(e,n,a,i);return}}mt.flags|=t,r.memoizedState=qs(1|e,n,a,i)}function Op(t,e){return cl(8390656,8,t,e)}function th(t,e){return cc(2048,8,t,e)}function H0(t,e){return cc(4,2,t,e)}function G0(t,e){return cc(4,4,t,e)}function W0(t,e){if(typeof e=="function")return t=t(),e(t),function(){e(null)};if(e!=null)return t=t(),e.current=t,function(){e.current=null}}function j0(t,e,n){return n=n!=null?n.concat([t]):null,cc(4,4,W0.bind(null,e,t),n)}function nh(){}function X0(t,e){var n=Un();e=e===void 0?null:e;var i=n.memoizedState;return i!==null&&e!==null&&Qf(e,i[1])?i[0]:(n.memoizedState=[t,e],t)}function $0(t,e){var n=Un();e=e===void 0?null:e;var i=n.memoizedState;return i!==null&&e!==null&&Qf(e,i[1])?i[0]:(t=t(),n.memoizedState=[t,e],t)}function q0(t,e,n){return jr&21?(Kn(n,e)||(n=Jg(),mt.lanes|=n,Xr|=n,t.baseState=!0),e):(t.baseState&&(t.baseState=!1,dn=!0),t.memoizedState=n)}function Gy(t,e){var n=nt;nt=n!==0&&4>n?n:4,t(!0);var i=$c.transition;$c.transition={};try{t(!1),e()}finally{nt=n,$c.transition=i}}function Y0(){return Un().memoizedState}function Wy(t,e,n){var i=gr(t);if(n={lane:i,action:n,hasEagerState:!1,eagerState:null,next:null},K0(t))Z0(e,n);else if(n=N0(t,e,n,i),n!==null){var r=rn();qn(n,t,i,r),Q0(n,e,i)}}function jy(t,e,n){var i=gr(t),r={lane:i,action:n,hasEagerState:!1,eagerState:null,next:null};if(K0(t))Z0(e,r);else{var a=t.alternate;if(t.lanes===0&&(a===null||a.lanes===0)&&(a=e.lastRenderedReducer,a!==null))try{var s=e.lastRenderedState,o=a(s,n);if(r.hasEagerState=!0,r.eagerState=o,Kn(o,s)){var l=e.interleaved;l===null?(r.next=r,$f(e)):(r.next=l.next,l.next=r),e.interleaved=r;return}}catch{}finally{}n=N0(t,e,r,i),n!==null&&(r=rn(),qn(n,t,i,r),Q0(n,e,i))}}function K0(t){var e=t.alternate;return t===mt||e!==null&&e===mt}function Z0(t,e){Rs=Bl=!0;var n=t.pending;n===null?e.next=e:(e.next=n.next,n.next=e),t.pending=e}function Q0(t,e,n){if(n&4194240){var i=e.lanes;i&=t.pendingLanes,n|=i,e.lanes=n,Df(t,n)}}var zl={readContext:In,useCallback:$t,useContext:$t,useEffect:$t,useImperativeHandle:$t,useInsertionEffect:$t,useLayoutEffect:$t,useMemo:$t,useReducer:$t,useRef:$t,useState:$t,useDebugValue:$t,useDeferredValue:$t,useTransition:$t,useMutableSource:$t,useSyncExternalStore:$t,useId:$t,unstable_isNewReconciler:!1},Xy={readContext:In,useCallback:function(t,e){return ai().memoizedState=[t,e===void 0?null:e],t},useContext:In,useEffect:Op,useImperativeHandle:function(t,e,n){return n=n!=null?n.concat([t]):null,cl(4194308,4,W0.bind(null,e,t),n)},useLayoutEffect:function(t,e){return cl(4194308,4,t,e)},useInsertionEffect:function(t,e){return cl(4,2,t,e)},useMemo:function(t,e){var n=ai();return e=e===void 0?null:e,t=t(),n.memoizedState=[t,e],t},useReducer:function(t,e,n){var i=ai();return e=n!==void 0?n(e):e,i.memoizedState=i.baseState=e,t={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:t,lastRenderedState:e},i.queue=t,t=t.dispatch=Wy.bind(null,mt,t),[i.memoizedState,t]},useRef:function(t){var e=ai();return t={current:t},e.memoizedState=t},useState:Fp,useDebugValue:nh,useDeferredValue:function(t){return ai().memoizedState=t},useTransition:function(){var t=Fp(!1),e=t[0];return t=Gy.bind(null,t[1]),ai().memoizedState=t,[e,t]},useMutableSource:function(){},useSyncExternalStore:function(t,e,n){var i=mt,r=ai();if(ht){if(n===void 0)throw Error(se(407));n=n()}else{if(n=e(),zt===null)throw Error(se(349));jr&30||F0(i,e,n)}r.memoizedState=n;var a={value:n,getSnapshot:e};return r.queue=a,Op(k0.bind(null,i,a,t),[t]),i.flags|=2048,qs(9,O0.bind(null,i,a,n,e),void 0,null),n},useId:function(){var t=ai(),e=zt.identifierPrefix;if(ht){var n=Ri,i=Ci;n=(i&~(1<<32-$n(i)-1)).toString(32)+n,e=":"+e+"R"+n,n=Xs++,0<n&&(e+="H"+n.toString(32)),e+=":"}else n=Hy++,e=":"+e+"r"+n.toString(32)+":";return t.memoizedState=e},unstable_isNewReconciler:!1},$y={readContext:In,useCallback:X0,useContext:In,useEffect:th,useImperativeHandle:j0,useInsertionEffect:H0,useLayoutEffect:G0,useMemo:$0,useReducer:qc,useRef:V0,useState:function(){return qc($s)},useDebugValue:nh,useDeferredValue:function(t){var e=Un();return q0(e,Dt.memoizedState,t)},useTransition:function(){var t=qc($s)[0],e=Un().memoizedState;return[t,e]},useMutableSource:I0,useSyncExternalStore:U0,useId:Y0,unstable_isNewReconciler:!1},qy={readContext:In,useCallback:X0,useContext:In,useEffect:th,useImperativeHandle:j0,useInsertionEffect:H0,useLayoutEffect:G0,useMemo:$0,useReducer:Yc,useRef:V0,useState:function(){return Yc($s)},useDebugValue:nh,useDeferredValue:function(t){var e=Un();return Dt===null?e.memoizedState=t:q0(e,Dt.memoizedState,t)},useTransition:function(){var t=Yc($s)[0],e=Un().memoizedState;return[t,e]},useMutableSource:I0,useSyncExternalStore:U0,useId:Y0,unstable_isNewReconciler:!1};function Vn(t,e){if(t&&t.defaultProps){e=_t({},e),t=t.defaultProps;for(var n in t)e[n]===void 0&&(e[n]=t[n]);return e}return e}function fd(t,e,n,i){e=t.memoizedState,n=n(i,e),n=n==null?e:_t({},e,n),t.memoizedState=n,t.lanes===0&&(t.updateQueue.baseState=n)}var uc={isMounted:function(t){return(t=t._reactInternals)?Qr(t)===t:!1},enqueueSetState:function(t,e,n){t=t._reactInternals;var i=rn(),r=gr(t),a=Ni(i,r);a.payload=e,n!=null&&(a.callback=n),e=pr(t,a,r),e!==null&&(qn(e,t,r,i),ol(e,t,r))},enqueueReplaceState:function(t,e,n){t=t._reactInternals;var i=rn(),r=gr(t),a=Ni(i,r);a.tag=1,a.payload=e,n!=null&&(a.callback=n),e=pr(t,a,r),e!==null&&(qn(e,t,r,i),ol(e,t,r))},enqueueForceUpdate:function(t,e){t=t._reactInternals;var n=rn(),i=gr(t),r=Ni(n,i);r.tag=2,e!=null&&(r.callback=e),e=pr(t,r,i),e!==null&&(qn(e,t,i,n),ol(e,t,i))}};function kp(t,e,n,i,r,a,s){return t=t.stateNode,typeof t.shouldComponentUpdate=="function"?t.shouldComponentUpdate(i,a,s):e.prototype&&e.prototype.isPureReactComponent?!zs(n,i)||!zs(r,a):!0}function J0(t,e,n){var i=!1,r=vr,a=e.contextType;return typeof a=="object"&&a!==null?a=In(a):(r=hn(e)?Gr:en.current,i=e.contextTypes,a=(i=i!=null)?za(t,r):vr),e=new e(n,a),t.memoizedState=e.state!==null&&e.state!==void 0?e.state:null,e.updater=uc,t.stateNode=e,e._reactInternals=t,i&&(t=t.stateNode,t.__reactInternalMemoizedUnmaskedChildContext=r,t.__reactInternalMemoizedMaskedChildContext=a),e}function Bp(t,e,n,i){t=e.state,typeof e.componentWillReceiveProps=="function"&&e.componentWillReceiveProps(n,i),typeof e.UNSAFE_componentWillReceiveProps=="function"&&e.UNSAFE_componentWillReceiveProps(n,i),e.state!==t&&uc.enqueueReplaceState(e,e.state,null)}function hd(t,e,n,i){var r=t.stateNode;r.props=n,r.state=t.memoizedState,r.refs={},qf(t);var a=e.contextType;typeof a=="object"&&a!==null?r.context=In(a):(a=hn(e)?Gr:en.current,r.context=za(t,a)),r.state=t.memoizedState,a=e.getDerivedStateFromProps,typeof a=="function"&&(fd(t,e,a,n),r.state=t.memoizedState),typeof e.getDerivedStateFromProps=="function"||typeof r.getSnapshotBeforeUpdate=="function"||typeof r.UNSAFE_componentWillMount!="function"&&typeof r.componentWillMount!="function"||(e=r.state,typeof r.componentWillMount=="function"&&r.componentWillMount(),typeof r.UNSAFE_componentWillMount=="function"&&r.UNSAFE_componentWillMount(),e!==r.state&&uc.enqueueReplaceState(r,r.state,null),Ol(t,n,r,i),r.state=t.memoizedState),typeof r.componentDidMount=="function"&&(t.flags|=4194308)}function Wa(t,e){try{var n="",i=e;do n+=Mv(i),i=i.return;while(i);var r=n}catch(a){r=`
Error generating stack: `+a.message+`
`+a.stack}return{value:t,source:e,stack:r,digest:null}}function Kc(t,e,n){return{value:t,source:null,stack:n??null,digest:e??null}}function pd(t,e){try{console.error(e.value)}catch(n){setTimeout(function(){throw n})}}var Yy=typeof WeakMap=="function"?WeakMap:Map;function e_(t,e,n){n=Ni(-1,n),n.tag=3,n.payload={element:null};var i=e.value;return n.callback=function(){Hl||(Hl=!0,bd=i),pd(t,e)},n}function t_(t,e,n){n=Ni(-1,n),n.tag=3;var i=t.type.getDerivedStateFromError;if(typeof i=="function"){var r=e.value;n.payload=function(){return i(r)},n.callback=function(){pd(t,e)}}var a=t.stateNode;return a!==null&&typeof a.componentDidCatch=="function"&&(n.callback=function(){pd(t,e),typeof i!="function"&&(mr===null?mr=new Set([this]):mr.add(this));var s=e.stack;this.componentDidCatch(e.value,{componentStack:s!==null?s:""})}),n}function zp(t,e,n){var i=t.pingCache;if(i===null){i=t.pingCache=new Yy;var r=new Set;i.set(e,r)}else r=i.get(e),r===void 0&&(r=new Set,i.set(e,r));r.has(n)||(r.add(n),t=c1.bind(null,t,e,n),e.then(t,t))}function Vp(t){do{var e;if((e=t.tag===13)&&(e=t.memoizedState,e=e!==null?e.dehydrated!==null:!0),e)return t;t=t.return}while(t!==null);return null}function Hp(t,e,n,i,r){return t.mode&1?(t.flags|=65536,t.lanes=r,t):(t===e?t.flags|=65536:(t.flags|=128,n.flags|=131072,n.flags&=-52805,n.tag===1&&(n.alternate===null?n.tag=17:(e=Ni(-1,1),e.tag=2,pr(n,e,1))),n.lanes|=1),t)}var Ky=Hi.ReactCurrentOwner,dn=!1;function nn(t,e,n,i){e.child=t===null?P0(e,null,n,i):Ha(e,t.child,n,i)}function Gp(t,e,n,i,r){n=n.render;var a=e.ref;return Ia(e,r),i=Jf(t,e,n,i,a,r),n=eh(),t!==null&&!dn?(e.updateQueue=t.updateQueue,e.flags&=-2053,t.lanes&=~r,ki(t,e,r)):(ht&&n&&Vf(e),e.flags|=1,nn(t,e,i,r),e.child)}function Wp(t,e,n,i,r){if(t===null){var a=n.type;return typeof a=="function"&&!uh(a)&&a.defaultProps===void 0&&n.compare===null&&n.defaultProps===void 0?(e.tag=15,e.type=a,n_(t,e,a,i,r)):(t=hl(n.type,null,i,e,e.mode,r),t.ref=e.ref,t.return=e,e.child=t)}if(a=t.child,!(t.lanes&r)){var s=a.memoizedProps;if(n=n.compare,n=n!==null?n:zs,n(s,i)&&t.ref===e.ref)return ki(t,e,r)}return e.flags|=1,t=_r(a,i),t.ref=e.ref,t.return=e,e.child=t}function n_(t,e,n,i,r){if(t!==null){var a=t.memoizedProps;if(zs(a,i)&&t.ref===e.ref)if(dn=!1,e.pendingProps=i=a,(t.lanes&r)!==0)t.flags&131072&&(dn=!0);else return e.lanes=t.lanes,ki(t,e,r)}return md(t,e,n,i,r)}function i_(t,e,n){var i=e.pendingProps,r=i.children,a=t!==null?t.memoizedState:null;if(i.mode==="hidden")if(!(e.mode&1))e.memoizedState={baseLanes:0,cachePool:null,transitions:null},ct(Ra,vn),vn|=n;else{if(!(n&1073741824))return t=a!==null?a.baseLanes|n:n,e.lanes=e.childLanes=1073741824,e.memoizedState={baseLanes:t,cachePool:null,transitions:null},e.updateQueue=null,ct(Ra,vn),vn|=t,null;e.memoizedState={baseLanes:0,cachePool:null,transitions:null},i=a!==null?a.baseLanes:n,ct(Ra,vn),vn|=i}else a!==null?(i=a.baseLanes|n,e.memoizedState=null):i=n,ct(Ra,vn),vn|=i;return nn(t,e,r,n),e.child}function r_(t,e){var n=e.ref;(t===null&&n!==null||t!==null&&t.ref!==n)&&(e.flags|=512,e.flags|=2097152)}function md(t,e,n,i,r){var a=hn(n)?Gr:en.current;return a=za(e,a),Ia(e,r),n=Jf(t,e,n,i,a,r),i=eh(),t!==null&&!dn?(e.updateQueue=t.updateQueue,e.flags&=-2053,t.lanes&=~r,ki(t,e,r)):(ht&&i&&Vf(e),e.flags|=1,nn(t,e,n,r),e.child)}function jp(t,e,n,i,r){if(hn(n)){var a=!0;Ll(e)}else a=!1;if(Ia(e,r),e.stateNode===null)ul(t,e),J0(e,n,i),hd(e,n,i,r),i=!0;else if(t===null){var s=e.stateNode,o=e.memoizedProps;s.props=o;var l=s.context,c=n.contextType;typeof c=="object"&&c!==null?c=In(c):(c=hn(n)?Gr:en.current,c=za(e,c));var f=n.getDerivedStateFromProps,h=typeof f=="function"||typeof s.getSnapshotBeforeUpdate=="function";h||typeof s.UNSAFE_componentWillReceiveProps!="function"&&typeof s.componentWillReceiveProps!="function"||(o!==i||l!==c)&&Bp(e,s,i,c),nr=!1;var u=e.memoizedState;s.state=u,Ol(e,i,s,r),l=e.memoizedState,o!==i||u!==l||fn.current||nr?(typeof f=="function"&&(fd(e,n,f,i),l=e.memoizedState),(o=nr||kp(e,n,o,i,u,l,c))?(h||typeof s.UNSAFE_componentWillMount!="function"&&typeof s.componentWillMount!="function"||(typeof s.componentWillMount=="function"&&s.componentWillMount(),typeof s.UNSAFE_componentWillMount=="function"&&s.UNSAFE_componentWillMount()),typeof s.componentDidMount=="function"&&(e.flags|=4194308)):(typeof s.componentDidMount=="function"&&(e.flags|=4194308),e.memoizedProps=i,e.memoizedState=l),s.props=i,s.state=l,s.context=c,i=o):(typeof s.componentDidMount=="function"&&(e.flags|=4194308),i=!1)}else{s=e.stateNode,L0(t,e),o=e.memoizedProps,c=e.type===e.elementType?o:Vn(e.type,o),s.props=c,h=e.pendingProps,u=s.context,l=n.contextType,typeof l=="object"&&l!==null?l=In(l):(l=hn(n)?Gr:en.current,l=za(e,l));var m=n.getDerivedStateFromProps;(f=typeof m=="function"||typeof s.getSnapshotBeforeUpdate=="function")||typeof s.UNSAFE_componentWillReceiveProps!="function"&&typeof s.componentWillReceiveProps!="function"||(o!==h||u!==l)&&Bp(e,s,i,l),nr=!1,u=e.memoizedState,s.state=u,Ol(e,i,s,r);var x=e.memoizedState;o!==h||u!==x||fn.current||nr?(typeof m=="function"&&(fd(e,n,m,i),x=e.memoizedState),(c=nr||kp(e,n,c,i,u,x,l)||!1)?(f||typeof s.UNSAFE_componentWillUpdate!="function"&&typeof s.componentWillUpdate!="function"||(typeof s.componentWillUpdate=="function"&&s.componentWillUpdate(i,x,l),typeof s.UNSAFE_componentWillUpdate=="function"&&s.UNSAFE_componentWillUpdate(i,x,l)),typeof s.componentDidUpdate=="function"&&(e.flags|=4),typeof s.getSnapshotBeforeUpdate=="function"&&(e.flags|=1024)):(typeof s.componentDidUpdate!="function"||o===t.memoizedProps&&u===t.memoizedState||(e.flags|=4),typeof s.getSnapshotBeforeUpdate!="function"||o===t.memoizedProps&&u===t.memoizedState||(e.flags|=1024),e.memoizedProps=i,e.memoizedState=x),s.props=i,s.state=x,s.context=l,i=c):(typeof s.componentDidUpdate!="function"||o===t.memoizedProps&&u===t.memoizedState||(e.flags|=4),typeof s.getSnapshotBeforeUpdate!="function"||o===t.memoizedProps&&u===t.memoizedState||(e.flags|=1024),i=!1)}return gd(t,e,n,i,a,r)}function gd(t,e,n,i,r,a){r_(t,e);var s=(e.flags&128)!==0;if(!i&&!s)return r&&Pp(e,n,!1),ki(t,e,a);i=e.stateNode,Ky.current=e;var o=s&&typeof n.getDerivedStateFromError!="function"?null:i.render();return e.flags|=1,t!==null&&s?(e.child=Ha(e,t.child,null,a),e.child=Ha(e,null,o,a)):nn(t,e,o,a),e.memoizedState=i.state,r&&Pp(e,n,!0),e.child}function a_(t){var e=t.stateNode;e.pendingContext?Rp(t,e.pendingContext,e.pendingContext!==e.context):e.context&&Rp(t,e.context,!1),Yf(t,e.containerInfo)}function Xp(t,e,n,i,r){return Va(),Gf(r),e.flags|=256,nn(t,e,n,i),e.child}var _d={dehydrated:null,treeContext:null,retryLane:0};function xd(t){return{baseLanes:t,cachePool:null,transitions:null}}function s_(t,e,n){var i=e.pendingProps,r=pt.current,a=!1,s=(e.flags&128)!==0,o;if((o=s)||(o=t!==null&&t.memoizedState===null?!1:(r&2)!==0),o?(a=!0,e.flags&=-129):(t===null||t.memoizedState!==null)&&(r|=1),ct(pt,r&1),t===null)return ud(e),t=e.memoizedState,t!==null&&(t=t.dehydrated,t!==null)?(e.mode&1?t.data==="$!"?e.lanes=8:e.lanes=1073741824:e.lanes=1,null):(s=i.children,t=i.fallback,a?(i=e.mode,a=e.child,s={mode:"hidden",children:s},!(i&1)&&a!==null?(a.childLanes=0,a.pendingProps=s):a=hc(s,i,0,null),t=Hr(t,i,n,null),a.return=e,t.return=e,a.sibling=t,e.child=a,e.child.memoizedState=xd(n),e.memoizedState=_d,t):ih(e,s));if(r=t.memoizedState,r!==null&&(o=r.dehydrated,o!==null))return Zy(t,e,s,i,o,r,n);if(a){a=i.fallback,s=e.mode,r=t.child,o=r.sibling;var l={mode:"hidden",children:i.children};return!(s&1)&&e.child!==r?(i=e.child,i.childLanes=0,i.pendingProps=l,e.deletions=null):(i=_r(r,l),i.subtreeFlags=r.subtreeFlags&14680064),o!==null?a=_r(o,a):(a=Hr(a,s,n,null),a.flags|=2),a.return=e,i.return=e,i.sibling=a,e.child=i,i=a,a=e.child,s=t.child.memoizedState,s=s===null?xd(n):{baseLanes:s.baseLanes|n,cachePool:null,transitions:s.transitions},a.memoizedState=s,a.childLanes=t.childLanes&~n,e.memoizedState=_d,i}return a=t.child,t=a.sibling,i=_r(a,{mode:"visible",children:i.children}),!(e.mode&1)&&(i.lanes=n),i.return=e,i.sibling=null,t!==null&&(n=e.deletions,n===null?(e.deletions=[t],e.flags|=16):n.push(t)),e.child=i,e.memoizedState=null,i}function ih(t,e){return e=hc({mode:"visible",children:e},t.mode,0,null),e.return=t,t.child=e}function Ao(t,e,n,i){return i!==null&&Gf(i),Ha(e,t.child,null,n),t=ih(e,e.pendingProps.children),t.flags|=2,e.memoizedState=null,t}function Zy(t,e,n,i,r,a,s){if(n)return e.flags&256?(e.flags&=-257,i=Kc(Error(se(422))),Ao(t,e,s,i)):e.memoizedState!==null?(e.child=t.child,e.flags|=128,null):(a=i.fallback,r=e.mode,i=hc({mode:"visible",children:i.children},r,0,null),a=Hr(a,r,s,null),a.flags|=2,i.return=e,a.return=e,i.sibling=a,e.child=i,e.mode&1&&Ha(e,t.child,null,s),e.child.memoizedState=xd(s),e.memoizedState=_d,a);if(!(e.mode&1))return Ao(t,e,s,null);if(r.data==="$!"){if(i=r.nextSibling&&r.nextSibling.dataset,i)var o=i.dgst;return i=o,a=Error(se(419)),i=Kc(a,i,void 0),Ao(t,e,s,i)}if(o=(s&t.childLanes)!==0,dn||o){if(i=zt,i!==null){switch(s&-s){case 4:r=2;break;case 16:r=8;break;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:r=32;break;case 536870912:r=268435456;break;default:r=0}r=r&(i.suspendedLanes|s)?0:r,r!==0&&r!==a.retryLane&&(a.retryLane=r,Oi(t,r),qn(i,t,r,-1))}return ch(),i=Kc(Error(se(421))),Ao(t,e,s,i)}return r.data==="$?"?(e.flags|=128,e.child=t.child,e=u1.bind(null,t),r._reactRetry=e,null):(t=a.treeContext,yn=hr(r.nextSibling),Sn=e,ht=!0,Gn=null,t!==null&&(Rn[Pn++]=Ci,Rn[Pn++]=Ri,Rn[Pn++]=Wr,Ci=t.id,Ri=t.overflow,Wr=e),e=ih(e,i.children),e.flags|=4096,e)}function $p(t,e,n){t.lanes|=e;var i=t.alternate;i!==null&&(i.lanes|=e),dd(t.return,e,n)}function Zc(t,e,n,i,r){var a=t.memoizedState;a===null?t.memoizedState={isBackwards:e,rendering:null,renderingStartTime:0,last:i,tail:n,tailMode:r}:(a.isBackwards=e,a.rendering=null,a.renderingStartTime=0,a.last=i,a.tail=n,a.tailMode=r)}function o_(t,e,n){var i=e.pendingProps,r=i.revealOrder,a=i.tail;if(nn(t,e,i.children,n),i=pt.current,i&2)i=i&1|2,e.flags|=128;else{if(t!==null&&t.flags&128)e:for(t=e.child;t!==null;){if(t.tag===13)t.memoizedState!==null&&$p(t,n,e);else if(t.tag===19)$p(t,n,e);else if(t.child!==null){t.child.return=t,t=t.child;continue}if(t===e)break e;for(;t.sibling===null;){if(t.return===null||t.return===e)break e;t=t.return}t.sibling.return=t.return,t=t.sibling}i&=1}if(ct(pt,i),!(e.mode&1))e.memoizedState=null;else switch(r){case"forwards":for(n=e.child,r=null;n!==null;)t=n.alternate,t!==null&&kl(t)===null&&(r=n),n=n.sibling;n=r,n===null?(r=e.child,e.child=null):(r=n.sibling,n.sibling=null),Zc(e,!1,r,n,a);break;case"backwards":for(n=null,r=e.child,e.child=null;r!==null;){if(t=r.alternate,t!==null&&kl(t)===null){e.child=r;break}t=r.sibling,r.sibling=n,n=r,r=t}Zc(e,!0,n,null,a);break;case"together":Zc(e,!1,null,null,void 0);break;default:e.memoizedState=null}return e.child}function ul(t,e){!(e.mode&1)&&t!==null&&(t.alternate=null,e.alternate=null,e.flags|=2)}function ki(t,e,n){if(t!==null&&(e.dependencies=t.dependencies),Xr|=e.lanes,!(n&e.childLanes))return null;if(t!==null&&e.child!==t.child)throw Error(se(153));if(e.child!==null){for(t=e.child,n=_r(t,t.pendingProps),e.child=n,n.return=e;t.sibling!==null;)t=t.sibling,n=n.sibling=_r(t,t.pendingProps),n.return=e;n.sibling=null}return e.child}function Qy(t,e,n){switch(e.tag){case 3:a_(e),Va();break;case 5:D0(e);break;case 1:hn(e.type)&&Ll(e);break;case 4:Yf(e,e.stateNode.containerInfo);break;case 10:var i=e.type._context,r=e.memoizedProps.value;ct(Ul,i._currentValue),i._currentValue=r;break;case 13:if(i=e.memoizedState,i!==null)return i.dehydrated!==null?(ct(pt,pt.current&1),e.flags|=128,null):n&e.child.childLanes?s_(t,e,n):(ct(pt,pt.current&1),t=ki(t,e,n),t!==null?t.sibling:null);ct(pt,pt.current&1);break;case 19:if(i=(n&e.childLanes)!==0,t.flags&128){if(i)return o_(t,e,n);e.flags|=128}if(r=e.memoizedState,r!==null&&(r.rendering=null,r.tail=null,r.lastEffect=null),ct(pt,pt.current),i)break;return null;case 22:case 23:return e.lanes=0,i_(t,e,n)}return ki(t,e,n)}var l_,vd,c_,u_;l_=function(t,e){for(var n=e.child;n!==null;){if(n.tag===5||n.tag===6)t.appendChild(n.stateNode);else if(n.tag!==4&&n.child!==null){n.child.return=n,n=n.child;continue}if(n===e)break;for(;n.sibling===null;){if(n.return===null||n.return===e)return;n=n.return}n.sibling.return=n.return,n=n.sibling}};vd=function(){};c_=function(t,e,n,i){var r=t.memoizedProps;if(r!==i){t=e.stateNode,kr(fi.current);var a=null;switch(n){case"input":r=Vu(t,r),i=Vu(t,i),a=[];break;case"select":r=_t({},r,{value:void 0}),i=_t({},i,{value:void 0}),a=[];break;case"textarea":r=Wu(t,r),i=Wu(t,i),a=[];break;default:typeof r.onClick!="function"&&typeof i.onClick=="function"&&(t.onclick=Pl)}Xu(n,i);var s;n=null;for(c in r)if(!i.hasOwnProperty(c)&&r.hasOwnProperty(c)&&r[c]!=null)if(c==="style"){var o=r[c];for(s in o)o.hasOwnProperty(s)&&(n||(n={}),n[s]="")}else c!=="dangerouslySetInnerHTML"&&c!=="children"&&c!=="suppressContentEditableWarning"&&c!=="suppressHydrationWarning"&&c!=="autoFocus"&&(Ds.hasOwnProperty(c)?a||(a=[]):(a=a||[]).push(c,null));for(c in i){var l=i[c];if(o=r!=null?r[c]:void 0,i.hasOwnProperty(c)&&l!==o&&(l!=null||o!=null))if(c==="style")if(o){for(s in o)!o.hasOwnProperty(s)||l&&l.hasOwnProperty(s)||(n||(n={}),n[s]="");for(s in l)l.hasOwnProperty(s)&&o[s]!==l[s]&&(n||(n={}),n[s]=l[s])}else n||(a||(a=[]),a.push(c,n)),n=l;else c==="dangerouslySetInnerHTML"?(l=l?l.__html:void 0,o=o?o.__html:void 0,l!=null&&o!==l&&(a=a||[]).push(c,l)):c==="children"?typeof l!="string"&&typeof l!="number"||(a=a||[]).push(c,""+l):c!=="suppressContentEditableWarning"&&c!=="suppressHydrationWarning"&&(Ds.hasOwnProperty(c)?(l!=null&&c==="onScroll"&&ut("scroll",t),a||o===l||(a=[])):(a=a||[]).push(c,l))}n&&(a=a||[]).push("style",n);var c=a;(e.updateQueue=c)&&(e.flags|=4)}};u_=function(t,e,n,i){n!==i&&(e.flags|=4)};function ls(t,e){if(!ht)switch(t.tailMode){case"hidden":e=t.tail;for(var n=null;e!==null;)e.alternate!==null&&(n=e),e=e.sibling;n===null?t.tail=null:n.sibling=null;break;case"collapsed":n=t.tail;for(var i=null;n!==null;)n.alternate!==null&&(i=n),n=n.sibling;i===null?e||t.tail===null?t.tail=null:t.tail.sibling=null:i.sibling=null}}function qt(t){var e=t.alternate!==null&&t.alternate.child===t.child,n=0,i=0;if(e)for(var r=t.child;r!==null;)n|=r.lanes|r.childLanes,i|=r.subtreeFlags&14680064,i|=r.flags&14680064,r.return=t,r=r.sibling;else for(r=t.child;r!==null;)n|=r.lanes|r.childLanes,i|=r.subtreeFlags,i|=r.flags,r.return=t,r=r.sibling;return t.subtreeFlags|=i,t.childLanes=n,e}function Jy(t,e,n){var i=e.pendingProps;switch(Hf(e),e.tag){case 2:case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return qt(e),null;case 1:return hn(e.type)&&Nl(),qt(e),null;case 3:return i=e.stateNode,Ga(),dt(fn),dt(en),Zf(),i.pendingContext&&(i.context=i.pendingContext,i.pendingContext=null),(t===null||t.child===null)&&(wo(e)?e.flags|=4:t===null||t.memoizedState.isDehydrated&&!(e.flags&256)||(e.flags|=1024,Gn!==null&&(Ad(Gn),Gn=null))),vd(t,e),qt(e),null;case 5:Kf(e);var r=kr(js.current);if(n=e.type,t!==null&&e.stateNode!=null)c_(t,e,n,i,r),t.ref!==e.ref&&(e.flags|=512,e.flags|=2097152);else{if(!i){if(e.stateNode===null)throw Error(se(166));return qt(e),null}if(t=kr(fi.current),wo(e)){i=e.stateNode,n=e.type;var a=e.memoizedProps;switch(i[oi]=e,i[Gs]=a,t=(e.mode&1)!==0,n){case"dialog":ut("cancel",i),ut("close",i);break;case"iframe":case"object":case"embed":ut("load",i);break;case"video":case"audio":for(r=0;r<Ss.length;r++)ut(Ss[r],i);break;case"source":ut("error",i);break;case"img":case"image":case"link":ut("error",i),ut("load",i);break;case"details":ut("toggle",i);break;case"input":np(i,a),ut("invalid",i);break;case"select":i._wrapperState={wasMultiple:!!a.multiple},ut("invalid",i);break;case"textarea":rp(i,a),ut("invalid",i)}Xu(n,a),r=null;for(var s in a)if(a.hasOwnProperty(s)){var o=a[s];s==="children"?typeof o=="string"?i.textContent!==o&&(a.suppressHydrationWarning!==!0&&bo(i.textContent,o,t),r=["children",o]):typeof o=="number"&&i.textContent!==""+o&&(a.suppressHydrationWarning!==!0&&bo(i.textContent,o,t),r=["children",""+o]):Ds.hasOwnProperty(s)&&o!=null&&s==="onScroll"&&ut("scroll",i)}switch(n){case"input":go(i),ip(i,a,!0);break;case"textarea":go(i),ap(i);break;case"select":case"option":break;default:typeof a.onClick=="function"&&(i.onclick=Pl)}i=r,e.updateQueue=i,i!==null&&(e.flags|=4)}else{s=r.nodeType===9?r:r.ownerDocument,t==="http://www.w3.org/1999/xhtml"&&(t=kg(n)),t==="http://www.w3.org/1999/xhtml"?n==="script"?(t=s.createElement("div"),t.innerHTML="<script><\/script>",t=t.removeChild(t.firstChild)):typeof i.is=="string"?t=s.createElement(n,{is:i.is}):(t=s.createElement(n),n==="select"&&(s=t,i.multiple?s.multiple=!0:i.size&&(s.size=i.size))):t=s.createElementNS(t,n),t[oi]=e,t[Gs]=i,l_(t,e,!1,!1),e.stateNode=t;e:{switch(s=$u(n,i),n){case"dialog":ut("cancel",t),ut("close",t),r=i;break;case"iframe":case"object":case"embed":ut("load",t),r=i;break;case"video":case"audio":for(r=0;r<Ss.length;r++)ut(Ss[r],t);r=i;break;case"source":ut("error",t),r=i;break;case"img":case"image":case"link":ut("error",t),ut("load",t),r=i;break;case"details":ut("toggle",t),r=i;break;case"input":np(t,i),r=Vu(t,i),ut("invalid",t);break;case"option":r=i;break;case"select":t._wrapperState={wasMultiple:!!i.multiple},r=_t({},i,{value:void 0}),ut("invalid",t);break;case"textarea":rp(t,i),r=Wu(t,i),ut("invalid",t);break;default:r=i}Xu(n,r),o=r;for(a in o)if(o.hasOwnProperty(a)){var l=o[a];a==="style"?Vg(t,l):a==="dangerouslySetInnerHTML"?(l=l?l.__html:void 0,l!=null&&Bg(t,l)):a==="children"?typeof l=="string"?(n!=="textarea"||l!=="")&&Is(t,l):typeof l=="number"&&Is(t,""+l):a!=="suppressContentEditableWarning"&&a!=="suppressHydrationWarning"&&a!=="autoFocus"&&(Ds.hasOwnProperty(a)?l!=null&&a==="onScroll"&&ut("scroll",t):l!=null&&Af(t,a,l,s))}switch(n){case"input":go(t),ip(t,i,!1);break;case"textarea":go(t),ap(t);break;case"option":i.value!=null&&t.setAttribute("value",""+xr(i.value));break;case"select":t.multiple=!!i.multiple,a=i.value,a!=null?Pa(t,!!i.multiple,a,!1):i.defaultValue!=null&&Pa(t,!!i.multiple,i.defaultValue,!0);break;default:typeof r.onClick=="function"&&(t.onclick=Pl)}switch(n){case"button":case"input":case"select":case"textarea":i=!!i.autoFocus;break e;case"img":i=!0;break e;default:i=!1}}i&&(e.flags|=4)}e.ref!==null&&(e.flags|=512,e.flags|=2097152)}return qt(e),null;case 6:if(t&&e.stateNode!=null)u_(t,e,t.memoizedProps,i);else{if(typeof i!="string"&&e.stateNode===null)throw Error(se(166));if(n=kr(js.current),kr(fi.current),wo(e)){if(i=e.stateNode,n=e.memoizedProps,i[oi]=e,(a=i.nodeValue!==n)&&(t=Sn,t!==null))switch(t.tag){case 3:bo(i.nodeValue,n,(t.mode&1)!==0);break;case 5:t.memoizedProps.suppressHydrationWarning!==!0&&bo(i.nodeValue,n,(t.mode&1)!==0)}a&&(e.flags|=4)}else i=(n.nodeType===9?n:n.ownerDocument).createTextNode(i),i[oi]=e,e.stateNode=i}return qt(e),null;case 13:if(dt(pt),i=e.memoizedState,t===null||t.memoizedState!==null&&t.memoizedState.dehydrated!==null){if(ht&&yn!==null&&e.mode&1&&!(e.flags&128))C0(),Va(),e.flags|=98560,a=!1;else if(a=wo(e),i!==null&&i.dehydrated!==null){if(t===null){if(!a)throw Error(se(318));if(a=e.memoizedState,a=a!==null?a.dehydrated:null,!a)throw Error(se(317));a[oi]=e}else Va(),!(e.flags&128)&&(e.memoizedState=null),e.flags|=4;qt(e),a=!1}else Gn!==null&&(Ad(Gn),Gn=null),a=!0;if(!a)return e.flags&65536?e:null}return e.flags&128?(e.lanes=n,e):(i=i!==null,i!==(t!==null&&t.memoizedState!==null)&&i&&(e.child.flags|=8192,e.mode&1&&(t===null||pt.current&1?It===0&&(It=3):ch())),e.updateQueue!==null&&(e.flags|=4),qt(e),null);case 4:return Ga(),vd(t,e),t===null&&Vs(e.stateNode.containerInfo),qt(e),null;case 10:return Xf(e.type._context),qt(e),null;case 17:return hn(e.type)&&Nl(),qt(e),null;case 19:if(dt(pt),a=e.memoizedState,a===null)return qt(e),null;if(i=(e.flags&128)!==0,s=a.rendering,s===null)if(i)ls(a,!1);else{if(It!==0||t!==null&&t.flags&128)for(t=e.child;t!==null;){if(s=kl(t),s!==null){for(e.flags|=128,ls(a,!1),i=s.updateQueue,i!==null&&(e.updateQueue=i,e.flags|=4),e.subtreeFlags=0,i=n,n=e.child;n!==null;)a=n,t=i,a.flags&=14680066,s=a.alternate,s===null?(a.childLanes=0,a.lanes=t,a.child=null,a.subtreeFlags=0,a.memoizedProps=null,a.memoizedState=null,a.updateQueue=null,a.dependencies=null,a.stateNode=null):(a.childLanes=s.childLanes,a.lanes=s.lanes,a.child=s.child,a.subtreeFlags=0,a.deletions=null,a.memoizedProps=s.memoizedProps,a.memoizedState=s.memoizedState,a.updateQueue=s.updateQueue,a.type=s.type,t=s.dependencies,a.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext}),n=n.sibling;return ct(pt,pt.current&1|2),e.child}t=t.sibling}a.tail!==null&&Tt()>ja&&(e.flags|=128,i=!0,ls(a,!1),e.lanes=4194304)}else{if(!i)if(t=kl(s),t!==null){if(e.flags|=128,i=!0,n=t.updateQueue,n!==null&&(e.updateQueue=n,e.flags|=4),ls(a,!0),a.tail===null&&a.tailMode==="hidden"&&!s.alternate&&!ht)return qt(e),null}else 2*Tt()-a.renderingStartTime>ja&&n!==1073741824&&(e.flags|=128,i=!0,ls(a,!1),e.lanes=4194304);a.isBackwards?(s.sibling=e.child,e.child=s):(n=a.last,n!==null?n.sibling=s:e.child=s,a.last=s)}return a.tail!==null?(e=a.tail,a.rendering=e,a.tail=e.sibling,a.renderingStartTime=Tt(),e.sibling=null,n=pt.current,ct(pt,i?n&1|2:n&1),e):(qt(e),null);case 22:case 23:return lh(),i=e.memoizedState!==null,t!==null&&t.memoizedState!==null!==i&&(e.flags|=8192),i&&e.mode&1?vn&1073741824&&(qt(e),e.subtreeFlags&6&&(e.flags|=8192)):qt(e),null;case 24:return null;case 25:return null}throw Error(se(156,e.tag))}function e1(t,e){switch(Hf(e),e.tag){case 1:return hn(e.type)&&Nl(),t=e.flags,t&65536?(e.flags=t&-65537|128,e):null;case 3:return Ga(),dt(fn),dt(en),Zf(),t=e.flags,t&65536&&!(t&128)?(e.flags=t&-65537|128,e):null;case 5:return Kf(e),null;case 13:if(dt(pt),t=e.memoizedState,t!==null&&t.dehydrated!==null){if(e.alternate===null)throw Error(se(340));Va()}return t=e.flags,t&65536?(e.flags=t&-65537|128,e):null;case 19:return dt(pt),null;case 4:return Ga(),null;case 10:return Xf(e.type._context),null;case 22:case 23:return lh(),null;case 24:return null;default:return null}}var Co=!1,Zt=!1,t1=typeof WeakSet=="function"?WeakSet:Set,Me=null;function Ca(t,e){var n=t.ref;if(n!==null)if(typeof n=="function")try{n(null)}catch(i){St(t,e,i)}else n.current=null}function yd(t,e,n){try{n()}catch(i){St(t,e,i)}}var qp=!1;function n1(t,e){if(id=Al,t=m0(),zf(t)){if("selectionStart"in t)var n={start:t.selectionStart,end:t.selectionEnd};else e:{n=(n=t.ownerDocument)&&n.defaultView||window;var i=n.getSelection&&n.getSelection();if(i&&i.rangeCount!==0){n=i.anchorNode;var r=i.anchorOffset,a=i.focusNode;i=i.focusOffset;try{n.nodeType,a.nodeType}catch{n=null;break e}var s=0,o=-1,l=-1,c=0,f=0,h=t,u=null;t:for(;;){for(var m;h!==n||r!==0&&h.nodeType!==3||(o=s+r),h!==a||i!==0&&h.nodeType!==3||(l=s+i),h.nodeType===3&&(s+=h.nodeValue.length),(m=h.firstChild)!==null;)u=h,h=m;for(;;){if(h===t)break t;if(u===n&&++c===r&&(o=s),u===a&&++f===i&&(l=s),(m=h.nextSibling)!==null)break;h=u,u=h.parentNode}h=m}n=o===-1||l===-1?null:{start:o,end:l}}else n=null}n=n||{start:0,end:0}}else n=null;for(rd={focusedElem:t,selectionRange:n},Al=!1,Me=e;Me!==null;)if(e=Me,t=e.child,(e.subtreeFlags&1028)!==0&&t!==null)t.return=e,Me=t;else for(;Me!==null;){e=Me;try{var x=e.alternate;if(e.flags&1024)switch(e.tag){case 0:case 11:case 15:break;case 1:if(x!==null){var E=x.memoizedProps,g=x.memoizedState,d=e.stateNode,v=d.getSnapshotBeforeUpdate(e.elementType===e.type?E:Vn(e.type,E),g);d.__reactInternalSnapshotBeforeUpdate=v}break;case 3:var S=e.stateNode.containerInfo;S.nodeType===1?S.textContent="":S.nodeType===9&&S.documentElement&&S.removeChild(S.documentElement);break;case 5:case 6:case 4:case 17:break;default:throw Error(se(163))}}catch(M){St(e,e.return,M)}if(t=e.sibling,t!==null){t.return=e.return,Me=t;break}Me=e.return}return x=qp,qp=!1,x}function Ps(t,e,n){var i=e.updateQueue;if(i=i!==null?i.lastEffect:null,i!==null){var r=i=i.next;do{if((r.tag&t)===t){var a=r.destroy;r.destroy=void 0,a!==void 0&&yd(e,n,a)}r=r.next}while(r!==i)}}function dc(t,e){if(e=e.updateQueue,e=e!==null?e.lastEffect:null,e!==null){var n=e=e.next;do{if((n.tag&t)===t){var i=n.create;n.destroy=i()}n=n.next}while(n!==e)}}function Sd(t){var e=t.ref;if(e!==null){var n=t.stateNode;switch(t.tag){case 5:t=n;break;default:t=n}typeof e=="function"?e(t):e.current=t}}function d_(t){var e=t.alternate;e!==null&&(t.alternate=null,d_(e)),t.child=null,t.deletions=null,t.sibling=null,t.tag===5&&(e=t.stateNode,e!==null&&(delete e[oi],delete e[Gs],delete e[od],delete e[ky],delete e[By])),t.stateNode=null,t.return=null,t.dependencies=null,t.memoizedProps=null,t.memoizedState=null,t.pendingProps=null,t.stateNode=null,t.updateQueue=null}function f_(t){return t.tag===5||t.tag===3||t.tag===4}function Yp(t){e:for(;;){for(;t.sibling===null;){if(t.return===null||f_(t.return))return null;t=t.return}for(t.sibling.return=t.return,t=t.sibling;t.tag!==5&&t.tag!==6&&t.tag!==18;){if(t.flags&2||t.child===null||t.tag===4)continue e;t.child.return=t,t=t.child}if(!(t.flags&2))return t.stateNode}}function Md(t,e,n){var i=t.tag;if(i===5||i===6)t=t.stateNode,e?n.nodeType===8?n.parentNode.insertBefore(t,e):n.insertBefore(t,e):(n.nodeType===8?(e=n.parentNode,e.insertBefore(t,n)):(e=n,e.appendChild(t)),n=n._reactRootContainer,n!=null||e.onclick!==null||(e.onclick=Pl));else if(i!==4&&(t=t.child,t!==null))for(Md(t,e,n),t=t.sibling;t!==null;)Md(t,e,n),t=t.sibling}function Ed(t,e,n){var i=t.tag;if(i===5||i===6)t=t.stateNode,e?n.insertBefore(t,e):n.appendChild(t);else if(i!==4&&(t=t.child,t!==null))for(Ed(t,e,n),t=t.sibling;t!==null;)Ed(t,e,n),t=t.sibling}var Ht=null,Hn=!1;function qi(t,e,n){for(n=n.child;n!==null;)h_(t,e,n),n=n.sibling}function h_(t,e,n){if(di&&typeof di.onCommitFiberUnmount=="function")try{di.onCommitFiberUnmount(ic,n)}catch{}switch(n.tag){case 5:Zt||Ca(n,e);case 6:var i=Ht,r=Hn;Ht=null,qi(t,e,n),Ht=i,Hn=r,Ht!==null&&(Hn?(t=Ht,n=n.stateNode,t.nodeType===8?t.parentNode.removeChild(n):t.removeChild(n)):Ht.removeChild(n.stateNode));break;case 18:Ht!==null&&(Hn?(t=Ht,n=n.stateNode,t.nodeType===8?Wc(t.parentNode,n):t.nodeType===1&&Wc(t,n),ks(t)):Wc(Ht,n.stateNode));break;case 4:i=Ht,r=Hn,Ht=n.stateNode.containerInfo,Hn=!0,qi(t,e,n),Ht=i,Hn=r;break;case 0:case 11:case 14:case 15:if(!Zt&&(i=n.updateQueue,i!==null&&(i=i.lastEffect,i!==null))){r=i=i.next;do{var a=r,s=a.destroy;a=a.tag,s!==void 0&&(a&2||a&4)&&yd(n,e,s),r=r.next}while(r!==i)}qi(t,e,n);break;case 1:if(!Zt&&(Ca(n,e),i=n.stateNode,typeof i.componentWillUnmount=="function"))try{i.props=n.memoizedProps,i.state=n.memoizedState,i.componentWillUnmount()}catch(o){St(n,e,o)}qi(t,e,n);break;case 21:qi(t,e,n);break;case 22:n.mode&1?(Zt=(i=Zt)||n.memoizedState!==null,qi(t,e,n),Zt=i):qi(t,e,n);break;default:qi(t,e,n)}}function Kp(t){var e=t.updateQueue;if(e!==null){t.updateQueue=null;var n=t.stateNode;n===null&&(n=t.stateNode=new t1),e.forEach(function(i){var r=d1.bind(null,t,i);n.has(i)||(n.add(i),i.then(r,r))})}}function On(t,e){var n=e.deletions;if(n!==null)for(var i=0;i<n.length;i++){var r=n[i];try{var a=t,s=e,o=s;e:for(;o!==null;){switch(o.tag){case 5:Ht=o.stateNode,Hn=!1;break e;case 3:Ht=o.stateNode.containerInfo,Hn=!0;break e;case 4:Ht=o.stateNode.containerInfo,Hn=!0;break e}o=o.return}if(Ht===null)throw Error(se(160));h_(a,s,r),Ht=null,Hn=!1;var l=r.alternate;l!==null&&(l.return=null),r.return=null}catch(c){St(r,e,c)}}if(e.subtreeFlags&12854)for(e=e.child;e!==null;)p_(e,t),e=e.sibling}function p_(t,e){var n=t.alternate,i=t.flags;switch(t.tag){case 0:case 11:case 14:case 15:if(On(e,t),ni(t),i&4){try{Ps(3,t,t.return),dc(3,t)}catch(E){St(t,t.return,E)}try{Ps(5,t,t.return)}catch(E){St(t,t.return,E)}}break;case 1:On(e,t),ni(t),i&512&&n!==null&&Ca(n,n.return);break;case 5:if(On(e,t),ni(t),i&512&&n!==null&&Ca(n,n.return),t.flags&32){var r=t.stateNode;try{Is(r,"")}catch(E){St(t,t.return,E)}}if(i&4&&(r=t.stateNode,r!=null)){var a=t.memoizedProps,s=n!==null?n.memoizedProps:a,o=t.type,l=t.updateQueue;if(t.updateQueue=null,l!==null)try{o==="input"&&a.type==="radio"&&a.name!=null&&Fg(r,a),$u(o,s);var c=$u(o,a);for(s=0;s<l.length;s+=2){var f=l[s],h=l[s+1];f==="style"?Vg(r,h):f==="dangerouslySetInnerHTML"?Bg(r,h):f==="children"?Is(r,h):Af(r,f,h,c)}switch(o){case"input":Hu(r,a);break;case"textarea":Og(r,a);break;case"select":var u=r._wrapperState.wasMultiple;r._wrapperState.wasMultiple=!!a.multiple;var m=a.value;m!=null?Pa(r,!!a.multiple,m,!1):u!==!!a.multiple&&(a.defaultValue!=null?Pa(r,!!a.multiple,a.defaultValue,!0):Pa(r,!!a.multiple,a.multiple?[]:"",!1))}r[Gs]=a}catch(E){St(t,t.return,E)}}break;case 6:if(On(e,t),ni(t),i&4){if(t.stateNode===null)throw Error(se(162));r=t.stateNode,a=t.memoizedProps;try{r.nodeValue=a}catch(E){St(t,t.return,E)}}break;case 3:if(On(e,t),ni(t),i&4&&n!==null&&n.memoizedState.isDehydrated)try{ks(e.containerInfo)}catch(E){St(t,t.return,E)}break;case 4:On(e,t),ni(t);break;case 13:On(e,t),ni(t),r=t.child,r.flags&8192&&(a=r.memoizedState!==null,r.stateNode.isHidden=a,!a||r.alternate!==null&&r.alternate.memoizedState!==null||(sh=Tt())),i&4&&Kp(t);break;case 22:if(f=n!==null&&n.memoizedState!==null,t.mode&1?(Zt=(c=Zt)||f,On(e,t),Zt=c):On(e,t),ni(t),i&8192){if(c=t.memoizedState!==null,(t.stateNode.isHidden=c)&&!f&&t.mode&1)for(Me=t,f=t.child;f!==null;){for(h=Me=f;Me!==null;){switch(u=Me,m=u.child,u.tag){case 0:case 11:case 14:case 15:Ps(4,u,u.return);break;case 1:Ca(u,u.return);var x=u.stateNode;if(typeof x.componentWillUnmount=="function"){i=u,n=u.return;try{e=i,x.props=e.memoizedProps,x.state=e.memoizedState,x.componentWillUnmount()}catch(E){St(i,n,E)}}break;case 5:Ca(u,u.return);break;case 22:if(u.memoizedState!==null){Qp(h);continue}}m!==null?(m.return=u,Me=m):Qp(h)}f=f.sibling}e:for(f=null,h=t;;){if(h.tag===5){if(f===null){f=h;try{r=h.stateNode,c?(a=r.style,typeof a.setProperty=="function"?a.setProperty("display","none","important"):a.display="none"):(o=h.stateNode,l=h.memoizedProps.style,s=l!=null&&l.hasOwnProperty("display")?l.display:null,o.style.display=zg("display",s))}catch(E){St(t,t.return,E)}}}else if(h.tag===6){if(f===null)try{h.stateNode.nodeValue=c?"":h.memoizedProps}catch(E){St(t,t.return,E)}}else if((h.tag!==22&&h.tag!==23||h.memoizedState===null||h===t)&&h.child!==null){h.child.return=h,h=h.child;continue}if(h===t)break e;for(;h.sibling===null;){if(h.return===null||h.return===t)break e;f===h&&(f=null),h=h.return}f===h&&(f=null),h.sibling.return=h.return,h=h.sibling}}break;case 19:On(e,t),ni(t),i&4&&Kp(t);break;case 21:break;default:On(e,t),ni(t)}}function ni(t){var e=t.flags;if(e&2){try{e:{for(var n=t.return;n!==null;){if(f_(n)){var i=n;break e}n=n.return}throw Error(se(160))}switch(i.tag){case 5:var r=i.stateNode;i.flags&32&&(Is(r,""),i.flags&=-33);var a=Yp(t);Ed(t,a,r);break;case 3:case 4:var s=i.stateNode.containerInfo,o=Yp(t);Md(t,o,s);break;default:throw Error(se(161))}}catch(l){St(t,t.return,l)}t.flags&=-3}e&4096&&(t.flags&=-4097)}function i1(t,e,n){Me=t,m_(t)}function m_(t,e,n){for(var i=(t.mode&1)!==0;Me!==null;){var r=Me,a=r.child;if(r.tag===22&&i){var s=r.memoizedState!==null||Co;if(!s){var o=r.alternate,l=o!==null&&o.memoizedState!==null||Zt;o=Co;var c=Zt;if(Co=s,(Zt=l)&&!c)for(Me=r;Me!==null;)s=Me,l=s.child,s.tag===22&&s.memoizedState!==null?Jp(r):l!==null?(l.return=s,Me=l):Jp(r);for(;a!==null;)Me=a,m_(a),a=a.sibling;Me=r,Co=o,Zt=c}Zp(t)}else r.subtreeFlags&8772&&a!==null?(a.return=r,Me=a):Zp(t)}}function Zp(t){for(;Me!==null;){var e=Me;if(e.flags&8772){var n=e.alternate;try{if(e.flags&8772)switch(e.tag){case 0:case 11:case 15:Zt||dc(5,e);break;case 1:var i=e.stateNode;if(e.flags&4&&!Zt)if(n===null)i.componentDidMount();else{var r=e.elementType===e.type?n.memoizedProps:Vn(e.type,n.memoizedProps);i.componentDidUpdate(r,n.memoizedState,i.__reactInternalSnapshotBeforeUpdate)}var a=e.updateQueue;a!==null&&Up(e,a,i);break;case 3:var s=e.updateQueue;if(s!==null){if(n=null,e.child!==null)switch(e.child.tag){case 5:n=e.child.stateNode;break;case 1:n=e.child.stateNode}Up(e,s,n)}break;case 5:var o=e.stateNode;if(n===null&&e.flags&4){n=o;var l=e.memoizedProps;switch(e.type){case"button":case"input":case"select":case"textarea":l.autoFocus&&n.focus();break;case"img":l.src&&(n.src=l.src)}}break;case 6:break;case 4:break;case 12:break;case 13:if(e.memoizedState===null){var c=e.alternate;if(c!==null){var f=c.memoizedState;if(f!==null){var h=f.dehydrated;h!==null&&ks(h)}}}break;case 19:case 17:case 21:case 22:case 23:case 25:break;default:throw Error(se(163))}Zt||e.flags&512&&Sd(e)}catch(u){St(e,e.return,u)}}if(e===t){Me=null;break}if(n=e.sibling,n!==null){n.return=e.return,Me=n;break}Me=e.return}}function Qp(t){for(;Me!==null;){var e=Me;if(e===t){Me=null;break}var n=e.sibling;if(n!==null){n.return=e.return,Me=n;break}Me=e.return}}function Jp(t){for(;Me!==null;){var e=Me;try{switch(e.tag){case 0:case 11:case 15:var n=e.return;try{dc(4,e)}catch(l){St(e,n,l)}break;case 1:var i=e.stateNode;if(typeof i.componentDidMount=="function"){var r=e.return;try{i.componentDidMount()}catch(l){St(e,r,l)}}var a=e.return;try{Sd(e)}catch(l){St(e,a,l)}break;case 5:var s=e.return;try{Sd(e)}catch(l){St(e,s,l)}}}catch(l){St(e,e.return,l)}if(e===t){Me=null;break}var o=e.sibling;if(o!==null){o.return=e.return,Me=o;break}Me=e.return}}var r1=Math.ceil,Vl=Hi.ReactCurrentDispatcher,rh=Hi.ReactCurrentOwner,Dn=Hi.ReactCurrentBatchConfig,Ke=0,zt=null,Pt=null,Wt=0,vn=0,Ra=Mr(0),It=0,Ys=null,Xr=0,fc=0,ah=0,Ns=null,un=null,sh=0,ja=1/0,bi=null,Hl=!1,bd=null,mr=null,Ro=!1,lr=null,Gl=0,Ls=0,wd=null,dl=-1,fl=0;function rn(){return Ke&6?Tt():dl!==-1?dl:dl=Tt()}function gr(t){return t.mode&1?Ke&2&&Wt!==0?Wt&-Wt:Vy.transition!==null?(fl===0&&(fl=Jg()),fl):(t=nt,t!==0||(t=window.event,t=t===void 0?16:s0(t.type)),t):1}function qn(t,e,n,i){if(50<Ls)throw Ls=0,wd=null,Error(se(185));eo(t,n,i),(!(Ke&2)||t!==zt)&&(t===zt&&(!(Ke&2)&&(fc|=n),It===4&&rr(t,Wt)),pn(t,i),n===1&&Ke===0&&!(e.mode&1)&&(ja=Tt()+500,lc&&Er()))}function pn(t,e){var n=t.callbackNode;Vv(t,e);var i=Tl(t,t===zt?Wt:0);if(i===0)n!==null&&lp(n),t.callbackNode=null,t.callbackPriority=0;else if(e=i&-i,t.callbackPriority!==e){if(n!=null&&lp(n),e===1)t.tag===0?zy(em.bind(null,t)):w0(em.bind(null,t)),Fy(function(){!(Ke&6)&&Er()}),n=null;else{switch(e0(i)){case 1:n=Lf;break;case 4:n=Zg;break;case 16:n=wl;break;case 536870912:n=Qg;break;default:n=wl}n=E_(n,g_.bind(null,t))}t.callbackPriority=e,t.callbackNode=n}}function g_(t,e){if(dl=-1,fl=0,Ke&6)throw Error(se(327));var n=t.callbackNode;if(Ua()&&t.callbackNode!==n)return null;var i=Tl(t,t===zt?Wt:0);if(i===0)return null;if(i&30||i&t.expiredLanes||e)e=Wl(t,i);else{e=i;var r=Ke;Ke|=2;var a=x_();(zt!==t||Wt!==e)&&(bi=null,ja=Tt()+500,Vr(t,e));do try{o1();break}catch(o){__(t,o)}while(!0);jf(),Vl.current=a,Ke=r,Pt!==null?e=0:(zt=null,Wt=0,e=It)}if(e!==0){if(e===2&&(r=Qu(t),r!==0&&(i=r,e=Td(t,r))),e===1)throw n=Ys,Vr(t,0),rr(t,i),pn(t,Tt()),n;if(e===6)rr(t,i);else{if(r=t.current.alternate,!(i&30)&&!a1(r)&&(e=Wl(t,i),e===2&&(a=Qu(t),a!==0&&(i=a,e=Td(t,a))),e===1))throw n=Ys,Vr(t,0),rr(t,i),pn(t,Tt()),n;switch(t.finishedWork=r,t.finishedLanes=i,e){case 0:case 1:throw Error(se(345));case 2:Nr(t,un,bi);break;case 3:if(rr(t,i),(i&130023424)===i&&(e=sh+500-Tt(),10<e)){if(Tl(t,0)!==0)break;if(r=t.suspendedLanes,(r&i)!==i){rn(),t.pingedLanes|=t.suspendedLanes&r;break}t.timeoutHandle=sd(Nr.bind(null,t,un,bi),e);break}Nr(t,un,bi);break;case 4:if(rr(t,i),(i&4194240)===i)break;for(e=t.eventTimes,r=-1;0<i;){var s=31-$n(i);a=1<<s,s=e[s],s>r&&(r=s),i&=~a}if(i=r,i=Tt()-i,i=(120>i?120:480>i?480:1080>i?1080:1920>i?1920:3e3>i?3e3:4320>i?4320:1960*r1(i/1960))-i,10<i){t.timeoutHandle=sd(Nr.bind(null,t,un,bi),i);break}Nr(t,un,bi);break;case 5:Nr(t,un,bi);break;default:throw Error(se(329))}}}return pn(t,Tt()),t.callbackNode===n?g_.bind(null,t):null}function Td(t,e){var n=Ns;return t.current.memoizedState.isDehydrated&&(Vr(t,e).flags|=256),t=Wl(t,e),t!==2&&(e=un,un=n,e!==null&&Ad(e)),t}function Ad(t){un===null?un=t:un.push.apply(un,t)}function a1(t){for(var e=t;;){if(e.flags&16384){var n=e.updateQueue;if(n!==null&&(n=n.stores,n!==null))for(var i=0;i<n.length;i++){var r=n[i],a=r.getSnapshot;r=r.value;try{if(!Kn(a(),r))return!1}catch{return!1}}}if(n=e.child,e.subtreeFlags&16384&&n!==null)n.return=e,e=n;else{if(e===t)break;for(;e.sibling===null;){if(e.return===null||e.return===t)return!0;e=e.return}e.sibling.return=e.return,e=e.sibling}}return!0}function rr(t,e){for(e&=~ah,e&=~fc,t.suspendedLanes|=e,t.pingedLanes&=~e,t=t.expirationTimes;0<e;){var n=31-$n(e),i=1<<n;t[n]=-1,e&=~i}}function em(t){if(Ke&6)throw Error(se(327));Ua();var e=Tl(t,0);if(!(e&1))return pn(t,Tt()),null;var n=Wl(t,e);if(t.tag!==0&&n===2){var i=Qu(t);i!==0&&(e=i,n=Td(t,i))}if(n===1)throw n=Ys,Vr(t,0),rr(t,e),pn(t,Tt()),n;if(n===6)throw Error(se(345));return t.finishedWork=t.current.alternate,t.finishedLanes=e,Nr(t,un,bi),pn(t,Tt()),null}function oh(t,e){var n=Ke;Ke|=1;try{return t(e)}finally{Ke=n,Ke===0&&(ja=Tt()+500,lc&&Er())}}function $r(t){lr!==null&&lr.tag===0&&!(Ke&6)&&Ua();var e=Ke;Ke|=1;var n=Dn.transition,i=nt;try{if(Dn.transition=null,nt=1,t)return t()}finally{nt=i,Dn.transition=n,Ke=e,!(Ke&6)&&Er()}}function lh(){vn=Ra.current,dt(Ra)}function Vr(t,e){t.finishedWork=null,t.finishedLanes=0;var n=t.timeoutHandle;if(n!==-1&&(t.timeoutHandle=-1,Uy(n)),Pt!==null)for(n=Pt.return;n!==null;){var i=n;switch(Hf(i),i.tag){case 1:i=i.type.childContextTypes,i!=null&&Nl();break;case 3:Ga(),dt(fn),dt(en),Zf();break;case 5:Kf(i);break;case 4:Ga();break;case 13:dt(pt);break;case 19:dt(pt);break;case 10:Xf(i.type._context);break;case 22:case 23:lh()}n=n.return}if(zt=t,Pt=t=_r(t.current,null),Wt=vn=e,It=0,Ys=null,ah=fc=Xr=0,un=Ns=null,Or!==null){for(e=0;e<Or.length;e++)if(n=Or[e],i=n.interleaved,i!==null){n.interleaved=null;var r=i.next,a=n.pending;if(a!==null){var s=a.next;a.next=r,i.next=s}n.pending=i}Or=null}return t}function __(t,e){do{var n=Pt;try{if(jf(),ll.current=zl,Bl){for(var i=mt.memoizedState;i!==null;){var r=i.queue;r!==null&&(r.pending=null),i=i.next}Bl=!1}if(jr=0,Bt=Dt=mt=null,Rs=!1,Xs=0,rh.current=null,n===null||n.return===null){It=1,Ys=e,Pt=null;break}e:{var a=t,s=n.return,o=n,l=e;if(e=Wt,o.flags|=32768,l!==null&&typeof l=="object"&&typeof l.then=="function"){var c=l,f=o,h=f.tag;if(!(f.mode&1)&&(h===0||h===11||h===15)){var u=f.alternate;u?(f.updateQueue=u.updateQueue,f.memoizedState=u.memoizedState,f.lanes=u.lanes):(f.updateQueue=null,f.memoizedState=null)}var m=Vp(s);if(m!==null){m.flags&=-257,Hp(m,s,o,a,e),m.mode&1&&zp(a,c,e),e=m,l=c;var x=e.updateQueue;if(x===null){var E=new Set;E.add(l),e.updateQueue=E}else x.add(l);break e}else{if(!(e&1)){zp(a,c,e),ch();break e}l=Error(se(426))}}else if(ht&&o.mode&1){var g=Vp(s);if(g!==null){!(g.flags&65536)&&(g.flags|=256),Hp(g,s,o,a,e),Gf(Wa(l,o));break e}}a=l=Wa(l,o),It!==4&&(It=2),Ns===null?Ns=[a]:Ns.push(a),a=s;do{switch(a.tag){case 3:a.flags|=65536,e&=-e,a.lanes|=e;var d=e_(a,l,e);Ip(a,d);break e;case 1:o=l;var v=a.type,S=a.stateNode;if(!(a.flags&128)&&(typeof v.getDerivedStateFromError=="function"||S!==null&&typeof S.componentDidCatch=="function"&&(mr===null||!mr.has(S)))){a.flags|=65536,e&=-e,a.lanes|=e;var M=t_(a,o,e);Ip(a,M);break e}}a=a.return}while(a!==null)}y_(n)}catch(A){e=A,Pt===n&&n!==null&&(Pt=n=n.return);continue}break}while(!0)}function x_(){var t=Vl.current;return Vl.current=zl,t===null?zl:t}function ch(){(It===0||It===3||It===2)&&(It=4),zt===null||!(Xr&268435455)&&!(fc&268435455)||rr(zt,Wt)}function Wl(t,e){var n=Ke;Ke|=2;var i=x_();(zt!==t||Wt!==e)&&(bi=null,Vr(t,e));do try{s1();break}catch(r){__(t,r)}while(!0);if(jf(),Ke=n,Vl.current=i,Pt!==null)throw Error(se(261));return zt=null,Wt=0,It}function s1(){for(;Pt!==null;)v_(Pt)}function o1(){for(;Pt!==null&&!Lv();)v_(Pt)}function v_(t){var e=M_(t.alternate,t,vn);t.memoizedProps=t.pendingProps,e===null?y_(t):Pt=e,rh.current=null}function y_(t){var e=t;do{var n=e.alternate;if(t=e.return,e.flags&32768){if(n=e1(n,e),n!==null){n.flags&=32767,Pt=n;return}if(t!==null)t.flags|=32768,t.subtreeFlags=0,t.deletions=null;else{It=6,Pt=null;return}}else if(n=Jy(n,e,vn),n!==null){Pt=n;return}if(e=e.sibling,e!==null){Pt=e;return}Pt=e=t}while(e!==null);It===0&&(It=5)}function Nr(t,e,n){var i=nt,r=Dn.transition;try{Dn.transition=null,nt=1,l1(t,e,n,i)}finally{Dn.transition=r,nt=i}return null}function l1(t,e,n,i){do Ua();while(lr!==null);if(Ke&6)throw Error(se(327));n=t.finishedWork;var r=t.finishedLanes;if(n===null)return null;if(t.finishedWork=null,t.finishedLanes=0,n===t.current)throw Error(se(177));t.callbackNode=null,t.callbackPriority=0;var a=n.lanes|n.childLanes;if(Hv(t,a),t===zt&&(Pt=zt=null,Wt=0),!(n.subtreeFlags&2064)&&!(n.flags&2064)||Ro||(Ro=!0,E_(wl,function(){return Ua(),null})),a=(n.flags&15990)!==0,n.subtreeFlags&15990||a){a=Dn.transition,Dn.transition=null;var s=nt;nt=1;var o=Ke;Ke|=4,rh.current=null,n1(t,n),p_(n,t),Cy(rd),Al=!!id,rd=id=null,t.current=n,i1(n),Dv(),Ke=o,nt=s,Dn.transition=a}else t.current=n;if(Ro&&(Ro=!1,lr=t,Gl=r),a=t.pendingLanes,a===0&&(mr=null),Fv(n.stateNode),pn(t,Tt()),e!==null)for(i=t.onRecoverableError,n=0;n<e.length;n++)r=e[n],i(r.value,{componentStack:r.stack,digest:r.digest});if(Hl)throw Hl=!1,t=bd,bd=null,t;return Gl&1&&t.tag!==0&&Ua(),a=t.pendingLanes,a&1?t===wd?Ls++:(Ls=0,wd=t):Ls=0,Er(),null}function Ua(){if(lr!==null){var t=e0(Gl),e=Dn.transition,n=nt;try{if(Dn.transition=null,nt=16>t?16:t,lr===null)var i=!1;else{if(t=lr,lr=null,Gl=0,Ke&6)throw Error(se(331));var r=Ke;for(Ke|=4,Me=t.current;Me!==null;){var a=Me,s=a.child;if(Me.flags&16){var o=a.deletions;if(o!==null){for(var l=0;l<o.length;l++){var c=o[l];for(Me=c;Me!==null;){var f=Me;switch(f.tag){case 0:case 11:case 15:Ps(8,f,a)}var h=f.child;if(h!==null)h.return=f,Me=h;else for(;Me!==null;){f=Me;var u=f.sibling,m=f.return;if(d_(f),f===c){Me=null;break}if(u!==null){u.return=m,Me=u;break}Me=m}}}var x=a.alternate;if(x!==null){var E=x.child;if(E!==null){x.child=null;do{var g=E.sibling;E.sibling=null,E=g}while(E!==null)}}Me=a}}if(a.subtreeFlags&2064&&s!==null)s.return=a,Me=s;else e:for(;Me!==null;){if(a=Me,a.flags&2048)switch(a.tag){case 0:case 11:case 15:Ps(9,a,a.return)}var d=a.sibling;if(d!==null){d.return=a.return,Me=d;break e}Me=a.return}}var v=t.current;for(Me=v;Me!==null;){s=Me;var S=s.child;if(s.subtreeFlags&2064&&S!==null)S.return=s,Me=S;else e:for(s=v;Me!==null;){if(o=Me,o.flags&2048)try{switch(o.tag){case 0:case 11:case 15:dc(9,o)}}catch(A){St(o,o.return,A)}if(o===s){Me=null;break e}var M=o.sibling;if(M!==null){M.return=o.return,Me=M;break e}Me=o.return}}if(Ke=r,Er(),di&&typeof di.onPostCommitFiberRoot=="function")try{di.onPostCommitFiberRoot(ic,t)}catch{}i=!0}return i}finally{nt=n,Dn.transition=e}}return!1}function tm(t,e,n){e=Wa(n,e),e=e_(t,e,1),t=pr(t,e,1),e=rn(),t!==null&&(eo(t,1,e),pn(t,e))}function St(t,e,n){if(t.tag===3)tm(t,t,n);else for(;e!==null;){if(e.tag===3){tm(e,t,n);break}else if(e.tag===1){var i=e.stateNode;if(typeof e.type.getDerivedStateFromError=="function"||typeof i.componentDidCatch=="function"&&(mr===null||!mr.has(i))){t=Wa(n,t),t=t_(e,t,1),e=pr(e,t,1),t=rn(),e!==null&&(eo(e,1,t),pn(e,t));break}}e=e.return}}function c1(t,e,n){var i=t.pingCache;i!==null&&i.delete(e),e=rn(),t.pingedLanes|=t.suspendedLanes&n,zt===t&&(Wt&n)===n&&(It===4||It===3&&(Wt&130023424)===Wt&&500>Tt()-sh?Vr(t,0):ah|=n),pn(t,e)}function S_(t,e){e===0&&(t.mode&1?(e=vo,vo<<=1,!(vo&130023424)&&(vo=4194304)):e=1);var n=rn();t=Oi(t,e),t!==null&&(eo(t,e,n),pn(t,n))}function u1(t){var e=t.memoizedState,n=0;e!==null&&(n=e.retryLane),S_(t,n)}function d1(t,e){var n=0;switch(t.tag){case 13:var i=t.stateNode,r=t.memoizedState;r!==null&&(n=r.retryLane);break;case 19:i=t.stateNode;break;default:throw Error(se(314))}i!==null&&i.delete(e),S_(t,n)}var M_;M_=function(t,e,n){if(t!==null)if(t.memoizedProps!==e.pendingProps||fn.current)dn=!0;else{if(!(t.lanes&n)&&!(e.flags&128))return dn=!1,Qy(t,e,n);dn=!!(t.flags&131072)}else dn=!1,ht&&e.flags&1048576&&T0(e,Il,e.index);switch(e.lanes=0,e.tag){case 2:var i=e.type;ul(t,e),t=e.pendingProps;var r=za(e,en.current);Ia(e,n),r=Jf(null,e,i,t,r,n);var a=eh();return e.flags|=1,typeof r=="object"&&r!==null&&typeof r.render=="function"&&r.$$typeof===void 0?(e.tag=1,e.memoizedState=null,e.updateQueue=null,hn(i)?(a=!0,Ll(e)):a=!1,e.memoizedState=r.state!==null&&r.state!==void 0?r.state:null,qf(e),r.updater=uc,e.stateNode=r,r._reactInternals=e,hd(e,i,t,n),e=gd(null,e,i,!0,a,n)):(e.tag=0,ht&&a&&Vf(e),nn(null,e,r,n),e=e.child),e;case 16:i=e.elementType;e:{switch(ul(t,e),t=e.pendingProps,r=i._init,i=r(i._payload),e.type=i,r=e.tag=h1(i),t=Vn(i,t),r){case 0:e=md(null,e,i,t,n);break e;case 1:e=jp(null,e,i,t,n);break e;case 11:e=Gp(null,e,i,t,n);break e;case 14:e=Wp(null,e,i,Vn(i.type,t),n);break e}throw Error(se(306,i,""))}return e;case 0:return i=e.type,r=e.pendingProps,r=e.elementType===i?r:Vn(i,r),md(t,e,i,r,n);case 1:return i=e.type,r=e.pendingProps,r=e.elementType===i?r:Vn(i,r),jp(t,e,i,r,n);case 3:e:{if(a_(e),t===null)throw Error(se(387));i=e.pendingProps,a=e.memoizedState,r=a.element,L0(t,e),Ol(e,i,null,n);var s=e.memoizedState;if(i=s.element,a.isDehydrated)if(a={element:i,isDehydrated:!1,cache:s.cache,pendingSuspenseBoundaries:s.pendingSuspenseBoundaries,transitions:s.transitions},e.updateQueue.baseState=a,e.memoizedState=a,e.flags&256){r=Wa(Error(se(423)),e),e=Xp(t,e,i,n,r);break e}else if(i!==r){r=Wa(Error(se(424)),e),e=Xp(t,e,i,n,r);break e}else for(yn=hr(e.stateNode.containerInfo.firstChild),Sn=e,ht=!0,Gn=null,n=P0(e,null,i,n),e.child=n;n;)n.flags=n.flags&-3|4096,n=n.sibling;else{if(Va(),i===r){e=ki(t,e,n);break e}nn(t,e,i,n)}e=e.child}return e;case 5:return D0(e),t===null&&ud(e),i=e.type,r=e.pendingProps,a=t!==null?t.memoizedProps:null,s=r.children,ad(i,r)?s=null:a!==null&&ad(i,a)&&(e.flags|=32),r_(t,e),nn(t,e,s,n),e.child;case 6:return t===null&&ud(e),null;case 13:return s_(t,e,n);case 4:return Yf(e,e.stateNode.containerInfo),i=e.pendingProps,t===null?e.child=Ha(e,null,i,n):nn(t,e,i,n),e.child;case 11:return i=e.type,r=e.pendingProps,r=e.elementType===i?r:Vn(i,r),Gp(t,e,i,r,n);case 7:return nn(t,e,e.pendingProps,n),e.child;case 8:return nn(t,e,e.pendingProps.children,n),e.child;case 12:return nn(t,e,e.pendingProps.children,n),e.child;case 10:e:{if(i=e.type._context,r=e.pendingProps,a=e.memoizedProps,s=r.value,ct(Ul,i._currentValue),i._currentValue=s,a!==null)if(Kn(a.value,s)){if(a.children===r.children&&!fn.current){e=ki(t,e,n);break e}}else for(a=e.child,a!==null&&(a.return=e);a!==null;){var o=a.dependencies;if(o!==null){s=a.child;for(var l=o.firstContext;l!==null;){if(l.context===i){if(a.tag===1){l=Ni(-1,n&-n),l.tag=2;var c=a.updateQueue;if(c!==null){c=c.shared;var f=c.pending;f===null?l.next=l:(l.next=f.next,f.next=l),c.pending=l}}a.lanes|=n,l=a.alternate,l!==null&&(l.lanes|=n),dd(a.return,n,e),o.lanes|=n;break}l=l.next}}else if(a.tag===10)s=a.type===e.type?null:a.child;else if(a.tag===18){if(s=a.return,s===null)throw Error(se(341));s.lanes|=n,o=s.alternate,o!==null&&(o.lanes|=n),dd(s,n,e),s=a.sibling}else s=a.child;if(s!==null)s.return=a;else for(s=a;s!==null;){if(s===e){s=null;break}if(a=s.sibling,a!==null){a.return=s.return,s=a;break}s=s.return}a=s}nn(t,e,r.children,n),e=e.child}return e;case 9:return r=e.type,i=e.pendingProps.children,Ia(e,n),r=In(r),i=i(r),e.flags|=1,nn(t,e,i,n),e.child;case 14:return i=e.type,r=Vn(i,e.pendingProps),r=Vn(i.type,r),Wp(t,e,i,r,n);case 15:return n_(t,e,e.type,e.pendingProps,n);case 17:return i=e.type,r=e.pendingProps,r=e.elementType===i?r:Vn(i,r),ul(t,e),e.tag=1,hn(i)?(t=!0,Ll(e)):t=!1,Ia(e,n),J0(e,i,r),hd(e,i,r,n),gd(null,e,i,!0,t,n);case 19:return o_(t,e,n);case 22:return i_(t,e,n)}throw Error(se(156,e.tag))};function E_(t,e){return Kg(t,e)}function f1(t,e,n,i){this.tag=t,this.key=n,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.ref=null,this.pendingProps=e,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=i,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function Ln(t,e,n,i){return new f1(t,e,n,i)}function uh(t){return t=t.prototype,!(!t||!t.isReactComponent)}function h1(t){if(typeof t=="function")return uh(t)?1:0;if(t!=null){if(t=t.$$typeof,t===Rf)return 11;if(t===Pf)return 14}return 2}function _r(t,e){var n=t.alternate;return n===null?(n=Ln(t.tag,e,t.key,t.mode),n.elementType=t.elementType,n.type=t.type,n.stateNode=t.stateNode,n.alternate=t,t.alternate=n):(n.pendingProps=e,n.type=t.type,n.flags=0,n.subtreeFlags=0,n.deletions=null),n.flags=t.flags&14680064,n.childLanes=t.childLanes,n.lanes=t.lanes,n.child=t.child,n.memoizedProps=t.memoizedProps,n.memoizedState=t.memoizedState,n.updateQueue=t.updateQueue,e=t.dependencies,n.dependencies=e===null?null:{lanes:e.lanes,firstContext:e.firstContext},n.sibling=t.sibling,n.index=t.index,n.ref=t.ref,n}function hl(t,e,n,i,r,a){var s=2;if(i=t,typeof t=="function")uh(t)&&(s=1);else if(typeof t=="string")s=5;else e:switch(t){case va:return Hr(n.children,r,a,e);case Cf:s=8,r|=8;break;case Ou:return t=Ln(12,n,e,r|2),t.elementType=Ou,t.lanes=a,t;case ku:return t=Ln(13,n,e,r),t.elementType=ku,t.lanes=a,t;case Bu:return t=Ln(19,n,e,r),t.elementType=Bu,t.lanes=a,t;case Dg:return hc(n,r,a,e);default:if(typeof t=="object"&&t!==null)switch(t.$$typeof){case Ng:s=10;break e;case Lg:s=9;break e;case Rf:s=11;break e;case Pf:s=14;break e;case tr:s=16,i=null;break e}throw Error(se(130,t==null?t:typeof t,""))}return e=Ln(s,n,e,r),e.elementType=t,e.type=i,e.lanes=a,e}function Hr(t,e,n,i){return t=Ln(7,t,i,e),t.lanes=n,t}function hc(t,e,n,i){return t=Ln(22,t,i,e),t.elementType=Dg,t.lanes=n,t.stateNode={isHidden:!1},t}function Qc(t,e,n){return t=Ln(6,t,null,e),t.lanes=n,t}function Jc(t,e,n){return e=Ln(4,t.children!==null?t.children:[],t.key,e),e.lanes=n,e.stateNode={containerInfo:t.containerInfo,pendingChildren:null,implementation:t.implementation},e}function p1(t,e,n,i,r){this.tag=e,this.containerInfo=t,this.finishedWork=this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.pendingContext=this.context=null,this.callbackPriority=0,this.eventTimes=Dc(0),this.expirationTimes=Dc(-1),this.entangledLanes=this.finishedLanes=this.mutableReadLanes=this.expiredLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=Dc(0),this.identifierPrefix=i,this.onRecoverableError=r,this.mutableSourceEagerHydrationData=null}function dh(t,e,n,i,r,a,s,o,l){return t=new p1(t,e,n,o,l),e===1?(e=1,a===!0&&(e|=8)):e=0,a=Ln(3,null,null,e),t.current=a,a.stateNode=t,a.memoizedState={element:i,isDehydrated:n,cache:null,transitions:null,pendingSuspenseBoundaries:null},qf(a),t}function m1(t,e,n){var i=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:xa,key:i==null?null:""+i,children:t,containerInfo:e,implementation:n}}function b_(t){if(!t)return vr;t=t._reactInternals;e:{if(Qr(t)!==t||t.tag!==1)throw Error(se(170));var e=t;do{switch(e.tag){case 3:e=e.stateNode.context;break e;case 1:if(hn(e.type)){e=e.stateNode.__reactInternalMemoizedMergedChildContext;break e}}e=e.return}while(e!==null);throw Error(se(171))}if(t.tag===1){var n=t.type;if(hn(n))return b0(t,n,e)}return e}function w_(t,e,n,i,r,a,s,o,l){return t=dh(n,i,!0,t,r,a,s,o,l),t.context=b_(null),n=t.current,i=rn(),r=gr(n),a=Ni(i,r),a.callback=e??null,pr(n,a,r),t.current.lanes=r,eo(t,r,i),pn(t,i),t}function pc(t,e,n,i){var r=e.current,a=rn(),s=gr(r);return n=b_(n),e.context===null?e.context=n:e.pendingContext=n,e=Ni(a,s),e.payload={element:t},i=i===void 0?null:i,i!==null&&(e.callback=i),t=pr(r,e,s),t!==null&&(qn(t,r,s,a),ol(t,r,s)),s}function jl(t){if(t=t.current,!t.child)return null;switch(t.child.tag){case 5:return t.child.stateNode;default:return t.child.stateNode}}function nm(t,e){if(t=t.memoizedState,t!==null&&t.dehydrated!==null){var n=t.retryLane;t.retryLane=n!==0&&n<e?n:e}}function fh(t,e){nm(t,e),(t=t.alternate)&&nm(t,e)}function g1(){return null}var T_=typeof reportError=="function"?reportError:function(t){console.error(t)};function hh(t){this._internalRoot=t}mc.prototype.render=hh.prototype.render=function(t){var e=this._internalRoot;if(e===null)throw Error(se(409));pc(t,e,null,null)};mc.prototype.unmount=hh.prototype.unmount=function(){var t=this._internalRoot;if(t!==null){this._internalRoot=null;var e=t.containerInfo;$r(function(){pc(null,t,null,null)}),e[Fi]=null}};function mc(t){this._internalRoot=t}mc.prototype.unstable_scheduleHydration=function(t){if(t){var e=i0();t={blockedOn:null,target:t,priority:e};for(var n=0;n<ir.length&&e!==0&&e<ir[n].priority;n++);ir.splice(n,0,t),n===0&&a0(t)}};function ph(t){return!(!t||t.nodeType!==1&&t.nodeType!==9&&t.nodeType!==11)}function gc(t){return!(!t||t.nodeType!==1&&t.nodeType!==9&&t.nodeType!==11&&(t.nodeType!==8||t.nodeValue!==" react-mount-point-unstable "))}function im(){}function _1(t,e,n,i,r){if(r){if(typeof i=="function"){var a=i;i=function(){var c=jl(s);a.call(c)}}var s=w_(e,i,t,0,null,!1,!1,"",im);return t._reactRootContainer=s,t[Fi]=s.current,Vs(t.nodeType===8?t.parentNode:t),$r(),s}for(;r=t.lastChild;)t.removeChild(r);if(typeof i=="function"){var o=i;i=function(){var c=jl(l);o.call(c)}}var l=dh(t,0,!1,null,null,!1,!1,"",im);return t._reactRootContainer=l,t[Fi]=l.current,Vs(t.nodeType===8?t.parentNode:t),$r(function(){pc(e,l,n,i)}),l}function _c(t,e,n,i,r){var a=n._reactRootContainer;if(a){var s=a;if(typeof r=="function"){var o=r;r=function(){var l=jl(s);o.call(l)}}pc(e,s,t,r)}else s=_1(n,e,t,r,i);return jl(s)}t0=function(t){switch(t.tag){case 3:var e=t.stateNode;if(e.current.memoizedState.isDehydrated){var n=ys(e.pendingLanes);n!==0&&(Df(e,n|1),pn(e,Tt()),!(Ke&6)&&(ja=Tt()+500,Er()))}break;case 13:$r(function(){var i=Oi(t,1);if(i!==null){var r=rn();qn(i,t,1,r)}}),fh(t,1)}};If=function(t){if(t.tag===13){var e=Oi(t,134217728);if(e!==null){var n=rn();qn(e,t,134217728,n)}fh(t,134217728)}};n0=function(t){if(t.tag===13){var e=gr(t),n=Oi(t,e);if(n!==null){var i=rn();qn(n,t,e,i)}fh(t,e)}};i0=function(){return nt};r0=function(t,e){var n=nt;try{return nt=t,e()}finally{nt=n}};Yu=function(t,e,n){switch(e){case"input":if(Hu(t,n),e=n.name,n.type==="radio"&&e!=null){for(n=t;n.parentNode;)n=n.parentNode;for(n=n.querySelectorAll("input[name="+JSON.stringify(""+e)+'][type="radio"]'),e=0;e<n.length;e++){var i=n[e];if(i!==t&&i.form===t.form){var r=oc(i);if(!r)throw Error(se(90));Ug(i),Hu(i,r)}}}break;case"textarea":Og(t,n);break;case"select":e=n.value,e!=null&&Pa(t,!!n.multiple,e,!1)}};Wg=oh;jg=$r;var x1={usingClientEntryPoint:!1,Events:[no,Ea,oc,Hg,Gg,oh]},cs={findFiberByHostInstance:Fr,bundleType:0,version:"18.3.1",rendererPackageName:"react-dom"},v1={bundleType:cs.bundleType,version:cs.version,rendererPackageName:cs.rendererPackageName,rendererConfig:cs.rendererConfig,overrideHookState:null,overrideHookStateDeletePath:null,overrideHookStateRenamePath:null,overrideProps:null,overridePropsDeletePath:null,overridePropsRenamePath:null,setErrorHandler:null,setSuspenseHandler:null,scheduleUpdate:null,currentDispatcherRef:Hi.ReactCurrentDispatcher,findHostInstanceByFiber:function(t){return t=qg(t),t===null?null:t.stateNode},findFiberByHostInstance:cs.findFiberByHostInstance||g1,findHostInstancesForRefresh:null,scheduleRefresh:null,scheduleRoot:null,setRefreshHandler:null,getCurrentFiber:null,reconcilerVersion:"18.3.1-next-f1338f8080-20240426"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"){var Po=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!Po.isDisabled&&Po.supportsFiber)try{ic=Po.inject(v1),di=Po}catch{}}bn.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=x1;bn.createPortal=function(t,e){var n=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!ph(e))throw Error(se(200));return m1(t,e,null,n)};bn.createRoot=function(t,e){if(!ph(t))throw Error(se(299));var n=!1,i="",r=T_;return e!=null&&(e.unstable_strictMode===!0&&(n=!0),e.identifierPrefix!==void 0&&(i=e.identifierPrefix),e.onRecoverableError!==void 0&&(r=e.onRecoverableError)),e=dh(t,1,!1,null,null,n,!1,i,r),t[Fi]=e.current,Vs(t.nodeType===8?t.parentNode:t),new hh(e)};bn.findDOMNode=function(t){if(t==null)return null;if(t.nodeType===1)return t;var e=t._reactInternals;if(e===void 0)throw typeof t.render=="function"?Error(se(188)):(t=Object.keys(t).join(","),Error(se(268,t)));return t=qg(e),t=t===null?null:t.stateNode,t};bn.flushSync=function(t){return $r(t)};bn.hydrate=function(t,e,n){if(!gc(e))throw Error(se(200));return _c(null,t,e,!0,n)};bn.hydrateRoot=function(t,e,n){if(!ph(t))throw Error(se(405));var i=n!=null&&n.hydratedSources||null,r=!1,a="",s=T_;if(n!=null&&(n.unstable_strictMode===!0&&(r=!0),n.identifierPrefix!==void 0&&(a=n.identifierPrefix),n.onRecoverableError!==void 0&&(s=n.onRecoverableError)),e=w_(e,null,t,1,n??null,r,!1,a,s),t[Fi]=e.current,Vs(t),i)for(t=0;t<i.length;t++)n=i[t],r=n._getVersion,r=r(n._source),e.mutableSourceEagerHydrationData==null?e.mutableSourceEagerHydrationData=[n,r]:e.mutableSourceEagerHydrationData.push(n,r);return new mc(e)};bn.render=function(t,e,n){if(!gc(e))throw Error(se(200));return _c(null,t,e,!1,n)};bn.unmountComponentAtNode=function(t){if(!gc(t))throw Error(se(40));return t._reactRootContainer?($r(function(){_c(null,null,t,!1,function(){t._reactRootContainer=null,t[Fi]=null})}),!0):!1};bn.unstable_batchedUpdates=oh;bn.unstable_renderSubtreeIntoContainer=function(t,e,n,i){if(!gc(n))throw Error(se(200));if(t==null||t._reactInternals===void 0)throw Error(se(38));return _c(t,e,n,!1,i)};bn.version="18.3.1-next-f1338f8080-20240426";function A_(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(A_)}catch(t){console.error(t)}}A_(),Ag.exports=bn;var y1=Ag.exports,C_,rm=y1;C_=rm.createRoot,rm.hydrateRoot;/**
 * react-router v7.18.1
 *
 * Copyright (c) Remix Software Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.md file in the root directory of this source tree.
 *
 * @license MIT
 */var mh=/^(?:[a-z][a-z0-9+.-]*:|[\\/]{2})/i,R_=/^[\\/]{2}/;function S1(t,e){return e+t.replace(/\\/g,"/")}var am="popstate";function sm(t){return typeof t=="object"&&t!=null&&"pathname"in t&&"search"in t&&"hash"in t&&"state"in t&&"key"in t}function M1(t={}){function e(r,a){let{pathname:s="/",search:o="",hash:l=""}=Jr(r.location.hash.substring(1));return!s.startsWith("/")&&!s.startsWith(".")&&(s="/"+s),Cd("",{pathname:s,search:o,hash:l},a.state&&a.state.usr||null,a.state&&a.state.key||"default")}function n(r,a){let s=r.document.querySelector("base"),o="";if(s&&s.getAttribute("href")){let l=r.location.href,c=l.indexOf("#");o=c===-1?l:l.slice(0,c)}return o+"#"+(typeof a=="string"?a:Ks(a))}function i(r,a){Zn(r.pathname.charAt(0)==="/",`relative pathnames are not supported in hash history.push(${JSON.stringify(a)})`)}return b1(e,n,i,t)}function gt(t,e){if(t===!1||t===null||typeof t>"u")throw new Error(e)}function Zn(t,e){if(!t){typeof console<"u"&&console.warn(e);try{throw new Error(e)}catch{}}}function E1(){return Math.random().toString(36).substring(2,10)}function om(t,e){return{usr:t.state,key:t.key,idx:e,masked:t.mask?{pathname:t.pathname,search:t.search,hash:t.hash}:void 0}}function Cd(t,e,n=null,i,r){return{pathname:typeof t=="string"?t:t.pathname,search:"",hash:"",...typeof e=="string"?Jr(e):e,state:n,key:e&&e.key||i||E1(),mask:r}}function Ks({pathname:t="/",search:e="",hash:n=""}){return e&&e!=="?"&&(t+=e.charAt(0)==="?"?e:"?"+e),n&&n!=="#"&&(t+=n.charAt(0)==="#"?n:"#"+n),t}function Jr(t){let e={};if(t){let n=t.indexOf("#");n>=0&&(e.hash=t.substring(n),t=t.substring(0,n));let i=t.indexOf("?");i>=0&&(e.search=t.substring(i),t=t.substring(0,i)),t&&(e.pathname=t)}return e}function b1(t,e,n,i={}){let{window:r=document.defaultView,v5Compat:a=!1}=i,s=r.history,o="POP",l=null,c=f();c==null&&(c=0,s.replaceState({...s.state,idx:c},""));function f(){return(s.state||{idx:null}).idx}function h(){o="POP";let g=f(),d=g==null?null:g-c;c=g,l&&l({action:o,location:E.location,delta:d})}function u(g,d){o="PUSH";let v=sm(g)?g:Cd(E.location,g,d);n&&n(v,g),c=f()+1;let S=om(v,c),M=E.createHref(v.mask||v);try{s.pushState(S,"",M)}catch(A){if(A instanceof DOMException&&A.name==="DataCloneError")throw A;r.location.assign(M)}a&&l&&l({action:o,location:E.location,delta:1})}function m(g,d){o="REPLACE";let v=sm(g)?g:Cd(E.location,g,d);n&&n(v,g),c=f();let S=om(v,c),M=E.createHref(v.mask||v);s.replaceState(S,"",M),a&&l&&l({action:o,location:E.location,delta:0})}function x(g){return w1(r,g)}let E={get action(){return o},get location(){return t(r,s)},listen(g){if(l)throw new Error("A history only accepts one active listener");return r.addEventListener(am,h),l=g,()=>{r.removeEventListener(am,h),l=null}},createHref(g){return e(r,g)},createURL:x,encodeLocation(g){let d=x(g);return{pathname:d.pathname,search:d.search,hash:d.hash}},push:u,replace:m,go(g){return s.go(g)}};return E}function w1(t,e,n=!1){let i="http://localhost";t&&(i=t.location.origin!=="null"?t.location.origin:t.location.href),gt(i,"No window.location.(origin|href) available to create URL");let r=typeof e=="string"?e:Ks(e);return r=r.replace(/ $/,"%20"),!n&&R_.test(r)&&(r=i+r),new URL(r,i)}function P_(t,e,n="/"){return T1(t,e,n,!1)}function T1(t,e,n,i,r){let a=typeof e=="string"?Jr(e):e,s=Bi(a.pathname||"/",n);if(s==null)return null;let o=A1(t),l=null,c=k1(s);for(let f=0;l==null&&f<o.length;++f)l=O1(o[f],c,i);return l}function A1(t){let e=N_(t);return C1(e),e}function N_(t,e=[],n=[],i="",r=!1){let a=(s,o,l=r,c)=>{let f={relativePath:c===void 0?s.path||"":c,caseSensitive:s.caseSensitive===!0,childrenIndex:o,route:s};if(f.relativePath.startsWith("/")){if(!f.relativePath.startsWith(i)&&l)return;gt(f.relativePath.startsWith(i),`Absolute route path "${f.relativePath}" nested under path "${i}" is not valid. An absolute child route path must start with the combined path of all its parent routes.`),f.relativePath=f.relativePath.slice(i.length)}let h=Yn([i,f.relativePath]),u=n.concat(f);s.children&&s.children.length>0&&(gt(s.index!==!0,`Index routes must not have child routes. Please remove all child routes from route path "${h}".`),N_(s.children,e,u,h,l)),!(s.path==null&&!s.index)&&e.push({path:h,score:U1(h,s.index),routesMeta:u.map((m,x)=>{let[E,g]=I_(m.relativePath,m.caseSensitive,x===u.length-1);return{...m,matcher:E,compiledParams:g}})})};return t.forEach((s,o)=>{var l;if(s.path===""||!((l=s.path)!=null&&l.includes("?")))a(s,o);else for(let c of L_(s.path))a(s,o,!0,c)}),e}function L_(t){let e=t.split("/");if(e.length===0)return[];let[n,...i]=e,r=n.endsWith("?"),a=n.replace(/\?$/,"");if(i.length===0)return r?[a,""]:[a];let s=L_(i.join("/")),o=[];return o.push(...s.map(l=>l===""?a:[a,l].join("/"))),r&&o.push(...s),o.map(l=>t.startsWith("/")&&l===""?"/":l)}function C1(t){t.sort((e,n)=>e.score!==n.score?n.score-e.score:F1(e.routesMeta.map(i=>i.childrenIndex),n.routesMeta.map(i=>i.childrenIndex)))}var R1=/^:[\w-]+$/,P1=3,N1=2,L1=1,D1=10,I1=-2,lm=t=>t==="*";function U1(t,e){let n=t.split("/"),i=n.length;return n.some(lm)&&(i+=I1),e&&(i+=N1),n.filter(r=>!lm(r)).reduce((r,a)=>r+(R1.test(a)?P1:a===""?L1:D1),i)}function F1(t,e){return t.length===e.length&&t.slice(0,-1).every((i,r)=>i===e[r])?t[t.length-1]-e[e.length-1]:0}function O1(t,e,n=!1){let{routesMeta:i}=t,r={},a="/",s=[];for(let o=0;o<i.length;++o){let l=i[o],c=o===i.length-1,f=a==="/"?e:e.slice(a.length)||"/",h={path:l.relativePath,caseSensitive:l.caseSensitive,end:c},u=l.matcher&&l.compiledParams?D_(h,f,l.matcher,l.compiledParams):Xl(h,f),m=l.route;if(!u&&c&&n&&!i[i.length-1].route.index&&(u=Xl({path:l.relativePath,caseSensitive:l.caseSensitive,end:!1},f)),!u)return null;Object.assign(r,u.params),s.push({params:r,pathname:Yn([a,u.pathname]),pathnameBase:V1(Yn([a,u.pathnameBase])),route:m}),u.pathnameBase!=="/"&&(a=Yn([a,u.pathnameBase]))}return s}function Xl(t,e){typeof t=="string"&&(t={path:t,caseSensitive:!1,end:!0});let[n,i]=I_(t.path,t.caseSensitive,t.end);return D_(t,e,n,i)}function D_(t,e,n,i){let r=e.match(n);if(!r)return null;let a=r[0],s=a.replace(/(.)\/+$/,"$1"),o=r.slice(1);return{params:i.reduce((c,{paramName:f,isOptional:h},u)=>{if(f==="*"){let x=o[u]||"";s=a.slice(0,a.length-x.length).replace(/(.)\/+$/,"$1")}const m=o[u];return h&&!m?c[f]=void 0:c[f]=(m||"").replace(/%2F/g,"/"),c},{}),pathname:a,pathnameBase:s,pattern:t}}function I_(t,e=!1,n=!0){Zn(t==="*"||!t.endsWith("*")||t.endsWith("/*"),`Route path "${t}" will be treated as if it were "${t.replace(/\*$/,"/*")}" because the \`*\` character must always follow a \`/\` in the pattern. To get rid of this warning, please change the route path to "${t.replace(/\*$/,"/*")}".`);let i=[],r="^"+t.replace(/\/*\*?$/,"").replace(/^\/*/,"/").replace(/[\\.*+^${}|()[\]]/g,"\\$&").replace(/\/:([\w-]+)(\?)?/g,(s,o,l,c,f)=>{if(i.push({paramName:o,isOptional:l!=null}),l){let h=f.charAt(c+s.length);return h&&h!=="/"?"/([^\\/]*)":"(?:/([^\\/]*))?"}return"/([^\\/]+)"}).replace(/\/([\w-]+)\?(\/|$)/g,"(/$1)?$2");return t.endsWith("*")?(i.push({paramName:"*"}),r+=t==="*"||t==="/*"?"(.*)$":"(?:\\/(.+)|\\/*)$"):n?r+="\\/*$":t!==""&&t!=="/"&&(r+="(?:(?=\\/|$))"),[new RegExp(r,e?void 0:"i"),i]}function k1(t){try{return t.split("/").map(e=>decodeURIComponent(e).replace(/\//g,"%2F")).join("/")}catch(e){return Zn(!1,`The URL path "${t}" could not be decoded because it is a malformed URL segment. This is probably due to a bad percent encoding (${e}).`),t}}function Bi(t,e){if(e==="/")return t;if(!t.toLowerCase().startsWith(e.toLowerCase()))return null;let n=e.endsWith("/")?e.length-1:e.length,i=t.charAt(n);return i&&i!=="/"?null:t.slice(n)||"/"}function B1(t,e="/"){let{pathname:n,search:i="",hash:r=""}=typeof t=="string"?Jr(t):t,a;return n?(n=F_(n),n.startsWith("/")?a=cm(n.substring(1),"/"):a=cm(n,e)):a=e,{pathname:a,search:H1(i),hash:G1(r)}}function cm(t,e){let n=$l(e).split("/");return t.split("/").forEach(r=>{r===".."?n.length>1&&n.pop():r!=="."&&n.push(r)}),n.length>1?n.join("/"):"/"}function eu(t,e,n,i){return`Cannot include a '${t}' character in a manually specified \`to.${e}\` field [${JSON.stringify(i)}].  Please separate it out to the \`to.${n}\` field. Alternatively you may provide the full path as a string in <Link to="..."> and the router will parse it for you.`}function z1(t){return t.filter((e,n)=>n===0||e.route.path&&e.route.path.length>0)}function U_(t){let e=z1(t);return e.map((n,i)=>i===e.length-1?n.pathname:n.pathnameBase)}function gh(t,e,n,i=!1){let r;typeof t=="string"?r=Jr(t):(r={...t},gt(!r.pathname||!r.pathname.includes("?"),eu("?","pathname","search",r)),gt(!r.pathname||!r.pathname.includes("#"),eu("#","pathname","hash",r)),gt(!r.search||!r.search.includes("#"),eu("#","search","hash",r)));let a=t===""||r.pathname==="",s=a?"/":r.pathname,o;if(s==null)o=n;else{let h=e.length-1;if(!i&&s.startsWith("..")){let u=s.split("/");for(;u[0]==="..";)u.shift(),h-=1;r.pathname=u.join("/")}o=h>=0?e[h]:"/"}let l=B1(r,o),c=s&&s!=="/"&&s.endsWith("/"),f=(a||s===".")&&n.endsWith("/");return!l.pathname.endsWith("/")&&(c||f)&&(l.pathname+="/"),l}var F_=t=>t.replace(/[\\/]{2,}/g,"/"),Yn=t=>F_(t.join("/")),$l=t=>t.replace(/\/+$/,""),V1=t=>$l(t).replace(/^\/*/,"/"),H1=t=>!t||t==="?"?"":t.startsWith("?")?t:"?"+t,G1=t=>!t||t==="#"?"":t.startsWith("#")?t:"#"+t,W1=class{constructor(t,e,n,i=!1){this.status=t,this.statusText=e||"",this.internal=i,n instanceof Error?(this.data=n.toString(),this.error=n):this.data=n}};function j1(t){return t!=null&&typeof t.status=="number"&&typeof t.statusText=="string"&&typeof t.internal=="boolean"&&"data"in t}function X1(t){let e=t.map(n=>n.route.path).filter(Boolean);return Yn(e)||"/"}var O_=typeof window<"u"&&typeof window.document<"u"&&typeof window.document.createElement<"u";function k_(t,e){let n=t;if(typeof n!="string"||!mh.test(n))return{absoluteURL:void 0,isExternal:!1,to:n};let i=n,r=!1;if(O_)try{let a=new URL(window.location.href),s=R_.test(n)?new URL(S1(n,a.protocol)):new URL(n),o=Bi(s.pathname,e);s.origin===a.origin&&o!=null?n=o+s.search+s.hash:r=!0}catch{Zn(!1,`<Link to="${n}"> contains an invalid URL which will probably break when clicked - please update to a valid URL path.`)}return{absoluteURL:i,isExternal:r,to:n}}Object.getOwnPropertyNames(Object.prototype).sort().join("\0");var B_=["POST","PUT","PATCH","DELETE"];new Set(B_);var $1=["GET",...B_];new Set($1);var q1=["about:","blob:","chrome:","chrome-untrusted:","content:","data:","devtools:","file:","filesystem:","javascript:"];function Y1(t){try{return q1.includes(new URL(t).protocol)}catch{return!1}}var Ja=z.createContext(null);Ja.displayName="DataRouter";var xc=z.createContext(null);xc.displayName="DataRouterState";var z_=z.createContext(!1);function K1(){return z.useContext(z_)}var V_=z.createContext({isTransitioning:!1});V_.displayName="ViewTransition";var Z1=z.createContext(new Map);Z1.displayName="Fetchers";var Q1=z.createContext(null);Q1.displayName="Await";var Fn=z.createContext(null);Fn.displayName="Navigation";var ro=z.createContext(null);ro.displayName="Location";var Gi=z.createContext({outlet:null,matches:[],isDataRoute:!1});Gi.displayName="Route";var _h=z.createContext(null);_h.displayName="RouteError";var H_="REACT_ROUTER_ERROR",J1="REDIRECT",eS="ROUTE_ERROR_RESPONSE";function tS(t){if(t.startsWith(`${H_}:${J1}:{`))try{let e=JSON.parse(t.slice(28));if(typeof e=="object"&&e&&typeof e.status=="number"&&typeof e.statusText=="string"&&typeof e.location=="string"&&typeof e.reloadDocument=="boolean"&&typeof e.replace=="boolean")return e}catch{}}function nS(t){if(t.startsWith(`${H_}:${eS}:{`))try{let e=JSON.parse(t.slice(40));if(typeof e=="object"&&e&&typeof e.status=="number"&&typeof e.statusText=="string")return new W1(e.status,e.statusText,e.data)}catch{}}function iS(t,{relative:e}={}){gt(ao(),"useHref() may be used only in the context of a <Router> component.");let{basename:n,navigator:i}=z.useContext(Fn),{hash:r,pathname:a,search:s}=so(t,{relative:e}),o=a;return n!=="/"&&(o=a==="/"?n:Yn([n,a])),i.createHref({pathname:o,search:s,hash:r})}function ao(){return z.useContext(ro)!=null}function xi(){return gt(ao(),"useLocation() may be used only in the context of a <Router> component."),z.useContext(ro).location}var G_="You should call navigate() in a React.useEffect(), not when your component is first rendered.";function W_(t){z.useContext(Fn).static||z.useLayoutEffect(t)}function rS(){let{isDataRoute:t}=z.useContext(Gi);return t?_S():aS()}function aS(){gt(ao(),"useNavigate() may be used only in the context of a <Router> component.");let t=z.useContext(Ja),{basename:e,navigator:n}=z.useContext(Fn),{matches:i}=z.useContext(Gi),{pathname:r}=xi(),a=JSON.stringify(U_(i)),s=z.useRef(!1);return W_(()=>{s.current=!0}),z.useCallback((l,c={})=>{if(Zn(s.current,G_),!s.current)return;if(typeof l=="number"){n.go(l);return}let f=gh(l,JSON.parse(a),r,c.relative==="path");t==null&&e!=="/"&&(f.pathname=f.pathname==="/"?e:Yn([e,f.pathname])),(c.replace?n.replace:n.push)(f,c.state,c)},[e,n,a,r,t])}z.createContext(null);function so(t,{relative:e}={}){let{matches:n}=z.useContext(Gi),{pathname:i}=xi(),r=JSON.stringify(U_(n));return z.useMemo(()=>gh(t,JSON.parse(r),i,e==="path"),[t,r,i,e])}function sS(t,e){return j_(t,e)}function j_(t,e,n){var g;gt(ao(),"useRoutes() may be used only in the context of a <Router> component.");let{navigator:i}=z.useContext(Fn),{matches:r}=z.useContext(Gi),a=r[r.length-1],s=a?a.params:{},o=a?a.pathname:"/",l=a?a.pathnameBase:"/",c=a&&a.route;{let d=c&&c.path||"";$_(o,!c||d.endsWith("*")||d.endsWith("*?"),`You rendered descendant <Routes> (or called \`useRoutes()\`) at "${o}" (under <Route path="${d}">) but the parent route path has no trailing "*". This means if you navigate deeper, the parent won't match anymore and therefore the child routes will never render.

Please change the parent <Route path="${d}"> to <Route path="${d==="/"?"*":`${d}/*`}">.`)}let f=xi(),h;if(e){let d=typeof e=="string"?Jr(e):e;gt(l==="/"||((g=d.pathname)==null?void 0:g.startsWith(l)),`When overriding the location using \`<Routes location>\` or \`useRoutes(routes, location)\`, the location pathname must begin with the portion of the URL pathname that was matched by all parent routes. The current pathname base is "${l}" but pathname "${d.pathname}" was given in the \`location\` prop.`),h=d}else h=f;let u=h.pathname||"/",m=u;if(l!=="/"){let d=l.replace(/^\//,"").split("/");m="/"+u.replace(/^\//,"").split("/").slice(d.length).join("/")}let x=n&&n.state.matches.length?n.state.matches.map(d=>Object.assign(d,{route:n.manifest[d.route.id]||d.route})):P_(t,{pathname:m});Zn(c||x!=null,`No routes matched location "${h.pathname}${h.search}${h.hash}" `),Zn(x==null||x[x.length-1].route.element!==void 0||x[x.length-1].route.Component!==void 0||x[x.length-1].route.lazy!==void 0,`Matched leaf route at location "${h.pathname}${h.search}${h.hash}" does not have an element or Component. This means it will render an <Outlet /> with a null value by default resulting in an "empty" page.`);let E=dS(x&&x.map(d=>Object.assign({},d,{params:Object.assign({},s,d.params),pathname:Yn([l,i.encodeLocation?i.encodeLocation(d.pathname.replace(/%/g,"%25").replace(/\?/g,"%3F").replace(/#/g,"%23")).pathname:d.pathname]),pathnameBase:d.pathnameBase==="/"?l:Yn([l,i.encodeLocation?i.encodeLocation(d.pathnameBase.replace(/%/g,"%25").replace(/\?/g,"%3F").replace(/#/g,"%23")).pathname:d.pathnameBase])})),r,n);return e&&E?z.createElement(ro.Provider,{value:{location:{pathname:"/",search:"",hash:"",state:null,key:"default",mask:void 0,...h},navigationType:"POP"}},E):E}function oS(){let t=gS(),e=j1(t)?`${t.status} ${t.statusText}`:t instanceof Error?t.message:JSON.stringify(t),n=t instanceof Error?t.stack:null,i="rgba(200,200,200, 0.5)",r={padding:"0.5rem",backgroundColor:i},a={padding:"2px 4px",backgroundColor:i},s=null;return console.error("Error handled by React Router default ErrorBoundary:",t),s=z.createElement(z.Fragment,null,z.createElement("p",null,"💿 Hey developer 👋"),z.createElement("p",null,"You can provide a way better UX than this when your app throws errors by providing your own ",z.createElement("code",{style:a},"ErrorBoundary")," or"," ",z.createElement("code",{style:a},"errorElement")," prop on your route.")),z.createElement(z.Fragment,null,z.createElement("h2",null,"Unexpected Application Error!"),z.createElement("h3",{style:{fontStyle:"italic"}},e),n?z.createElement("pre",{style:r},n):null,s)}var lS=z.createElement(oS,null),X_=class extends z.Component{constructor(t){super(t),this.state={location:t.location,revalidation:t.revalidation,error:t.error}}static getDerivedStateFromError(t){return{error:t}}static getDerivedStateFromProps(t,e){return e.location!==t.location||e.revalidation!=="idle"&&t.revalidation==="idle"?{error:t.error,location:t.location,revalidation:t.revalidation}:{error:t.error!==void 0?t.error:e.error,location:e.location,revalidation:t.revalidation||e.revalidation}}componentDidCatch(t,e){this.props.onError?this.props.onError(t,e):console.error("React Router caught the following error during render",t)}render(){let t=this.state.error;if(this.context&&typeof t=="object"&&t&&"digest"in t&&typeof t.digest=="string"){const n=nS(t.digest);n&&(t=n)}let e=t!==void 0?z.createElement(Gi.Provider,{value:this.props.routeContext},z.createElement(_h.Provider,{value:t,children:this.props.component})):this.props.children;return this.context?z.createElement(cS,{error:t},e):e}};X_.contextType=z_;var tu=new WeakMap;function cS({children:t,error:e}){let{basename:n}=z.useContext(Fn);if(typeof e=="object"&&e&&"digest"in e&&typeof e.digest=="string"){let i=tS(e.digest);if(i){let r=tu.get(e);if(r)throw r;let a=k_(i.location,n),s=a.absoluteURL||a.to;if(Y1(s))throw new Error("Invalid redirect location");if(O_&&!tu.get(e))if(a.isExternal||i.reloadDocument)window.location.href=s;else{const o=Promise.resolve().then(()=>window.__reactRouterDataRouter.navigate(a.to,{replace:i.replace}));throw tu.set(e,o),o}return z.createElement("meta",{httpEquiv:"refresh",content:`0;url=${s}`})}}return t}function uS({routeContext:t,match:e,children:n}){let i=z.useContext(Ja);return i&&i.static&&i.staticContext&&(e.route.errorElement||e.route.ErrorBoundary)&&(i.staticContext._deepestRenderedBoundaryId=e.route.id),z.createElement(Gi.Provider,{value:t},n)}function dS(t,e=[],n){let i=n==null?void 0:n.state;if(t==null){if(!i)return null;if(i.errors)t=i.matches;else if(e.length===0&&!i.initialized&&i.matches.length>0)t=i.matches;else return null}let r=t,a=i==null?void 0:i.errors;if(a!=null){let f=r.findIndex(h=>h.route.id&&(a==null?void 0:a[h.route.id])!==void 0);gt(f>=0,`Could not find a matching route for errors on route IDs: ${Object.keys(a).join(",")}`),r=r.slice(0,Math.min(r.length,f+1))}let s=!1,o=-1;if(n&&i){s=i.renderFallback;for(let f=0;f<r.length;f++){let h=r[f];if((h.route.HydrateFallback||h.route.hydrateFallbackElement)&&(o=f),h.route.id){let{loaderData:u,errors:m}=i,x=h.route.loader&&!u.hasOwnProperty(h.route.id)&&(!m||m[h.route.id]===void 0);if(h.route.lazy||x){n.isStatic&&(s=!0),o>=0?r=r.slice(0,o+1):r=[r[0]];break}}}}let l=n==null?void 0:n.onError,c=i&&l?(f,h)=>{var u,m;l(f,{location:i.location,params:((m=(u=i.matches)==null?void 0:u[0])==null?void 0:m.params)??{},pattern:X1(i.matches),errorInfo:h})}:void 0;return r.reduceRight((f,h,u)=>{let m,x=!1,E=null,g=null;i&&(m=a&&h.route.id?a[h.route.id]:void 0,E=h.route.errorElement||lS,s&&(o<0&&u===0?($_("route-fallback",!1,"No `HydrateFallback` element provided to render during initial hydration"),x=!0,g=null):o===u&&(x=!0,g=h.route.hydrateFallbackElement||null)));let d=e.concat(r.slice(0,u+1)),v=()=>{let S;return m?S=E:x?S=g:h.route.Component?S=z.createElement(h.route.Component,null):h.route.element?S=h.route.element:S=f,z.createElement(uS,{match:h,routeContext:{outlet:f,matches:d,isDataRoute:i!=null},children:S})};return i&&(h.route.ErrorBoundary||h.route.errorElement||u===0)?z.createElement(X_,{location:i.location,revalidation:i.revalidation,component:E,error:m,children:v(),routeContext:{outlet:null,matches:d,isDataRoute:!0},onError:c}):v()},null)}function xh(t){return`${t} must be used within a data router.  See https://reactrouter.com/en/main/routers/picking-a-router.`}function fS(t){let e=z.useContext(Ja);return gt(e,xh(t)),e}function hS(t){let e=z.useContext(xc);return gt(e,xh(t)),e}function pS(t){let e=z.useContext(Gi);return gt(e,xh(t)),e}function vh(t){let e=pS(t),n=e.matches[e.matches.length-1];return gt(n.route.id,`${t} can only be used on routes that contain a unique "id"`),n.route.id}function mS(){return vh("useRouteId")}function gS(){var i;let t=z.useContext(_h),e=hS("useRouteError"),n=vh("useRouteError");return t!==void 0?t:(i=e.errors)==null?void 0:i[n]}function _S(){let{router:t}=fS("useNavigate"),e=vh("useNavigate"),n=z.useRef(!1);return W_(()=>{n.current=!0}),z.useCallback(async(r,a={})=>{Zn(n.current,G_),n.current&&(typeof r=="number"?await t.navigate(r):await t.navigate(r,{fromRouteId:e,...a}))},[t,e])}var um={};function $_(t,e,n){!e&&!um[t]&&(um[t]=!0,Zn(!1,n))}z.memo(xS);function xS({routes:t,manifest:e,future:n,state:i,isStatic:r,onError:a}){return j_(t,void 0,{manifest:e,state:i,isStatic:r,onError:a,future:n})}function Lr(t){gt(!1,"A <Route> is only ever to be used as the child of <Routes> element, never rendered directly. Please wrap your <Route> in a <Routes>.")}function vS({basename:t="/",children:e=null,location:n,navigationType:i="POP",navigator:r,static:a=!1,useTransitions:s}){gt(!ao(),"You cannot render a <Router> inside another <Router>. You should never have more than one in your app.");let o=t.replace(/^\/*/,"/"),l=z.useMemo(()=>({basename:o,navigator:r,static:a,useTransitions:s,future:{}}),[o,r,a,s]);typeof n=="string"&&(n=Jr(n));let{pathname:c="/",search:f="",hash:h="",state:u=null,key:m="default",mask:x}=n,E=z.useMemo(()=>{let g=Bi(c,o);return g==null?null:{location:{pathname:g,search:f,hash:h,state:u,key:m,mask:x},navigationType:i}},[o,c,f,h,u,m,i,x]);return Zn(E!=null,`<Router basename="${o}"> is not able to match the URL "${c}${f}${h}" because it does not start with the basename, so the <Router> won't render anything.`),E==null?null:z.createElement(Fn.Provider,{value:l},z.createElement(ro.Provider,{children:e,value:E}))}function yS({children:t,location:e}){return sS(Rd(t),e)}function Rd(t,e=[]){let n=[];return z.Children.forEach(t,(i,r)=>{if(!z.isValidElement(i))return;let a=[...e,r];if(i.type===z.Fragment){n.push.apply(n,Rd(i.props.children,a));return}gt(i.type===Lr,`[${typeof i.type=="string"?i.type:i.type.name}] is not a <Route> component. All component children of <Routes> must be a <Route> or <React.Fragment>`),gt(!i.props.index||!i.props.children,"An index route cannot have child routes.");let s={id:i.props.id||a.join("-"),caseSensitive:i.props.caseSensitive,element:i.props.element,Component:i.props.Component,index:i.props.index,path:i.props.path,middleware:i.props.middleware,loader:i.props.loader,action:i.props.action,hydrateFallbackElement:i.props.hydrateFallbackElement,HydrateFallback:i.props.HydrateFallback,errorElement:i.props.errorElement,ErrorBoundary:i.props.ErrorBoundary,hasErrorBoundary:i.props.hasErrorBoundary===!0||i.props.ErrorBoundary!=null||i.props.errorElement!=null,shouldRevalidate:i.props.shouldRevalidate,handle:i.props.handle,lazy:i.props.lazy};i.props.children&&(s.children=Rd(i.props.children,a)),n.push(s)}),n}var pl="get",ml="application/x-www-form-urlencoded";function vc(t){return typeof HTMLElement<"u"&&t instanceof HTMLElement}function SS(t){return vc(t)&&t.tagName.toLowerCase()==="button"}function MS(t){return vc(t)&&t.tagName.toLowerCase()==="form"}function ES(t){return vc(t)&&t.tagName.toLowerCase()==="input"}function bS(t){return!!(t.metaKey||t.altKey||t.ctrlKey||t.shiftKey)}function wS(t,e){return t.button===0&&(!e||e==="_self")&&!bS(t)}var No=null;function TS(){if(No===null)try{new FormData(document.createElement("form"),0),No=!1}catch{No=!0}return No}var AS=new Set(["application/x-www-form-urlencoded","multipart/form-data","text/plain"]);function nu(t){return t!=null&&!AS.has(t)?(Zn(!1,`"${t}" is not a valid \`encType\` for \`<Form>\`/\`<fetcher.Form>\` and will default to "${ml}"`),null):t}function CS(t,e){let n,i,r,a,s;if(MS(t)){let o=t.getAttribute("action");i=o?Bi(o,e):null,n=t.getAttribute("method")||pl,r=nu(t.getAttribute("enctype"))||ml,a=new FormData(t)}else if(SS(t)||ES(t)&&(t.type==="submit"||t.type==="image")){let o=t.form;if(o==null)throw new Error('Cannot submit a <button> or <input type="submit"> without a <form>');let l=t.getAttribute("formaction")||o.getAttribute("action");if(i=l?Bi(l,e):null,n=t.getAttribute("formmethod")||o.getAttribute("method")||pl,r=nu(t.getAttribute("formenctype"))||nu(o.getAttribute("enctype"))||ml,a=new FormData(o,t),!TS()){let{name:c,type:f,value:h}=t;if(f==="image"){let u=c?`${c}.`:"";a.append(`${u}x`,"0"),a.append(`${u}y`,"0")}else c&&a.append(c,h)}}else{if(vc(t))throw new Error('Cannot submit element that is not <form>, <button>, or <input type="submit|image">');n=pl,i=null,r=ml,s=t}return a&&r==="text/plain"&&(s=a,a=void 0),{action:i,method:n.toLowerCase(),encType:r,formData:a,body:s}}Object.getOwnPropertyNames(Object.prototype).sort().join("\0");function yh(t,e){if(t===!1||t===null||typeof t>"u")throw new Error(e)}function q_(t,e,n,i){let r=typeof t=="string"?new URL(t,typeof window>"u"?"server://singlefetch/":window.location.origin):t;return n?r.pathname.endsWith("/")?r.pathname=`${r.pathname}_.${i}`:r.pathname=`${r.pathname}.${i}`:r.pathname==="/"?r.pathname=`_root.${i}`:e&&Bi(r.pathname,e)==="/"?r.pathname=`${$l(e)}/_root.${i}`:r.pathname=`${$l(r.pathname)}.${i}`,r}async function RS(t,e){if(t.id in e)return e[t.id];try{let n=await import(t.module);return e[t.id]=n,n}catch(n){return console.error(`Error loading route module \`${t.module}\`, reloading page...`),console.error(n),window.__reactRouterContext&&window.__reactRouterContext.isSpaMode,window.location.reload(),new Promise(()=>{})}}function PS(t){return t==null?!1:t.href==null?t.rel==="preload"&&typeof t.imageSrcSet=="string"&&typeof t.imageSizes=="string":typeof t.rel=="string"&&typeof t.href=="string"}async function NS(t,e,n){let i=await Promise.all(t.map(async r=>{let a=e.routes[r.route.id];if(a){let s=await RS(a,n);return s.links?s.links():[]}return[]}));return US(i.flat(1).filter(PS).filter(r=>r.rel==="stylesheet"||r.rel==="preload").map(r=>r.rel==="stylesheet"?{...r,rel:"prefetch",as:"style"}:{...r,rel:"prefetch"}))}function dm(t,e,n,i,r,a){let s=(l,c)=>n[c]?l.route.id!==n[c].route.id:!0,o=(l,c)=>{var f;return n[c].pathname!==l.pathname||((f=n[c].route.path)==null?void 0:f.endsWith("*"))&&n[c].params["*"]!==l.params["*"]};return a==="assets"?e.filter((l,c)=>s(l,c)||o(l,c)):a==="data"?e.filter((l,c)=>{var h;let f=i.routes[l.route.id];if(!f||!f.hasLoader)return!1;if(s(l,c)||o(l,c))return!0;if(l.route.shouldRevalidate){let u=l.route.shouldRevalidate({currentUrl:new URL(r.pathname+r.search+r.hash,window.origin),currentParams:((h=n[0])==null?void 0:h.params)||{},nextUrl:new URL(t,window.origin),nextParams:l.params,defaultShouldRevalidate:!0});if(typeof u=="boolean")return u}return!0}):[]}function LS(t,e,{includeHydrateFallback:n}={}){return DS(t.map(i=>{let r=e.routes[i.route.id];if(!r)return[];let a=[r.module];return r.clientActionModule&&(a=a.concat(r.clientActionModule)),r.clientLoaderModule&&(a=a.concat(r.clientLoaderModule)),n&&r.hydrateFallbackModule&&(a=a.concat(r.hydrateFallbackModule)),r.imports&&(a=a.concat(r.imports)),a}).flat(1))}function DS(t){return[...new Set(t)]}function IS(t){let e={},n=Object.keys(t).sort();for(let i of n)e[i]=t[i];return e}function US(t,e){let n=new Set;return new Set(e),t.reduce((i,r)=>{let a=JSON.stringify(IS(r));return n.has(a)||(n.add(a),i.push({key:a,link:r})),i},[])}function Sh(){let t=z.useContext(Ja);return yh(t,"You must render this element inside a <DataRouterContext.Provider> element"),t}function FS(){let t=z.useContext(xc);return yh(t,"You must render this element inside a <DataRouterStateContext.Provider> element"),t}var Mh=z.createContext(void 0);Mh.displayName="FrameworkContext";function yc(){let t=z.useContext(Mh);return yh(t,"You must render this element inside a <HydratedRouter> element"),t}function OS(t,e){let n=z.useContext(Mh),[i,r]=z.useState(!1),[a,s]=z.useState(!1),{onFocus:o,onBlur:l,onMouseEnter:c,onMouseLeave:f,onTouchStart:h}=e,u=z.useRef(null);z.useEffect(()=>{if(t==="render"&&s(!0),t==="viewport"){let E=d=>{d.forEach(v=>{s(v.isIntersecting)})},g=new IntersectionObserver(E,{threshold:.5});return u.current&&g.observe(u.current),()=>{g.disconnect()}}},[t]),z.useEffect(()=>{if(i){let E=setTimeout(()=>{s(!0)},100);return()=>{clearTimeout(E)}}},[i]);let m=()=>{r(!0)},x=()=>{r(!1),s(!1)};return n?t!=="intent"?[a,u,{}]:[a,u,{onFocus:us(o,m),onBlur:us(l,x),onMouseEnter:us(c,m),onMouseLeave:us(f,x),onTouchStart:us(h,m)}]:[!1,u,{}]}function us(t,e){return n=>{t&&t(n),n.defaultPrevented||e(n)}}function kS({page:t,...e}){let n=K1(),{nonce:i}=yc(),{router:r}=Sh(),a=z.useMemo(()=>P_(r.routes,t,r.basename),[r.routes,t,r.basename]);return a?(e.nonce==null&&i&&(e={...e,nonce:i}),n?z.createElement(zS,{page:t,matches:a,...e}):z.createElement(VS,{page:t,matches:a,...e})):null}function BS(t){let{manifest:e,routeModules:n}=yc(),[i,r]=z.useState([]);return z.useEffect(()=>{let a=!1;return NS(t,e,n).then(s=>{a||r(s)}),()=>{a=!0}},[t,e,n]),i}function zS({page:t,matches:e,...n}){let i=xi(),{future:r}=yc(),{basename:a}=Sh(),s=z.useMemo(()=>{if(t===i.pathname+i.search+i.hash)return[];let o=q_(t,a,r.v8_trailingSlashAwareDataRequests,"rsc"),l=!1,c=[];for(let f of e)typeof f.route.shouldRevalidate=="function"?l=!0:c.push(f.route.id);return l&&c.length>0&&o.searchParams.set("_routes",c.join(",")),[o.pathname+o.search]},[a,r.v8_trailingSlashAwareDataRequests,t,i,e]);return z.createElement(z.Fragment,null,s.map(o=>z.createElement("link",{key:o,rel:"prefetch",as:"fetch",href:o,...n})))}function VS({page:t,matches:e,...n}){let i=xi(),{future:r,manifest:a,routeModules:s}=yc(),{basename:o}=Sh(),{loaderData:l,matches:c}=FS(),f=z.useMemo(()=>dm(t,e,c,a,i,"data"),[t,e,c,a,i]),h=z.useMemo(()=>dm(t,e,c,a,i,"assets"),[t,e,c,a,i]),u=z.useMemo(()=>{if(t===i.pathname+i.search+i.hash)return[];let E=new Set,g=!1;if(e.forEach(v=>{var M;let S=a.routes[v.route.id];!S||!S.hasLoader||(!f.some(A=>A.route.id===v.route.id)&&v.route.id in l&&((M=s[v.route.id])!=null&&M.shouldRevalidate)||S.hasClientLoader?g=!0:E.add(v.route.id))}),E.size===0)return[];let d=q_(t,o,r.v8_trailingSlashAwareDataRequests,"data");return g&&E.size>0&&d.searchParams.set("_routes",e.filter(v=>E.has(v.route.id)).map(v=>v.route.id).join(",")),[d.pathname+d.search]},[o,r.v8_trailingSlashAwareDataRequests,l,i,a,f,e,t,s]),m=z.useMemo(()=>LS(h,a),[h,a]),x=BS(h);return z.createElement(z.Fragment,null,u.map(E=>z.createElement("link",{key:E,rel:"prefetch",as:"fetch",href:E,...n})),m.map(E=>z.createElement("link",{key:E,rel:"modulepreload",href:E,...n})),x.map(({key:E,link:g})=>z.createElement("link",{key:E,nonce:n.nonce,...g,crossOrigin:g.crossOrigin??n.crossOrigin})))}function HS(...t){return e=>{t.forEach(n=>{typeof n=="function"?n(e):n!=null&&(n.current=e)})}}var GS=typeof window<"u"&&typeof window.document<"u"&&typeof window.document.createElement<"u";try{GS&&(window.__reactRouterVersion="7.18.1")}catch{}function WS({basename:t,children:e,useTransitions:n,window:i}){let r=z.useRef();r.current==null&&(r.current=M1({window:i,v5Compat:!0}));let a=r.current,[s,o]=z.useState({action:a.action,location:a.location}),l=z.useCallback(c=>{n===!1?o(c):z.startTransition(()=>o(c))},[n]);return z.useLayoutEffect(()=>a.listen(l),[a,l]),z.createElement(vS,{basename:t,children:e,location:s.location,navigationType:s.action,navigator:a,useTransitions:n})}var Qt=z.forwardRef(function({onClick:e,discover:n="render",prefetch:i="none",relative:r,reloadDocument:a,replace:s,mask:o,state:l,target:c,to:f,preventScrollReset:h,viewTransition:u,defaultShouldRevalidate:m,...x},E){let{basename:g,navigator:d,useTransitions:v}=z.useContext(Fn),S=typeof f=="string"&&mh.test(f),M=k_(f,g);f=M.to;let A=iS(f,{relative:r}),T=xi(),w=null;if(o){let k=gh(o,[],T.mask?T.mask.pathname:"/",!0);g!=="/"&&(k.pathname=k.pathname==="/"?g:Yn([g,k.pathname])),w=d.createHref(k)}let[_,C,P]=OS(i,x),N=$S(f,{replace:s,mask:o,state:l,target:c,preventScrollReset:h,relative:r,viewTransition:u,defaultShouldRevalidate:m,useTransitions:v});function F(k){e&&e(k),k.defaultPrevented||N(k)}let q=!(M.isExternal||a),ie=z.createElement("a",{...x,...P,href:(q?w:void 0)||M.absoluteURL||A,onClick:q?F:e,ref:HS(E,C),target:c,"data-discover":!S&&n==="render"?"true":void 0});return _&&!S?z.createElement(z.Fragment,null,ie,z.createElement(kS,{page:A})):ie});Qt.displayName="Link";var ar=z.forwardRef(function({"aria-current":e="page",caseSensitive:n=!1,className:i="",end:r=!1,style:a,to:s,viewTransition:o,children:l,...c},f){let h=so(s,{relative:c.relative}),u=xi(),m=z.useContext(xc),{navigator:x,basename:E}=z.useContext(Fn),g=m!=null&&QS(h)&&o===!0,d=x.encodeLocation?x.encodeLocation(h).pathname:h.pathname,v=u.pathname,S=m&&m.navigation&&m.navigation.location?m.navigation.location.pathname:null;n||(v=v.toLowerCase(),S=S?S.toLowerCase():null,d=d.toLowerCase()),S&&E&&(S=Bi(S,E)||S);const M=d!=="/"&&d.endsWith("/")?d.length-1:d.length;let A=v===d||!r&&v.startsWith(d)&&v.charAt(M)==="/",T=S!=null&&(S===d||!r&&S.startsWith(d)&&S.charAt(d.length)==="/"),w={isActive:A,isPending:T,isTransitioning:g},_=A?e:void 0,C;typeof i=="function"?C=i(w):C=[i,A?"active":null,T?"pending":null,g?"transitioning":null].filter(Boolean).join(" ");let P=typeof a=="function"?a(w):a;return z.createElement(Qt,{...c,"aria-current":_,className:C,ref:f,style:P,to:s,viewTransition:o},typeof l=="function"?l(w):l)});ar.displayName="NavLink";var jS=z.forwardRef(({discover:t="render",fetcherKey:e,navigate:n,reloadDocument:i,replace:r,state:a,method:s=pl,action:o,onSubmit:l,relative:c,preventScrollReset:f,viewTransition:h,defaultShouldRevalidate:u,...m},x)=>{let{useTransitions:E}=z.useContext(Fn),g=KS(),d=ZS(o,{relative:c}),v=s.toLowerCase()==="get"?"get":"post",S=typeof o=="string"&&mh.test(o),M=A=>{if(l&&l(A),A.defaultPrevented)return;A.preventDefault();let T=A.nativeEvent.submitter,w=(T==null?void 0:T.getAttribute("formmethod"))||s,_=()=>g(T||A.currentTarget,{fetcherKey:e,method:w,navigate:n,replace:r,state:a,relative:c,preventScrollReset:f,viewTransition:h,defaultShouldRevalidate:u});E&&n!==!1?z.startTransition(()=>_()):_()};return z.createElement("form",{ref:x,method:v,action:d,onSubmit:i?l:M,...m,"data-discover":!S&&t==="render"?"true":void 0})});jS.displayName="Form";function XS(t){return`${t} must be used within a data router.  See https://reactrouter.com/en/main/routers/picking-a-router.`}function Y_(t){let e=z.useContext(Ja);return gt(e,XS(t)),e}function $S(t,{target:e,replace:n,mask:i,state:r,preventScrollReset:a,relative:s,viewTransition:o,defaultShouldRevalidate:l,useTransitions:c}={}){let f=rS(),h=xi(),u=so(t,{relative:s});return z.useCallback(m=>{if(wS(m,e)){m.preventDefault();let x=n!==void 0?n:Ks(h)===Ks(u),E=()=>f(t,{replace:x,mask:i,state:r,preventScrollReset:a,relative:s,viewTransition:o,defaultShouldRevalidate:l});c?z.startTransition(()=>E()):E()}},[h,f,u,n,i,r,e,t,a,s,o,l,c])}var qS=0,YS=()=>`__${String(++qS)}__`;function KS(){let{router:t}=Y_("useSubmit"),{basename:e}=z.useContext(Fn),n=mS(),i=t.fetch,r=t.navigate;return z.useCallback(async(a,s={})=>{let{action:o,method:l,encType:c,formData:f,body:h}=CS(a,e);if(s.navigate===!1){let u=s.fetcherKey||YS();await i(u,n,s.action||o,{defaultShouldRevalidate:s.defaultShouldRevalidate,preventScrollReset:s.preventScrollReset,formData:f,body:h,formMethod:s.method||l,formEncType:s.encType||c,flushSync:s.flushSync})}else await r(s.action||o,{defaultShouldRevalidate:s.defaultShouldRevalidate,preventScrollReset:s.preventScrollReset,formData:f,body:h,formMethod:s.method||l,formEncType:s.encType||c,replace:s.replace,state:s.state,fromRouteId:n,flushSync:s.flushSync,viewTransition:s.viewTransition})},[i,r,e,n])}function ZS(t,{relative:e}={}){let{basename:n}=z.useContext(Fn),i=z.useContext(Gi);gt(i,"useFormAction must be used inside a RouteContext");let[r]=i.matches.slice(-1),a={...so(t||".",{relative:e})},s=xi();if(t==null){a.search=s.search;let o=new URLSearchParams(a.search),l=o.getAll("index");if(l.some(f=>f==="")){o.delete("index"),l.filter(h=>h).forEach(h=>o.append("index",h));let f=o.toString();a.search=f?`?${f}`:""}}return(!t||t===".")&&r.route.index&&(a.search=a.search?a.search.replace(/^\?/,"?index&"):"?index"),n!=="/"&&(a.pathname=a.pathname==="/"?n:Yn([n,a.pathname])),Ks(a)}function QS(t,{relative:e}={}){let n=z.useContext(V_);gt(n!=null,"`useViewTransitionState` must be used within `react-router-dom`'s `RouterProvider`.  Did you accidentally import `RouterProvider` from `react-router`?");let{basename:i}=Y_("useViewTransitionState"),r=so(t,{relative:e});if(!n.isTransitioning)return!1;let a=Bi(n.currentLocation.pathname,i)||n.currentLocation.pathname,s=Bi(n.nextLocation.pathname,i)||n.nextLocation.pathname;return Xl(r.pathname,s)!=null||Xl(r.pathname,a)!=null}/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var JS={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const eM=t=>t.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase().trim(),ft=(t,e)=>{const n=z.forwardRef(({color:i="currentColor",size:r=24,strokeWidth:a=2,absoluteStrokeWidth:s,className:o="",children:l,...c},f)=>z.createElement("svg",{ref:f,...JS,width:r,height:r,stroke:i,strokeWidth:s?Number(a)*24/Number(r):a,className:["lucide",`lucide-${eM(t)}`,o].join(" "),...c},[...e.map(([h,u])=>z.createElement(h,u)),...Array.isArray(l)?l:[l]]));return n.displayName=`${t}`,n};/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ti=ft("ArrowRight",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]]);/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const K_=ft("Award",[["circle",{cx:"12",cy:"8",r:"6",key:"1vp47v"}],["path",{d:"M15.477 12.89 17 22l-5-3-5 3 1.523-9.11",key:"em7aur"}]]);/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ql=ft("CheckCircle2",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]]);/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const tM=ft("ChevronDown",[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]]);/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const nM=ft("ChevronRight",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]]);/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const iM=ft("Clock",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["polyline",{points:"12 6 12 12 16 14",key:"68esgv"}]]);/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const rM=ft("Droplets",[["path",{d:"M7 16.3c2.2 0 4-1.83 4-4.05 0-1.16-.57-2.26-1.71-3.19S7.29 6.75 7 5.3c-.29 1.45-1.14 2.84-2.29 3.76S3 11.1 3 12.25c0 2.22 1.8 4.05 4 4.05z",key:"1ptgy4"}],["path",{d:"M12.56 6.6A10.97 10.97 0 0 0 14 3.02c.5 2.5 2 4.9 4 6.5s3 3.5 3 5.5a6.98 6.98 0 0 1-11.91 4.97",key:"1sl1rz"}]]);/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Z_=ft("Globe",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20",key:"13o1zl"}],["path",{d:"M2 12h20",key:"9i4pu4"}]]);/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const aM=ft("Image",[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",ry:"2",key:"1m3agn"}],["circle",{cx:"9",cy:"9",r:"2",key:"af1f0g"}],["path",{d:"m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21",key:"1xmnt7"}]]);/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Q_=ft("Leaf",[["path",{d:"M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10Z",key:"nnexq3"}],["path",{d:"M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12",key:"mt58a7"}]]);/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const J_=ft("Mail",[["rect",{width:"20",height:"16",x:"2",y:"4",rx:"2",key:"18n3k1"}],["path",{d:"m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7",key:"1ocrg3"}]]);/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ex=ft("MapPin",[["path",{d:"M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z",key:"2oe9fu"}],["circle",{cx:"12",cy:"10",r:"3",key:"ilqhr7"}]]);/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const sM=ft("Menu",[["line",{x1:"4",x2:"20",y1:"12",y2:"12",key:"1e0a9i"}],["line",{x1:"4",x2:"20",y1:"6",y2:"6",key:"1owob3"}],["line",{x1:"4",x2:"20",y1:"18",y2:"18",key:"yk5zj1"}]]);/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Eh=ft("MessageCircle",[["path",{d:"M7.9 20A9 9 0 1 0 4 16.1L2 22Z",key:"vv11sd"}]]);/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const tx=ft("Phone",[["path",{d:"M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z",key:"foiqr5"}]]);/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const oM=ft("Quote",[["path",{d:"M3 21c3 0 7-1 7-8V5c0-1.25-.756-2.017-2-2H4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2 1 0 1 0 1 1v1c0 1-1 2-2 2s-1 .008-1 1.031V20c0 1 0 1 1 1z",key:"4rm80e"}],["path",{d:"M15 21c3 0 7-1 7-8V5c0-1.25-.757-2.017-2-2h-4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2h.75c0 2.25.25 4-2.75 4v3c0 1 0 1 1 1z",key:"10za9r"}]]);/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const nx=ft("RotateCcw",[["path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8",key:"1357e3"}],["path",{d:"M3 3v5h5",key:"1xhq8a"}]]);/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const fm=ft("Send",[["path",{d:"m22 2-7 20-4-9-9-4Z",key:"1q3vgg"}],["path",{d:"M22 2 11 13",key:"nzbqef"}]]);/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const li=ft("Shield",[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}]]);/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const hm=ft("Star",[["polygon",{points:"12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2",key:"8f66p6"}]]);/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const lM=ft("Thermometer",[["path",{d:"M14 4v10.54a4 4 0 1 1-4 0V4a2 2 0 0 1 4 0Z",key:"17jzev"}]]);/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const cM=ft("Timer",[["line",{x1:"10",x2:"14",y1:"2",y2:"2",key:"14vaq8"}],["line",{x1:"12",x2:"15",y1:"14",y2:"11",key:"17fdiu"}],["circle",{cx:"12",cy:"14",r:"8",key:"1e1u0o"}]]);/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ix=ft("Users",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["path",{d:"M16 3.13a4 4 0 0 1 0 7.75",key:"1da9ce"}]]);/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const uM=ft("X",[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]]);/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const rx=ft("Zap",[["polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2",key:"45s27k"}]]),Y={site:{logo_url:"",site_name:"Dove Gel Packs",tagline:"Superior Cooling Technology",whatsapp_number:"https://wa.me/message/dovegelpacks",whatsapp_channel:"https://www.whatsapp.com/channel/0029Vapq05N3AzNLpO2tkO1x",email:"info@dovegelpacks.com",phone:"+1 (800) DOVE-GEL",phone_href:"tel:+18003683435",address:"Made in India — Worldwide Shipping",footer_tagline:"Superior cooling technology engineered for medical, food, pharmaceutical, and packaging applications worldwide. Made in India.",facebook_url:"https://www.facebook.com/dove.gelpacks",instagram_url:"https://www.instagram.com/dovegelpacks/",linkedin_url:"https://www.linkedin.com/company/doveindustries/",nav_btn_quote:"Get a Quote",footer_brand_name:"Dove Gel Packs",footer_quick_links_title:"Quick Links",footer_products_title:"Products",footer_contact_title:"Contact Us",footer_whatsapp_label:"WhatsApp Direct",footer_rights:"All rights reserved."},hero:{badge_text:"20+ Years of Cooling Innovation • Made in India",headline_line1:"Superior",headline_line2:"Cooling.",headline_line3:"Engineered",headline_line4:"For Excellence.",subheadline:'DOVE Ice Gel Packs are independently lab-tested, non-toxic, and stay cold up to <strong class="text-ice-300">65% longer</strong> than regular ice.',btn_products_text:"View Products",btn_whatsapp_text:"Buy on WhatsApp",cta_headline:"Ready to Keep Your Products Perfectly Cold?",cta_sub:"Bulk orders, custom sizes, OEM — we deliver worldwide.",cta_btn_whatsapp:"Buy on WhatsApp",cta_btn_quote:"Get a Quote",cta_title_highlight:"Perfectly Cold?"},stats:[{icon:"Timer",value:"24h",label:"Max Cooling",color:"text-sky-400"},{icon:"Droplets",value:"100%",label:"Leak-Proof",color:"text-cyan-400"},{icon:"RotateCcw",value:"∞",label:"Reusable",color:"text-teal-400"},{icon:"Award",value:"20+",label:"Years Trust",color:"text-blue-400"}],big_stats:[{value:"20+",label:"Years in Cold Chain",sub:"Since 2003"},{value:"40+",label:"Countries Served",sub:"Globally trusted"},{value:"500+",label:"Happy Clients",sub:"B2B & B2C"},{value:"65%",label:"Longer Cooling",sub:"vs regular ice"}],services:[{icon:"Shield",text:"Leak-Proof Seal"},{icon:"Zap",text:"Quick Freeze"},{icon:"Thermometer",text:"−18°C Rated"},{icon:"RotateCcw",text:"Reusable"}],home_products:[{id:1,name:"Ice Gel Packs / Pouches",desc:"50g–500g. Lab-tested, non-toxic. Stays cold 65% longer than regular ice.",icon:"🧊",tag:"Most Popular",grad:"from-ice-600 to-ice-500",sizes:"50g · 100g · 150g · 200g · 250g · 400g · 500g",image:"",sort_order:1},{id:2,name:"Ice Gel Container",desc:"Rigid HDPE containers. 300g–700g. Vacuum-sealed, ideal for seafood & pharma.",icon:"📦",tag:"For Export",grad:"from-cyan-600 to-teal-500",sizes:"300g · 500g · 700g",image:"",sort_order:2},{id:3,name:"Ice Gel Sheets",desc:"12-cell & 24-cell. Trimmable to any size. Eco-friendly & reusable.",icon:"🧱",tag:"Flexible",grad:"from-teal-600 to-cyan-500",sizes:"12-Cell · 24-Cell",image:"",sort_order:3},{id:4,name:"Thermocol Insulated Box",desc:"EPS insulated boxes 3L–150L. Water-resistant, vermin-proof.",icon:"🏗️",tag:"Heavy Duty",grad:"from-arctic-600 to-teal-500",sizes:"3L · 5L · 7L · 10L · 15L · 20L · 36L · 55L · 120L · 150L",image:"",sort_order:4}],product_categories:[{id:"pouches",label:"Pouches",title:"ICE GEL PACKS",description:"Durable reusable gel pack pouches 50g–500g. Non-toxic, lab-tested, stays cold 65% longer.",accent_from:"#1e7ec8",accent_to:"#0db2e8",sort_order:1,specs:["32°F & 10°F formulations","Lab-tested & certified","Non-toxic, food-safe","Leak-proof & reusable","Custom sizes available"],variants:[{id:1,category_id:"pouches",name:"50 Gram",image:"",sort_order:1},{id:2,category_id:"pouches",name:"100 Gram",image:"",sort_order:2},{id:3,category_id:"pouches",name:"150 Gram",image:"",sort_order:3},{id:4,category_id:"pouches",name:"200 Gram",image:"",sort_order:4},{id:5,category_id:"pouches",name:"250 Gram",image:"",sort_order:5},{id:6,category_id:"pouches",name:"400 Gram",image:"",sort_order:6},{id:7,category_id:"pouches",name:"500 Gram",image:"",sort_order:7}]},{id:"container",label:"Container",title:"ICE GEL CONTAINER",description:"Rigid HDPE containers with vacuum-sealed fill. Ideal for seafood export and pharmaceutical cold chains.",accent_from:"#0d9488",accent_to:"#06b6d4",sort_order:2,specs:["Rigid HDPE material","300g, 500g, 700g","Vacuum-sealed fill","White colour","Made in India"],variants:[{id:8,category_id:"container",name:"300 Gram",image:"",sort_order:1},{id:9,category_id:"container",name:"500 Gram",image:"",sort_order:2},{id:10,category_id:"container",name:"700 Gram",image:"",sort_order:3}]},{id:"sheets",label:"Sheets",title:"ICE GEL SHEETS",description:"Multi-cell flexible sheets trimmable to any size. Works ambient, refrigerated, or frozen.",accent_from:"#0d7a6e",accent_to:"#14b8a6",sort_order:3,specs:["12-cell & 24-cell configs","Trimmable to any size","Ambient / fridge / frozen","Eco-friendly & reusable","Lightweight design"],variants:[{id:11,category_id:"sheets",name:"12 Cell",image:"",sort_order:1},{id:12,category_id:"sheets",name:"24 Cell",image:"",sort_order:2}]},{id:"thermocol",label:"Thermocol Box",title:"THERMOCOL INSULATED BOX",description:"EPS boxes 3L–150L. Water-resistant, vermin-proof. Rotational moulded versions available.",accent_from:"#1a4e8a",accent_to:"#2e7ce0",sort_order:4,specs:["3L to 150L range","EPS construction","Water-resistant","Drain plug (RM version)","Custom sizes available"],variants:[{id:13,category_id:"thermocol",name:"3 Litre",image:"",sort_order:1},{id:14,category_id:"thermocol",name:"5 Litre",image:"",sort_order:2},{id:15,category_id:"thermocol",name:"7 Litre",image:"",sort_order:3},{id:16,category_id:"thermocol",name:"10 Litre",image:"",sort_order:4},{id:17,category_id:"thermocol",name:"15 Litre",image:"",sort_order:5},{id:18,category_id:"thermocol",name:"20 Litre",image:"",sort_order:6},{id:19,category_id:"thermocol",name:"36 Litre",image:"",sort_order:7},{id:20,category_id:"thermocol",name:"55 Litre",image:"",sort_order:8},{id:21,category_id:"thermocol",name:"120 Litre",image:"",sort_order:9},{id:22,category_id:"thermocol",name:"150 Litre",image:"",sort_order:10}]}],home_applications:[{id:1,title:"Food & Seafood",icon:"🐟",desc:"Frozen goods, fresh produce, seafood, dairy",sort_order:1},{id:2,title:"Pharmaceutical",icon:"💊",desc:"Vaccines, medicines, biologics, lab samples",sort_order:2},{id:3,title:"Medical / Healthcare",icon:"🏥",desc:"Surgical items, blood transport, clinical use",sort_order:3},{id:4,title:"Fruits & Vegetables",icon:"🥦",desc:"Post-harvest freshness, farm-to-table delivery",sort_order:4},{id:5,title:"Cold Chain Logistics",icon:"🚛",desc:"Long-haul, last-mile, international shipment",sort_order:5},{id:6,title:"Packaging & Retail",icon:"📦",desc:"E-commerce, subscription boxes, gifting",sort_order:6}],testimonials:[{id:1,name:"Rahul Mehta",role:"Operations Head, FreshExpress Logistics",text:"Dove Gel Packs have completely transformed our cold chain. Leak-proof, every single time. We've cut our product loss by over 30% since switching.",rating:5,sort_order:1},{id:2,name:"Dr. Priya Nair",role:"Procurement Manager, Apollo Pharma",text:"The pharmaceutical-grade packs meet all regulatory requirements. Temperature stability is excellent. Dove delivers exactly what we need.",rating:5,sort_order:2},{id:3,name:"James Thornton",role:"Founder, ChillBox UK",text:"We switched to Dove Gel Sheets for our subscription meal kits. Customers love that they're reusable. Our reviews went up significantly.",rating:5,sort_order:3}],applications:[{id:1,title:"Medical & Healthcare",description:"Precise temperature control for medications, blood samples, surgical instruments and recovery kits.",img:"https://images.pexels.com/photos/3825586/pexels-photo-3825586.jpeg?auto=compress&cs=tinysrgb&w=600",tag:"Healthcare",details:["Blood sample transport","Medication storage","Post-surgical recovery","Emergency medical kits"],sort_order:1},{id:2,title:"Pharmaceutical Cold Chain",description:"Maintain strict thermal conditions for vaccines, biologics and temperature-sensitive drugs during transit.",img:"https://images.pexels.com/photos/3683041/pexels-photo-3683041.jpeg?auto=compress&cs=tinysrgb&w=600",tag:"Pharma",details:["Vaccine transport","Biologics storage","Drug stability testing","Clinical trial samples"],sort_order:2},{id:3,title:"Food Preservation",description:"Keep fresh produce, meat, dairy and perishables at safe temperatures from farm to table.",img:"https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=600",tag:"Food Safety",details:["Fresh produce","Meat & seafood","Dairy products","Baked goods"],sort_order:3},{id:4,title:"Packaging & Shipping",description:"Versatile cooling inserts for any insulated box or mailer — e-commerce and subscription fulfilment.",img:"https://images.pexels.com/photos/4393668/pexels-photo-4393668.jpeg?auto=compress&cs=tinysrgb&w=600",tag:"Packaging",details:["E-commerce fulfillment","Meal kit delivery","Subscription boxes","Direct-to-consumer"],sort_order:4},{id:5,title:"Transport & Logistics",description:"Lightweight and durable for long-haul delivery, freight and last-mile cold-chain operations.",img:"https://images.pexels.com/photos/906982/pexels-photo-906982.jpeg?auto=compress&cs=tinysrgb&w=600",tag:"Logistics",details:["Long-haul trucking","Last-mile delivery","Courier services","Air freight"],sort_order:5}],about_page:{hero_title_line1:"Two Decades of",hero_title_line2:"Cold Chain",hero_title_line3:"Excellence",hero_sub:"Since 2003, Dove Ice Gel Packs has been at the forefront of cooling technology — delivering durable, leak-proof solutions trusted by medical professionals, food distributors, and logistics companies worldwide.",story_title:"A Journey of Innovation",values_title:"What Drives Us Forward",features_title:"Built to the Highest Standards",features_sub:"Every Dove Gel Pack undergoes rigorous quality control before leaving our facility.",cta_headline:"Partner with Dove Gel Packs",cta_sub:"Join 500+ businesses worldwide who trust our cooling solutions.",about_intro_title:"India's Trusted",about_intro_highlight:"Cold Chain Partner",about_intro_p1:"Founded over two decades ago, Dove Industries manufactures premium ice gel packs, containers, sheets, and insulated thermocol boxes — all independently lab-tested and non-toxic.",about_intro_p2:"Our products are a proven substitute for dry ice, keeping items fresh up to 24 hours and performing in ambient, refrigerated, or frozen environments.",hero_badge:"About Dove Gel Packs",story_badge:"Our Story",values_badge:"Our Values",features_badge:"",btn_products:"View Products",btn_contact:"Contact Us",cta_btn_contact:"Get in Touch",cta_btn_products:"View Products"},about_snippets:[{icon:"Shield",title:"Non-Toxic Formula",desc:"Safe for food contact, FDA compliant gel"},{icon:"Award",title:"Lab Tested",desc:"Independently certified for performance"},{icon:"Zap",title:"Quick Freeze",desc:"Ready to use in under 60 minutes"},{icon:"RotateCcw",title:"Eco-Friendly",desc:"Reusable, sustainable, zero waste"}],about_stats:[{icon:"Award",value:"20+",label:"Years of Innovation"},{icon:"Globe",value:"40+",label:"Countries Served"},{icon:"Users",value:"500+",label:"Global Clients"},{icon:"RotateCcw",value:"100%",label:"Reusable Products"}],values:[{icon:"Shield",title:"Reliability",desc:"Every pack tested for consistent performance across hundreds of freeze cycles.",color:"from-ice-500 to-ice-400"},{icon:"Zap",title:"Performance",desc:"Engineered for maximum cooling efficiency with quick-freeze capability.",color:"from-cyan-500 to-ice-500"},{icon:"Leaf",title:"Sustainability",desc:"Reusable, eco-conscious design that reduces single-use waste dramatically.",color:"from-teal-500 to-cyan-400"},{icon:"Globe",title:"Global Reach",desc:"Serving clients in 40+ countries with reliable worldwide shipping and support.",color:"from-arctic-500 to-teal-400"}],features:[{text:"Thermoplastic polymer construction for maximum durability"},{text:"Works with all insulated shipping boxes and coolers"},{text:"Non-toxic, food-safe gel formula — FDA compliant"},{text:"Lightweight design reduces shipping costs significantly"},{text:"Available in multiple sizes from 50g to 500g+"},{text:"Custom sizes and branding available for bulk orders"},{text:"Maintains consistent temperature throughout full cooling cycle"},{text:"Quick freezing — ready to use in under 60 minutes"}],certifications:[{name:"FDA Compliant"},{name:"ISO 9001 Certified"},{name:"Food Safe Gel"},{name:"Non-Toxic Formula"}],milestones:[{id:1,year:"2003",title:"Company Founded",desc:"Dove Gel Packs established with a focus on superior cold-chain solutions.",sort_order:1},{id:2,year:"2008",title:"ISO Certification",desc:"Achieved ISO 9001 quality management certification.",sort_order:2},{id:3,year:"2012",title:"Pharmaceutical Grade",desc:"Launched FDA-compliant pharmaceutical-grade gel pack line.",sort_order:3},{id:4,year:"2016",title:"Global Expansion",desc:"Extended distribution to 40+ countries worldwide.",sort_order:4},{id:5,year:"2020",title:"Eco Reusable Line",desc:"Introduced 100% recyclable packaging and enhanced reusable gel formula.",sort_order:5},{id:6,year:"2024",title:"20 Years Strong",desc:"Celebrating two decades of innovation and cold-chain excellence.",sort_order:6}],contact_page:{hero_title_line1:"Let's Talk About",hero_title_line2:"Staying Cold",hero_sub:"Whether you need bulk pricing, custom sizes, technical specifications, or just have a question — our team is ready to help.",help_items:["Bulk order pricing & discounts","Custom sizes & configurations","Pharmaceutical certifications","Technical specifications","Private label & branding","International shipping logistics"],hero_badge:"Contact Us",service_area_label:"Service Area",service_area_value:"Worldwide Shipping Available",response_time_label:"Response Time",response_time_value:"Within 24 business hours",whatsapp_card_title:"WhatsApp",whatsapp_card_sub:"Quick response within minutes",help_heading:"We can help with:",form_title:"Send a Message",form_sub:"Fill in the form and we'll get back to you promptly.",form_name_label:"Full Name *",form_email_label:"Email *",form_company_label:"Company",form_phone_label:"Phone",form_subject_label:"Subject *",form_message_label:"Message *",form_name_ph:"Your full name",form_email_ph:"your@company.com",form_company_ph:"Company name (optional)",form_phone_ph:"+1 (000) 000-0000",form_message_ph:"Describe your cooling needs — quantities, pack sizes, application, timeline...",form_subjects:[{label:"Bulk Order Inquiry",value:"bulk"},{label:"Custom Size Request",value:"custom"},{label:"Pharmaceutical Grade",value:"pharma"},{label:"Technical Specifications",value:"technical"},{label:"Shipping & Logistics",value:"shipping"},{label:"Other",value:"other"}],form_btn_sending:"Sending...",form_btn_sent:"Message Sent!",form_btn_send:"Send Message",form_success_msg:"Thank you! We will get back to you within 24 hours.",faq_title_line1:"Frequently Asked",faq_title_line2:"Questions",cta_text:"Looking for our product range?",cta_btn:"View All Products →"},faqs:[{id:1,q:"What is the minimum order quantity?",a:"We welcome orders of all sizes. For bulk pricing tiers, please contact us directly.",sort_order:1},{id:2,q:"Are your gel packs food safe?",a:"Yes — all our packs use FDA-compliant, non-toxic gel formulas certified food safe for direct contact applications.",sort_order:2},{id:3,q:"How quickly can gel packs be frozen?",a:"Our packs reach working temperature in under 60 minutes in a standard domestic or commercial freezer.",sort_order:3},{id:4,q:"Do you offer custom sizes and branding?",a:"Absolutely. We offer custom sizes, colours, and private-label printing for bulk orders. Contact us for details.",sort_order:4}],products_page:{hero_badge:"Product Catalog",hero_title_line1:"Premium Cold Chain",hero_title_line2:"Solutions",hero_sub:"4 product lines engineered for every cold-chain application — made in India, trusted worldwide.",btn_whatsapp:"Order via WhatsApp",btn_quote:"Get Bulk Quote",strip_title:"All Product Categories"},applications_page:{hero_badge:"Applications",hero_title_line1:"Trusted Across",hero_title_line2:"Every Industry",hero_sub:"From hospital wards to home delivery — Dove Gel Packs ensure the cold chain stays intact wherever your products travel.",cta_headline:"Don't See Your Industry?",cta_sub:"Our gel packs work wherever temperature control matters. Get in touch for a custom solution.",cta_btn_contact:"Contact Us",cta_btn_products:"View Products"},home_sections:{about_badge:"About Dove Gel Packs",products_badge:"Our Products",products_title_line1:"The Right Pack for",products_title_line2:"Every Need",products_sub:"4 product lines covering every cold-chain application — from small pouches to industrial insulated boxes.",products_btn:"View Full Product Details",applications_badge:"Applications",applications_title_line1:"Trusted Across",applications_title_line2:"Every Industry",applications_sub:"From hospital wards to home delivery — Dove keeps the cold chain intact.",applications_btn:"See All Applications",testimonials_badge:"Testimonials",testimonials_title_line1:"What Our",testimonials_title_line2:"Clients Say"},loaded:!0},ax=z.createContext(Y);function dM(t){const e=t.settings??{},n=(I,J)=>e[I]!==void 0&&e[I]!==""?e[I]:J,i={logo_url:n("logo_url",Y.site.logo_url),site_name:n("site_name",Y.site.site_name),tagline:n("tagline",Y.site.tagline),whatsapp_number:n("whatsapp_number",Y.site.whatsapp_number),whatsapp_channel:n("whatsapp_channel",Y.site.whatsapp_channel),email:n("email",Y.site.email),phone:n("phone",Y.site.phone),phone_href:n("phone_href",Y.site.phone_href),address:n("address",Y.site.address),footer_tagline:n("footer_tagline",Y.site.footer_tagline),facebook_url:n("facebook_url",Y.site.facebook_url),instagram_url:n("instagram_url",Y.site.instagram_url),linkedin_url:n("linkedin_url",Y.site.linkedin_url),nav_btn_quote:n("nav_btn_quote",Y.site.nav_btn_quote),footer_brand_name:n("footer_brand_name",Y.site.footer_brand_name),footer_quick_links_title:n("footer_quick_links_title",Y.site.footer_quick_links_title),footer_products_title:n("footer_products_title",Y.site.footer_products_title),footer_contact_title:n("footer_contact_title",Y.site.footer_contact_title),footer_whatsapp_label:n("footer_whatsapp_label",Y.site.footer_whatsapp_label),footer_rights:n("footer_rights",Y.site.footer_rights)},r={badge_text:n("hero_badge_text",Y.hero.badge_text),headline_line1:n("hero_headline_line1",Y.hero.headline_line1),headline_line2:n("hero_headline_line2",Y.hero.headline_line2),headline_line3:n("hero_headline_line3",Y.hero.headline_line3),headline_line4:n("hero_headline_line4",Y.hero.headline_line4),subheadline:n("hero_subheadline",Y.hero.subheadline),btn_products_text:n("hero_btn_products_text",Y.hero.btn_products_text),btn_whatsapp_text:n("hero_btn_whatsapp_text",Y.hero.btn_whatsapp_text),cta_headline:n("hero_cta_headline",Y.hero.cta_headline),cta_sub:n("hero_cta_sub",Y.hero.cta_sub),cta_btn_whatsapp:n("hero_cta_btn_whatsapp",Y.hero.cta_btn_whatsapp),cta_btn_quote:n("hero_cta_btn_quote",Y.hero.cta_btn_quote),cta_title_highlight:n("home_cta_title_highlight",Y.hero.cta_title_highlight)},a={hero_title_line1:n("about_hero_title_line1",Y.about_page.hero_title_line1),hero_title_line2:n("about_hero_title_line2",Y.about_page.hero_title_line2),hero_title_line3:n("about_hero_title_line3",Y.about_page.hero_title_line3),hero_sub:n("about_hero_sub",Y.about_page.hero_sub),hero_badge:n("about_hero_badge",Y.about_page.hero_badge),story_badge:n("about_story_badge",Y.about_page.story_badge),values_badge:n("about_values_badge",Y.about_page.values_badge),features_badge:n("about_features_badge",Y.about_page.features_badge),story_title:n("about_story_title",Y.about_page.story_title),values_title:n("about_values_title",Y.about_page.values_title),features_title:n("about_features_title",Y.about_page.features_title),features_sub:n("about_features_sub",Y.about_page.features_sub),cta_headline:n("about_cta_headline",Y.about_page.cta_headline),cta_sub:n("about_cta_sub",Y.about_page.cta_sub),about_intro_title:n("about_intro_title",Y.about_page.about_intro_title),about_intro_highlight:n("about_intro_highlight",Y.about_page.about_intro_highlight),about_intro_p1:n("about_intro_p1",Y.about_page.about_intro_p1),about_intro_p2:n("about_intro_p2",Y.about_page.about_intro_p2),btn_products:n("about_btn_products",Y.about_page.btn_products),btn_contact:n("about_btn_contact",Y.about_page.btn_contact),cta_btn_contact:n("about_cta_btn_contact",Y.about_page.cta_btn_contact),cta_btn_products:n("about_cta_btn_products",Y.about_page.cta_btn_products)};let s=Y.contact_page.help_items;try{const I=JSON.parse(n("contact_help_items",""));Array.isArray(I)&&I.length&&(s=I)}catch{}let o=Y.contact_page.form_subjects;try{const I=JSON.parse(n("contact_form_subjects",""));Array.isArray(I)&&I.length&&(o=I)}catch{}const l={hero_title_line1:n("contact_hero_title_line1",Y.contact_page.hero_title_line1),hero_title_line2:n("contact_hero_title_line2",Y.contact_page.hero_title_line2),hero_sub:n("contact_hero_sub",Y.contact_page.hero_sub),help_items:s,hero_badge:n("contact_hero_badge",Y.contact_page.hero_badge),service_area_label:n("contact_service_area_label",Y.contact_page.service_area_label),service_area_value:n("contact_service_area_value",Y.contact_page.service_area_value),response_time_label:n("contact_response_time_label",Y.contact_page.response_time_label),response_time_value:n("contact_response_time_value",Y.contact_page.response_time_value),whatsapp_card_title:n("contact_whatsapp_card_title",Y.contact_page.whatsapp_card_title),whatsapp_card_sub:n("contact_whatsapp_card_sub",Y.contact_page.whatsapp_card_sub),help_heading:n("contact_help_heading",Y.contact_page.help_heading),form_title:n("contact_form_title",Y.contact_page.form_title),form_sub:n("contact_form_sub",Y.contact_page.form_sub),form_name_label:n("contact_form_name_label",Y.contact_page.form_name_label),form_email_label:n("contact_form_email_label",Y.contact_page.form_email_label),form_company_label:n("contact_form_company_label",Y.contact_page.form_company_label),form_phone_label:n("contact_form_phone_label",Y.contact_page.form_phone_label),form_subject_label:n("contact_form_subject_label",Y.contact_page.form_subject_label),form_message_label:n("contact_form_message_label",Y.contact_page.form_message_label),form_name_ph:n("contact_form_name_ph",Y.contact_page.form_name_ph),form_email_ph:n("contact_form_email_ph",Y.contact_page.form_email_ph),form_company_ph:n("contact_form_company_ph",Y.contact_page.form_company_ph),form_phone_ph:n("contact_form_phone_ph",Y.contact_page.form_phone_ph),form_message_ph:n("contact_form_message_ph",Y.contact_page.form_message_ph),form_subjects:o,form_btn_sending:n("contact_form_btn_sending",Y.contact_page.form_btn_sending),form_btn_sent:n("contact_form_btn_sent",Y.contact_page.form_btn_sent),form_btn_send:n("contact_form_btn_send",Y.contact_page.form_btn_send),form_success_msg:n("contact_form_success_msg",Y.contact_page.form_success_msg),faq_title_line1:n("contact_faq_title_line1",Y.contact_page.faq_title_line1),faq_title_line2:n("contact_faq_title_line2",Y.contact_page.faq_title_line2),cta_text:n("contact_cta_text",Y.contact_page.cta_text),cta_btn:n("contact_cta_btn",Y.contact_page.cta_btn)},c=t.home_products??[],f=c.length>0?c.map(I=>({...I,desc:I.description??I.desc??""})):Y.home_products,h=t.home_applications??[],u=h.length>0?h.map(I=>({...I,desc:I.description??I.desc??""})):Y.home_applications,m=t.milestones??[],x=m.length>0?m.map(I=>({...I,desc:I.description??I.desc??""})):Y.milestones,E=t.faqs??[],g=E.length>0?E.map(I=>({...I,q:I.question??I.q??"",a:I.answer??I.a??""})):Y.faqs,d=t.product_categories??[],v=d.length>0?d.map(I=>({...I,specs:Array.isArray(I.specs)?I.specs:typeof I.specs=="string"?JSON.parse(I.specs):[]})):Y.product_categories,S=t.applications??[],M=S.length>0?S.map(I=>({...I,details:Array.isArray(I.details)?I.details:typeof I.details=="string"?JSON.parse(I.details):[]})):Y.applications,A=t.testimonials??[],T=A.length>0?A:Y.testimonials,w={hero_badge:n("products_hero_badge",Y.products_page.hero_badge),hero_title_line1:n("products_hero_title_line1",Y.products_page.hero_title_line1),hero_title_line2:n("products_hero_title_line2",Y.products_page.hero_title_line2),hero_sub:n("products_hero_sub",Y.products_page.hero_sub),btn_whatsapp:n("products_btn_whatsapp",Y.products_page.btn_whatsapp),btn_quote:n("products_btn_quote",Y.products_page.btn_quote),strip_title:n("products_strip_title",Y.products_page.strip_title)},_={hero_badge:n("applications_hero_badge",Y.applications_page.hero_badge),hero_title_line1:n("applications_hero_title_line1",Y.applications_page.hero_title_line1),hero_title_line2:n("applications_hero_title_line2",Y.applications_page.hero_title_line2),hero_sub:n("applications_hero_sub",Y.applications_page.hero_sub),cta_headline:n("applications_cta_headline",Y.applications_page.cta_headline),cta_sub:n("applications_cta_sub",Y.applications_page.cta_sub),cta_btn_contact:n("applications_cta_btn_contact",Y.applications_page.cta_btn_contact),cta_btn_products:n("applications_cta_btn_products",Y.applications_page.cta_btn_products)},C={about_badge:n("home_about_badge",Y.home_sections.about_badge),products_badge:n("home_products_badge",Y.home_sections.products_badge),products_title_line1:n("home_products_title_line1",Y.home_sections.products_title_line1),products_title_line2:n("home_products_title_line2",Y.home_sections.products_title_line2),products_sub:n("home_products_sub",Y.home_sections.products_sub),products_btn:n("home_products_btn",Y.home_sections.products_btn),applications_badge:n("home_applications_badge",Y.home_sections.applications_badge),applications_title_line1:n("home_applications_title_line1",Y.home_sections.applications_title_line1),applications_title_line2:n("home_applications_title_line2",Y.home_sections.applications_title_line2),applications_sub:n("home_applications_sub",Y.home_sections.applications_sub),applications_btn:n("home_applications_btn",Y.home_sections.applications_btn),testimonials_badge:n("home_testimonials_badge",Y.home_sections.testimonials_badge),testimonials_title_line1:n("home_testimonials_title_line1",Y.home_sections.testimonials_title_line1),testimonials_title_line2:n("home_testimonials_title_line2",Y.home_sections.testimonials_title_line2)},P=(I,J)=>{try{const ae=JSON.parse(n(I,""));if(Array.isArray(ae)&&ae.length)return ae}catch{}return J},N=P("stats",Y.stats),F=P("big_stats",Y.big_stats),q=P("services",Y.services),ie=P("about_snippets",Y.about_snippets),k=P("about_stats",Y.about_stats),X=P("values",Y.values),V=P("features",Y.features),O=P("certifications",Y.certifications);return{...Y,site:i,hero:r,about_page:a,contact_page:l,products_page:w,applications_page:_,home_sections:C,stats:N,big_stats:F,services:q,about_snippets:ie,about_stats:k,values:X,features:V,certifications:O,home_products:f,product_categories:v,home_applications:u,testimonials:T,applications:M,milestones:x,faqs:g,loaded:!0}}function fM({children:t}){const[e,n]=z.useState(Y);return z.useEffect(()=>{fetch("./api/content.php").then(i=>i.ok?i.json():null).then(i=>{i&&typeof i=="object"&&n(dM(i))}).catch(()=>{})},[]),p.jsx(ax.Provider,{value:e,children:t})}function br(){return z.useContext(ax)}const pm=[{label:"Home",to:"/"},{label:"Products",to:"/products"},{label:"Applications",to:"/applications"},{label:"About Us",to:"/about"},{label:"Contact",to:"/contact"}];function hM(){const t=br(),{site:e}=t,[n,i]=z.useState(!1),[r,a]=z.useState(!1),s=xi(),o=[{label:"Facebook",href:e.facebook_url,icon:p.jsx("svg",{viewBox:"0 0 24 24",fill:"currentColor",className:"w-4 h-4",children:p.jsx("path",{d:"M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"})})},{label:"WhatsApp",href:e.whatsapp_channel,icon:p.jsx("svg",{viewBox:"0 0 24 24",fill:"currentColor",className:"w-4 h-4",children:p.jsx("path",{d:"M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413z"})})},{label:"Instagram",href:e.instagram_url,icon:p.jsxs("svg",{viewBox:"0 0 24 24",fill:"currentColor",className:"w-4 h-4",children:[p.jsx("rect",{x:"2",y:"2",width:"20",height:"20",rx:"5",ry:"5",fill:"none",stroke:"currentColor",strokeWidth:"2"}),p.jsx("path",{d:"M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z",fill:"none",stroke:"currentColor",strokeWidth:"2"}),p.jsx("line",{x1:"17.5",y1:"6.5",x2:"17.51",y2:"6.5",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"})]})},{label:"LinkedIn",href:e.linkedin_url,icon:p.jsxs("svg",{viewBox:"0 0 24 24",fill:"currentColor",className:"w-4 h-4",children:[p.jsx("path",{d:"M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6zM2 9h4v12H2z"}),p.jsx("circle",{cx:"4",cy:"4",r:"2"})]})}];return z.useEffect(()=>{const l=()=>i(window.scrollY>50);return window.addEventListener("scroll",l,{passive:!0}),()=>window.removeEventListener("scroll",l)},[]),z.useEffect(()=>{a(!1),window.scrollTo(0,0)},[s.pathname]),p.jsxs("nav",{className:`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${n?"py-3 shadow-lg shadow-black/10":"py-5"}`,style:{background:"#ffffff",borderBottom:"1px solid rgba(0,0,0,0.08)"},children:[p.jsxs("div",{className:"max-w-7xl mx-auto px-6 flex items-center justify-between gap-4",children:[p.jsx(ar,{to:"/",className:"flex items-center gap-2.5 group flex-shrink-0",children:p.jsx("img",{src:"/dove-logo.png",alt:"Dove Gel Packs",className:"h-10 object-contain group-hover:scale-105 transition-all duration-300"})}),p.jsx("div",{className:"hidden md:flex items-center gap-0.5 flex-1 justify-center",children:pm.map(l=>p.jsx(ar,{to:l.to,end:l.to==="/",className:({isActive:c})=>`px-3.5 py-2 text-sm font-medium rounded-lg transition-all duration-200 ${c?"text-black bg-[#e8f2fc]":"text-black/70 hover:text-black hover:bg-black/5"}`,children:l.label},l.to))}),p.jsxs("div",{className:"hidden md:flex items-center gap-2 flex-shrink-0",children:[o.map(l=>p.jsx("a",{href:l.href,target:"_blank",rel:"noopener noreferrer","aria-label":l.label,className:"w-8 h-8 flex items-center justify-center rounded-lg text-black/60 hover:text-black hover:bg-black/8 transition-all duration-200",children:l.icon},l.label)),p.jsx("div",{className:"w-px h-5 bg-black/15 mx-1"}),p.jsx(ar,{to:"/contact",className:"glow-button inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-ice-500 text-white font-semibold text-sm hover:bg-ice-400 transition-colors shadow-lg shadow-ice-500/25",children:e.nav_btn_quote})]}),p.jsx("button",{className:"md:hidden p-2 rounded-lg text-black hover:bg-black/5 transition-colors",onClick:()=>a(!r),children:r?p.jsx(uM,{className:"w-6 h-6"}):p.jsx(sM,{className:"w-6 h-6"})})]}),r&&p.jsxs("div",{className:"md:hidden border-t border-black/10 mt-2 px-6 py-4 space-y-1",style:{background:"#ffffff"},children:[pm.map(l=>p.jsx(ar,{to:l.to,end:l.to==="/",onClick:()=>a(!1),className:({isActive:c})=>`block px-4 py-2.5 rounded-xl font-medium transition-colors ${c?"text-black bg-[#e8f2fc]":"text-black/70 hover:text-black hover:bg-black/5"}`,children:l.label},l.to)),p.jsx("div",{className:"flex gap-3 px-4 pt-2",children:o.map(l=>p.jsx("a",{href:l.href,target:"_blank",rel:"noopener noreferrer","aria-label":l.label,className:"w-8 h-8 flex items-center justify-center rounded-lg text-black/60 hover:text-black hover:bg-black/8 transition-all",children:l.icon},l.label))}),p.jsx(ar,{to:"/contact",onClick:()=>a(!1),className:"block mt-2 text-center px-4 py-2.5 rounded-xl bg-ice-500 text-white font-semibold hover:bg-ice-400 transition-colors",children:e.nav_btn_quote})]})]})}function pM({className:t="w-9 h-9"}){return p.jsxs("svg",{viewBox:"0 0 64 64",className:t,xmlns:"http://www.w3.org/2000/svg",children:[p.jsx("rect",{width:"64",height:"64",rx:"12",fill:"url(#logoGrad)"}),p.jsx("defs",{children:p.jsxs("linearGradient",{id:"logoGrad",x1:"0%",y1:"0%",x2:"100%",y2:"100%",children:[p.jsx("stop",{offset:"0%",stopColor:"#1e7ec8"}),p.jsx("stop",{offset:"100%",stopColor:"#0d5ba0"})]})}),p.jsx("path",{d:"M40 11 C36 10, 30 13, 27 18 L13 31 C10 34, 10 40, 14 42 C18 44, 23 42, 25 38 L30 32 L32 39 C33 42, 37 44, 41 43 C45 41, 46 37, 44 34 L42 28 L47 25 C50 23, 51 19, 49 16 C47 13, 43 12, 40 11 Z",fill:"white",opacity:"0.95"}),p.jsx("path",{d:"M14 42 C12 46, 10 48, 8 50 C12 49, 16 47, 18 44 Z",fill:"white",opacity:"0.85"}),p.jsx("path",{d:"M16 43 C15 47, 14 50, 13 52 C16 50, 19 47, 20 44 Z",fill:"white",opacity:"0.7"}),p.jsx("path",{d:"M33 17 C31 20, 30 24, 32 28",stroke:"#1a56a0",strokeWidth:"1.5",fill:"none",strokeLinecap:"round",opacity:"0.6"}),p.jsx("circle",{cx:"44",cy:"17",r:"2",fill:"#1a56a0",opacity:"0.8"}),p.jsx("circle",{cx:"44.5",cy:"16.5",r:"0.7",fill:"white"})]})}const mM=[{label:"Home",to:"/"},{label:"Products",to:"/products"},{label:"Applications",to:"/applications"},{label:"About Us",to:"/about"},{label:"Contact",to:"/contact"}],gM=["Ice Gel Packs / Pouches","Ice Gel Containers (HDPE)","Ice Gel Sheets (12 & 24 cell)","Thermocol Insulated Boxes"];function _M(){const{site:t}=br(),e=[{label:"Facebook",href:t.facebook_url,icon:p.jsx("svg",{viewBox:"0 0 24 24",fill:"currentColor",className:"w-5 h-5",children:p.jsx("path",{d:"M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"})})},{label:"WhatsApp",href:t.whatsapp_channel,icon:p.jsx("svg",{viewBox:"0 0 24 24",fill:"currentColor",className:"w-5 h-5",children:p.jsx("path",{d:"M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413z"})})},{label:"Instagram",href:t.instagram_url,icon:p.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",className:"w-5 h-5",children:[p.jsx("rect",{x:"2",y:"2",width:"20",height:"20",rx:"5",ry:"5"}),p.jsx("path",{d:"M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"}),p.jsx("line",{x1:"17.5",y1:"6.5",x2:"17.51",y2:"6.5",strokeLinecap:"round"})]})},{label:"LinkedIn",href:t.linkedin_url,icon:p.jsxs("svg",{viewBox:"0 0 24 24",fill:"currentColor",className:"w-5 h-5",children:[p.jsx("path",{d:"M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6zM2 9h4v12H2z"}),p.jsx("circle",{cx:"4",cy:"4",r:"2"})]})}];return p.jsx("footer",{className:"relative",style:{background:"linear-gradient(180deg, #030c1e 0%, #051022 100%)",borderTop:"1px solid rgba(13,178,232,0.12)"},children:p.jsxs("div",{className:"max-w-7xl mx-auto px-6 pt-16 pb-8",children:[p.jsxs("div",{className:"grid md:grid-cols-2 lg:grid-cols-4 gap-10 mb-12",children:[p.jsxs("div",{className:"space-y-4",children:[p.jsxs(ar,{to:"/",className:"flex items-center gap-2.5",children:[t.logo_url?p.jsx("img",{src:t.logo_url,alt:t.site_name,className:"w-10 h-10 object-contain"}):p.jsx(pM,{className:"w-10 h-10"}),p.jsx("div",{className:"leading-none",children:p.jsx("span",{className:"font-display font-bold text-white text-lg",children:t.footer_brand_name})})]}),p.jsx("p",{className:"text-ice-200/45 text-sm leading-relaxed max-w-xs",children:t.footer_tagline}),p.jsx("div",{className:"flex gap-2 pt-1",children:e.map(n=>p.jsx("a",{href:n.href,target:"_blank",rel:"noopener noreferrer","aria-label":n.label,className:"w-9 h-9 rounded-xl bg-ice-500/8 border border-ice-500/15 flex items-center justify-center text-ice-300/50 hover:text-ice-300 hover:bg-ice-500/15 hover:border-ice-500/30 transition-all duration-200",children:n.icon},n.label))})]}),p.jsxs("div",{children:[p.jsx("h4",{className:"font-display font-semibold text-white text-sm mb-5 uppercase tracking-widest",children:t.footer_quick_links_title}),p.jsx("ul",{className:"space-y-2.5",children:mM.map(n=>p.jsx("li",{children:p.jsxs(ar,{to:n.to,className:"text-ice-200/45 text-sm hover:text-ice-300 transition-colors inline-flex items-center gap-1.5 group",children:[p.jsx("span",{className:"w-1 h-1 rounded-full bg-ice-500/30 group-hover:bg-ice-400 transition-colors"}),n.label]})},n.to))})]}),p.jsxs("div",{children:[p.jsx("h4",{className:"font-display font-semibold text-white text-sm mb-5 uppercase tracking-widest",children:t.footer_products_title}),p.jsx("ul",{className:"space-y-2.5",children:gM.map(n=>p.jsxs("li",{className:"text-ice-200/45 text-sm flex items-start gap-1.5",children:[p.jsx("span",{className:"w-1 h-1 rounded-full bg-ice-500/25 mt-1.5 flex-shrink-0"}),n]},n))})]}),p.jsxs("div",{children:[p.jsx("h4",{className:"font-display font-semibold text-white text-sm mb-5 uppercase tracking-widest",children:t.footer_contact_title}),p.jsxs("div",{className:"space-y-3.5",children:[p.jsxs("a",{href:`mailto:${t.email}`,className:"flex items-center gap-3 text-ice-200/45 hover:text-ice-300 transition-colors text-sm",children:[p.jsx(J_,{className:"w-4 h-4 text-ice-400 flex-shrink-0"}),t.email]}),p.jsxs("a",{href:t.whatsapp_number,target:"_blank",rel:"noopener noreferrer",className:"flex items-center gap-3 text-ice-200/45 hover:text-ice-300 transition-colors text-sm",children:[p.jsx(tx,{className:"w-4 h-4 text-ice-400 flex-shrink-0"}),t.footer_whatsapp_label]}),p.jsxs("p",{className:"flex items-start gap-3 text-ice-200/45 text-sm",children:[p.jsx(ex,{className:"w-4 h-4 text-ice-400 flex-shrink-0 mt-0.5"}),t.address]})]})]})]}),p.jsxs("div",{className:"border-t border-ice-500/10 pt-6 flex flex-col sm:flex-row items-center justify-between gap-3",children:[p.jsxs("p",{className:"text-ice-200/30 text-xs",children:["© ",new Date().getFullYear()," ",t.site_name,". ",t.footer_rights]}),p.jsx("div",{className:"flex gap-4",children:e.map(n=>p.jsx("a",{href:n.href,target:"_blank",rel:"noopener noreferrer","aria-label":n.label,className:"text-ice-300/30 hover:text-ice-300 transition-colors",children:n.icon},n.label))})]})]})})}function xM(){const{site:t}=br();return p.jsxs("a",{href:t.whatsapp_number,target:"_blank",rel:"noopener noreferrer",className:"fixed bottom-6 right-6 z-50 flex items-center gap-2.5 px-4 py-3 rounded-2xl bg-green-500 text-white font-semibold text-sm shadow-2xl shadow-green-500/40 hover:bg-green-400 hover:shadow-green-400/50 hover:-translate-y-1 transition-all duration-300",children:[p.jsx(Eh,{className:"w-5 h-5"}),p.jsx("span",{className:"hidden sm:inline",children:"WhatsApp Us"})]})}/**
 * @license
 * Copyright 2010-2026 Three.js Authors
 * SPDX-License-Identifier: MIT
 */const bh="185",vM=0,mm=1,yM=2,gl=1,SM=2,Ms=3,yr=0,mn=1,Ai=2,Li=0,Fa=1,gm=2,_m=3,xm=4,MM=5,Ir=100,EM=101,bM=102,wM=103,TM=104,AM=200,CM=201,RM=202,PM=203,Pd=204,Nd=205,NM=206,LM=207,DM=208,IM=209,UM=210,FM=211,OM=212,kM=213,BM=214,Ld=0,Dd=1,Id=2,Xa=3,Ud=4,Fd=5,Od=6,kd=7,sx=0,zM=1,VM=2,hi=0,ox=1,lx=2,cx=3,ux=4,dx=5,fx=6,hx=7,px=300,qr=301,$a=302,iu=303,ru=304,Sc=306,Bd=1e3,Pi=1001,zd=1002,Gt=1003,HM=1004,Lo=1005,Jt=1006,au=1007,Br=1008,Nn=1009,mx=1010,gx=1011,Zs=1012,wh=1013,gi=1014,ci=1015,zi=1016,Th=1017,Ah=1018,Qs=1020,_x=35902,xx=35899,vx=1021,yx=1022,Xn=1023,Vi=1026,zr=1027,Sx=1028,Ch=1029,Yr=1030,Rh=1031,Ph=1033,_l=33776,xl=33777,vl=33778,yl=33779,Vd=35840,Hd=35841,Gd=35842,Wd=35843,jd=36196,Xd=37492,$d=37496,qd=37488,Yd=37489,Yl=37490,Kd=37491,Zd=37808,Qd=37809,Jd=37810,ef=37811,tf=37812,nf=37813,rf=37814,af=37815,sf=37816,of=37817,lf=37818,cf=37819,uf=37820,df=37821,ff=36492,hf=36494,pf=36495,mf=36283,gf=36284,Kl=36285,_f=36286,GM=3200,vm=0,WM=1,sr="",Cn="srgb",Zl="srgb-linear",Ql="linear",tt="srgb",ra=7680,ym=519,jM=512,XM=513,$M=514,Nh=515,qM=516,YM=517,Lh=518,KM=519,Sm=35044,Mm="300 es",ui=2e3,Jl=2001;function ZM(t){for(let e=t.length-1;e>=0;--e)if(t[e]>=65535)return!0;return!1}function ec(t){return document.createElementNS("http://www.w3.org/1999/xhtml",t)}function QM(){const t=ec("canvas");return t.style.display="block",t}const Em={};function bm(...t){const e="THREE."+t.shift();console.log(e,...t)}function Mx(t){const e=t[0];if(typeof e=="string"&&e.startsWith("TSL:")){const n=t[1];n&&n.isStackTrace?t[0]+=" "+n.getLocation():t[1]='Stack trace not available. Enable "THREE.Node.captureStackTrace" to capture stack traces.'}return t}function De(...t){t=Mx(t);const e="THREE."+t.shift();{const n=t[0];n&&n.isStackTrace?console.warn(n.getError(e)):console.warn(e,...t)}}function Ye(...t){t=Mx(t);const e="THREE."+t.shift();{const n=t[0];n&&n.isStackTrace?console.error(n.getError(e)):console.error(e,...t)}}function Oa(...t){const e=t.join(" ");e in Em||(Em[e]=!0,De(...t))}function JM(t,e,n){return new Promise(function(i,r){function a(){switch(t.clientWaitSync(e,t.SYNC_FLUSH_COMMANDS_BIT,0)){case t.WAIT_FAILED:r();break;case t.TIMEOUT_EXPIRED:setTimeout(a,n);break;default:i()}}setTimeout(a,n)})}const eE={[Ld]:Dd,[Id]:Od,[Ud]:kd,[Xa]:Fd,[Dd]:Ld,[Od]:Id,[kd]:Ud,[Fd]:Xa};class ea{addEventListener(e,n){this._listeners===void 0&&(this._listeners={});const i=this._listeners;i[e]===void 0&&(i[e]=[]),i[e].indexOf(n)===-1&&i[e].push(n)}hasEventListener(e,n){const i=this._listeners;return i===void 0?!1:i[e]!==void 0&&i[e].indexOf(n)!==-1}removeEventListener(e,n){const i=this._listeners;if(i===void 0)return;const r=i[e];if(r!==void 0){const a=r.indexOf(n);a!==-1&&r.splice(a,1)}}dispatchEvent(e){const n=this._listeners;if(n===void 0)return;const i=n[e.type];if(i!==void 0){e.target=this;const r=i.slice(0);for(let a=0,s=r.length;a<s;a++)r[a].call(this,e);e.target=null}}}const Yt=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],su=Math.PI/180,xf=180/Math.PI;function oo(){const t=Math.random()*4294967295|0,e=Math.random()*4294967295|0,n=Math.random()*4294967295|0,i=Math.random()*4294967295|0;return(Yt[t&255]+Yt[t>>8&255]+Yt[t>>16&255]+Yt[t>>24&255]+"-"+Yt[e&255]+Yt[e>>8&255]+"-"+Yt[e>>16&15|64]+Yt[e>>24&255]+"-"+Yt[n&63|128]+Yt[n>>8&255]+"-"+Yt[n>>16&255]+Yt[n>>24&255]+Yt[i&255]+Yt[i>>8&255]+Yt[i>>16&255]+Yt[i>>24&255]).toLowerCase()}function je(t,e,n){return Math.max(e,Math.min(n,t))}function tE(t,e){return(t%e+e)%e}function ou(t,e,n){return(1-n)*t+n*e}function ds(t,e){switch(e.constructor){case Float32Array:return t;case Uint32Array:return t/4294967295;case Uint16Array:return t/65535;case Uint8Array:return t/255;case Int32Array:return Math.max(t/2147483647,-1);case Int16Array:return Math.max(t/32767,-1);case Int8Array:return Math.max(t/127,-1);default:throw new Error("THREE.MathUtils: Invalid component type.")}}function cn(t,e){switch(e.constructor){case Float32Array:return t;case Uint32Array:return Math.round(t*4294967295);case Uint16Array:return Math.round(t*65535);case Uint8Array:return Math.round(t*255);case Int32Array:return Math.round(t*2147483647);case Int16Array:return Math.round(t*32767);case Int8Array:return Math.round(t*127);default:throw new Error("THREE.MathUtils: Invalid component type.")}}const Fh=class Fh{constructor(e=0,n=0){this.x=e,this.y=n}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,n){return this.x=e,this.y=n,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,n){switch(e){case 0:this.x=n;break;case 1:this.y=n;break;default:throw new Error("THREE.Vector2: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("THREE.Vector2: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,n){return this.x=e.x+n.x,this.y=e.y+n.y,this}addScaledVector(e,n){return this.x+=e.x*n,this.y+=e.y*n,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,n){return this.x=e.x-n.x,this.y=e.y-n.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){const n=this.x,i=this.y,r=e.elements;return this.x=r[0]*n+r[3]*i+r[6],this.y=r[1]*n+r[4]*i+r[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,n){return this.x=je(this.x,e.x,n.x),this.y=je(this.y,e.y,n.y),this}clampScalar(e,n){return this.x=je(this.x,e,n),this.y=je(this.y,e,n),this}clampLength(e,n){const i=this.length();return this.divideScalar(i||1).multiplyScalar(je(i,e,n))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){const n=Math.sqrt(this.lengthSq()*e.lengthSq());if(n===0)return Math.PI/2;const i=this.dot(e)/n;return Math.acos(je(i,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const n=this.x-e.x,i=this.y-e.y;return n*n+i*i}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,n){return this.x+=(e.x-this.x)*n,this.y+=(e.y-this.y)*n,this}lerpVectors(e,n,i){return this.x=e.x+(n.x-e.x)*i,this.y=e.y+(n.y-e.y)*i,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,n=0){return this.x=e[n],this.y=e[n+1],this}toArray(e=[],n=0){return e[n]=this.x,e[n+1]=this.y,e}fromBufferAttribute(e,n){return this.x=e.getX(n),this.y=e.getY(n),this}rotateAround(e,n){const i=Math.cos(n),r=Math.sin(n),a=this.x-e.x,s=this.y-e.y;return this.x=a*i-s*r+e.x,this.y=a*r+s*i+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}};Fh.prototype.isVector2=!0;let Ze=Fh;class es{constructor(e=0,n=0,i=0,r=1){this.isQuaternion=!0,this._x=e,this._y=n,this._z=i,this._w=r}static slerpFlat(e,n,i,r,a,s,o){let l=i[r+0],c=i[r+1],f=i[r+2],h=i[r+3],u=a[s+0],m=a[s+1],x=a[s+2],E=a[s+3];if(h!==E||l!==u||c!==m||f!==x){let g=l*u+c*m+f*x+h*E;g<0&&(u=-u,m=-m,x=-x,E=-E,g=-g);let d=1-o;if(g<.9995){const v=Math.acos(g),S=Math.sin(v);d=Math.sin(d*v)/S,o=Math.sin(o*v)/S,l=l*d+u*o,c=c*d+m*o,f=f*d+x*o,h=h*d+E*o}else{l=l*d+u*o,c=c*d+m*o,f=f*d+x*o,h=h*d+E*o;const v=1/Math.sqrt(l*l+c*c+f*f+h*h);l*=v,c*=v,f*=v,h*=v}}e[n]=l,e[n+1]=c,e[n+2]=f,e[n+3]=h}static multiplyQuaternionsFlat(e,n,i,r,a,s){const o=i[r],l=i[r+1],c=i[r+2],f=i[r+3],h=a[s],u=a[s+1],m=a[s+2],x=a[s+3];return e[n]=o*x+f*h+l*m-c*u,e[n+1]=l*x+f*u+c*h-o*m,e[n+2]=c*x+f*m+o*u-l*h,e[n+3]=f*x-o*h-l*u-c*m,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,n,i,r){return this._x=e,this._y=n,this._z=i,this._w=r,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,n=!0){const i=e._x,r=e._y,a=e._z,s=e._order,o=Math.cos,l=Math.sin,c=o(i/2),f=o(r/2),h=o(a/2),u=l(i/2),m=l(r/2),x=l(a/2);switch(s){case"XYZ":this._x=u*f*h+c*m*x,this._y=c*m*h-u*f*x,this._z=c*f*x+u*m*h,this._w=c*f*h-u*m*x;break;case"YXZ":this._x=u*f*h+c*m*x,this._y=c*m*h-u*f*x,this._z=c*f*x-u*m*h,this._w=c*f*h+u*m*x;break;case"ZXY":this._x=u*f*h-c*m*x,this._y=c*m*h+u*f*x,this._z=c*f*x+u*m*h,this._w=c*f*h-u*m*x;break;case"ZYX":this._x=u*f*h-c*m*x,this._y=c*m*h+u*f*x,this._z=c*f*x-u*m*h,this._w=c*f*h+u*m*x;break;case"YZX":this._x=u*f*h+c*m*x,this._y=c*m*h+u*f*x,this._z=c*f*x-u*m*h,this._w=c*f*h-u*m*x;break;case"XZY":this._x=u*f*h-c*m*x,this._y=c*m*h-u*f*x,this._z=c*f*x+u*m*h,this._w=c*f*h+u*m*x;break;default:De("Quaternion: .setFromEuler() encountered an unknown order: "+s)}return n===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,n){const i=n/2,r=Math.sin(i);return this._x=e.x*r,this._y=e.y*r,this._z=e.z*r,this._w=Math.cos(i),this._onChangeCallback(),this}setFromRotationMatrix(e){const n=e.elements,i=n[0],r=n[4],a=n[8],s=n[1],o=n[5],l=n[9],c=n[2],f=n[6],h=n[10],u=i+o+h;if(u>0){const m=.5/Math.sqrt(u+1);this._w=.25/m,this._x=(f-l)*m,this._y=(a-c)*m,this._z=(s-r)*m}else if(i>o&&i>h){const m=2*Math.sqrt(1+i-o-h);this._w=(f-l)/m,this._x=.25*m,this._y=(r+s)/m,this._z=(a+c)/m}else if(o>h){const m=2*Math.sqrt(1+o-i-h);this._w=(a-c)/m,this._x=(r+s)/m,this._y=.25*m,this._z=(l+f)/m}else{const m=2*Math.sqrt(1+h-i-o);this._w=(s-r)/m,this._x=(a+c)/m,this._y=(l+f)/m,this._z=.25*m}return this._onChangeCallback(),this}setFromUnitVectors(e,n){let i=e.dot(n)+1;return i<1e-8?(i=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=i):(this._x=0,this._y=-e.z,this._z=e.y,this._w=i)):(this._x=e.y*n.z-e.z*n.y,this._y=e.z*n.x-e.x*n.z,this._z=e.x*n.y-e.y*n.x,this._w=i),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(je(this.dot(e),-1,1)))}rotateTowards(e,n){const i=this.angleTo(e);if(i===0)return this;const r=Math.min(1,n/i);return this.slerp(e,r),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,n){const i=e._x,r=e._y,a=e._z,s=e._w,o=n._x,l=n._y,c=n._z,f=n._w;return this._x=i*f+s*o+r*c-a*l,this._y=r*f+s*l+a*o-i*c,this._z=a*f+s*c+i*l-r*o,this._w=s*f-i*o-r*l-a*c,this._onChangeCallback(),this}slerp(e,n){let i=e._x,r=e._y,a=e._z,s=e._w,o=this.dot(e);o<0&&(i=-i,r=-r,a=-a,s=-s,o=-o);let l=1-n;if(o<.9995){const c=Math.acos(o),f=Math.sin(c);l=Math.sin(l*c)/f,n=Math.sin(n*c)/f,this._x=this._x*l+i*n,this._y=this._y*l+r*n,this._z=this._z*l+a*n,this._w=this._w*l+s*n,this._onChangeCallback()}else this._x=this._x*l+i*n,this._y=this._y*l+r*n,this._z=this._z*l+a*n,this._w=this._w*l+s*n,this.normalize();return this}slerpQuaternions(e,n,i){return this.copy(e).slerp(n,i)}random(){const e=2*Math.PI*Math.random(),n=2*Math.PI*Math.random(),i=Math.random(),r=Math.sqrt(1-i),a=Math.sqrt(i);return this.set(r*Math.sin(e),r*Math.cos(e),a*Math.sin(n),a*Math.cos(n))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,n=0){return this._x=e[n],this._y=e[n+1],this._z=e[n+2],this._w=e[n+3],this._onChangeCallback(),this}toArray(e=[],n=0){return e[n]=this._x,e[n+1]=this._y,e[n+2]=this._z,e[n+3]=this._w,e}fromBufferAttribute(e,n){return this._x=e.getX(n),this._y=e.getY(n),this._z=e.getZ(n),this._w=e.getW(n),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}const Oh=class Oh{constructor(e=0,n=0,i=0){this.x=e,this.y=n,this.z=i}set(e,n,i){return i===void 0&&(i=this.z),this.x=e,this.y=n,this.z=i,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,n){switch(e){case 0:this.x=n;break;case 1:this.y=n;break;case 2:this.z=n;break;default:throw new Error("THREE.Vector3: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("THREE.Vector3: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,n){return this.x=e.x+n.x,this.y=e.y+n.y,this.z=e.z+n.z,this}addScaledVector(e,n){return this.x+=e.x*n,this.y+=e.y*n,this.z+=e.z*n,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,n){return this.x=e.x-n.x,this.y=e.y-n.y,this.z=e.z-n.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,n){return this.x=e.x*n.x,this.y=e.y*n.y,this.z=e.z*n.z,this}applyEuler(e){return this.applyQuaternion(wm.setFromEuler(e))}applyAxisAngle(e,n){return this.applyQuaternion(wm.setFromAxisAngle(e,n))}applyMatrix3(e){const n=this.x,i=this.y,r=this.z,a=e.elements;return this.x=a[0]*n+a[3]*i+a[6]*r,this.y=a[1]*n+a[4]*i+a[7]*r,this.z=a[2]*n+a[5]*i+a[8]*r,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){const n=this.x,i=this.y,r=this.z,a=e.elements,s=1/(a[3]*n+a[7]*i+a[11]*r+a[15]);return this.x=(a[0]*n+a[4]*i+a[8]*r+a[12])*s,this.y=(a[1]*n+a[5]*i+a[9]*r+a[13])*s,this.z=(a[2]*n+a[6]*i+a[10]*r+a[14])*s,this}applyQuaternion(e){const n=this.x,i=this.y,r=this.z,a=e.x,s=e.y,o=e.z,l=e.w,c=2*(s*r-o*i),f=2*(o*n-a*r),h=2*(a*i-s*n);return this.x=n+l*c+s*h-o*f,this.y=i+l*f+o*c-a*h,this.z=r+l*h+a*f-s*c,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){const n=this.x,i=this.y,r=this.z,a=e.elements;return this.x=a[0]*n+a[4]*i+a[8]*r,this.y=a[1]*n+a[5]*i+a[9]*r,this.z=a[2]*n+a[6]*i+a[10]*r,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,n){return this.x=je(this.x,e.x,n.x),this.y=je(this.y,e.y,n.y),this.z=je(this.z,e.z,n.z),this}clampScalar(e,n){return this.x=je(this.x,e,n),this.y=je(this.y,e,n),this.z=je(this.z,e,n),this}clampLength(e,n){const i=this.length();return this.divideScalar(i||1).multiplyScalar(je(i,e,n))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,n){return this.x+=(e.x-this.x)*n,this.y+=(e.y-this.y)*n,this.z+=(e.z-this.z)*n,this}lerpVectors(e,n,i){return this.x=e.x+(n.x-e.x)*i,this.y=e.y+(n.y-e.y)*i,this.z=e.z+(n.z-e.z)*i,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,n){const i=e.x,r=e.y,a=e.z,s=n.x,o=n.y,l=n.z;return this.x=r*l-a*o,this.y=a*s-i*l,this.z=i*o-r*s,this}projectOnVector(e){const n=e.lengthSq();if(n===0)return this.set(0,0,0);const i=e.dot(this)/n;return this.copy(e).multiplyScalar(i)}projectOnPlane(e){return lu.copy(this).projectOnVector(e),this.sub(lu)}reflect(e){return this.sub(lu.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){const n=Math.sqrt(this.lengthSq()*e.lengthSq());if(n===0)return Math.PI/2;const i=this.dot(e)/n;return Math.acos(je(i,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const n=this.x-e.x,i=this.y-e.y,r=this.z-e.z;return n*n+i*i+r*r}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,n,i){const r=Math.sin(n)*e;return this.x=r*Math.sin(i),this.y=Math.cos(n)*e,this.z=r*Math.cos(i),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,n,i){return this.x=e*Math.sin(n),this.y=i,this.z=e*Math.cos(n),this}setFromMatrixPosition(e){const n=e.elements;return this.x=n[12],this.y=n[13],this.z=n[14],this}setFromMatrixScale(e){const n=this.setFromMatrixColumn(e,0).length(),i=this.setFromMatrixColumn(e,1).length(),r=this.setFromMatrixColumn(e,2).length();return this.x=n,this.y=i,this.z=r,this}setFromMatrixColumn(e,n){return this.fromArray(e.elements,n*4)}setFromMatrix3Column(e,n){return this.fromArray(e.elements,n*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,n=0){return this.x=e[n],this.y=e[n+1],this.z=e[n+2],this}toArray(e=[],n=0){return e[n]=this.x,e[n+1]=this.y,e[n+2]=this.z,e}fromBufferAttribute(e,n){return this.x=e.getX(n),this.y=e.getY(n),this.z=e.getZ(n),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const e=Math.random()*Math.PI*2,n=Math.random()*2-1,i=Math.sqrt(1-n*n);return this.x=i*Math.cos(e),this.y=n,this.z=i*Math.sin(e),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}};Oh.prototype.isVector3=!0;let j=Oh;const lu=new j,wm=new es,kh=class kh{constructor(e,n,i,r,a,s,o,l,c){this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,n,i,r,a,s,o,l,c)}set(e,n,i,r,a,s,o,l,c){const f=this.elements;return f[0]=e,f[1]=r,f[2]=o,f[3]=n,f[4]=a,f[5]=l,f[6]=i,f[7]=s,f[8]=c,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){const n=this.elements,i=e.elements;return n[0]=i[0],n[1]=i[1],n[2]=i[2],n[3]=i[3],n[4]=i[4],n[5]=i[5],n[6]=i[6],n[7]=i[7],n[8]=i[8],this}extractBasis(e,n,i){return e.setFromMatrix3Column(this,0),n.setFromMatrix3Column(this,1),i.setFromMatrix3Column(this,2),this}setFromMatrix4(e){const n=e.elements;return this.set(n[0],n[4],n[8],n[1],n[5],n[9],n[2],n[6],n[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,n){const i=e.elements,r=n.elements,a=this.elements,s=i[0],o=i[3],l=i[6],c=i[1],f=i[4],h=i[7],u=i[2],m=i[5],x=i[8],E=r[0],g=r[3],d=r[6],v=r[1],S=r[4],M=r[7],A=r[2],T=r[5],w=r[8];return a[0]=s*E+o*v+l*A,a[3]=s*g+o*S+l*T,a[6]=s*d+o*M+l*w,a[1]=c*E+f*v+h*A,a[4]=c*g+f*S+h*T,a[7]=c*d+f*M+h*w,a[2]=u*E+m*v+x*A,a[5]=u*g+m*S+x*T,a[8]=u*d+m*M+x*w,this}multiplyScalar(e){const n=this.elements;return n[0]*=e,n[3]*=e,n[6]*=e,n[1]*=e,n[4]*=e,n[7]*=e,n[2]*=e,n[5]*=e,n[8]*=e,this}determinant(){const e=this.elements,n=e[0],i=e[1],r=e[2],a=e[3],s=e[4],o=e[5],l=e[6],c=e[7],f=e[8];return n*s*f-n*o*c-i*a*f+i*o*l+r*a*c-r*s*l}invert(){const e=this.elements,n=e[0],i=e[1],r=e[2],a=e[3],s=e[4],o=e[5],l=e[6],c=e[7],f=e[8],h=f*s-o*c,u=o*l-f*a,m=c*a-s*l,x=n*h+i*u+r*m;if(x===0)return this.set(0,0,0,0,0,0,0,0,0);const E=1/x;return e[0]=h*E,e[1]=(r*c-f*i)*E,e[2]=(o*i-r*s)*E,e[3]=u*E,e[4]=(f*n-r*l)*E,e[5]=(r*a-o*n)*E,e[6]=m*E,e[7]=(i*l-c*n)*E,e[8]=(s*n-i*a)*E,this}transpose(){let e;const n=this.elements;return e=n[1],n[1]=n[3],n[3]=e,e=n[2],n[2]=n[6],n[6]=e,e=n[5],n[5]=n[7],n[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){const n=this.elements;return e[0]=n[0],e[1]=n[3],e[2]=n[6],e[3]=n[1],e[4]=n[4],e[5]=n[7],e[6]=n[2],e[7]=n[5],e[8]=n[8],this}setUvTransform(e,n,i,r,a,s,o){const l=Math.cos(a),c=Math.sin(a);return this.set(i*l,i*c,-i*(l*s+c*o)+s+e,-r*c,r*l,-r*(-c*s+l*o)+o+n,0,0,1),this}scale(e,n){return Oa("Matrix3: .scale() is deprecated. Use .makeScale() instead."),this.premultiply(cu.makeScale(e,n)),this}rotate(e){return Oa("Matrix3: .rotate() is deprecated. Use .makeRotation() instead."),this.premultiply(cu.makeRotation(-e)),this}translate(e,n){return Oa("Matrix3: .translate() is deprecated. Use .makeTranslation() instead."),this.premultiply(cu.makeTranslation(e,n)),this}makeTranslation(e,n){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,n,0,0,1),this}makeRotation(e){const n=Math.cos(e),i=Math.sin(e);return this.set(n,-i,0,i,n,0,0,0,1),this}makeScale(e,n){return this.set(e,0,0,0,n,0,0,0,1),this}equals(e){const n=this.elements,i=e.elements;for(let r=0;r<9;r++)if(n[r]!==i[r])return!1;return!0}fromArray(e,n=0){for(let i=0;i<9;i++)this.elements[i]=e[i+n];return this}toArray(e=[],n=0){const i=this.elements;return e[n]=i[0],e[n+1]=i[1],e[n+2]=i[2],e[n+3]=i[3],e[n+4]=i[4],e[n+5]=i[5],e[n+6]=i[6],e[n+7]=i[7],e[n+8]=i[8],e}clone(){return new this.constructor().fromArray(this.elements)}};kh.prototype.isMatrix3=!0;let Ie=kh;const cu=new Ie,Tm=new Ie().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),Am=new Ie().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function nE(){const t={enabled:!0,workingColorSpace:Zl,spaces:{},convert:function(r,a,s){return this.enabled===!1||a===s||!a||!s||(this.spaces[a].transfer===tt&&(r.r=Di(r.r),r.g=Di(r.g),r.b=Di(r.b)),this.spaces[a].primaries!==this.spaces[s].primaries&&(r.applyMatrix3(this.spaces[a].toXYZ),r.applyMatrix3(this.spaces[s].fromXYZ)),this.spaces[s].transfer===tt&&(r.r=ka(r.r),r.g=ka(r.g),r.b=ka(r.b))),r},workingToColorSpace:function(r,a){return this.convert(r,this.workingColorSpace,a)},colorSpaceToWorking:function(r,a){return this.convert(r,a,this.workingColorSpace)},getPrimaries:function(r){return this.spaces[r].primaries},getTransfer:function(r){return r===sr?Ql:this.spaces[r].transfer},getToneMappingMode:function(r){return this.spaces[r].outputColorSpaceConfig.toneMappingMode||"standard"},getLuminanceCoefficients:function(r,a=this.workingColorSpace){return r.fromArray(this.spaces[a].luminanceCoefficients)},define:function(r){Object.assign(this.spaces,r)},_getMatrix:function(r,a,s){return r.copy(this.spaces[a].toXYZ).multiply(this.spaces[s].fromXYZ)},_getDrawingBufferColorSpace:function(r){return this.spaces[r].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(r=this.workingColorSpace){return this.spaces[r].workingColorSpaceConfig.unpackColorSpace},fromWorkingColorSpace:function(r,a){return Oa("ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace()."),t.workingToColorSpace(r,a)},toWorkingColorSpace:function(r,a){return Oa("ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking()."),t.colorSpaceToWorking(r,a)}},e=[.64,.33,.3,.6,.15,.06],n=[.2126,.7152,.0722],i=[.3127,.329];return t.define({[Zl]:{primaries:e,whitePoint:i,transfer:Ql,toXYZ:Tm,fromXYZ:Am,luminanceCoefficients:n,workingColorSpaceConfig:{unpackColorSpace:Cn},outputColorSpaceConfig:{drawingBufferColorSpace:Cn}},[Cn]:{primaries:e,whitePoint:i,transfer:tt,toXYZ:Tm,fromXYZ:Am,luminanceCoefficients:n,outputColorSpaceConfig:{drawingBufferColorSpace:Cn}}}),t}const We=nE();function Di(t){return t<.04045?t*.0773993808:Math.pow(t*.9478672986+.0521327014,2.4)}function ka(t){return t<.0031308?t*12.92:1.055*Math.pow(t,.41666)-.055}let aa;class iE{static getDataURL(e,n="image/png"){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let i;if(e instanceof HTMLCanvasElement)i=e;else{aa===void 0&&(aa=ec("canvas")),aa.width=e.width,aa.height=e.height;const r=aa.getContext("2d");e instanceof ImageData?r.putImageData(e,0,0):r.drawImage(e,0,0,e.width,e.height),i=aa}return i.toDataURL(n)}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){const n=ec("canvas");n.width=e.width,n.height=e.height;const i=n.getContext("2d");i.drawImage(e,0,0,e.width,e.height);const r=i.getImageData(0,0,e.width,e.height),a=r.data;for(let s=0;s<a.length;s++)a[s]=Di(a[s]/255)*255;return i.putImageData(r,0,0),n}else if(e.data){const n=e.data.slice(0);for(let i=0;i<n.length;i++)n instanceof Uint8Array||n instanceof Uint8ClampedArray?n[i]=Math.floor(Di(n[i]/255)*255):n[i]=Di(n[i]);return{data:n,width:e.width,height:e.height}}else return De("ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}}let rE=0;class Dh{constructor(e=null){this.isSource=!0,Object.defineProperty(this,"id",{value:rE++}),this.uuid=oo(),this.data=e,this.dataReady=!0,this.version=0}getSize(e){const n=this.data;return typeof HTMLVideoElement<"u"&&n instanceof HTMLVideoElement?e.set(n.videoWidth,n.videoHeight,0):typeof VideoFrame<"u"&&n instanceof VideoFrame?e.set(n.displayWidth,n.displayHeight,0):n!==null?e.set(n.width,n.height,n.depth||0):e.set(0,0,0),e}set needsUpdate(e){e===!0&&this.version++}toJSON(e){const n=e===void 0||typeof e=="string";if(!n&&e.images[this.uuid]!==void 0)return e.images[this.uuid];const i={uuid:this.uuid,url:""},r=this.data;if(r!==null){let a;if(Array.isArray(r)){a=[];for(let s=0,o=r.length;s<o;s++)r[s].isDataTexture?a.push(uu(r[s].image)):a.push(uu(r[s]))}else a=uu(r);i.url=a}return n||(e.images[this.uuid]=i),i}}function uu(t){return typeof HTMLImageElement<"u"&&t instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&t instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&t instanceof ImageBitmap?iE.getDataURL(t):t.data?{data:Array.from(t.data),width:t.width,height:t.height,type:t.data.constructor.name}:(De("Texture: Unable to serialize Texture."),{})}let aE=0;const du=new j;class an extends ea{constructor(e=an.DEFAULT_IMAGE,n=an.DEFAULT_MAPPING,i=Pi,r=Pi,a=Jt,s=Br,o=Xn,l=Nn,c=an.DEFAULT_ANISOTROPY,f=sr){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:aE++}),this.uuid=oo(),this.name="",this.source=new Dh(e),this.mipmaps=[],this.mapping=n,this.channel=0,this.wrapS=i,this.wrapT=r,this.magFilter=a,this.minFilter=s,this.anisotropy=c,this.format=o,this.internalFormat=null,this.type=l,this.offset=new Ze(0,0),this.repeat=new Ze(1,1),this.center=new Ze(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new Ie,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=f,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(e&&e.depth&&e.depth>1),this.pmremVersion=0,this.normalized=!1}get width(){return this.source.getSize(du).x}get height(){return this.source.getSize(du).y}get depth(){return this.source.getSize(du).z}get image(){return this.source.data}set image(e){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(e,n){this.updateRanges.push({start:e,count:n})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.normalized=e.normalized,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.renderTarget=e.renderTarget,this.isRenderTargetTexture=e.isRenderTargetTexture,this.isArrayTexture=e.isArrayTexture,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}setValues(e){for(const n in e){const i=e[n];if(i===void 0){De(`Texture.setValues(): parameter '${n}' has value of undefined.`);continue}const r=this[n];if(r===void 0){De(`Texture.setValues(): property '${n}' does not exist.`);continue}r&&i&&r.isVector2&&i.isVector2||r&&i&&r.isVector3&&i.isVector3||r&&i&&r.isMatrix3&&i.isMatrix3?r.copy(i):this[n]=i}}toJSON(e){const n=e===void 0||typeof e=="string";if(!n&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];const i={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,normalized:this.normalized,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(i.userData=this.userData),n||(e.textures[this.uuid]=i),i}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==px)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case Bd:e.x=e.x-Math.floor(e.x);break;case Pi:e.x=e.x<0?0:1;break;case zd:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case Bd:e.y=e.y-Math.floor(e.y);break;case Pi:e.y=e.y<0?0:1;break;case zd:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(e){e===!0&&this.pmremVersion++}}an.DEFAULT_IMAGE=null;an.DEFAULT_MAPPING=px;an.DEFAULT_ANISOTROPY=1;const Bh=class Bh{constructor(e=0,n=0,i=0,r=1){this.x=e,this.y=n,this.z=i,this.w=r}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,n,i,r){return this.x=e,this.y=n,this.z=i,this.w=r,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,n){switch(e){case 0:this.x=n;break;case 1:this.y=n;break;case 2:this.z=n;break;case 3:this.w=n;break;default:throw new Error("THREE.Vector4: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("THREE.Vector4: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,n){return this.x=e.x+n.x,this.y=e.y+n.y,this.z=e.z+n.z,this.w=e.w+n.w,this}addScaledVector(e,n){return this.x+=e.x*n,this.y+=e.y*n,this.z+=e.z*n,this.w+=e.w*n,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,n){return this.x=e.x-n.x,this.y=e.y-n.y,this.z=e.z-n.z,this.w=e.w-n.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){const n=this.x,i=this.y,r=this.z,a=this.w,s=e.elements;return this.x=s[0]*n+s[4]*i+s[8]*r+s[12]*a,this.y=s[1]*n+s[5]*i+s[9]*r+s[13]*a,this.z=s[2]*n+s[6]*i+s[10]*r+s[14]*a,this.w=s[3]*n+s[7]*i+s[11]*r+s[15]*a,this}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this.w/=e.w,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);const n=Math.sqrt(1-e.w*e.w);return n<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/n,this.y=e.y/n,this.z=e.z/n),this}setAxisAngleFromRotationMatrix(e){let n,i,r,a;const l=e.elements,c=l[0],f=l[4],h=l[8],u=l[1],m=l[5],x=l[9],E=l[2],g=l[6],d=l[10];if(Math.abs(f-u)<.01&&Math.abs(h-E)<.01&&Math.abs(x-g)<.01){if(Math.abs(f+u)<.1&&Math.abs(h+E)<.1&&Math.abs(x+g)<.1&&Math.abs(c+m+d-3)<.1)return this.set(1,0,0,0),this;n=Math.PI;const S=(c+1)/2,M=(m+1)/2,A=(d+1)/2,T=(f+u)/4,w=(h+E)/4,_=(x+g)/4;return S>M&&S>A?S<.01?(i=0,r=.707106781,a=.707106781):(i=Math.sqrt(S),r=T/i,a=w/i):M>A?M<.01?(i=.707106781,r=0,a=.707106781):(r=Math.sqrt(M),i=T/r,a=_/r):A<.01?(i=.707106781,r=.707106781,a=0):(a=Math.sqrt(A),i=w/a,r=_/a),this.set(i,r,a,n),this}let v=Math.sqrt((g-x)*(g-x)+(h-E)*(h-E)+(u-f)*(u-f));return Math.abs(v)<.001&&(v=1),this.x=(g-x)/v,this.y=(h-E)/v,this.z=(u-f)/v,this.w=Math.acos((c+m+d-1)/2),this}setFromMatrixPosition(e){const n=e.elements;return this.x=n[12],this.y=n[13],this.z=n[14],this.w=n[15],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,n){return this.x=je(this.x,e.x,n.x),this.y=je(this.y,e.y,n.y),this.z=je(this.z,e.z,n.z),this.w=je(this.w,e.w,n.w),this}clampScalar(e,n){return this.x=je(this.x,e,n),this.y=je(this.y,e,n),this.z=je(this.z,e,n),this.w=je(this.w,e,n),this}clampLength(e,n){const i=this.length();return this.divideScalar(i||1).multiplyScalar(je(i,e,n))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,n){return this.x+=(e.x-this.x)*n,this.y+=(e.y-this.y)*n,this.z+=(e.z-this.z)*n,this.w+=(e.w-this.w)*n,this}lerpVectors(e,n,i){return this.x=e.x+(n.x-e.x)*i,this.y=e.y+(n.y-e.y)*i,this.z=e.z+(n.z-e.z)*i,this.w=e.w+(n.w-e.w)*i,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,n=0){return this.x=e[n],this.y=e[n+1],this.z=e[n+2],this.w=e[n+3],this}toArray(e=[],n=0){return e[n]=this.x,e[n+1]=this.y,e[n+2]=this.z,e[n+3]=this.w,e}fromBufferAttribute(e,n){return this.x=e.getX(n),this.y=e.getY(n),this.z=e.getZ(n),this.w=e.getW(n),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}};Bh.prototype.isVector4=!0;let Mt=Bh;class sE extends ea{constructor(e=1,n=1,i={}){super(),i=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Jt,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1,useArrayDepthTexture:!1},i),this.isRenderTarget=!0,this.width=e,this.height=n,this.depth=i.depth,this.scissor=new Mt(0,0,e,n),this.scissorTest=!1,this.viewport=new Mt(0,0,e,n),this.textures=[];const r={width:e,height:n,depth:i.depth},a=new an(r),s=i.count;for(let o=0;o<s;o++)this.textures[o]=a.clone(),this.textures[o].isRenderTargetTexture=!0,this.textures[o].renderTarget=this;this._setTextureOptions(i),this.depthBuffer=i.depthBuffer,this.stencilBuffer=i.stencilBuffer,this.resolveDepthBuffer=i.resolveDepthBuffer,this.resolveStencilBuffer=i.resolveStencilBuffer,this._depthTexture=null,this.depthTexture=i.depthTexture,this.samples=i.samples,this.multiview=i.multiview,this.useArrayDepthTexture=i.useArrayDepthTexture}_setTextureOptions(e={}){const n={minFilter:Jt,generateMipmaps:!1,flipY:!1,internalFormat:null};e.mapping!==void 0&&(n.mapping=e.mapping),e.wrapS!==void 0&&(n.wrapS=e.wrapS),e.wrapT!==void 0&&(n.wrapT=e.wrapT),e.wrapR!==void 0&&(n.wrapR=e.wrapR),e.magFilter!==void 0&&(n.magFilter=e.magFilter),e.minFilter!==void 0&&(n.minFilter=e.minFilter),e.format!==void 0&&(n.format=e.format),e.type!==void 0&&(n.type=e.type),e.anisotropy!==void 0&&(n.anisotropy=e.anisotropy),e.colorSpace!==void 0&&(n.colorSpace=e.colorSpace),e.flipY!==void 0&&(n.flipY=e.flipY),e.generateMipmaps!==void 0&&(n.generateMipmaps=e.generateMipmaps),e.internalFormat!==void 0&&(n.internalFormat=e.internalFormat);for(let i=0;i<this.textures.length;i++)this.textures[i].setValues(n)}get texture(){return this.textures[0]}set texture(e){this.textures[0]=e}set depthTexture(e){this._depthTexture!==null&&(this._depthTexture.renderTarget=null),e!==null&&(e.renderTarget=this),this._depthTexture=e}get depthTexture(){return this._depthTexture}setSize(e,n,i=1){if(this.width!==e||this.height!==n||this.depth!==i){this.width=e,this.height=n,this.depth=i;for(let r=0,a=this.textures.length;r<a;r++)this.textures[r].image.width=e,this.textures[r].image.height=n,this.textures[r].image.depth=i,this.textures[r].isData3DTexture!==!0&&(this.textures[r].isArrayTexture=this.textures[r].image.depth>1);this.dispose()}this.viewport.set(0,0,e,n),this.scissor.set(0,0,e,n)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.textures.length=0;for(let n=0,i=e.textures.length;n<i;n++){this.textures[n]=e.textures[n].clone(),this.textures[n].isRenderTargetTexture=!0,this.textures[n].renderTarget=this;const r=Object.assign({},e.textures[n].image);this.textures[n].source=new Dh(r)}return this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,this.resolveDepthBuffer=e.resolveDepthBuffer,this.resolveStencilBuffer=e.resolveStencilBuffer,e.depthTexture!==null&&(this.depthTexture=e.depthTexture.clone()),this.samples=e.samples,this.multiview=e.multiview,this.useArrayDepthTexture=e.useArrayDepthTexture,this}dispose(){this.dispatchEvent({type:"dispose"})}}class pi extends sE{constructor(e=1,n=1,i={}){super(e,n,i),this.isWebGLRenderTarget=!0}}class Ex extends an{constructor(e=null,n=1,i=1,r=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:n,height:i,depth:r},this.magFilter=Gt,this.minFilter=Gt,this.wrapR=Pi,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(e){this.layerUpdates.add(e)}clearLayerUpdates(){this.layerUpdates.clear()}}class oE extends an{constructor(e=null,n=1,i=1,r=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:n,height:i,depth:r},this.magFilter=Gt,this.minFilter=Gt,this.wrapR=Pi,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}const tc=class tc{constructor(e,n,i,r,a,s,o,l,c,f,h,u,m,x,E,g){this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,n,i,r,a,s,o,l,c,f,h,u,m,x,E,g)}set(e,n,i,r,a,s,o,l,c,f,h,u,m,x,E,g){const d=this.elements;return d[0]=e,d[4]=n,d[8]=i,d[12]=r,d[1]=a,d[5]=s,d[9]=o,d[13]=l,d[2]=c,d[6]=f,d[10]=h,d[14]=u,d[3]=m,d[7]=x,d[11]=E,d[15]=g,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new tc().fromArray(this.elements)}copy(e){const n=this.elements,i=e.elements;return n[0]=i[0],n[1]=i[1],n[2]=i[2],n[3]=i[3],n[4]=i[4],n[5]=i[5],n[6]=i[6],n[7]=i[7],n[8]=i[8],n[9]=i[9],n[10]=i[10],n[11]=i[11],n[12]=i[12],n[13]=i[13],n[14]=i[14],n[15]=i[15],this}copyPosition(e){const n=this.elements,i=e.elements;return n[12]=i[12],n[13]=i[13],n[14]=i[14],this}setFromMatrix3(e){const n=e.elements;return this.set(n[0],n[3],n[6],0,n[1],n[4],n[7],0,n[2],n[5],n[8],0,0,0,0,1),this}extractBasis(e,n,i){return this.determinantAffine()===0?(e.set(1,0,0),n.set(0,1,0),i.set(0,0,1),this):(e.setFromMatrixColumn(this,0),n.setFromMatrixColumn(this,1),i.setFromMatrixColumn(this,2),this)}makeBasis(e,n,i){return this.set(e.x,n.x,i.x,0,e.y,n.y,i.y,0,e.z,n.z,i.z,0,0,0,0,1),this}extractRotation(e){if(e.determinantAffine()===0)return this.identity();const n=this.elements,i=e.elements,r=1/sa.setFromMatrixColumn(e,0).length(),a=1/sa.setFromMatrixColumn(e,1).length(),s=1/sa.setFromMatrixColumn(e,2).length();return n[0]=i[0]*r,n[1]=i[1]*r,n[2]=i[2]*r,n[3]=0,n[4]=i[4]*a,n[5]=i[5]*a,n[6]=i[6]*a,n[7]=0,n[8]=i[8]*s,n[9]=i[9]*s,n[10]=i[10]*s,n[11]=0,n[12]=0,n[13]=0,n[14]=0,n[15]=1,this}makeRotationFromEuler(e){const n=this.elements,i=e.x,r=e.y,a=e.z,s=Math.cos(i),o=Math.sin(i),l=Math.cos(r),c=Math.sin(r),f=Math.cos(a),h=Math.sin(a);if(e.order==="XYZ"){const u=s*f,m=s*h,x=o*f,E=o*h;n[0]=l*f,n[4]=-l*h,n[8]=c,n[1]=m+x*c,n[5]=u-E*c,n[9]=-o*l,n[2]=E-u*c,n[6]=x+m*c,n[10]=s*l}else if(e.order==="YXZ"){const u=l*f,m=l*h,x=c*f,E=c*h;n[0]=u+E*o,n[4]=x*o-m,n[8]=s*c,n[1]=s*h,n[5]=s*f,n[9]=-o,n[2]=m*o-x,n[6]=E+u*o,n[10]=s*l}else if(e.order==="ZXY"){const u=l*f,m=l*h,x=c*f,E=c*h;n[0]=u-E*o,n[4]=-s*h,n[8]=x+m*o,n[1]=m+x*o,n[5]=s*f,n[9]=E-u*o,n[2]=-s*c,n[6]=o,n[10]=s*l}else if(e.order==="ZYX"){const u=s*f,m=s*h,x=o*f,E=o*h;n[0]=l*f,n[4]=x*c-m,n[8]=u*c+E,n[1]=l*h,n[5]=E*c+u,n[9]=m*c-x,n[2]=-c,n[6]=o*l,n[10]=s*l}else if(e.order==="YZX"){const u=s*l,m=s*c,x=o*l,E=o*c;n[0]=l*f,n[4]=E-u*h,n[8]=x*h+m,n[1]=h,n[5]=s*f,n[9]=-o*f,n[2]=-c*f,n[6]=m*h+x,n[10]=u-E*h}else if(e.order==="XZY"){const u=s*l,m=s*c,x=o*l,E=o*c;n[0]=l*f,n[4]=-h,n[8]=c*f,n[1]=u*h+E,n[5]=s*f,n[9]=m*h-x,n[2]=x*h-m,n[6]=o*f,n[10]=E*h+u}return n[3]=0,n[7]=0,n[11]=0,n[12]=0,n[13]=0,n[14]=0,n[15]=1,this}makeRotationFromQuaternion(e){return this.compose(lE,e,cE)}lookAt(e,n,i){const r=this.elements;return _n.subVectors(e,n),_n.lengthSq()===0&&(_n.z=1),_n.normalize(),Yi.crossVectors(i,_n),Yi.lengthSq()===0&&(Math.abs(i.z)===1?_n.x+=1e-4:_n.z+=1e-4,_n.normalize(),Yi.crossVectors(i,_n)),Yi.normalize(),Do.crossVectors(_n,Yi),r[0]=Yi.x,r[4]=Do.x,r[8]=_n.x,r[1]=Yi.y,r[5]=Do.y,r[9]=_n.y,r[2]=Yi.z,r[6]=Do.z,r[10]=_n.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,n){const i=e.elements,r=n.elements,a=this.elements,s=i[0],o=i[4],l=i[8],c=i[12],f=i[1],h=i[5],u=i[9],m=i[13],x=i[2],E=i[6],g=i[10],d=i[14],v=i[3],S=i[7],M=i[11],A=i[15],T=r[0],w=r[4],_=r[8],C=r[12],P=r[1],N=r[5],F=r[9],q=r[13],ie=r[2],k=r[6],X=r[10],V=r[14],O=r[3],I=r[7],J=r[11],ae=r[15];return a[0]=s*T+o*P+l*ie+c*O,a[4]=s*w+o*N+l*k+c*I,a[8]=s*_+o*F+l*X+c*J,a[12]=s*C+o*q+l*V+c*ae,a[1]=f*T+h*P+u*ie+m*O,a[5]=f*w+h*N+u*k+m*I,a[9]=f*_+h*F+u*X+m*J,a[13]=f*C+h*q+u*V+m*ae,a[2]=x*T+E*P+g*ie+d*O,a[6]=x*w+E*N+g*k+d*I,a[10]=x*_+E*F+g*X+d*J,a[14]=x*C+E*q+g*V+d*ae,a[3]=v*T+S*P+M*ie+A*O,a[7]=v*w+S*N+M*k+A*I,a[11]=v*_+S*F+M*X+A*J,a[15]=v*C+S*q+M*V+A*ae,this}multiplyScalar(e){const n=this.elements;return n[0]*=e,n[4]*=e,n[8]*=e,n[12]*=e,n[1]*=e,n[5]*=e,n[9]*=e,n[13]*=e,n[2]*=e,n[6]*=e,n[10]*=e,n[14]*=e,n[3]*=e,n[7]*=e,n[11]*=e,n[15]*=e,this}determinant(){const e=this.elements,n=e[0],i=e[4],r=e[8],a=e[12],s=e[1],o=e[5],l=e[9],c=e[13],f=e[2],h=e[6],u=e[10],m=e[14],x=e[3],E=e[7],g=e[11],d=e[15],v=l*m-c*u,S=o*m-c*h,M=o*u-l*h,A=s*m-c*f,T=s*u-l*f,w=s*h-o*f;return n*(E*v-g*S+d*M)-i*(x*v-g*A+d*T)+r*(x*S-E*A+d*w)-a*(x*M-E*T+g*w)}determinantAffine(){const e=this.elements,n=e[0],i=e[4],r=e[8],a=e[1],s=e[5],o=e[9],l=e[2],c=e[6],f=e[10];return n*(s*f-o*c)-i*(a*f-o*l)+r*(a*c-s*l)}transpose(){const e=this.elements;let n;return n=e[1],e[1]=e[4],e[4]=n,n=e[2],e[2]=e[8],e[8]=n,n=e[6],e[6]=e[9],e[9]=n,n=e[3],e[3]=e[12],e[12]=n,n=e[7],e[7]=e[13],e[13]=n,n=e[11],e[11]=e[14],e[14]=n,this}setPosition(e,n,i){const r=this.elements;return e.isVector3?(r[12]=e.x,r[13]=e.y,r[14]=e.z):(r[12]=e,r[13]=n,r[14]=i),this}invert(){const e=this.elements,n=e[0],i=e[1],r=e[2],a=e[3],s=e[4],o=e[5],l=e[6],c=e[7],f=e[8],h=e[9],u=e[10],m=e[11],x=e[12],E=e[13],g=e[14],d=e[15],v=n*o-i*s,S=n*l-r*s,M=n*c-a*s,A=i*l-r*o,T=i*c-a*o,w=r*c-a*l,_=f*E-h*x,C=f*g-u*x,P=f*d-m*x,N=h*g-u*E,F=h*d-m*E,q=u*d-m*g,ie=v*q-S*F+M*N+A*P-T*C+w*_;if(ie===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const k=1/ie;return e[0]=(o*q-l*F+c*N)*k,e[1]=(r*F-i*q-a*N)*k,e[2]=(E*w-g*T+d*A)*k,e[3]=(u*T-h*w-m*A)*k,e[4]=(l*P-s*q-c*C)*k,e[5]=(n*q-r*P+a*C)*k,e[6]=(g*M-x*w-d*S)*k,e[7]=(f*w-u*M+m*S)*k,e[8]=(s*F-o*P+c*_)*k,e[9]=(i*P-n*F-a*_)*k,e[10]=(x*T-E*M+d*v)*k,e[11]=(h*M-f*T-m*v)*k,e[12]=(o*C-s*N-l*_)*k,e[13]=(n*N-i*C+r*_)*k,e[14]=(E*S-x*A-g*v)*k,e[15]=(f*A-h*S+u*v)*k,this}scale(e){const n=this.elements,i=e.x,r=e.y,a=e.z;return n[0]*=i,n[4]*=r,n[8]*=a,n[1]*=i,n[5]*=r,n[9]*=a,n[2]*=i,n[6]*=r,n[10]*=a,n[3]*=i,n[7]*=r,n[11]*=a,this}getMaxScaleOnAxis(){const e=this.elements,n=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],i=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],r=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(n,i,r))}makeTranslation(e,n,i){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,n,0,0,1,i,0,0,0,1),this}makeRotationX(e){const n=Math.cos(e),i=Math.sin(e);return this.set(1,0,0,0,0,n,-i,0,0,i,n,0,0,0,0,1),this}makeRotationY(e){const n=Math.cos(e),i=Math.sin(e);return this.set(n,0,i,0,0,1,0,0,-i,0,n,0,0,0,0,1),this}makeRotationZ(e){const n=Math.cos(e),i=Math.sin(e);return this.set(n,-i,0,0,i,n,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,n){const i=Math.cos(n),r=Math.sin(n),a=1-i,s=e.x,o=e.y,l=e.z,c=a*s,f=a*o;return this.set(c*s+i,c*o-r*l,c*l+r*o,0,c*o+r*l,f*o+i,f*l-r*s,0,c*l-r*o,f*l+r*s,a*l*l+i,0,0,0,0,1),this}makeScale(e,n,i){return this.set(e,0,0,0,0,n,0,0,0,0,i,0,0,0,0,1),this}makeShear(e,n,i,r,a,s){return this.set(1,i,a,0,e,1,s,0,n,r,1,0,0,0,0,1),this}compose(e,n,i){const r=this.elements,a=n._x,s=n._y,o=n._z,l=n._w,c=a+a,f=s+s,h=o+o,u=a*c,m=a*f,x=a*h,E=s*f,g=s*h,d=o*h,v=l*c,S=l*f,M=l*h,A=i.x,T=i.y,w=i.z;return r[0]=(1-(E+d))*A,r[1]=(m+M)*A,r[2]=(x-S)*A,r[3]=0,r[4]=(m-M)*T,r[5]=(1-(u+d))*T,r[6]=(g+v)*T,r[7]=0,r[8]=(x+S)*w,r[9]=(g-v)*w,r[10]=(1-(u+E))*w,r[11]=0,r[12]=e.x,r[13]=e.y,r[14]=e.z,r[15]=1,this}decompose(e,n,i){const r=this.elements;e.x=r[12],e.y=r[13],e.z=r[14];const a=this.determinantAffine();if(a===0)return i.set(1,1,1),n.identity(),this;let s=sa.set(r[0],r[1],r[2]).length();const o=sa.set(r[4],r[5],r[6]).length(),l=sa.set(r[8],r[9],r[10]).length();a<0&&(s=-s),kn.copy(this);const c=1/s,f=1/o,h=1/l;return kn.elements[0]*=c,kn.elements[1]*=c,kn.elements[2]*=c,kn.elements[4]*=f,kn.elements[5]*=f,kn.elements[6]*=f,kn.elements[8]*=h,kn.elements[9]*=h,kn.elements[10]*=h,n.setFromRotationMatrix(kn),i.x=s,i.y=o,i.z=l,this}makePerspective(e,n,i,r,a,s,o=ui,l=!1){const c=this.elements,f=2*a/(n-e),h=2*a/(i-r),u=(n+e)/(n-e),m=(i+r)/(i-r);let x,E;if(l)x=a/(s-a),E=s*a/(s-a);else if(o===ui)x=-(s+a)/(s-a),E=-2*s*a/(s-a);else if(o===Jl)x=-s/(s-a),E=-s*a/(s-a);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+o);return c[0]=f,c[4]=0,c[8]=u,c[12]=0,c[1]=0,c[5]=h,c[9]=m,c[13]=0,c[2]=0,c[6]=0,c[10]=x,c[14]=E,c[3]=0,c[7]=0,c[11]=-1,c[15]=0,this}makeOrthographic(e,n,i,r,a,s,o=ui,l=!1){const c=this.elements,f=2/(n-e),h=2/(i-r),u=-(n+e)/(n-e),m=-(i+r)/(i-r);let x,E;if(l)x=1/(s-a),E=s/(s-a);else if(o===ui)x=-2/(s-a),E=-(s+a)/(s-a);else if(o===Jl)x=-1/(s-a),E=-a/(s-a);else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+o);return c[0]=f,c[4]=0,c[8]=0,c[12]=u,c[1]=0,c[5]=h,c[9]=0,c[13]=m,c[2]=0,c[6]=0,c[10]=x,c[14]=E,c[3]=0,c[7]=0,c[11]=0,c[15]=1,this}equals(e){const n=this.elements,i=e.elements;for(let r=0;r<16;r++)if(n[r]!==i[r])return!1;return!0}fromArray(e,n=0){for(let i=0;i<16;i++)this.elements[i]=e[i+n];return this}toArray(e=[],n=0){const i=this.elements;return e[n]=i[0],e[n+1]=i[1],e[n+2]=i[2],e[n+3]=i[3],e[n+4]=i[4],e[n+5]=i[5],e[n+6]=i[6],e[n+7]=i[7],e[n+8]=i[8],e[n+9]=i[9],e[n+10]=i[10],e[n+11]=i[11],e[n+12]=i[12],e[n+13]=i[13],e[n+14]=i[14],e[n+15]=i[15],e}};tc.prototype.isMatrix4=!0;let Nt=tc;const sa=new j,kn=new Nt,lE=new j(0,0,0),cE=new j(1,1,1),Yi=new j,Do=new j,_n=new j,Cm=new Nt,Rm=new es;class Kr{constructor(e=0,n=0,i=0,r=Kr.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=n,this._z=i,this._order=r}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,n,i,r=this._order){return this._x=e,this._y=n,this._z=i,this._order=r,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,n=this._order,i=!0){const r=e.elements,a=r[0],s=r[4],o=r[8],l=r[1],c=r[5],f=r[9],h=r[2],u=r[6],m=r[10];switch(n){case"XYZ":this._y=Math.asin(je(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(-f,m),this._z=Math.atan2(-s,a)):(this._x=Math.atan2(u,c),this._z=0);break;case"YXZ":this._x=Math.asin(-je(f,-1,1)),Math.abs(f)<.9999999?(this._y=Math.atan2(o,m),this._z=Math.atan2(l,c)):(this._y=Math.atan2(-h,a),this._z=0);break;case"ZXY":this._x=Math.asin(je(u,-1,1)),Math.abs(u)<.9999999?(this._y=Math.atan2(-h,m),this._z=Math.atan2(-s,c)):(this._y=0,this._z=Math.atan2(l,a));break;case"ZYX":this._y=Math.asin(-je(h,-1,1)),Math.abs(h)<.9999999?(this._x=Math.atan2(u,m),this._z=Math.atan2(l,a)):(this._x=0,this._z=Math.atan2(-s,c));break;case"YZX":this._z=Math.asin(je(l,-1,1)),Math.abs(l)<.9999999?(this._x=Math.atan2(-f,c),this._y=Math.atan2(-h,a)):(this._x=0,this._y=Math.atan2(o,m));break;case"XZY":this._z=Math.asin(-je(s,-1,1)),Math.abs(s)<.9999999?(this._x=Math.atan2(u,c),this._y=Math.atan2(o,a)):(this._x=Math.atan2(-f,m),this._y=0);break;default:De("Euler: .setFromRotationMatrix() encountered an unknown order: "+n)}return this._order=n,i===!0&&this._onChangeCallback(),this}setFromQuaternion(e,n,i){return Cm.makeRotationFromQuaternion(e),this.setFromRotationMatrix(Cm,n,i)}setFromVector3(e,n=this._order){return this.set(e.x,e.y,e.z,n)}reorder(e){return Rm.setFromEuler(this),this.setFromQuaternion(Rm,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],n=0){return e[n]=this._x,e[n+1]=this._y,e[n+2]=this._z,e[n+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}Kr.DEFAULT_ORDER="XYZ";class bx{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}}let uE=0;const Pm=new j,oa=new es,vi=new Nt,Io=new j,fs=new j,dE=new j,fE=new es,Nm=new j(1,0,0),Lm=new j(0,1,0),Dm=new j(0,0,1),Im={type:"added"},hE={type:"removed"},la={type:"childadded",child:null},fu={type:"childremoved",child:null};class Mn extends ea{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:uE++}),this.uuid=oo(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=Mn.DEFAULT_UP.clone();const e=new j,n=new Kr,i=new es,r=new j(1,1,1);function a(){i.setFromEuler(n,!1)}function s(){n.setFromQuaternion(i,void 0,!1)}n._onChange(a),i._onChange(s),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:n},quaternion:{configurable:!0,enumerable:!0,value:i},scale:{configurable:!0,enumerable:!0,value:r},modelViewMatrix:{value:new Nt},normalMatrix:{value:new Ie}}),this.matrix=new Nt,this.matrixWorld=new Nt,this.matrixAutoUpdate=Mn.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=Mn.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new bx,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.static=!1,this.userData={},this.pivot=null}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,n){this.quaternion.setFromAxisAngle(e,n)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,n){return oa.setFromAxisAngle(e,n),this.quaternion.multiply(oa),this}rotateOnWorldAxis(e,n){return oa.setFromAxisAngle(e,n),this.quaternion.premultiply(oa),this}rotateX(e){return this.rotateOnAxis(Nm,e)}rotateY(e){return this.rotateOnAxis(Lm,e)}rotateZ(e){return this.rotateOnAxis(Dm,e)}translateOnAxis(e,n){return Pm.copy(e).applyQuaternion(this.quaternion),this.position.add(Pm.multiplyScalar(n)),this}translateX(e){return this.translateOnAxis(Nm,e)}translateY(e){return this.translateOnAxis(Lm,e)}translateZ(e){return this.translateOnAxis(Dm,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(vi.copy(this.matrixWorld).invert())}lookAt(e,n,i){e.isVector3?Io.copy(e):Io.set(e,n,i);const r=this.parent;this.updateWorldMatrix(!0,!1),fs.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?vi.lookAt(fs,Io,this.up):vi.lookAt(Io,fs,this.up),this.quaternion.setFromRotationMatrix(vi),r&&(vi.extractRotation(r.matrixWorld),oa.setFromRotationMatrix(vi),this.quaternion.premultiply(oa.invert()))}add(e){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.add(arguments[n]);return this}return e===this?(Ye("Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.removeFromParent(),e.parent=this,this.children.push(e),e.dispatchEvent(Im),la.child=e,this.dispatchEvent(la),la.child=null):Ye("Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let i=0;i<arguments.length;i++)this.remove(arguments[i]);return this}const n=this.children.indexOf(e);return n!==-1&&(e.parent=null,this.children.splice(n,1),e.dispatchEvent(hE),fu.child=e,this.dispatchEvent(fu),fu.child=null),this}removeFromParent(){const e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),vi.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),vi.multiply(e.parent.matrixWorld)),e.applyMatrix4(vi),e.removeFromParent(),e.parent=this,this.children.push(e),e.updateWorldMatrix(!1,!0),e.dispatchEvent(Im),la.child=e,this.dispatchEvent(la),la.child=null,this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,n){if(this[e]===n)return this;for(let i=0,r=this.children.length;i<r;i++){const s=this.children[i].getObjectByProperty(e,n);if(s!==void 0)return s}}getObjectsByProperty(e,n,i=[]){this[e]===n&&i.push(this);const r=this.children;for(let a=0,s=r.length;a<s;a++)r[a].getObjectsByProperty(e,n,i);return i}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(fs,e,dE),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(fs,fE,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);const n=this.matrixWorld.elements;return e.set(n[8],n[9],n[10]).normalize()}raycast(){}traverse(e){e(this);const n=this.children;for(let i=0,r=n.length;i<r;i++)n[i].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);const n=this.children;for(let i=0,r=n.length;i<r;i++)n[i].traverseVisible(e)}traverseAncestors(e){const n=this.parent;n!==null&&(e(n),n.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale);const e=this.pivot;if(e!==null){const n=e.x,i=e.y,r=e.z,a=this.matrix.elements;a[12]+=n-a[0]*n-a[4]*i-a[8]*r,a[13]+=i-a[1]*n-a[5]*i-a[9]*r,a[14]+=r-a[2]*n-a[6]*i-a[10]*r}this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,e=!0);const n=this.children;for(let i=0,r=n.length;i<r;i++)n[i].updateMatrixWorld(e)}updateWorldMatrix(e,n,i=!1){const r=this.parent;if(e===!0&&r!==null&&r.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||i)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,i=!0),n===!0){const a=this.children;for(let s=0,o=a.length;s<o;s++)a[s].updateWorldMatrix(!1,!0,i)}}toJSON(e){const n=e===void 0||typeof e=="string",i={};n&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},i.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});const r={};r.uuid=this.uuid,r.type=this.type,this.name!==""&&(r.name=this.name),this.castShadow===!0&&(r.castShadow=!0),this.receiveShadow===!0&&(r.receiveShadow=!0),this.visible===!1&&(r.visible=!1),this.frustumCulled===!1&&(r.frustumCulled=!1),this.renderOrder!==0&&(r.renderOrder=this.renderOrder),this.static!==!1&&(r.static=this.static),Object.keys(this.userData).length>0&&(r.userData=this.userData),r.layers=this.layers.mask,r.matrix=this.matrix.toArray(),r.up=this.up.toArray(),this.pivot!==null&&(r.pivot=this.pivot.toArray()),this.matrixAutoUpdate===!1&&(r.matrixAutoUpdate=!1),this.morphTargetDictionary!==void 0&&(r.morphTargetDictionary=Object.assign({},this.morphTargetDictionary)),this.morphTargetInfluences!==void 0&&(r.morphTargetInfluences=this.morphTargetInfluences.slice()),this.isInstancedMesh&&(r.type="InstancedMesh",r.count=this.count,r.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(r.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(r.type="BatchedMesh",r.perObjectFrustumCulled=this.perObjectFrustumCulled,r.sortObjects=this.sortObjects,r.drawRanges=this._drawRanges,r.reservedRanges=this._reservedRanges,r.geometryInfo=this._geometryInfo.map(o=>({...o,boundingBox:o.boundingBox?o.boundingBox.toJSON():void 0,boundingSphere:o.boundingSphere?o.boundingSphere.toJSON():void 0})),r.instanceInfo=this._instanceInfo.map(o=>({...o})),r.availableInstanceIds=this._availableInstanceIds.slice(),r.availableGeometryIds=this._availableGeometryIds.slice(),r.nextIndexStart=this._nextIndexStart,r.nextVertexStart=this._nextVertexStart,r.geometryCount=this._geometryCount,r.maxInstanceCount=this._maxInstanceCount,r.maxVertexCount=this._maxVertexCount,r.maxIndexCount=this._maxIndexCount,r.geometryInitialized=this._geometryInitialized,r.matricesTexture=this._matricesTexture.toJSON(e),r.indirectTexture=this._indirectTexture.toJSON(e),this._colorsTexture!==null&&(r.colorsTexture=this._colorsTexture.toJSON(e)),this.boundingSphere!==null&&(r.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(r.boundingBox=this.boundingBox.toJSON()));function a(o,l){return o[l.uuid]===void 0&&(o[l.uuid]=l.toJSON(e)),l.uuid}if(this.isScene)this.background&&(this.background.isColor?r.background=this.background.toJSON():this.background.isTexture&&(r.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(r.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){r.geometry=a(e.geometries,this.geometry);const o=this.geometry.parameters;if(o!==void 0&&o.shapes!==void 0){const l=o.shapes;if(Array.isArray(l))for(let c=0,f=l.length;c<f;c++){const h=l[c];a(e.shapes,h)}else a(e.shapes,l)}}if(this.isSkinnedMesh&&(r.bindMode=this.bindMode,r.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(a(e.skeletons,this.skeleton),r.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const o=[];for(let l=0,c=this.material.length;l<c;l++)o.push(a(e.materials,this.material[l]));r.material=o}else r.material=a(e.materials,this.material);if(this.children.length>0){r.children=[];for(let o=0;o<this.children.length;o++)r.children.push(this.children[o].toJSON(e).object)}if(this.animations.length>0){r.animations=[];for(let o=0;o<this.animations.length;o++){const l=this.animations[o];r.animations.push(a(e.animations,l))}}if(n){const o=s(e.geometries),l=s(e.materials),c=s(e.textures),f=s(e.images),h=s(e.shapes),u=s(e.skeletons),m=s(e.animations),x=s(e.nodes);o.length>0&&(i.geometries=o),l.length>0&&(i.materials=l),c.length>0&&(i.textures=c),f.length>0&&(i.images=f),h.length>0&&(i.shapes=h),u.length>0&&(i.skeletons=u),m.length>0&&(i.animations=m),x.length>0&&(i.nodes=x)}return i.object=r,i;function s(o){const l=[];for(const c in o){const f=o[c];delete f.metadata,l.push(f)}return l}}clone(e){return new this.constructor().copy(this,e)}copy(e,n=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.pivot=e.pivot!==null?e.pivot.clone():null,this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.static=e.static,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),n===!0)for(let i=0;i<e.children.length;i++){const r=e.children[i];this.add(r.clone())}return this}}Mn.DEFAULT_UP=new j(0,1,0);Mn.DEFAULT_MATRIX_AUTO_UPDATE=!0;Mn.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;class Uo extends Mn{constructor(){super(),this.isGroup=!0,this.type="Group"}}const pE={type:"move"};class hu{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new Uo,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new Uo,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new j,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new j),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new Uo,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new j,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new j,this._grip.eventsEnabled=!1),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){const n=this._hand;if(n)for(const i of e.hand.values())this._getHandJoint(n,i)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,n,i){let r=null,a=null,s=null;const o=this._targetRay,l=this._grip,c=this._hand;if(e&&n.session.visibilityState!=="visible-blurred"){if(c&&e.hand){s=!0;for(const E of e.hand.values()){const g=n.getJointPose(E,i),d=this._getHandJoint(c,E);g!==null&&(d.matrix.fromArray(g.transform.matrix),d.matrix.decompose(d.position,d.rotation,d.scale),d.matrixWorldNeedsUpdate=!0,d.jointRadius=g.radius),d.visible=g!==null}const f=c.joints["index-finger-tip"],h=c.joints["thumb-tip"],u=f.position.distanceTo(h.position),m=.02,x=.005;c.inputState.pinching&&u>m+x?(c.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!c.inputState.pinching&&u<=m-x&&(c.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else l!==null&&e.gripSpace&&(a=n.getPose(e.gripSpace,i),a!==null&&(l.matrix.fromArray(a.transform.matrix),l.matrix.decompose(l.position,l.rotation,l.scale),l.matrixWorldNeedsUpdate=!0,a.linearVelocity?(l.hasLinearVelocity=!0,l.linearVelocity.copy(a.linearVelocity)):l.hasLinearVelocity=!1,a.angularVelocity?(l.hasAngularVelocity=!0,l.angularVelocity.copy(a.angularVelocity)):l.hasAngularVelocity=!1,l.eventsEnabled&&l.dispatchEvent({type:"gripUpdated",data:e,target:this})));o!==null&&(r=n.getPose(e.targetRaySpace,i),r===null&&a!==null&&(r=a),r!==null&&(o.matrix.fromArray(r.transform.matrix),o.matrix.decompose(o.position,o.rotation,o.scale),o.matrixWorldNeedsUpdate=!0,r.linearVelocity?(o.hasLinearVelocity=!0,o.linearVelocity.copy(r.linearVelocity)):o.hasLinearVelocity=!1,r.angularVelocity?(o.hasAngularVelocity=!0,o.angularVelocity.copy(r.angularVelocity)):o.hasAngularVelocity=!1,this.dispatchEvent(pE)))}return o!==null&&(o.visible=r!==null),l!==null&&(l.visible=a!==null),c!==null&&(c.visible=s!==null),this}_getHandJoint(e,n){if(e.joints[n.jointName]===void 0){const i=new Uo;i.matrixAutoUpdate=!1,i.visible=!1,e.joints[n.jointName]=i,e.add(i)}return e.joints[n.jointName]}}const wx={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},Ki={h:0,s:0,l:0},Fo={h:0,s:0,l:0};function pu(t,e,n){return n<0&&(n+=1),n>1&&(n-=1),n<1/6?t+(e-t)*6*n:n<1/2?e:n<2/3?t+(e-t)*6*(2/3-n):t}class Qe{constructor(e,n,i){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,n,i)}set(e,n,i){if(n===void 0&&i===void 0){const r=e;r&&r.isColor?this.copy(r):typeof r=="number"?this.setHex(r):typeof r=="string"&&this.setStyle(r)}else this.setRGB(e,n,i);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,n=Cn){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,We.colorSpaceToWorking(this,n),this}setRGB(e,n,i,r=We.workingColorSpace){return this.r=e,this.g=n,this.b=i,We.colorSpaceToWorking(this,r),this}setHSL(e,n,i,r=We.workingColorSpace){if(e=tE(e,1),n=je(n,0,1),i=je(i,0,1),n===0)this.r=this.g=this.b=i;else{const a=i<=.5?i*(1+n):i+n-i*n,s=2*i-a;this.r=pu(s,a,e+1/3),this.g=pu(s,a,e),this.b=pu(s,a,e-1/3)}return We.colorSpaceToWorking(this,r),this}setStyle(e,n=Cn){function i(a){a!==void 0&&parseFloat(a)<1&&De("Color: Alpha component of "+e+" will be ignored.")}let r;if(r=/^(\w+)\(([^\)]*)\)/.exec(e)){let a;const s=r[1],o=r[2];switch(s){case"rgb":case"rgba":if(a=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return i(a[4]),this.setRGB(Math.min(255,parseInt(a[1],10))/255,Math.min(255,parseInt(a[2],10))/255,Math.min(255,parseInt(a[3],10))/255,n);if(a=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return i(a[4]),this.setRGB(Math.min(100,parseInt(a[1],10))/100,Math.min(100,parseInt(a[2],10))/100,Math.min(100,parseInt(a[3],10))/100,n);break;case"hsl":case"hsla":if(a=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return i(a[4]),this.setHSL(parseFloat(a[1])/360,parseFloat(a[2])/100,parseFloat(a[3])/100,n);break;default:De("Color: Unknown color model "+e)}}else if(r=/^\#([A-Fa-f\d]+)$/.exec(e)){const a=r[1],s=a.length;if(s===3)return this.setRGB(parseInt(a.charAt(0),16)/15,parseInt(a.charAt(1),16)/15,parseInt(a.charAt(2),16)/15,n);if(s===6)return this.setHex(parseInt(a,16),n);De("Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,n);return this}setColorName(e,n=Cn){const i=wx[e.toLowerCase()];return i!==void 0?this.setHex(i,n):De("Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=Di(e.r),this.g=Di(e.g),this.b=Di(e.b),this}copyLinearToSRGB(e){return this.r=ka(e.r),this.g=ka(e.g),this.b=ka(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=Cn){return We.workingToColorSpace(Kt.copy(this),e),Math.round(je(Kt.r*255,0,255))*65536+Math.round(je(Kt.g*255,0,255))*256+Math.round(je(Kt.b*255,0,255))}getHexString(e=Cn){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,n=We.workingColorSpace){We.workingToColorSpace(Kt.copy(this),n);const i=Kt.r,r=Kt.g,a=Kt.b,s=Math.max(i,r,a),o=Math.min(i,r,a);let l,c;const f=(o+s)/2;if(o===s)l=0,c=0;else{const h=s-o;switch(c=f<=.5?h/(s+o):h/(2-s-o),s){case i:l=(r-a)/h+(r<a?6:0);break;case r:l=(a-i)/h+2;break;case a:l=(i-r)/h+4;break}l/=6}return e.h=l,e.s=c,e.l=f,e}getRGB(e,n=We.workingColorSpace){return We.workingToColorSpace(Kt.copy(this),n),e.r=Kt.r,e.g=Kt.g,e.b=Kt.b,e}getStyle(e=Cn){We.workingToColorSpace(Kt.copy(this),e);const n=Kt.r,i=Kt.g,r=Kt.b;return e!==Cn?`color(${e} ${n.toFixed(3)} ${i.toFixed(3)} ${r.toFixed(3)})`:`rgb(${Math.round(n*255)},${Math.round(i*255)},${Math.round(r*255)})`}offsetHSL(e,n,i){return this.getHSL(Ki),this.setHSL(Ki.h+e,Ki.s+n,Ki.l+i)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,n){return this.r=e.r+n.r,this.g=e.g+n.g,this.b=e.b+n.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,n){return this.r+=(e.r-this.r)*n,this.g+=(e.g-this.g)*n,this.b+=(e.b-this.b)*n,this}lerpColors(e,n,i){return this.r=e.r+(n.r-e.r)*i,this.g=e.g+(n.g-e.g)*i,this.b=e.b+(n.b-e.b)*i,this}lerpHSL(e,n){this.getHSL(Ki),e.getHSL(Fo);const i=ou(Ki.h,Fo.h,n),r=ou(Ki.s,Fo.s,n),a=ou(Ki.l,Fo.l,n);return this.setHSL(i,r,a),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){const n=this.r,i=this.g,r=this.b,a=e.elements;return this.r=a[0]*n+a[3]*i+a[6]*r,this.g=a[1]*n+a[4]*i+a[7]*r,this.b=a[2]*n+a[5]*i+a[8]*r,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,n=0){return this.r=e[n],this.g=e[n+1],this.b=e[n+2],this}toArray(e=[],n=0){return e[n]=this.r,e[n+1]=this.g,e[n+2]=this.b,e}fromBufferAttribute(e,n){return this.r=e.getX(n),this.g=e.getY(n),this.b=e.getZ(n),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const Kt=new Qe;Qe.NAMES=wx;class mE extends Mn{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new Kr,this.environmentIntensity=1,this.environmentRotation=new Kr,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,n){return super.copy(e,n),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,this.backgroundRotation.copy(e.backgroundRotation),this.environmentIntensity=e.environmentIntensity,this.environmentRotation.copy(e.environmentRotation),e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){const n=super.toJSON(e);return this.fog!==null&&(n.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(n.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(n.object.backgroundIntensity=this.backgroundIntensity),n.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(n.object.environmentIntensity=this.environmentIntensity),n.object.environmentRotation=this.environmentRotation.toArray(),n}}const Bn=new j,yi=new j,mu=new j,Si=new j,ca=new j,ua=new j,Um=new j,gu=new j,_u=new j,xu=new j,vu=new Mt,yu=new Mt,Su=new Mt;class jn{constructor(e=new j,n=new j,i=new j){this.a=e,this.b=n,this.c=i}static getNormal(e,n,i,r){r.subVectors(i,n),Bn.subVectors(e,n),r.cross(Bn);const a=r.lengthSq();return a>0?r.multiplyScalar(1/Math.sqrt(a)):r.set(0,0,0)}static getBarycoord(e,n,i,r,a){Bn.subVectors(r,n),yi.subVectors(i,n),mu.subVectors(e,n);const s=Bn.dot(Bn),o=Bn.dot(yi),l=Bn.dot(mu),c=yi.dot(yi),f=yi.dot(mu),h=s*c-o*o;if(h===0)return a.set(0,0,0),null;const u=1/h,m=(c*l-o*f)*u,x=(s*f-o*l)*u;return a.set(1-m-x,x,m)}static containsPoint(e,n,i,r){return this.getBarycoord(e,n,i,r,Si)===null?!1:Si.x>=0&&Si.y>=0&&Si.x+Si.y<=1}static getInterpolation(e,n,i,r,a,s,o,l){return this.getBarycoord(e,n,i,r,Si)===null?(l.x=0,l.y=0,"z"in l&&(l.z=0),"w"in l&&(l.w=0),null):(l.setScalar(0),l.addScaledVector(a,Si.x),l.addScaledVector(s,Si.y),l.addScaledVector(o,Si.z),l)}static getInterpolatedAttribute(e,n,i,r,a,s){return vu.setScalar(0),yu.setScalar(0),Su.setScalar(0),vu.fromBufferAttribute(e,n),yu.fromBufferAttribute(e,i),Su.fromBufferAttribute(e,r),s.setScalar(0),s.addScaledVector(vu,a.x),s.addScaledVector(yu,a.y),s.addScaledVector(Su,a.z),s}static isFrontFacing(e,n,i,r){return Bn.subVectors(i,n),yi.subVectors(e,n),Bn.cross(yi).dot(r)<0}set(e,n,i){return this.a.copy(e),this.b.copy(n),this.c.copy(i),this}setFromPointsAndIndices(e,n,i,r){return this.a.copy(e[n]),this.b.copy(e[i]),this.c.copy(e[r]),this}setFromAttributeAndIndices(e,n,i,r){return this.a.fromBufferAttribute(e,n),this.b.fromBufferAttribute(e,i),this.c.fromBufferAttribute(e,r),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return Bn.subVectors(this.c,this.b),yi.subVectors(this.a,this.b),Bn.cross(yi).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return jn.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,n){return jn.getBarycoord(e,this.a,this.b,this.c,n)}getInterpolation(e,n,i,r,a){return jn.getInterpolation(e,this.a,this.b,this.c,n,i,r,a)}containsPoint(e){return jn.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return jn.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,n){const i=this.a,r=this.b,a=this.c;let s,o;ca.subVectors(r,i),ua.subVectors(a,i),gu.subVectors(e,i);const l=ca.dot(gu),c=ua.dot(gu);if(l<=0&&c<=0)return n.copy(i);_u.subVectors(e,r);const f=ca.dot(_u),h=ua.dot(_u);if(f>=0&&h<=f)return n.copy(r);const u=l*h-f*c;if(u<=0&&l>=0&&f<=0)return s=l/(l-f),n.copy(i).addScaledVector(ca,s);xu.subVectors(e,a);const m=ca.dot(xu),x=ua.dot(xu);if(x>=0&&m<=x)return n.copy(a);const E=m*c-l*x;if(E<=0&&c>=0&&x<=0)return o=c/(c-x),n.copy(i).addScaledVector(ua,o);const g=f*x-m*h;if(g<=0&&h-f>=0&&m-x>=0)return Um.subVectors(a,r),o=(h-f)/(h-f+(m-x)),n.copy(r).addScaledVector(Um,o);const d=1/(g+E+u);return s=E*d,o=u*d,n.copy(i).addScaledVector(ca,s).addScaledVector(ua,o)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}}class lo{constructor(e=new j(1/0,1/0,1/0),n=new j(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=n}set(e,n){return this.min.copy(e),this.max.copy(n),this}setFromArray(e){this.makeEmpty();for(let n=0,i=e.length;n<i;n+=3)this.expandByPoint(zn.fromArray(e,n));return this}setFromBufferAttribute(e){this.makeEmpty();for(let n=0,i=e.count;n<i;n++)this.expandByPoint(zn.fromBufferAttribute(e,n));return this}setFromPoints(e){this.makeEmpty();for(let n=0,i=e.length;n<i;n++)this.expandByPoint(e[n]);return this}setFromCenterAndSize(e,n){const i=zn.copy(n).multiplyScalar(.5);return this.min.copy(e).sub(i),this.max.copy(e).add(i),this}setFromObject(e,n=!1){return this.makeEmpty(),this.expandByObject(e,n)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,n=!1){e.updateWorldMatrix(!1,!1);const i=e.geometry;if(i!==void 0){const a=i.getAttribute("position");if(n===!0&&a!==void 0&&e.isInstancedMesh!==!0)for(let s=0,o=a.count;s<o;s++)e.isMesh===!0?e.getVertexPosition(s,zn):zn.fromBufferAttribute(a,s),zn.applyMatrix4(e.matrixWorld),this.expandByPoint(zn);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),Oo.copy(e.boundingBox)):(i.boundingBox===null&&i.computeBoundingBox(),Oo.copy(i.boundingBox)),Oo.applyMatrix4(e.matrixWorld),this.union(Oo)}const r=e.children;for(let a=0,s=r.length;a<s;a++)this.expandByObject(r[a],n);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,n){return n.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,zn),zn.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let n,i;return e.normal.x>0?(n=e.normal.x*this.min.x,i=e.normal.x*this.max.x):(n=e.normal.x*this.max.x,i=e.normal.x*this.min.x),e.normal.y>0?(n+=e.normal.y*this.min.y,i+=e.normal.y*this.max.y):(n+=e.normal.y*this.max.y,i+=e.normal.y*this.min.y),e.normal.z>0?(n+=e.normal.z*this.min.z,i+=e.normal.z*this.max.z):(n+=e.normal.z*this.max.z,i+=e.normal.z*this.min.z),n<=-e.constant&&i>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(hs),ko.subVectors(this.max,hs),da.subVectors(e.a,hs),fa.subVectors(e.b,hs),ha.subVectors(e.c,hs),Zi.subVectors(fa,da),Qi.subVectors(ha,fa),Tr.subVectors(da,ha);let n=[0,-Zi.z,Zi.y,0,-Qi.z,Qi.y,0,-Tr.z,Tr.y,Zi.z,0,-Zi.x,Qi.z,0,-Qi.x,Tr.z,0,-Tr.x,-Zi.y,Zi.x,0,-Qi.y,Qi.x,0,-Tr.y,Tr.x,0];return!Mu(n,da,fa,ha,ko)||(n=[1,0,0,0,1,0,0,0,1],!Mu(n,da,fa,ha,ko))?!1:(Bo.crossVectors(Zi,Qi),n=[Bo.x,Bo.y,Bo.z],Mu(n,da,fa,ha,ko))}clampPoint(e,n){return n.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,zn).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(zn).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(Mi[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),Mi[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),Mi[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),Mi[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),Mi[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),Mi[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),Mi[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),Mi[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(Mi),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(e){return this.min.fromArray(e.min),this.max.fromArray(e.max),this}}const Mi=[new j,new j,new j,new j,new j,new j,new j,new j],zn=new j,Oo=new lo,da=new j,fa=new j,ha=new j,Zi=new j,Qi=new j,Tr=new j,hs=new j,ko=new j,Bo=new j,Ar=new j;function Mu(t,e,n,i,r){for(let a=0,s=t.length-3;a<=s;a+=3){Ar.fromArray(t,a);const o=r.x*Math.abs(Ar.x)+r.y*Math.abs(Ar.y)+r.z*Math.abs(Ar.z),l=e.dot(Ar),c=n.dot(Ar),f=i.dot(Ar);if(Math.max(-Math.max(l,c,f),Math.min(l,c,f))>o)return!1}return!0}const Rt=new j,zo=new Ze;let gE=0;class mi extends ea{constructor(e,n,i=!1){if(super(),Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:gE++}),this.name="",this.array=e,this.itemSize=n,this.count=e!==void 0?e.length/n:0,this.normalized=i,this.usage=Sm,this.updateRanges=[],this.gpuType=ci,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,n){this.updateRanges.push({start:e,count:n})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,n,i){e*=this.itemSize,i*=n.itemSize;for(let r=0,a=this.itemSize;r<a;r++)this.array[e+r]=n.array[i+r];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let n=0,i=this.count;n<i;n++)zo.fromBufferAttribute(this,n),zo.applyMatrix3(e),this.setXY(n,zo.x,zo.y);else if(this.itemSize===3)for(let n=0,i=this.count;n<i;n++)Rt.fromBufferAttribute(this,n),Rt.applyMatrix3(e),this.setXYZ(n,Rt.x,Rt.y,Rt.z);return this}applyMatrix4(e){for(let n=0,i=this.count;n<i;n++)Rt.fromBufferAttribute(this,n),Rt.applyMatrix4(e),this.setXYZ(n,Rt.x,Rt.y,Rt.z);return this}applyNormalMatrix(e){for(let n=0,i=this.count;n<i;n++)Rt.fromBufferAttribute(this,n),Rt.applyNormalMatrix(e),this.setXYZ(n,Rt.x,Rt.y,Rt.z);return this}transformDirection(e){for(let n=0,i=this.count;n<i;n++)Rt.fromBufferAttribute(this,n),Rt.transformDirection(e),this.setXYZ(n,Rt.x,Rt.y,Rt.z);return this}set(e,n=0){return this.array.set(e,n),this}getComponent(e,n){let i=this.array[e*this.itemSize+n];return this.normalized&&(i=ds(i,this.array)),i}setComponent(e,n,i){return this.normalized&&(i=cn(i,this.array)),this.array[e*this.itemSize+n]=i,this}getX(e){let n=this.array[e*this.itemSize];return this.normalized&&(n=ds(n,this.array)),n}setX(e,n){return this.normalized&&(n=cn(n,this.array)),this.array[e*this.itemSize]=n,this}getY(e){let n=this.array[e*this.itemSize+1];return this.normalized&&(n=ds(n,this.array)),n}setY(e,n){return this.normalized&&(n=cn(n,this.array)),this.array[e*this.itemSize+1]=n,this}getZ(e){let n=this.array[e*this.itemSize+2];return this.normalized&&(n=ds(n,this.array)),n}setZ(e,n){return this.normalized&&(n=cn(n,this.array)),this.array[e*this.itemSize+2]=n,this}getW(e){let n=this.array[e*this.itemSize+3];return this.normalized&&(n=ds(n,this.array)),n}setW(e,n){return this.normalized&&(n=cn(n,this.array)),this.array[e*this.itemSize+3]=n,this}setXY(e,n,i){return e*=this.itemSize,this.normalized&&(n=cn(n,this.array),i=cn(i,this.array)),this.array[e+0]=n,this.array[e+1]=i,this}setXYZ(e,n,i,r){return e*=this.itemSize,this.normalized&&(n=cn(n,this.array),i=cn(i,this.array),r=cn(r,this.array)),this.array[e+0]=n,this.array[e+1]=i,this.array[e+2]=r,this}setXYZW(e,n,i,r,a){return e*=this.itemSize,this.normalized&&(n=cn(n,this.array),i=cn(i,this.array),r=cn(r,this.array),a=cn(a,this.array)),this.array[e+0]=n,this.array[e+1]=i,this.array[e+2]=r,this.array[e+3]=a,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(e.name=this.name),this.usage!==Sm&&(e.usage=this.usage),e}dispose(){this.dispatchEvent({type:"dispose"})}}class Tx extends mi{constructor(e,n,i){super(new Uint16Array(e),n,i)}}class Ax extends mi{constructor(e,n,i){super(new Uint32Array(e),n,i)}}class Ii extends mi{constructor(e,n,i){super(new Float32Array(e),n,i)}}const _E=new lo,ps=new j,Eu=new j;class Ih{constructor(e=new j,n=-1){this.isSphere=!0,this.center=e,this.radius=n}set(e,n){return this.center.copy(e),this.radius=n,this}setFromPoints(e,n){const i=this.center;n!==void 0?i.copy(n):_E.setFromPoints(e).getCenter(i);let r=0;for(let a=0,s=e.length;a<s;a++)r=Math.max(r,i.distanceToSquared(e[a]));return this.radius=Math.sqrt(r),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){const n=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=n*n}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,n){const i=this.center.distanceToSquared(e);return n.copy(e),i>this.radius*this.radius&&(n.sub(this.center).normalize(),n.multiplyScalar(this.radius).add(this.center)),n}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;ps.subVectors(e,this.center);const n=ps.lengthSq();if(n>this.radius*this.radius){const i=Math.sqrt(n),r=(i-this.radius)*.5;this.center.addScaledVector(ps,r/i),this.radius+=r}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(Eu.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(ps.copy(e.center).add(Eu)),this.expandByPoint(ps.copy(e.center).sub(Eu))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(e){return this.radius=e.radius,this.center.fromArray(e.center),this}}let xE=0;const An=new Nt,bu=new Mn,pa=new j,xn=new lo,ms=new lo,kt=new j;class Wi extends ea{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:xE++}),this.uuid=oo(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.indirectOffset=0,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={},this._transformed=!1}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(ZM(e)?Ax:Tx)(e,1):this.index=e,this}setIndirect(e,n=0){return this.indirect=e,this.indirectOffset=n,this}getIndirect(){return this.indirect}getAttribute(e){return this.attributes[e]}setAttribute(e,n){return this.attributes[e]=n,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,n,i=0){this.groups.push({start:e,count:n,materialIndex:i})}clearGroups(){this.groups=[]}setDrawRange(e,n){this.drawRange.start=e,this.drawRange.count=n}applyMatrix4(e){const n=this.attributes.position;n!==void 0&&(n.applyMatrix4(e),n.needsUpdate=!0);const i=this.attributes.normal;if(i!==void 0){const a=new Ie().getNormalMatrix(e);i.applyNormalMatrix(a),i.needsUpdate=!0}const r=this.attributes.tangent;return r!==void 0&&(r.transformDirection(e),r.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this._transformed=!0,this}applyQuaternion(e){return An.makeRotationFromQuaternion(e),this.applyMatrix4(An),this}rotateX(e){return An.makeRotationX(e),this.applyMatrix4(An),this}rotateY(e){return An.makeRotationY(e),this.applyMatrix4(An),this}rotateZ(e){return An.makeRotationZ(e),this.applyMatrix4(An),this}translate(e,n,i){return An.makeTranslation(e,n,i),this.applyMatrix4(An),this}scale(e,n,i){return An.makeScale(e,n,i),this.applyMatrix4(An),this}lookAt(e){return bu.lookAt(e),bu.updateMatrix(),this.applyMatrix4(bu.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(pa).negate(),this.translate(pa.x,pa.y,pa.z),this}setFromPoints(e){const n=this.getAttribute("position");if(n===void 0){const i=[];for(let r=0,a=e.length;r<a;r++){const s=e[r];i.push(s.x,s.y,s.z||0)}this.setAttribute("position",new Ii(i,3))}else{const i=Math.min(e.length,n.count);for(let r=0;r<i;r++){const a=e[r];n.setXYZ(r,a.x,a.y,a.z||0)}e.length>n.count&&De("BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),n.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new lo);const e=this.attributes.position,n=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){Ye("BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new j(-1/0,-1/0,-1/0),new j(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),n)for(let i=0,r=n.length;i<r;i++){const a=n[i];xn.setFromBufferAttribute(a),this.morphTargetsRelative?(kt.addVectors(this.boundingBox.min,xn.min),this.boundingBox.expandByPoint(kt),kt.addVectors(this.boundingBox.max,xn.max),this.boundingBox.expandByPoint(kt)):(this.boundingBox.expandByPoint(xn.min),this.boundingBox.expandByPoint(xn.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&Ye('BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new Ih);const e=this.attributes.position,n=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){Ye("BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new j,1/0);return}if(e){const i=this.boundingSphere.center;if(xn.setFromBufferAttribute(e),n)for(let a=0,s=n.length;a<s;a++){const o=n[a];ms.setFromBufferAttribute(o),this.morphTargetsRelative?(kt.addVectors(xn.min,ms.min),xn.expandByPoint(kt),kt.addVectors(xn.max,ms.max),xn.expandByPoint(kt)):(xn.expandByPoint(ms.min),xn.expandByPoint(ms.max))}xn.getCenter(i);let r=0;for(let a=0,s=e.count;a<s;a++)kt.fromBufferAttribute(e,a),r=Math.max(r,i.distanceToSquared(kt));if(n)for(let a=0,s=n.length;a<s;a++){const o=n[a],l=this.morphTargetsRelative;for(let c=0,f=o.count;c<f;c++)kt.fromBufferAttribute(o,c),l&&(pa.fromBufferAttribute(e,c),kt.add(pa)),r=Math.max(r,i.distanceToSquared(kt))}this.boundingSphere.radius=Math.sqrt(r),isNaN(this.boundingSphere.radius)&&Ye('BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const e=this.index,n=this.attributes;if(e===null||n.position===void 0||n.normal===void 0||n.uv===void 0){Ye("BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const i=n.position,r=n.normal,a=n.uv;let s=this.getAttribute("tangent");(s===void 0||s.count!==i.count)&&(s=new mi(new Float32Array(4*i.count),4),this.setAttribute("tangent",s));const o=[],l=[];for(let _=0;_<i.count;_++)o[_]=new j,l[_]=new j;const c=new j,f=new j,h=new j,u=new Ze,m=new Ze,x=new Ze,E=new j,g=new j;function d(_,C,P){c.fromBufferAttribute(i,_),f.fromBufferAttribute(i,C),h.fromBufferAttribute(i,P),u.fromBufferAttribute(a,_),m.fromBufferAttribute(a,C),x.fromBufferAttribute(a,P),f.sub(c),h.sub(c),m.sub(u),x.sub(u);const N=1/(m.x*x.y-x.x*m.y);isFinite(N)&&(E.copy(f).multiplyScalar(x.y).addScaledVector(h,-m.y).multiplyScalar(N),g.copy(h).multiplyScalar(m.x).addScaledVector(f,-x.x).multiplyScalar(N),o[_].add(E),o[C].add(E),o[P].add(E),l[_].add(g),l[C].add(g),l[P].add(g))}let v=this.groups;v.length===0&&(v=[{start:0,count:e.count}]);for(let _=0,C=v.length;_<C;++_){const P=v[_],N=P.start,F=P.count;for(let q=N,ie=N+F;q<ie;q+=3)d(e.getX(q+0),e.getX(q+1),e.getX(q+2))}const S=new j,M=new j,A=new j,T=new j;function w(_){A.fromBufferAttribute(r,_),T.copy(A);const C=o[_];S.copy(C),S.sub(A.multiplyScalar(A.dot(C))).normalize(),M.crossVectors(T,C);const N=M.dot(l[_])<0?-1:1;s.setXYZW(_,S.x,S.y,S.z,N)}for(let _=0,C=v.length;_<C;++_){const P=v[_],N=P.start,F=P.count;for(let q=N,ie=N+F;q<ie;q+=3)w(e.getX(q+0)),w(e.getX(q+1)),w(e.getX(q+2))}this._transformed=!0}computeVertexNormals(){const e=this.index,n=this.getAttribute("position");if(n!==void 0){let i=this.getAttribute("normal");if(i===void 0||i.count!==n.count)i=new mi(new Float32Array(n.count*3),3),this.setAttribute("normal",i);else for(let u=0,m=i.count;u<m;u++)i.setXYZ(u,0,0,0);const r=new j,a=new j,s=new j,o=new j,l=new j,c=new j,f=new j,h=new j;if(e)for(let u=0,m=e.count;u<m;u+=3){const x=e.getX(u+0),E=e.getX(u+1),g=e.getX(u+2);r.fromBufferAttribute(n,x),a.fromBufferAttribute(n,E),s.fromBufferAttribute(n,g),f.subVectors(s,a),h.subVectors(r,a),f.cross(h),o.fromBufferAttribute(i,x),l.fromBufferAttribute(i,E),c.fromBufferAttribute(i,g),o.add(f),l.add(f),c.add(f),i.setXYZ(x,o.x,o.y,o.z),i.setXYZ(E,l.x,l.y,l.z),i.setXYZ(g,c.x,c.y,c.z)}else for(let u=0,m=n.count;u<m;u+=3)r.fromBufferAttribute(n,u+0),a.fromBufferAttribute(n,u+1),s.fromBufferAttribute(n,u+2),f.subVectors(s,a),h.subVectors(r,a),f.cross(h),i.setXYZ(u+0,f.x,f.y,f.z),i.setXYZ(u+1,f.x,f.y,f.z),i.setXYZ(u+2,f.x,f.y,f.z);this.normalizeNormals(),i.needsUpdate=!0}}normalizeNormals(){const e=this.attributes.normal;for(let n=0,i=e.count;n<i;n++)kt.fromBufferAttribute(e,n),kt.normalize(),e.setXYZ(n,kt.x,kt.y,kt.z)}toNonIndexed(){function e(o,l){const c=o.array,f=o.itemSize,h=o.normalized,u=new c.constructor(l.length*f);let m=0,x=0;for(let E=0,g=l.length;E<g;E++){o.isInterleavedBufferAttribute?m=l[E]*o.data.stride+o.offset:m=l[E]*f;for(let d=0;d<f;d++)u[x++]=c[m++]}return new mi(u,f,h)}if(this.index===null)return De("BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const n=new Wi,i=this.index.array,r=this.attributes;for(const o in r){const l=r[o],c=e(l,i);n.setAttribute(o,c)}const a=this.morphAttributes;for(const o in a){const l=[],c=a[o];for(let f=0,h=c.length;f<h;f++){const u=c[f],m=e(u,i);l.push(m)}n.morphAttributes[o]=l}n.morphTargetsRelative=this.morphTargetsRelative;const s=this.groups;for(let o=0,l=s.length;o<l;o++){const c=s[o];n.addGroup(c.start,c.count,c.materialIndex)}return n}toJSON(){const e={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.parameters!==void 0&&this._transformed===!0?"BufferGeometry":this.type,this.name!==""&&(e.name=this.name),Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0&&this._transformed!==!0){const l=this.parameters;for(const c in l)l[c]!==void 0&&(e[c]=l[c]);return e}e.data={attributes:{}};const n=this.index;n!==null&&(e.data.index={type:n.array.constructor.name,array:Array.prototype.slice.call(n.array)});const i=this.attributes;for(const l in i){const c=i[l];e.data.attributes[l]=c.toJSON(e.data)}const r={};let a=!1;for(const l in this.morphAttributes){const c=this.morphAttributes[l],f=[];for(let h=0,u=c.length;h<u;h++){const m=c[h];f.push(m.toJSON(e.data))}f.length>0&&(r[l]=f,a=!0)}a&&(e.data.morphAttributes=r,e.data.morphTargetsRelative=this.morphTargetsRelative);const s=this.groups;s.length>0&&(e.data.groups=JSON.parse(JSON.stringify(s)));const o=this.boundingSphere;return o!==null&&(e.data.boundingSphere=o.toJSON()),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const n={};this.name=e.name;const i=e.index;i!==null&&this.setIndex(i.clone());const r=e.attributes;for(const c in r){const f=r[c];this.setAttribute(c,f.clone(n))}const a=e.morphAttributes;for(const c in a){const f=[],h=a[c];for(let u=0,m=h.length;u<m;u++)f.push(h[u].clone(n));this.morphAttributes[c]=f}this.morphTargetsRelative=e.morphTargetsRelative;const s=e.groups;for(let c=0,f=s.length;c<f;c++){const h=s[c];this.addGroup(h.start,h.count,h.materialIndex)}const o=e.boundingBox;o!==null&&(this.boundingBox=o.clone());const l=e.boundingSphere;return l!==null&&(this.boundingSphere=l.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this._transformed=e._transformed,this}dispose(){this.dispatchEvent({type:"dispose"})}}let vE=0;class Mc extends ea{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:vE++}),this.uuid=oo(),this.name="",this.type="Material",this.blending=Fa,this.side=yr,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=Pd,this.blendDst=Nd,this.blendEquation=Ir,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new Qe(0,0,0),this.blendAlpha=0,this.depthFunc=Xa,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=ym,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=ra,this.stencilZFail=ra,this.stencilZPass=ra,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(const n in e){const i=e[n];if(i===void 0){De(`Material: parameter '${n}' has value of undefined.`);continue}const r=this[n];if(r===void 0){De(`Material: '${n}' is not a property of THREE.${this.type}.`);continue}r&&r.isColor?r.set(i):r&&r.isVector2&&i&&i.isVector2||r&&r.isEuler&&i&&i.isEuler||r&&r.isVector3&&i&&i.isVector3?r.copy(i):this[n]=i}}toJSON(e){const n=e===void 0||typeof e=="string";n&&(e={textures:{},images:{}});const i={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};i.uuid=this.uuid,i.type=this.type,this.name!==""&&(i.name=this.name),this.color&&this.color.isColor&&(i.color=this.color.getHex()),this.roughness!==void 0&&(i.roughness=this.roughness),this.metalness!==void 0&&(i.metalness=this.metalness),this.sheen!==void 0&&(i.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(i.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(i.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(i.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(i.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(i.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(i.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(i.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(i.shininess=this.shininess),this.clearcoat!==void 0&&(i.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(i.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(i.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(i.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(i.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,i.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(i.sheenColorMap=this.sheenColorMap.toJSON(e).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(i.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(e).uuid),this.dispersion!==void 0&&(i.dispersion=this.dispersion),this.iridescence!==void 0&&(i.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(i.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(i.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(i.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(i.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(i.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(i.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(i.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(i.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(i.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(i.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(i.lightMap=this.lightMap.toJSON(e).uuid,i.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(i.aoMap=this.aoMap.toJSON(e).uuid,i.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(i.bumpMap=this.bumpMap.toJSON(e).uuid,i.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(i.normalMap=this.normalMap.toJSON(e).uuid,i.normalMapType=this.normalMapType,i.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(i.displacementMap=this.displacementMap.toJSON(e).uuid,i.displacementScale=this.displacementScale,i.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(i.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(i.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(i.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(i.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(i.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(i.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(i.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(i.combine=this.combine)),this.envMapRotation!==void 0&&(i.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(i.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(i.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(i.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(i.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(i.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(i.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(i.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(i.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(i.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(i.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(i.size=this.size),this.shadowSide!==null&&(i.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(i.sizeAttenuation=this.sizeAttenuation),this.blending!==Fa&&(i.blending=this.blending),this.side!==yr&&(i.side=this.side),this.vertexColors===!0&&(i.vertexColors=!0),this.opacity<1&&(i.opacity=this.opacity),this.transparent===!0&&(i.transparent=!0),this.blendSrc!==Pd&&(i.blendSrc=this.blendSrc),this.blendDst!==Nd&&(i.blendDst=this.blendDst),this.blendEquation!==Ir&&(i.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(i.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(i.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(i.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(i.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(i.blendAlpha=this.blendAlpha),this.depthFunc!==Xa&&(i.depthFunc=this.depthFunc),this.depthTest===!1&&(i.depthTest=this.depthTest),this.depthWrite===!1&&(i.depthWrite=this.depthWrite),this.colorWrite===!1&&(i.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(i.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==ym&&(i.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(i.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(i.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==ra&&(i.stencilFail=this.stencilFail),this.stencilZFail!==ra&&(i.stencilZFail=this.stencilZFail),this.stencilZPass!==ra&&(i.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(i.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(i.rotation=this.rotation),this.polygonOffset===!0&&(i.polygonOffset=!0),this.polygonOffsetFactor!==0&&(i.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(i.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(i.linewidth=this.linewidth),this.dashSize!==void 0&&(i.dashSize=this.dashSize),this.gapSize!==void 0&&(i.gapSize=this.gapSize),this.scale!==void 0&&(i.scale=this.scale),this.dithering===!0&&(i.dithering=!0),this.alphaTest>0&&(i.alphaTest=this.alphaTest),this.alphaHash===!0&&(i.alphaHash=!0),this.alphaToCoverage===!0&&(i.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(i.premultipliedAlpha=!0),this.forceSinglePass===!0&&(i.forceSinglePass=!0),this.allowOverride===!1&&(i.allowOverride=!1),this.wireframe===!0&&(i.wireframe=!0),this.wireframeLinewidth>1&&(i.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(i.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(i.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(i.flatShading=!0),this.visible===!1&&(i.visible=!1),this.toneMapped===!1&&(i.toneMapped=!1),this.fog===!1&&(i.fog=!1),Object.keys(this.userData).length>0&&(i.userData=this.userData);function r(a){const s=[];for(const o in a){const l=a[o];delete l.metadata,s.push(l)}return s}if(n){const a=r(e.textures),s=r(e.images);a.length>0&&(i.textures=a),s.length>0&&(i.images=s)}return i}fromJSON(e,n){if(e.uuid!==void 0&&(this.uuid=e.uuid),e.name!==void 0&&(this.name=e.name),e.color!==void 0&&this.color!==void 0&&this.color.setHex(e.color),e.roughness!==void 0&&(this.roughness=e.roughness),e.metalness!==void 0&&(this.metalness=e.metalness),e.sheen!==void 0&&(this.sheen=e.sheen),e.sheenColor!==void 0&&(this.sheenColor=new Qe().setHex(e.sheenColor)),e.sheenRoughness!==void 0&&(this.sheenRoughness=e.sheenRoughness),e.emissive!==void 0&&this.emissive!==void 0&&this.emissive.setHex(e.emissive),e.specular!==void 0&&this.specular!==void 0&&this.specular.setHex(e.specular),e.specularIntensity!==void 0&&(this.specularIntensity=e.specularIntensity),e.specularColor!==void 0&&this.specularColor!==void 0&&this.specularColor.setHex(e.specularColor),e.shininess!==void 0&&(this.shininess=e.shininess),e.clearcoat!==void 0&&(this.clearcoat=e.clearcoat),e.clearcoatRoughness!==void 0&&(this.clearcoatRoughness=e.clearcoatRoughness),e.dispersion!==void 0&&(this.dispersion=e.dispersion),e.iridescence!==void 0&&(this.iridescence=e.iridescence),e.iridescenceIOR!==void 0&&(this.iridescenceIOR=e.iridescenceIOR),e.iridescenceThicknessRange!==void 0&&(this.iridescenceThicknessRange=e.iridescenceThicknessRange),e.transmission!==void 0&&(this.transmission=e.transmission),e.thickness!==void 0&&(this.thickness=e.thickness),e.attenuationDistance!==void 0&&(this.attenuationDistance=e.attenuationDistance),e.attenuationColor!==void 0&&this.attenuationColor!==void 0&&this.attenuationColor.setHex(e.attenuationColor),e.anisotropy!==void 0&&(this.anisotropy=e.anisotropy),e.anisotropyRotation!==void 0&&(this.anisotropyRotation=e.anisotropyRotation),e.fog!==void 0&&(this.fog=e.fog),e.flatShading!==void 0&&(this.flatShading=e.flatShading),e.blending!==void 0&&(this.blending=e.blending),e.combine!==void 0&&(this.combine=e.combine),e.side!==void 0&&(this.side=e.side),e.shadowSide!==void 0&&(this.shadowSide=e.shadowSide),e.opacity!==void 0&&(this.opacity=e.opacity),e.transparent!==void 0&&(this.transparent=e.transparent),e.alphaTest!==void 0&&(this.alphaTest=e.alphaTest),e.alphaHash!==void 0&&(this.alphaHash=e.alphaHash),e.depthFunc!==void 0&&(this.depthFunc=e.depthFunc),e.depthTest!==void 0&&(this.depthTest=e.depthTest),e.depthWrite!==void 0&&(this.depthWrite=e.depthWrite),e.colorWrite!==void 0&&(this.colorWrite=e.colorWrite),e.blendSrc!==void 0&&(this.blendSrc=e.blendSrc),e.blendDst!==void 0&&(this.blendDst=e.blendDst),e.blendEquation!==void 0&&(this.blendEquation=e.blendEquation),e.blendSrcAlpha!==void 0&&(this.blendSrcAlpha=e.blendSrcAlpha),e.blendDstAlpha!==void 0&&(this.blendDstAlpha=e.blendDstAlpha),e.blendEquationAlpha!==void 0&&(this.blendEquationAlpha=e.blendEquationAlpha),e.blendColor!==void 0&&this.blendColor!==void 0&&this.blendColor.setHex(e.blendColor),e.blendAlpha!==void 0&&(this.blendAlpha=e.blendAlpha),e.stencilWriteMask!==void 0&&(this.stencilWriteMask=e.stencilWriteMask),e.stencilFunc!==void 0&&(this.stencilFunc=e.stencilFunc),e.stencilRef!==void 0&&(this.stencilRef=e.stencilRef),e.stencilFuncMask!==void 0&&(this.stencilFuncMask=e.stencilFuncMask),e.stencilFail!==void 0&&(this.stencilFail=e.stencilFail),e.stencilZFail!==void 0&&(this.stencilZFail=e.stencilZFail),e.stencilZPass!==void 0&&(this.stencilZPass=e.stencilZPass),e.stencilWrite!==void 0&&(this.stencilWrite=e.stencilWrite),e.wireframe!==void 0&&(this.wireframe=e.wireframe),e.wireframeLinewidth!==void 0&&(this.wireframeLinewidth=e.wireframeLinewidth),e.wireframeLinecap!==void 0&&(this.wireframeLinecap=e.wireframeLinecap),e.wireframeLinejoin!==void 0&&(this.wireframeLinejoin=e.wireframeLinejoin),e.rotation!==void 0&&(this.rotation=e.rotation),e.linewidth!==void 0&&(this.linewidth=e.linewidth),e.dashSize!==void 0&&(this.dashSize=e.dashSize),e.gapSize!==void 0&&(this.gapSize=e.gapSize),e.scale!==void 0&&(this.scale=e.scale),e.polygonOffset!==void 0&&(this.polygonOffset=e.polygonOffset),e.polygonOffsetFactor!==void 0&&(this.polygonOffsetFactor=e.polygonOffsetFactor),e.polygonOffsetUnits!==void 0&&(this.polygonOffsetUnits=e.polygonOffsetUnits),e.dithering!==void 0&&(this.dithering=e.dithering),e.alphaToCoverage!==void 0&&(this.alphaToCoverage=e.alphaToCoverage),e.premultipliedAlpha!==void 0&&(this.premultipliedAlpha=e.premultipliedAlpha),e.forceSinglePass!==void 0&&(this.forceSinglePass=e.forceSinglePass),e.allowOverride!==void 0&&(this.allowOverride=e.allowOverride),e.visible!==void 0&&(this.visible=e.visible),e.toneMapped!==void 0&&(this.toneMapped=e.toneMapped),e.userData!==void 0&&(this.userData=e.userData),e.vertexColors!==void 0&&(typeof e.vertexColors=="number"?this.vertexColors=e.vertexColors>0:this.vertexColors=e.vertexColors),e.size!==void 0&&(this.size=e.size),e.sizeAttenuation!==void 0&&(this.sizeAttenuation=e.sizeAttenuation),e.map!==void 0&&(this.map=n[e.map]||null),e.matcap!==void 0&&(this.matcap=n[e.matcap]||null),e.alphaMap!==void 0&&(this.alphaMap=n[e.alphaMap]||null),e.bumpMap!==void 0&&(this.bumpMap=n[e.bumpMap]||null),e.bumpScale!==void 0&&(this.bumpScale=e.bumpScale),e.normalMap!==void 0&&(this.normalMap=n[e.normalMap]||null),e.normalMapType!==void 0&&(this.normalMapType=e.normalMapType),e.normalScale!==void 0){let i=e.normalScale;Array.isArray(i)===!1&&(i=[i,i]),this.normalScale=new Ze().fromArray(i)}return e.displacementMap!==void 0&&(this.displacementMap=n[e.displacementMap]||null),e.displacementScale!==void 0&&(this.displacementScale=e.displacementScale),e.displacementBias!==void 0&&(this.displacementBias=e.displacementBias),e.roughnessMap!==void 0&&(this.roughnessMap=n[e.roughnessMap]||null),e.metalnessMap!==void 0&&(this.metalnessMap=n[e.metalnessMap]||null),e.emissiveMap!==void 0&&(this.emissiveMap=n[e.emissiveMap]||null),e.emissiveIntensity!==void 0&&(this.emissiveIntensity=e.emissiveIntensity),e.specularMap!==void 0&&(this.specularMap=n[e.specularMap]||null),e.specularIntensityMap!==void 0&&(this.specularIntensityMap=n[e.specularIntensityMap]||null),e.specularColorMap!==void 0&&(this.specularColorMap=n[e.specularColorMap]||null),e.envMap!==void 0&&(this.envMap=n[e.envMap]||null),e.envMapRotation!==void 0&&this.envMapRotation.fromArray(e.envMapRotation),e.envMapIntensity!==void 0&&(this.envMapIntensity=e.envMapIntensity),e.reflectivity!==void 0&&(this.reflectivity=e.reflectivity),e.refractionRatio!==void 0&&(this.refractionRatio=e.refractionRatio),e.lightMap!==void 0&&(this.lightMap=n[e.lightMap]||null),e.lightMapIntensity!==void 0&&(this.lightMapIntensity=e.lightMapIntensity),e.aoMap!==void 0&&(this.aoMap=n[e.aoMap]||null),e.aoMapIntensity!==void 0&&(this.aoMapIntensity=e.aoMapIntensity),e.gradientMap!==void 0&&(this.gradientMap=n[e.gradientMap]||null),e.clearcoatMap!==void 0&&(this.clearcoatMap=n[e.clearcoatMap]||null),e.clearcoatRoughnessMap!==void 0&&(this.clearcoatRoughnessMap=n[e.clearcoatRoughnessMap]||null),e.clearcoatNormalMap!==void 0&&(this.clearcoatNormalMap=n[e.clearcoatNormalMap]||null),e.clearcoatNormalScale!==void 0&&(this.clearcoatNormalScale=new Ze().fromArray(e.clearcoatNormalScale)),e.iridescenceMap!==void 0&&(this.iridescenceMap=n[e.iridescenceMap]||null),e.iridescenceThicknessMap!==void 0&&(this.iridescenceThicknessMap=n[e.iridescenceThicknessMap]||null),e.transmissionMap!==void 0&&(this.transmissionMap=n[e.transmissionMap]||null),e.thicknessMap!==void 0&&(this.thicknessMap=n[e.thicknessMap]||null),e.anisotropyMap!==void 0&&(this.anisotropyMap=n[e.anisotropyMap]||null),e.sheenColorMap!==void 0&&(this.sheenColorMap=n[e.sheenColorMap]||null),e.sheenRoughnessMap!==void 0&&(this.sheenRoughnessMap=n[e.sheenRoughnessMap]||null),this}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;const n=e.clippingPlanes;let i=null;if(n!==null){const r=n.length;i=new Array(r);for(let a=0;a!==r;++a)i[a]=n[a].clone()}return this.clippingPlanes=i,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.allowOverride=e.allowOverride,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}}const Ei=new j,wu=new j,Vo=new j,Ji=new j,Tu=new j,Ho=new j,Au=new j;class yE{constructor(e=new j,n=new j(0,0,-1)){this.origin=e,this.direction=n}set(e,n){return this.origin.copy(e),this.direction.copy(n),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,n){return n.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,Ei)),this}closestPointToPoint(e,n){n.subVectors(e,this.origin);const i=n.dot(this.direction);return i<0?n.copy(this.origin):n.copy(this.origin).addScaledVector(this.direction,i)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){const n=Ei.subVectors(e,this.origin).dot(this.direction);return n<0?this.origin.distanceToSquared(e):(Ei.copy(this.origin).addScaledVector(this.direction,n),Ei.distanceToSquared(e))}distanceSqToSegment(e,n,i,r){wu.copy(e).add(n).multiplyScalar(.5),Vo.copy(n).sub(e).normalize(),Ji.copy(this.origin).sub(wu);const a=e.distanceTo(n)*.5,s=-this.direction.dot(Vo),o=Ji.dot(this.direction),l=-Ji.dot(Vo),c=Ji.lengthSq(),f=Math.abs(1-s*s);let h,u,m,x;if(f>0)if(h=s*l-o,u=s*o-l,x=a*f,h>=0)if(u>=-x)if(u<=x){const E=1/f;h*=E,u*=E,m=h*(h+s*u+2*o)+u*(s*h+u+2*l)+c}else u=a,h=Math.max(0,-(s*u+o)),m=-h*h+u*(u+2*l)+c;else u=-a,h=Math.max(0,-(s*u+o)),m=-h*h+u*(u+2*l)+c;else u<=-x?(h=Math.max(0,-(-s*a+o)),u=h>0?-a:Math.min(Math.max(-a,-l),a),m=-h*h+u*(u+2*l)+c):u<=x?(h=0,u=Math.min(Math.max(-a,-l),a),m=u*(u+2*l)+c):(h=Math.max(0,-(s*a+o)),u=h>0?a:Math.min(Math.max(-a,-l),a),m=-h*h+u*(u+2*l)+c);else u=s>0?-a:a,h=Math.max(0,-(s*u+o)),m=-h*h+u*(u+2*l)+c;return i&&i.copy(this.origin).addScaledVector(this.direction,h),r&&r.copy(wu).addScaledVector(Vo,u),m}intersectSphere(e,n){Ei.subVectors(e.center,this.origin);const i=Ei.dot(this.direction),r=Ei.dot(Ei)-i*i,a=e.radius*e.radius;if(r>a)return null;const s=Math.sqrt(a-r),o=i-s,l=i+s;return l<0?null:o<0?this.at(l,n):this.at(o,n)}intersectsSphere(e){return e.radius<0?!1:this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){const n=e.normal.dot(this.direction);if(n===0)return e.distanceToPoint(this.origin)===0?0:null;const i=-(this.origin.dot(e.normal)+e.constant)/n;return i>=0?i:null}intersectPlane(e,n){const i=this.distanceToPlane(e);return i===null?null:this.at(i,n)}intersectsPlane(e){const n=e.distanceToPoint(this.origin);return n===0||e.normal.dot(this.direction)*n<0}intersectBox(e,n){let i,r,a,s,o,l;const c=1/this.direction.x,f=1/this.direction.y,h=1/this.direction.z,u=this.origin;return c>=0?(i=(e.min.x-u.x)*c,r=(e.max.x-u.x)*c):(i=(e.max.x-u.x)*c,r=(e.min.x-u.x)*c),f>=0?(a=(e.min.y-u.y)*f,s=(e.max.y-u.y)*f):(a=(e.max.y-u.y)*f,s=(e.min.y-u.y)*f),i>s||a>r||((a>i||isNaN(i))&&(i=a),(s<r||isNaN(r))&&(r=s),h>=0?(o=(e.min.z-u.z)*h,l=(e.max.z-u.z)*h):(o=(e.max.z-u.z)*h,l=(e.min.z-u.z)*h),i>l||o>r)||((o>i||i!==i)&&(i=o),(l<r||r!==r)&&(r=l),r<0)?null:this.at(i>=0?i:r,n)}intersectsBox(e){return this.intersectBox(e,Ei)!==null}intersectTriangle(e,n,i,r,a){Tu.subVectors(n,e),Ho.subVectors(i,e),Au.crossVectors(Tu,Ho);let s=this.direction.dot(Au),o;if(s>0){if(r)return null;o=1}else if(s<0)o=-1,s=-s;else return null;Ji.subVectors(this.origin,e);const l=o*this.direction.dot(Ho.crossVectors(Ji,Ho));if(l<0)return null;const c=o*this.direction.dot(Tu.cross(Ji));if(c<0||l+c>s)return null;const f=-o*Ji.dot(Au);return f<0?null:this.at(f/s,a)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class Cx extends Mc{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new Qe(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Kr,this.combine=sx,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}}const Fm=new Nt,Cr=new yE,Go=new Ih,Om=new j,Wo=new j,jo=new j,Xo=new j,Cu=new j,$o=new j,km=new j,qo=new j;class _i extends Mn{constructor(e=new Wi,n=new Cx){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=n,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(e,n){return super.copy(e,n),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){const n=this.geometry.morphAttributes,i=Object.keys(n);if(i.length>0){const r=n[i[0]];if(r!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let a=0,s=r.length;a<s;a++){const o=r[a].name||String(a);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=a}}}}getVertexPosition(e,n){const i=this.geometry,r=i.attributes.position,a=i.morphAttributes.position,s=i.morphTargetsRelative;n.fromBufferAttribute(r,e);const o=this.morphTargetInfluences;if(a&&o){$o.set(0,0,0);for(let l=0,c=a.length;l<c;l++){const f=o[l],h=a[l];f!==0&&(Cu.fromBufferAttribute(h,e),s?$o.addScaledVector(Cu,f):$o.addScaledVector(Cu.sub(n),f))}n.add($o)}return n}raycast(e,n){const i=this.geometry,r=this.material,a=this.matrixWorld;r!==void 0&&(i.boundingSphere===null&&i.computeBoundingSphere(),Go.copy(i.boundingSphere),Go.applyMatrix4(a),Cr.copy(e.ray).recast(e.near),!(Go.containsPoint(Cr.origin)===!1&&(Cr.intersectSphere(Go,Om)===null||Cr.origin.distanceToSquared(Om)>(e.far-e.near)**2))&&(Fm.copy(a).invert(),Cr.copy(e.ray).applyMatrix4(Fm),!(i.boundingBox!==null&&Cr.intersectsBox(i.boundingBox)===!1)&&this._computeIntersections(e,n,Cr)))}_computeIntersections(e,n,i){let r;const a=this.geometry,s=this.material,o=a.index,l=a.attributes.position,c=a.attributes.uv,f=a.attributes.uv1,h=a.attributes.normal,u=a.groups,m=a.drawRange;if(o!==null)if(Array.isArray(s))for(let x=0,E=u.length;x<E;x++){const g=u[x],d=s[g.materialIndex],v=Math.max(g.start,m.start),S=Math.min(o.count,Math.min(g.start+g.count,m.start+m.count));for(let M=v,A=S;M<A;M+=3){const T=o.getX(M),w=o.getX(M+1),_=o.getX(M+2);r=Yo(this,d,e,i,c,f,h,T,w,_),r&&(r.faceIndex=Math.floor(M/3),r.face.materialIndex=g.materialIndex,n.push(r))}}else{const x=Math.max(0,m.start),E=Math.min(o.count,m.start+m.count);for(let g=x,d=E;g<d;g+=3){const v=o.getX(g),S=o.getX(g+1),M=o.getX(g+2);r=Yo(this,s,e,i,c,f,h,v,S,M),r&&(r.faceIndex=Math.floor(g/3),n.push(r))}}else if(l!==void 0)if(Array.isArray(s))for(let x=0,E=u.length;x<E;x++){const g=u[x],d=s[g.materialIndex],v=Math.max(g.start,m.start),S=Math.min(l.count,Math.min(g.start+g.count,m.start+m.count));for(let M=v,A=S;M<A;M+=3){const T=M,w=M+1,_=M+2;r=Yo(this,d,e,i,c,f,h,T,w,_),r&&(r.faceIndex=Math.floor(M/3),r.face.materialIndex=g.materialIndex,n.push(r))}}else{const x=Math.max(0,m.start),E=Math.min(l.count,m.start+m.count);for(let g=x,d=E;g<d;g+=3){const v=g,S=g+1,M=g+2;r=Yo(this,s,e,i,c,f,h,v,S,M),r&&(r.faceIndex=Math.floor(g/3),n.push(r))}}}}function SE(t,e,n,i,r,a,s,o){let l;if(e.side===mn?l=i.intersectTriangle(s,a,r,!0,o):l=i.intersectTriangle(r,a,s,e.side===yr,o),l===null)return null;qo.copy(o),qo.applyMatrix4(t.matrixWorld);const c=n.ray.origin.distanceTo(qo);return c<n.near||c>n.far?null:{distance:c,point:qo.clone(),object:t}}function Yo(t,e,n,i,r,a,s,o,l,c){t.getVertexPosition(o,Wo),t.getVertexPosition(l,jo),t.getVertexPosition(c,Xo);const f=SE(t,e,n,i,Wo,jo,Xo,km);if(f){const h=new j;jn.getBarycoord(km,Wo,jo,Xo,h),r&&(f.uv=jn.getInterpolatedAttribute(r,o,l,c,h,new Ze)),a&&(f.uv1=jn.getInterpolatedAttribute(a,o,l,c,h,new Ze)),s&&(f.normal=jn.getInterpolatedAttribute(s,o,l,c,h,new j),f.normal.dot(i.direction)>0&&f.normal.multiplyScalar(-1));const u={a:o,b:l,c,normal:new j,materialIndex:0};jn.getNormal(Wo,jo,Xo,u.normal),f.face=u,f.barycoord=h}return f}class ME extends an{constructor(e=null,n=1,i=1,r,a,s,o,l,c=Gt,f=Gt,h,u){super(null,s,o,l,c,f,r,a,h,u),this.isDataTexture=!0,this.image={data:e,width:n,height:i},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}const Ru=new j,EE=new j,bE=new Ie;class Dr{constructor(e=new j(1,0,0),n=0){this.isPlane=!0,this.normal=e,this.constant=n}set(e,n){return this.normal.copy(e),this.constant=n,this}setComponents(e,n,i,r){return this.normal.set(e,n,i),this.constant=r,this}setFromNormalAndCoplanarPoint(e,n){return this.normal.copy(e),this.constant=-n.dot(this.normal),this}setFromCoplanarPoints(e,n,i){const r=Ru.subVectors(i,n).cross(EE.subVectors(e,n)).normalize();return this.setFromNormalAndCoplanarPoint(r,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){const e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,n){return n.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,n,i=!0){const r=e.delta(Ru),a=this.normal.dot(r);if(a===0)return this.distanceToPoint(e.start)===0?n.copy(e.start):null;const s=-(e.start.dot(this.normal)+this.constant)/a;return i===!0&&(s<0||s>1)?null:n.copy(e.start).addScaledVector(r,s)}intersectsLine(e){const n=this.distanceToPoint(e.start),i=this.distanceToPoint(e.end);return n<0&&i>0||i<0&&n>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,n){const i=n||bE.getNormalMatrix(e),r=this.coplanarPoint(Ru).applyMatrix4(e),a=this.normal.applyMatrix3(i).normalize();return this.constant=-r.dot(a),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}}const Rr=new Ih,wE=new Ze(.5,.5),Ko=new j;class Rx{constructor(e=new Dr,n=new Dr,i=new Dr,r=new Dr,a=new Dr,s=new Dr){this.planes=[e,n,i,r,a,s]}set(e,n,i,r,a,s){const o=this.planes;return o[0].copy(e),o[1].copy(n),o[2].copy(i),o[3].copy(r),o[4].copy(a),o[5].copy(s),this}copy(e){const n=this.planes;for(let i=0;i<6;i++)n[i].copy(e.planes[i]);return this}setFromProjectionMatrix(e,n=ui,i=!1){const r=this.planes,a=e.elements,s=a[0],o=a[1],l=a[2],c=a[3],f=a[4],h=a[5],u=a[6],m=a[7],x=a[8],E=a[9],g=a[10],d=a[11],v=a[12],S=a[13],M=a[14],A=a[15];if(r[0].setComponents(c-s,m-f,d-x,A-v).normalize(),r[1].setComponents(c+s,m+f,d+x,A+v).normalize(),r[2].setComponents(c+o,m+h,d+E,A+S).normalize(),r[3].setComponents(c-o,m-h,d-E,A-S).normalize(),i)r[4].setComponents(l,u,g,M).normalize(),r[5].setComponents(c-l,m-u,d-g,A-M).normalize();else if(r[4].setComponents(c-l,m-u,d-g,A-M).normalize(),n===ui)r[5].setComponents(c+l,m+u,d+g,A+M).normalize();else if(n===Jl)r[5].setComponents(l,u,g,M).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+n);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),Rr.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{const n=e.geometry;n.boundingSphere===null&&n.computeBoundingSphere(),Rr.copy(n.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(Rr)}intersectsSprite(e){Rr.center.set(0,0,0);const n=wE.distanceTo(e.center);return Rr.radius=.7071067811865476+n,Rr.applyMatrix4(e.matrixWorld),this.intersectsSphere(Rr)}intersectsSphere(e){const n=this.planes,i=e.center,r=-e.radius;for(let a=0;a<6;a++)if(n[a].distanceToPoint(i)<r)return!1;return!0}intersectsBox(e){const n=this.planes;for(let i=0;i<6;i++){const r=n[i];if(Ko.x=r.normal.x>0?e.max.x:e.min.x,Ko.y=r.normal.y>0?e.max.y:e.min.y,Ko.z=r.normal.z>0?e.max.z:e.min.z,r.distanceToPoint(Ko)<0)return!1}return!0}containsPoint(e){const n=this.planes;for(let i=0;i<6;i++)if(n[i].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}class Px extends an{constructor(e=[],n=qr,i,r,a,s,o,l,c,f){super(e,n,i,r,a,s,o,l,c,f),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}}class qa extends an{constructor(e,n,i=gi,r,a,s,o=Gt,l=Gt,c,f=Vi,h=1){if(f!==Vi&&f!==zr)throw new Error("THREE.DepthTexture: format must be either THREE.DepthFormat or THREE.DepthStencilFormat");const u={width:e,height:n,depth:h};super(u,r,a,s,o,l,f,i,c),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.source=new Dh(Object.assign({},e.image)),this.compareFunction=e.compareFunction,this}toJSON(e){const n=super.toJSON(e);return this.compareFunction!==null&&(n.compareFunction=this.compareFunction),n}}class TE extends qa{constructor(e,n=gi,i=qr,r,a,s=Gt,o=Gt,l,c=Vi){const f={width:e,height:e,depth:1},h=[f,f,f,f,f,f];super(e,e,n,i,r,a,s,o,l,c),this.image=h,this.isCubeDepthTexture=!0,this.isCubeTexture=!0}get images(){return this.image}set images(e){this.image=e}}class Nx extends an{constructor(e=null){super(),this.sourceTexture=e,this.isExternalTexture=!0}copy(e){return super.copy(e),this.sourceTexture=e.sourceTexture,this}}class co extends Wi{constructor(e=1,n=1,i=1,r=1,a=1,s=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:n,depth:i,widthSegments:r,heightSegments:a,depthSegments:s};const o=this;r=Math.floor(r),a=Math.floor(a),s=Math.floor(s);const l=[],c=[],f=[],h=[];let u=0,m=0;x("z","y","x",-1,-1,i,n,e,s,a,0),x("z","y","x",1,-1,i,n,-e,s,a,1),x("x","z","y",1,1,e,i,n,r,s,2),x("x","z","y",1,-1,e,i,-n,r,s,3),x("x","y","z",1,-1,e,n,i,r,a,4),x("x","y","z",-1,-1,e,n,-i,r,a,5),this.setIndex(l),this.setAttribute("position",new Ii(c,3)),this.setAttribute("normal",new Ii(f,3)),this.setAttribute("uv",new Ii(h,2));function x(E,g,d,v,S,M,A,T,w,_,C){const P=M/w,N=A/_,F=M/2,q=A/2,ie=T/2,k=w+1,X=_+1;let V=0,O=0;const I=new j;for(let J=0;J<X;J++){const ae=J*N-q;for(let le=0;le<k;le++){const Be=le*P-F;I[E]=Be*v,I[g]=ae*S,I[d]=ie,c.push(I.x,I.y,I.z),I[E]=0,I[g]=0,I[d]=T>0?1:-1,f.push(I.x,I.y,I.z),h.push(le/w),h.push(1-J/_),V+=1}}for(let J=0;J<_;J++)for(let ae=0;ae<w;ae++){const le=u+ae+k*J,Be=u+ae+k*(J+1),Xe=u+(ae+1)+k*(J+1),ze=u+(ae+1)+k*J;l.push(le,Be,ze),l.push(Be,Xe,ze),O+=6}o.addGroup(m,O,C),m+=O,u+=V}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new co(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}}class uo extends Wi{constructor(e=1,n=1,i=1,r=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:n,widthSegments:i,heightSegments:r};const a=e/2,s=n/2,o=Math.floor(i),l=Math.floor(r),c=o+1,f=l+1,h=e/o,u=n/l,m=[],x=[],E=[],g=[];for(let d=0;d<f;d++){const v=d*u-s;for(let S=0;S<c;S++){const M=S*h-a;x.push(M,-v,0),E.push(0,0,1),g.push(S/o),g.push(1-d/l)}}for(let d=0;d<l;d++)for(let v=0;v<o;v++){const S=v+c*d,M=v+c*(d+1),A=v+1+c*(d+1),T=v+1+c*d;m.push(S,M,T),m.push(M,A,T)}this.setIndex(m),this.setAttribute("position",new Ii(x,3)),this.setAttribute("normal",new Ii(E,3)),this.setAttribute("uv",new Ii(g,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new uo(e.width,e.height,e.widthSegments,e.heightSegments)}}function Ya(t){const e={};for(const n in t){e[n]={};for(const i in t[n]){const r=t[n][i];if(Bm(r))r.isRenderTargetTexture?(De("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[n][i]=null):e[n][i]=r.clone();else if(Array.isArray(r))if(Bm(r[0])){const a=[];for(let s=0,o=r.length;s<o;s++)a[s]=r[s].clone();e[n][i]=a}else e[n][i]=r.slice();else e[n][i]=r}}return e}function tn(t){const e={};for(let n=0;n<t.length;n++){const i=Ya(t[n]);for(const r in i)e[r]=i[r]}return e}function Bm(t){return t&&(t.isColor||t.isMatrix3||t.isMatrix4||t.isVector2||t.isVector3||t.isVector4||t.isTexture||t.isQuaternion)}function AE(t){const e=[];for(let n=0;n<t.length;n++)e.push(t[n].clone());return e}function Lx(t){const e=t.getRenderTarget();return e===null?t.outputColorSpace:e.isXRRenderTarget===!0?e.texture.colorSpace:We.workingColorSpace}const CE={clone:Ya,merge:tn};var RE=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,PE=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class Qn extends Mc{constructor(e){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=RE,this.fragmentShader=PE,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=Ya(e.uniforms),this.uniformsGroups=AE(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this.defaultAttributeValues=Object.assign({},e.defaultAttributeValues),this.index0AttributeName=e.index0AttributeName,this.uniformsNeedUpdate=e.uniformsNeedUpdate,this}toJSON(e){const n=super.toJSON(e);n.glslVersion=this.glslVersion,n.uniforms={};for(const r in this.uniforms){const s=this.uniforms[r].value;s&&s.isTexture?n.uniforms[r]={type:"t",value:s.toJSON(e).uuid}:s&&s.isColor?n.uniforms[r]={type:"c",value:s.getHex()}:s&&s.isVector2?n.uniforms[r]={type:"v2",value:s.toArray()}:s&&s.isVector3?n.uniforms[r]={type:"v3",value:s.toArray()}:s&&s.isVector4?n.uniforms[r]={type:"v4",value:s.toArray()}:s&&s.isMatrix3?n.uniforms[r]={type:"m3",value:s.toArray()}:s&&s.isMatrix4?n.uniforms[r]={type:"m4",value:s.toArray()}:n.uniforms[r]={value:s}}Object.keys(this.defines).length>0&&(n.defines=this.defines),n.vertexShader=this.vertexShader,n.fragmentShader=this.fragmentShader,n.lights=this.lights,n.clipping=this.clipping;const i={};for(const r in this.extensions)this.extensions[r]===!0&&(i[r]=!0);return Object.keys(i).length>0&&(n.extensions=i),n}fromJSON(e,n){if(super.fromJSON(e,n),e.uniforms!==void 0)for(const i in e.uniforms){const r=e.uniforms[i];switch(this.uniforms[i]={},r.type){case"t":this.uniforms[i].value=n[r.value]||null;break;case"c":this.uniforms[i].value=new Qe().setHex(r.value);break;case"v2":this.uniforms[i].value=new Ze().fromArray(r.value);break;case"v3":this.uniforms[i].value=new j().fromArray(r.value);break;case"v4":this.uniforms[i].value=new Mt().fromArray(r.value);break;case"m3":this.uniforms[i].value=new Ie().fromArray(r.value);break;case"m4":this.uniforms[i].value=new Nt().fromArray(r.value);break;default:this.uniforms[i].value=r.value}}if(e.defines!==void 0&&(this.defines=e.defines),e.vertexShader!==void 0&&(this.vertexShader=e.vertexShader),e.fragmentShader!==void 0&&(this.fragmentShader=e.fragmentShader),e.glslVersion!==void 0&&(this.glslVersion=e.glslVersion),e.extensions!==void 0)for(const i in e.extensions)this.extensions[i]=e.extensions[i];return e.lights!==void 0&&(this.lights=e.lights),e.clipping!==void 0&&(this.clipping=e.clipping),this}}class NE extends Qn{constructor(e){super(e),this.isRawShaderMaterial=!0,this.type="RawShaderMaterial"}}class LE extends Mc{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=GM,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}}class DE extends Mc{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}}const Zo=new j,Qo=new es,ii=new j;class Dx extends Mn{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new Nt,this.projectionMatrix=new Nt,this.projectionMatrixInverse=new Nt,this.coordinateSystem=ui,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(e,n){return super.copy(e,n),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorld.decompose(Zo,Qo,ii),ii.x===1&&ii.y===1&&ii.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(Zo,Qo,ii.set(1,1,1)).invert()}updateWorldMatrix(e,n,i=!1){super.updateWorldMatrix(e,n,i),this.matrixWorld.decompose(Zo,Qo,ii),ii.x===1&&ii.y===1&&ii.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(Zo,Qo,ii.set(1,1,1)).invert()}clone(){return new this.constructor().copy(this)}}const er=new j,zm=new Ze,Vm=new Ze;class Wn extends Dx{constructor(e=50,n=1,i=.1,r=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=i,this.far=r,this.focus=10,this.aspect=n,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,n){return super.copy(e,n),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){const n=.5*this.getFilmHeight()/e;this.fov=xf*2*Math.atan(n),this.updateProjectionMatrix()}getFocalLength(){const e=Math.tan(su*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return xf*2*Math.atan(Math.tan(su*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,n,i){er.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(er.x,er.y).multiplyScalar(-e/er.z),er.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),i.set(er.x,er.y).multiplyScalar(-e/er.z)}getViewSize(e,n){return this.getViewBounds(e,zm,Vm),n.subVectors(Vm,zm)}setViewOffset(e,n,i,r,a,s){this.aspect=e/n,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=n,this.view.offsetX=i,this.view.offsetY=r,this.view.width=a,this.view.height=s,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=this.near;let n=e*Math.tan(su*.5*this.fov)/this.zoom,i=2*n,r=this.aspect*i,a=-.5*r;const s=this.view;if(this.view!==null&&this.view.enabled){const l=s.fullWidth,c=s.fullHeight;a+=s.offsetX*r/l,n-=s.offsetY*i/c,r*=s.width/l,i*=s.height/c}const o=this.filmOffset;o!==0&&(a+=e*o/this.getFilmWidth()),this.projectionMatrix.makePerspective(a,a+r,n,n-i,e,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const n=super.toJSON(e);return n.object.fov=this.fov,n.object.zoom=this.zoom,n.object.near=this.near,n.object.far=this.far,n.object.focus=this.focus,n.object.aspect=this.aspect,this.view!==null&&(n.object.view=Object.assign({},this.view)),n.object.filmGauge=this.filmGauge,n.object.filmOffset=this.filmOffset,n}}class Uh extends Dx{constructor(e=-1,n=1,i=1,r=-1,a=.1,s=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=n,this.top=i,this.bottom=r,this.near=a,this.far=s,this.updateProjectionMatrix()}copy(e,n){return super.copy(e,n),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,n,i,r,a,s){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=n,this.view.offsetX=i,this.view.offsetY=r,this.view.width=a,this.view.height=s,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=(this.right-this.left)/(2*this.zoom),n=(this.top-this.bottom)/(2*this.zoom),i=(this.right+this.left)/2,r=(this.top+this.bottom)/2;let a=i-e,s=i+e,o=r+n,l=r-n;if(this.view!==null&&this.view.enabled){const c=(this.right-this.left)/this.view.fullWidth/this.zoom,f=(this.top-this.bottom)/this.view.fullHeight/this.zoom;a+=c*this.view.offsetX,s=a+c*this.view.width,o-=f*this.view.offsetY,l=o-f*this.view.height}this.projectionMatrix.makeOrthographic(a,s,o,l,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const n=super.toJSON(e);return n.object.zoom=this.zoom,n.object.left=this.left,n.object.right=this.right,n.object.top=this.top,n.object.bottom=this.bottom,n.object.near=this.near,n.object.far=this.far,this.view!==null&&(n.object.view=Object.assign({},this.view)),n}}const ma=-90,ga=1;class IE extends Mn{constructor(e,n,i){super(),this.type="CubeCamera",this.renderTarget=i,this.coordinateSystem=null,this.activeMipmapLevel=0;const r=new Wn(ma,ga,e,n);r.layers=this.layers,this.add(r);const a=new Wn(ma,ga,e,n);a.layers=this.layers,this.add(a);const s=new Wn(ma,ga,e,n);s.layers=this.layers,this.add(s);const o=new Wn(ma,ga,e,n);o.layers=this.layers,this.add(o);const l=new Wn(ma,ga,e,n);l.layers=this.layers,this.add(l);const c=new Wn(ma,ga,e,n);c.layers=this.layers,this.add(c)}updateCoordinateSystem(){const e=this.coordinateSystem,n=this.children.concat(),[i,r,a,s,o,l]=n;for(const c of n)this.remove(c);if(e===ui)i.up.set(0,1,0),i.lookAt(1,0,0),r.up.set(0,1,0),r.lookAt(-1,0,0),a.up.set(0,0,-1),a.lookAt(0,1,0),s.up.set(0,0,1),s.lookAt(0,-1,0),o.up.set(0,1,0),o.lookAt(0,0,1),l.up.set(0,1,0),l.lookAt(0,0,-1);else if(e===Jl)i.up.set(0,-1,0),i.lookAt(-1,0,0),r.up.set(0,-1,0),r.lookAt(1,0,0),a.up.set(0,0,1),a.lookAt(0,1,0),s.up.set(0,0,-1),s.lookAt(0,-1,0),o.up.set(0,-1,0),o.lookAt(0,0,1),l.up.set(0,-1,0),l.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);for(const c of n)this.add(c),c.updateMatrixWorld()}update(e,n){this.parent===null&&this.updateMatrixWorld();const{renderTarget:i,activeMipmapLevel:r}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());const[a,s,o,l,c,f]=this.children,h=e.getRenderTarget(),u=e.getActiveCubeFace(),m=e.getActiveMipmapLevel(),x=e.xr.enabled;e.xr.enabled=!1;const E=i.texture.generateMipmaps;i.texture.generateMipmaps=!1;let g=!1;e.isWebGLRenderer===!0?g=e.state.buffers.depth.getReversed():g=e.reversedDepthBuffer,e.setRenderTarget(i,0,r),g&&e.autoClear===!1&&e.clearDepth(),e.render(n,a),e.setRenderTarget(i,1,r),g&&e.autoClear===!1&&e.clearDepth(),e.render(n,s),e.setRenderTarget(i,2,r),g&&e.autoClear===!1&&e.clearDepth(),e.render(n,o),e.setRenderTarget(i,3,r),g&&e.autoClear===!1&&e.clearDepth(),e.render(n,l),e.setRenderTarget(i,4,r),g&&e.autoClear===!1&&e.clearDepth(),e.render(n,c),i.texture.generateMipmaps=E,e.setRenderTarget(i,5,r),g&&e.autoClear===!1&&e.clearDepth(),e.render(n,f),e.setRenderTarget(h,u,m),e.xr.enabled=x,i.texture.needsPMREMUpdate=!0}}class UE extends Wn{constructor(e=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=e}}const zh=class zh{constructor(e,n,i,r){this.elements=[1,0,0,1],e!==void 0&&this.set(e,n,i,r)}identity(){return this.set(1,0,0,1),this}fromArray(e,n=0){for(let i=0;i<4;i++)this.elements[i]=e[i+n];return this}set(e,n,i,r){const a=this.elements;return a[0]=e,a[2]=n,a[1]=i,a[3]=r,this}};zh.prototype.isMatrix2=!0;let Hm=zh;function Gm(t,e,n,i){const r=FE(i);switch(n){case vx:return t*e;case Sx:return t*e/r.components*r.byteLength;case Ch:return t*e/r.components*r.byteLength;case Yr:return t*e*2/r.components*r.byteLength;case Rh:return t*e*2/r.components*r.byteLength;case yx:return t*e*3/r.components*r.byteLength;case Xn:return t*e*4/r.components*r.byteLength;case Ph:return t*e*4/r.components*r.byteLength;case _l:case xl:return Math.floor((t+3)/4)*Math.floor((e+3)/4)*8;case vl:case yl:return Math.floor((t+3)/4)*Math.floor((e+3)/4)*16;case Hd:case Wd:return Math.max(t,16)*Math.max(e,8)/4;case Vd:case Gd:return Math.max(t,8)*Math.max(e,8)/2;case jd:case Xd:case qd:case Yd:return Math.floor((t+3)/4)*Math.floor((e+3)/4)*8;case $d:case Yl:case Kd:return Math.floor((t+3)/4)*Math.floor((e+3)/4)*16;case Zd:return Math.floor((t+3)/4)*Math.floor((e+3)/4)*16;case Qd:return Math.floor((t+4)/5)*Math.floor((e+3)/4)*16;case Jd:return Math.floor((t+4)/5)*Math.floor((e+4)/5)*16;case ef:return Math.floor((t+5)/6)*Math.floor((e+4)/5)*16;case tf:return Math.floor((t+5)/6)*Math.floor((e+5)/6)*16;case nf:return Math.floor((t+7)/8)*Math.floor((e+4)/5)*16;case rf:return Math.floor((t+7)/8)*Math.floor((e+5)/6)*16;case af:return Math.floor((t+7)/8)*Math.floor((e+7)/8)*16;case sf:return Math.floor((t+9)/10)*Math.floor((e+4)/5)*16;case of:return Math.floor((t+9)/10)*Math.floor((e+5)/6)*16;case lf:return Math.floor((t+9)/10)*Math.floor((e+7)/8)*16;case cf:return Math.floor((t+9)/10)*Math.floor((e+9)/10)*16;case uf:return Math.floor((t+11)/12)*Math.floor((e+9)/10)*16;case df:return Math.floor((t+11)/12)*Math.floor((e+11)/12)*16;case ff:case hf:case pf:return Math.ceil(t/4)*Math.ceil(e/4)*16;case mf:case gf:return Math.ceil(t/4)*Math.ceil(e/4)*8;case Kl:case _f:return Math.ceil(t/4)*Math.ceil(e/4)*16}throw new Error(`Unable to determine texture byte length for ${n} format.`)}function FE(t){switch(t){case Nn:case mx:return{byteLength:1,components:1};case Zs:case gx:case zi:return{byteLength:2,components:1};case Th:case Ah:return{byteLength:2,components:4};case gi:case wh:case ci:return{byteLength:4,components:1};case _x:case xx:return{byteLength:4,components:3}}throw new Error(`THREE.TextureUtils: Unknown texture type ${t}.`)}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:bh}}));typeof window<"u"&&(window.__THREE__?De("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=bh);/**
 * @license
 * Copyright 2010-2026 Three.js Authors
 * SPDX-License-Identifier: MIT
 */function Ix(){let t=null,e=!1,n=null,i=null;function r(a,s){n(a,s),i=t.requestAnimationFrame(r)}return{start:function(){e!==!0&&n!==null&&t!==null&&(i=t.requestAnimationFrame(r),e=!0)},stop:function(){t!==null&&t.cancelAnimationFrame(i),e=!1},setAnimationLoop:function(a){n=a},setContext:function(a){t=a}}}function OE(t){const e=new WeakMap;function n(o,l){const c=o.array,f=o.usage,h=c.byteLength,u=t.createBuffer();t.bindBuffer(l,u),t.bufferData(l,c,f),o.onUploadCallback();let m;if(c instanceof Float32Array)m=t.FLOAT;else if(typeof Float16Array<"u"&&c instanceof Float16Array)m=t.HALF_FLOAT;else if(c instanceof Uint16Array)o.isFloat16BufferAttribute?m=t.HALF_FLOAT:m=t.UNSIGNED_SHORT;else if(c instanceof Int16Array)m=t.SHORT;else if(c instanceof Uint32Array)m=t.UNSIGNED_INT;else if(c instanceof Int32Array)m=t.INT;else if(c instanceof Int8Array)m=t.BYTE;else if(c instanceof Uint8Array)m=t.UNSIGNED_BYTE;else if(c instanceof Uint8ClampedArray)m=t.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+c);return{buffer:u,type:m,bytesPerElement:c.BYTES_PER_ELEMENT,version:o.version,size:h}}function i(o,l,c){const f=l.array,h=l.updateRanges;if(t.bindBuffer(c,o),h.length===0)t.bufferSubData(c,0,f);else{h.sort((m,x)=>m.start-x.start);let u=0;for(let m=1;m<h.length;m++){const x=h[u],E=h[m];E.start<=x.start+x.count+1?x.count=Math.max(x.count,E.start+E.count-x.start):(++u,h[u]=E)}h.length=u+1;for(let m=0,x=h.length;m<x;m++){const E=h[m];t.bufferSubData(c,E.start*f.BYTES_PER_ELEMENT,f,E.start,E.count)}l.clearUpdateRanges()}l.onUploadCallback()}function r(o){return o.isInterleavedBufferAttribute&&(o=o.data),e.get(o)}function a(o){o.isInterleavedBufferAttribute&&(o=o.data);const l=e.get(o);l&&(t.deleteBuffer(l.buffer),e.delete(o))}function s(o,l){if(o.isInterleavedBufferAttribute&&(o=o.data),o.isGLBufferAttribute){const f=e.get(o);(!f||f.version<o.version)&&e.set(o,{buffer:o.buffer,type:o.type,bytesPerElement:o.elementSize,version:o.version});return}const c=e.get(o);if(c===void 0)e.set(o,n(o,l));else if(c.version<o.version){if(c.size!==o.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");i(c.buffer,o,l),c.version=o.version}}return{get:r,remove:a,update:s}}var kE=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,BE=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,zE=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,VE=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,HE=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,GE=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,WE=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,jE=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,XE=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec4 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 );
	}
#endif`,$E=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,qE=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,YE=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,KE=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,ZE=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,QE=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,JE=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,eb=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,tb=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,nb=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,ib=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#endif`,rb=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#endif`,ab=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec4 vColor;
#endif`,sb=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec4( 1.0 );
#endif
#ifdef USE_COLOR_ALPHA
	vColor *= color;
#elif defined( USE_COLOR )
	vColor.rgb *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.rgb *= instanceColor.rgb;
#endif
#ifdef USE_BATCHING_COLOR
	vColor *= getBatchingColor( getIndirectIndex( gl_DrawID ) );
#endif`,ob=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
#define inverseTransformDirection transformDirectionByInverseViewMatrix
vec3 transformNormalByInverseViewMatrix( in vec3 normal, in mat4 viewMatrix ) {
	return normalize( ( vec4( normal, 0.0 ) * viewMatrix ).xyz );
}
vec3 transformDirectionByInverseViewMatrix( in vec3 dir, in mat4 viewMatrix ) {
	return normalize( ( vec4( dir, 0.0 ) * viewMatrix ).xyz );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,lb=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,cb=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
#endif`,ub=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,db=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,fb=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,hb=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,pb="gl_FragColor = linearToOutputTexel( gl_FragColor );",mb=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,gb=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * reflectVec );
		#ifdef ENVMAP_BLENDING_MULTIPLY
			outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_MIX )
			outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_ADD )
			outgoingLight += envColor.xyz * specularStrength * reflectivity;
		#endif
	#endif
#endif`,_b=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
#endif`,xb=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,vb=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,yb=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,Sb=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,Mb=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,Eb=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,bb=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,wb=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,Tb=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,Ab=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,Cb=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,Rb=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif
#include <lightprobes_pars_fragment>`,Pb=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );
			reflectVec = transformDirectionByInverseViewMatrix( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,Nb=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,Lb=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,Db=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,Ib=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,Ub=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.diffuseContribution = diffuseColor.rgb * ( 1.0 - metalnessFactor );
material.metalness = metalnessFactor;
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor;
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = vec3( 0.04 );
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.0001, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,Fb=`uniform sampler2D dfgLUT;
struct PhysicalMaterial {
	vec3 diffuseColor;
	vec3 diffuseContribution;
	vec3 specularColor;
	vec3 specularColorBlended;
	float roughness;
	float metalness;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
		vec3 iridescenceFresnelDielectric;
		vec3 iridescenceFresnelMetallic;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		return 0.5 / max( gv + gl, EPSILON );
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColorBlended;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float rInv = 1.0 / ( roughness + 0.1 );
	float a = -1.9362 + 1.0678 * roughness + 0.4573 * r2 - 0.8469 * rInv;
	float b = -0.6014 + 0.5538 * roughness - 0.4670 * r2 - 0.1255 * rInv;
	float DG = exp( a * dotNV + b );
	return saturate( DG );
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
vec3 BRDF_GGX_Multiscatter( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 singleScatter = BRDF_GGX( lightDir, viewDir, normal, material );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 dfgV = texture2D( dfgLUT, vec2( material.roughness, dotNV ) ).rg;
	vec2 dfgL = texture2D( dfgLUT, vec2( material.roughness, dotNL ) ).rg;
	vec3 FssEss_V = material.specularColorBlended * dfgV.x + material.specularF90 * dfgV.y;
	vec3 FssEss_L = material.specularColorBlended * dfgL.x + material.specularF90 * dfgL.y;
	float Ess_V = dfgV.x + dfgV.y;
	float Ess_L = dfgL.x + dfgL.y;
	float Ems_V = 1.0 - Ess_V;
	float Ems_L = 1.0 - Ess_L;
	vec3 Favg = material.specularColorBlended + ( 1.0 - material.specularColorBlended ) * 0.047619;
	vec3 Fms = FssEss_V * FssEss_L * Favg / ( 1.0 - Ems_V * Ems_L * Favg + EPSILON );
	float compensationFactor = Ems_V * Ems_L;
	vec3 multiScatter = Fms * compensationFactor;
	return singleScatter + multiScatter;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColorBlended * t2.x + ( material.specularF90 - material.specularColorBlended ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseContribution * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
		#ifdef USE_CLEARCOAT
			vec3 Ncc = geometryClearcoatNormal;
			vec2 uvClearcoat = LTC_Uv( Ncc, viewDir, material.clearcoatRoughness );
			vec4 t1Clearcoat = texture2D( ltc_1, uvClearcoat );
			vec4 t2Clearcoat = texture2D( ltc_2, uvClearcoat );
			mat3 mInvClearcoat = mat3(
				vec3( t1Clearcoat.x, 0, t1Clearcoat.y ),
				vec3(             0, 1,             0 ),
				vec3( t1Clearcoat.z, 0, t1Clearcoat.w )
			);
			vec3 fresnelClearcoat = material.clearcoatF0 * t2Clearcoat.x + ( material.clearcoatF90 - material.clearcoatF0 ) * t2Clearcoat.y;
			clearcoatSpecularDirect += lightColor * fresnelClearcoat * LTC_Evaluate( Ncc, viewDir, position, mInvClearcoat, rectCoords );
		#endif
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
 
 		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
 
 		float sheenAlbedoV = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
 		float sheenAlbedoL = IBLSheenBRDF( geometryNormal, directLight.direction, material.sheenRoughness );
 
 		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * max( sheenAlbedoV, sheenAlbedoL );
 
 		irradiance *= sheenEnergyComp;
 
 	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX_Multiscatter( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseContribution );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 diffuse = irradiance * BRDF_Lambert( material.diffuseContribution );
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		diffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectDiffuse += diffuse;
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness ) * RECIPROCAL_PI;
 	#endif
	vec3 singleScatteringDielectric = vec3( 0.0 );
	vec3 multiScatteringDielectric = vec3( 0.0 );
	vec3 singleScatteringMetallic = vec3( 0.0 );
	vec3 multiScatteringMetallic = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnelDielectric, material.roughness, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.diffuseColor, material.specularF90, material.iridescence, material.iridescenceFresnelMetallic, material.roughness, singleScatteringMetallic, multiScatteringMetallic );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscattering( geometryNormal, geometryViewDir, material.diffuseColor, material.specularF90, material.roughness, singleScatteringMetallic, multiScatteringMetallic );
	#endif
	vec3 singleScattering = mix( singleScatteringDielectric, singleScatteringMetallic, material.metalness );
	vec3 multiScattering = mix( multiScatteringDielectric, multiScatteringMetallic, material.metalness );
	vec3 totalScatteringDielectric = singleScatteringDielectric + multiScatteringDielectric;
	vec3 diffuse = material.diffuseContribution * ( 1.0 - totalScatteringDielectric );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	vec3 indirectSpecular = radiance * singleScattering;
	indirectSpecular += multiScattering * cosineWeightedIrradiance;
	vec3 indirectDiffuse = diffuse * cosineWeightedIrradiance;
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		indirectSpecular *= sheenEnergyComp;
		indirectDiffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectSpecular += indirectSpecular;
	reflectedLight.indirectDiffuse += indirectDiffuse;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,Ob=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnelDielectric = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceFresnelMetallic = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.diffuseColor );
		material.iridescenceFresnel = mix( material.iridescenceFresnelDielectric, material.iridescenceFresnelMetallic, material.metalness );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS ) && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
	#ifdef USE_LIGHT_PROBES_GRID
		vec3 probeWorldPos = ( ( vec4( geometryPosition, 1.0 ) - viewMatrix[ 3 ] ) * viewMatrix ).xyz;
		vec3 probeWorldNormal = transformNormalByInverseViewMatrix( geometryNormal, viewMatrix );
		irradiance += getLightProbeGridIrradiance( probeWorldPos, probeWorldNormal );
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,kb=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( ENVMAP_TYPE_CUBE_UV )
		#if defined( STANDARD ) || defined( LAMBERT ) || defined( PHONG )
			iblIrradiance += getIBLIrradiance( geometryNormal );
		#endif
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,Bb=`#if defined( RE_IndirectDiffuse )
	#if defined( LAMBERT ) || defined( PHONG )
		irradiance += iblIrradiance;
	#endif
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,zb=`#ifdef USE_LIGHT_PROBES_GRID
uniform highp sampler3D probesSH;
uniform vec3 probesMin;
uniform vec3 probesMax;
uniform vec3 probesResolution;
vec3 getLightProbeGridIrradiance( vec3 worldPos, vec3 worldNormal ) {
	vec3 res = probesResolution;
	vec3 gridRange = probesMax - probesMin;
	vec3 resMinusOne = res - 1.0;
	vec3 probeSpacing = gridRange / resMinusOne;
	vec3 samplePos = worldPos + worldNormal * probeSpacing * 0.5;
	vec3 uvw = clamp( ( samplePos - probesMin ) / gridRange, 0.0, 1.0 );
	uvw = uvw * resMinusOne / res + 0.5 / res;
	float nz          = res.z;
	float paddedSlices = nz + 2.0;
	float atlasDepth  = 7.0 * paddedSlices;
	float uvZBase     = uvw.z * nz + 1.0;
	vec4 s0 = texture( probesSH, vec3( uvw.xy, ( uvZBase                       ) / atlasDepth ) );
	vec4 s1 = texture( probesSH, vec3( uvw.xy, ( uvZBase +       paddedSlices   ) / atlasDepth ) );
	vec4 s2 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 2.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s3 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 3.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s4 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 4.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s5 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 5.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s6 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 6.0 * paddedSlices   ) / atlasDepth ) );
	vec3 c0 = s0.xyz;
	vec3 c1 = vec3( s0.w, s1.xy );
	vec3 c2 = vec3( s1.zw, s2.x );
	vec3 c3 = s2.yzw;
	vec3 c4 = s3.xyz;
	vec3 c5 = vec3( s3.w, s4.xy );
	vec3 c6 = vec3( s4.zw, s5.x );
	vec3 c7 = s5.yzw;
	vec3 c8 = s6.xyz;
	float x = worldNormal.x, y = worldNormal.y, z = worldNormal.z;
	vec3 result = c0 * 0.886227;
	result += c1 * 2.0 * 0.511664 * y;
	result += c2 * 2.0 * 0.511664 * z;
	result += c3 * 2.0 * 0.511664 * x;
	result += c4 * 2.0 * 0.429043 * x * y;
	result += c5 * 2.0 * 0.429043 * y * z;
	result += c6 * ( 0.743125 * z * z - 0.247708 );
	result += c7 * 2.0 * 0.429043 * x * z;
	result += c8 * 0.429043 * ( x * x - y * y );
	return max( result, vec3( 0.0 ) );
}
#endif`,Vb=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,Hb=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,Gb=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,Wb=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,jb=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,Xb=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,$b=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,qb=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Yb=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,Kb=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,Zb=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,Qb=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,Jb=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,ew=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,tw=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,nw=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#ifdef DOUBLE_SIDED
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#ifdef DOUBLE_SIDED
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,iw=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#if defined( USE_PACKED_NORMALMAP )
		mapN = vec3( mapN.xy, sqrt( saturate( 1.0 - dot( mapN.xy, mapN.xy ) ) ) );
	#endif
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,rw=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,aw=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,sw=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
		#ifdef FLIP_SIDED
			vBitangent = - vBitangent;
		#endif
	#endif
#endif`,ow=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,lw=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,cw=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,uw=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,dw=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,fw=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,hw=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	#ifdef USE_REVERSED_DEPTH_BUFFER
	
		return depth * ( far - near ) - far;
	#else
		return depth * ( near - far ) - near;
	#endif
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	
	#ifdef USE_REVERSED_DEPTH_BUFFER
		return ( near * far ) / ( ( near - far ) * depth - near );
	#else
		return ( near * far ) / ( ( far - near ) * depth - far );
	#endif
}`,pw=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,mw=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,gw=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,_w=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,xw=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,vw=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,yw=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#else
			uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#endif
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#else
			uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#endif
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform samplerCubeShadow pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#elif defined( SHADOWMAP_TYPE_BASIC )
			uniform samplerCube pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#endif
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float interleavedGradientNoise( vec2 position ) {
			return fract( 52.9829189 * fract( dot( position, vec2( 0.06711056, 0.00583715 ) ) ) );
		}
		vec2 vogelDiskSample( int sampleIndex, int samplesCount, float phi ) {
			const float goldenAngle = 2.399963229728653;
			float r = sqrt( ( float( sampleIndex ) + 0.5 ) / float( samplesCount ) );
			float theta = float( sampleIndex ) * goldenAngle + phi;
			return vec2( cos( theta ), sin( theta ) ) * r;
		}
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float getShadow( sampler2DShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			shadowCoord.z += shadowBias;
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
				float radius = shadowRadius * texelSize.x;
				float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
				shadow = (
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 0, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 1, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 2, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 3, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 4, 5, phi ) * radius, shadowCoord.z ) )
				) * 0.2;
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#elif defined( SHADOWMAP_TYPE_VSM )
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 distribution = texture2D( shadowMap, shadowCoord.xy ).rg;
				float mean = distribution.x;
				float variance = distribution.y * distribution.y;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					float hard_shadow = step( mean, shadowCoord.z );
				#else
					float hard_shadow = step( shadowCoord.z, mean );
				#endif
				
				if ( hard_shadow == 1.0 ) {
					shadow = 1.0;
				} else {
					variance = max( variance, 0.0000001 );
					float d = shadowCoord.z - mean;
					float p_max = variance / ( variance + d * d );
					p_max = clamp( ( p_max - 0.3 ) / 0.65, 0.0, 1.0 );
					shadow = max( hard_shadow, p_max );
				}
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#else
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				float depth = texture2D( shadowMap, shadowCoord.xy ).r;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					shadow = step( depth, shadowCoord.z );
				#else
					shadow = step( shadowCoord.z, depth );
				#endif
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	#if defined( SHADOWMAP_TYPE_PCF )
	float getPointShadow( samplerCubeShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 bd3D = normalize( lightToPosition );
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			#ifdef USE_REVERSED_DEPTH_BUFFER
				float dp = ( shadowCameraNear * ( shadowCameraFar - viewSpaceZ ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp -= shadowBias;
			#else
				float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp += shadowBias;
			#endif
			float texelSize = shadowRadius / shadowMapSize.x;
			vec3 absDir = abs( bd3D );
			vec3 tangent = absDir.x > absDir.z ? vec3( 0.0, 1.0, 0.0 ) : vec3( 1.0, 0.0, 0.0 );
			tangent = normalize( cross( bd3D, tangent ) );
			vec3 bitangent = cross( bd3D, tangent );
			float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
			vec2 sample0 = vogelDiskSample( 0, 5, phi );
			vec2 sample1 = vogelDiskSample( 1, 5, phi );
			vec2 sample2 = vogelDiskSample( 2, 5, phi );
			vec2 sample3 = vogelDiskSample( 3, 5, phi );
			vec2 sample4 = vogelDiskSample( 4, 5, phi );
			shadow = (
				texture( shadowMap, vec4( bd3D + ( tangent * sample0.x + bitangent * sample0.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample1.x + bitangent * sample1.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample2.x + bitangent * sample2.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample3.x + bitangent * sample3.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample4.x + bitangent * sample4.y ) * texelSize, dp ) )
			) * 0.2;
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#elif defined( SHADOWMAP_TYPE_BASIC )
	float getPointShadow( samplerCube shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			float depth = textureCube( shadowMap, bd3D ).r;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				depth = 1.0 - depth;
			#endif
			shadow = step( dp, depth );
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#endif
	#endif
#endif`,Sw=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,Mw=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	#ifdef HAS_NORMAL
		vec3 shadowWorldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
	#else
		vec3 shadowWorldNormal = vec3( 0.0 );
	#endif
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,Ew=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0 && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,bw=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,ww=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,Tw=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,Aw=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,Cw=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,Rw=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,Pw=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,Nw=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,Lw=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseContribution, material.specularColorBlended, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,Dw=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,Iw=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Uw=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Fw=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,Ow=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const kw=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,Bw=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,zw=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Vw=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vWorldDirection );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Hw=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Gw=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Ww=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,jw=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,Xw=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,$w=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = vec4( dist, 0.0, 0.0, 1.0 );
}`,qw=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,Yw=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Kw=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Zw=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Qw=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,Jw=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,eT=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,tT=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,nT=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,iT=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,rT=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,aT=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( normalize( normal ) * 0.5 + 0.5, diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,sT=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,oT=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,lT=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,cT=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
 
		outgoingLight = outgoingLight + sheenSpecularDirect + sheenSpecularIndirect;
 
 	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,uT=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,dT=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,fT=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,hT=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,pT=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,mT=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,gT=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,_T=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,ke={alphahash_fragment:kE,alphahash_pars_fragment:BE,alphamap_fragment:zE,alphamap_pars_fragment:VE,alphatest_fragment:HE,alphatest_pars_fragment:GE,aomap_fragment:WE,aomap_pars_fragment:jE,batching_pars_vertex:XE,batching_vertex:$E,begin_vertex:qE,beginnormal_vertex:YE,bsdfs:KE,iridescence_fragment:ZE,bumpmap_pars_fragment:QE,clipping_planes_fragment:JE,clipping_planes_pars_fragment:eb,clipping_planes_pars_vertex:tb,clipping_planes_vertex:nb,color_fragment:ib,color_pars_fragment:rb,color_pars_vertex:ab,color_vertex:sb,common:ob,cube_uv_reflection_fragment:lb,defaultnormal_vertex:cb,displacementmap_pars_vertex:ub,displacementmap_vertex:db,emissivemap_fragment:fb,emissivemap_pars_fragment:hb,colorspace_fragment:pb,colorspace_pars_fragment:mb,envmap_fragment:gb,envmap_common_pars_fragment:_b,envmap_pars_fragment:xb,envmap_pars_vertex:vb,envmap_physical_pars_fragment:Pb,envmap_vertex:yb,fog_vertex:Sb,fog_pars_vertex:Mb,fog_fragment:Eb,fog_pars_fragment:bb,gradientmap_pars_fragment:wb,lightmap_pars_fragment:Tb,lights_lambert_fragment:Ab,lights_lambert_pars_fragment:Cb,lights_pars_begin:Rb,lights_toon_fragment:Nb,lights_toon_pars_fragment:Lb,lights_phong_fragment:Db,lights_phong_pars_fragment:Ib,lights_physical_fragment:Ub,lights_physical_pars_fragment:Fb,lights_fragment_begin:Ob,lights_fragment_maps:kb,lights_fragment_end:Bb,lightprobes_pars_fragment:zb,logdepthbuf_fragment:Vb,logdepthbuf_pars_fragment:Hb,logdepthbuf_pars_vertex:Gb,logdepthbuf_vertex:Wb,map_fragment:jb,map_pars_fragment:Xb,map_particle_fragment:$b,map_particle_pars_fragment:qb,metalnessmap_fragment:Yb,metalnessmap_pars_fragment:Kb,morphinstance_vertex:Zb,morphcolor_vertex:Qb,morphnormal_vertex:Jb,morphtarget_pars_vertex:ew,morphtarget_vertex:tw,normal_fragment_begin:nw,normal_fragment_maps:iw,normal_pars_fragment:rw,normal_pars_vertex:aw,normal_vertex:sw,normalmap_pars_fragment:ow,clearcoat_normal_fragment_begin:lw,clearcoat_normal_fragment_maps:cw,clearcoat_pars_fragment:uw,iridescence_pars_fragment:dw,opaque_fragment:fw,packing:hw,premultiplied_alpha_fragment:pw,project_vertex:mw,dithering_fragment:gw,dithering_pars_fragment:_w,roughnessmap_fragment:xw,roughnessmap_pars_fragment:vw,shadowmap_pars_fragment:yw,shadowmap_pars_vertex:Sw,shadowmap_vertex:Mw,shadowmask_pars_fragment:Ew,skinbase_vertex:bw,skinning_pars_vertex:ww,skinning_vertex:Tw,skinnormal_vertex:Aw,specularmap_fragment:Cw,specularmap_pars_fragment:Rw,tonemapping_fragment:Pw,tonemapping_pars_fragment:Nw,transmission_fragment:Lw,transmission_pars_fragment:Dw,uv_pars_fragment:Iw,uv_pars_vertex:Uw,uv_vertex:Fw,worldpos_vertex:Ow,background_vert:kw,background_frag:Bw,backgroundCube_vert:zw,backgroundCube_frag:Vw,cube_vert:Hw,cube_frag:Gw,depth_vert:Ww,depth_frag:jw,distance_vert:Xw,distance_frag:$w,equirect_vert:qw,equirect_frag:Yw,linedashed_vert:Kw,linedashed_frag:Zw,meshbasic_vert:Qw,meshbasic_frag:Jw,meshlambert_vert:eT,meshlambert_frag:tT,meshmatcap_vert:nT,meshmatcap_frag:iT,meshnormal_vert:rT,meshnormal_frag:aT,meshphong_vert:sT,meshphong_frag:oT,meshphysical_vert:lT,meshphysical_frag:cT,meshtoon_vert:uT,meshtoon_frag:dT,points_vert:fT,points_frag:hT,shadow_vert:pT,shadow_frag:mT,sprite_vert:gT,sprite_frag:_T},ge={common:{diffuse:{value:new Qe(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new Ie},alphaMap:{value:null},alphaMapTransform:{value:new Ie},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new Ie}},envmap:{envMap:{value:null},envMapRotation:{value:new Ie},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new Ie}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new Ie}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new Ie},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new Ie},normalScale:{value:new Ze(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new Ie},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new Ie}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new Ie}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new Ie}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new Qe(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null},probesSH:{value:null},probesMin:{value:new j},probesMax:{value:new j},probesResolution:{value:new j}},points:{diffuse:{value:new Qe(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new Ie},alphaTest:{value:0},uvTransform:{value:new Ie}},sprite:{diffuse:{value:new Qe(16777215)},opacity:{value:1},center:{value:new Ze(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new Ie},alphaMap:{value:null},alphaMapTransform:{value:new Ie},alphaTest:{value:0}}},si={basic:{uniforms:tn([ge.common,ge.specularmap,ge.envmap,ge.aomap,ge.lightmap,ge.fog]),vertexShader:ke.meshbasic_vert,fragmentShader:ke.meshbasic_frag},lambert:{uniforms:tn([ge.common,ge.specularmap,ge.envmap,ge.aomap,ge.lightmap,ge.emissivemap,ge.bumpmap,ge.normalmap,ge.displacementmap,ge.fog,ge.lights,{emissive:{value:new Qe(0)},envMapIntensity:{value:1}}]),vertexShader:ke.meshlambert_vert,fragmentShader:ke.meshlambert_frag},phong:{uniforms:tn([ge.common,ge.specularmap,ge.envmap,ge.aomap,ge.lightmap,ge.emissivemap,ge.bumpmap,ge.normalmap,ge.displacementmap,ge.fog,ge.lights,{emissive:{value:new Qe(0)},specular:{value:new Qe(1118481)},shininess:{value:30},envMapIntensity:{value:1}}]),vertexShader:ke.meshphong_vert,fragmentShader:ke.meshphong_frag},standard:{uniforms:tn([ge.common,ge.envmap,ge.aomap,ge.lightmap,ge.emissivemap,ge.bumpmap,ge.normalmap,ge.displacementmap,ge.roughnessmap,ge.metalnessmap,ge.fog,ge.lights,{emissive:{value:new Qe(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:ke.meshphysical_vert,fragmentShader:ke.meshphysical_frag},toon:{uniforms:tn([ge.common,ge.aomap,ge.lightmap,ge.emissivemap,ge.bumpmap,ge.normalmap,ge.displacementmap,ge.gradientmap,ge.fog,ge.lights,{emissive:{value:new Qe(0)}}]),vertexShader:ke.meshtoon_vert,fragmentShader:ke.meshtoon_frag},matcap:{uniforms:tn([ge.common,ge.bumpmap,ge.normalmap,ge.displacementmap,ge.fog,{matcap:{value:null}}]),vertexShader:ke.meshmatcap_vert,fragmentShader:ke.meshmatcap_frag},points:{uniforms:tn([ge.points,ge.fog]),vertexShader:ke.points_vert,fragmentShader:ke.points_frag},dashed:{uniforms:tn([ge.common,ge.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:ke.linedashed_vert,fragmentShader:ke.linedashed_frag},depth:{uniforms:tn([ge.common,ge.displacementmap]),vertexShader:ke.depth_vert,fragmentShader:ke.depth_frag},normal:{uniforms:tn([ge.common,ge.bumpmap,ge.normalmap,ge.displacementmap,{opacity:{value:1}}]),vertexShader:ke.meshnormal_vert,fragmentShader:ke.meshnormal_frag},sprite:{uniforms:tn([ge.sprite,ge.fog]),vertexShader:ke.sprite_vert,fragmentShader:ke.sprite_frag},background:{uniforms:{uvTransform:{value:new Ie},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:ke.background_vert,fragmentShader:ke.background_frag},backgroundCube:{uniforms:{envMap:{value:null},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new Ie}},vertexShader:ke.backgroundCube_vert,fragmentShader:ke.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:ke.cube_vert,fragmentShader:ke.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:ke.equirect_vert,fragmentShader:ke.equirect_frag},distance:{uniforms:tn([ge.common,ge.displacementmap,{referencePosition:{value:new j},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:ke.distance_vert,fragmentShader:ke.distance_frag},shadow:{uniforms:tn([ge.lights,ge.fog,{color:{value:new Qe(0)},opacity:{value:1}}]),vertexShader:ke.shadow_vert,fragmentShader:ke.shadow_frag}};si.physical={uniforms:tn([si.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new Ie},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new Ie},clearcoatNormalScale:{value:new Ze(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new Ie},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new Ie},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new Ie},sheen:{value:0},sheenColor:{value:new Qe(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new Ie},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new Ie},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new Ie},transmissionSamplerSize:{value:new Ze},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new Ie},attenuationDistance:{value:0},attenuationColor:{value:new Qe(0)},specularColor:{value:new Qe(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new Ie},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new Ie},anisotropyVector:{value:new Ze},anisotropyMap:{value:null},anisotropyMapTransform:{value:new Ie}}]),vertexShader:ke.meshphysical_vert,fragmentShader:ke.meshphysical_frag};const Jo={r:0,b:0,g:0},xT=new Nt,Ux=new Ie;Ux.set(-1,0,0,0,1,0,0,0,1);function vT(t,e,n,i,r,a){const s=new Qe(0);let o=r===!0?0:1,l,c,f=null,h=0,u=null;function m(v){let S=v.isScene===!0?v.background:null;if(S&&S.isTexture){const M=v.backgroundBlurriness>0;S=e.get(S,M)}return S}function x(v){let S=!1;const M=m(v);M===null?g(s,o):M&&M.isColor&&(g(M,1),S=!0);const A=t.xr.getEnvironmentBlendMode();A==="additive"?n.buffers.color.setClear(0,0,0,1,a):A==="alpha-blend"&&n.buffers.color.setClear(0,0,0,0,a),(t.autoClear||S)&&(n.buffers.depth.setTest(!0),n.buffers.depth.setMask(!0),n.buffers.color.setMask(!0),t.clear(t.autoClearColor,t.autoClearDepth,t.autoClearStencil))}function E(v,S){const M=m(S);M&&(M.isCubeTexture||M.mapping===Sc)?(c===void 0&&(c=new _i(new co(1,1,1),new Qn({name:"BackgroundCubeMaterial",uniforms:Ya(si.backgroundCube.uniforms),vertexShader:si.backgroundCube.vertexShader,fragmentShader:si.backgroundCube.fragmentShader,side:mn,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),c.geometry.deleteAttribute("normal"),c.geometry.deleteAttribute("uv"),c.onBeforeRender=function(A,T,w){this.matrixWorld.copyPosition(w.matrixWorld)},Object.defineProperty(c.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),i.update(c)),c.material.uniforms.envMap.value=M,c.material.uniforms.backgroundBlurriness.value=S.backgroundBlurriness,c.material.uniforms.backgroundIntensity.value=S.backgroundIntensity,c.material.uniforms.backgroundRotation.value.setFromMatrix4(xT.makeRotationFromEuler(S.backgroundRotation)).transpose(),M.isCubeTexture&&M.isRenderTargetTexture===!1&&c.material.uniforms.backgroundRotation.value.premultiply(Ux),c.material.toneMapped=We.getTransfer(M.colorSpace)!==tt,(f!==M||h!==M.version||u!==t.toneMapping)&&(c.material.needsUpdate=!0,f=M,h=M.version,u=t.toneMapping),c.layers.enableAll(),v.unshift(c,c.geometry,c.material,0,0,null)):M&&M.isTexture&&(l===void 0&&(l=new _i(new uo(2,2),new Qn({name:"BackgroundMaterial",uniforms:Ya(si.background.uniforms),vertexShader:si.background.vertexShader,fragmentShader:si.background.fragmentShader,side:yr,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),l.geometry.deleteAttribute("normal"),Object.defineProperty(l.material,"map",{get:function(){return this.uniforms.t2D.value}}),i.update(l)),l.material.uniforms.t2D.value=M,l.material.uniforms.backgroundIntensity.value=S.backgroundIntensity,l.material.toneMapped=We.getTransfer(M.colorSpace)!==tt,M.matrixAutoUpdate===!0&&M.updateMatrix(),l.material.uniforms.uvTransform.value.copy(M.matrix),(f!==M||h!==M.version||u!==t.toneMapping)&&(l.material.needsUpdate=!0,f=M,h=M.version,u=t.toneMapping),l.layers.enableAll(),v.unshift(l,l.geometry,l.material,0,0,null))}function g(v,S){v.getRGB(Jo,Lx(t)),n.buffers.color.setClear(Jo.r,Jo.g,Jo.b,S,a)}function d(){c!==void 0&&(c.geometry.dispose(),c.material.dispose(),c=void 0),l!==void 0&&(l.geometry.dispose(),l.material.dispose(),l=void 0)}return{getClearColor:function(){return s},setClearColor:function(v,S=1){s.set(v),o=S,g(s,o)},getClearAlpha:function(){return o},setClearAlpha:function(v){o=v,g(s,o)},render:x,addToRenderList:E,dispose:d}}function yT(t,e){const n=t.getParameter(t.MAX_VERTEX_ATTRIBS),i={},r=u(null);let a=r,s=!1;function o(N,F,q,ie,k){let X=!1;const V=h(N,ie,q,F);a!==V&&(a=V,c(a.object)),X=m(N,ie,q,k),X&&x(N,ie,q,k),k!==null&&e.update(k,t.ELEMENT_ARRAY_BUFFER),(X||s)&&(s=!1,M(N,F,q,ie),k!==null&&t.bindBuffer(t.ELEMENT_ARRAY_BUFFER,e.get(k).buffer))}function l(){return t.createVertexArray()}function c(N){return t.bindVertexArray(N)}function f(N){return t.deleteVertexArray(N)}function h(N,F,q,ie){const k=ie.wireframe===!0;let X=i[F.id];X===void 0&&(X={},i[F.id]=X);const V=N.isInstancedMesh===!0?N.id:0;let O=X[V];O===void 0&&(O={},X[V]=O);let I=O[q.id];I===void 0&&(I={},O[q.id]=I);let J=I[k];return J===void 0&&(J=u(l()),I[k]=J),J}function u(N){const F=[],q=[],ie=[];for(let k=0;k<n;k++)F[k]=0,q[k]=0,ie[k]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:F,enabledAttributes:q,attributeDivisors:ie,object:N,attributes:{},index:null}}function m(N,F,q,ie){const k=a.attributes,X=F.attributes;let V=0;const O=q.getAttributes();for(const I in O)if(O[I].location>=0){const ae=k[I];let le=X[I];if(le===void 0&&(I==="instanceMatrix"&&N.instanceMatrix&&(le=N.instanceMatrix),I==="instanceColor"&&N.instanceColor&&(le=N.instanceColor)),ae===void 0||ae.attribute!==le||le&&ae.data!==le.data)return!0;V++}return a.attributesNum!==V||a.index!==ie}function x(N,F,q,ie){const k={},X=F.attributes;let V=0;const O=q.getAttributes();for(const I in O)if(O[I].location>=0){let ae=X[I];ae===void 0&&(I==="instanceMatrix"&&N.instanceMatrix&&(ae=N.instanceMatrix),I==="instanceColor"&&N.instanceColor&&(ae=N.instanceColor));const le={};le.attribute=ae,ae&&ae.data&&(le.data=ae.data),k[I]=le,V++}a.attributes=k,a.attributesNum=V,a.index=ie}function E(){const N=a.newAttributes;for(let F=0,q=N.length;F<q;F++)N[F]=0}function g(N){d(N,0)}function d(N,F){const q=a.newAttributes,ie=a.enabledAttributes,k=a.attributeDivisors;q[N]=1,ie[N]===0&&(t.enableVertexAttribArray(N),ie[N]=1),k[N]!==F&&(t.vertexAttribDivisor(N,F),k[N]=F)}function v(){const N=a.newAttributes,F=a.enabledAttributes;for(let q=0,ie=F.length;q<ie;q++)F[q]!==N[q]&&(t.disableVertexAttribArray(q),F[q]=0)}function S(N,F,q,ie,k,X,V){V===!0?t.vertexAttribIPointer(N,F,q,k,X):t.vertexAttribPointer(N,F,q,ie,k,X)}function M(N,F,q,ie){E();const k=ie.attributes,X=q.getAttributes(),V=F.defaultAttributeValues;for(const O in X){const I=X[O];if(I.location>=0){let J=k[O];if(J===void 0&&(O==="instanceMatrix"&&N.instanceMatrix&&(J=N.instanceMatrix),O==="instanceColor"&&N.instanceColor&&(J=N.instanceColor)),J!==void 0){const ae=J.normalized,le=J.itemSize,Be=e.get(J);if(Be===void 0)continue;const Xe=Be.buffer,ze=Be.type,Q=Be.bytesPerElement,oe=ze===t.INT||ze===t.UNSIGNED_INT||J.gpuType===wh;if(J.isInterleavedBufferAttribute){const ee=J.data,Pe=ee.stride,Ue=J.offset;if(ee.isInstancedInterleavedBuffer){for(let Ne=0;Ne<I.locationSize;Ne++)d(I.location+Ne,ee.meshPerAttribute);N.isInstancedMesh!==!0&&ie._maxInstanceCount===void 0&&(ie._maxInstanceCount=ee.meshPerAttribute*ee.count)}else for(let Ne=0;Ne<I.locationSize;Ne++)g(I.location+Ne);t.bindBuffer(t.ARRAY_BUFFER,Xe);for(let Ne=0;Ne<I.locationSize;Ne++)S(I.location+Ne,le/I.locationSize,ze,ae,Pe*Q,(Ue+le/I.locationSize*Ne)*Q,oe)}else{if(J.isInstancedBufferAttribute){for(let ee=0;ee<I.locationSize;ee++)d(I.location+ee,J.meshPerAttribute);N.isInstancedMesh!==!0&&ie._maxInstanceCount===void 0&&(ie._maxInstanceCount=J.meshPerAttribute*J.count)}else for(let ee=0;ee<I.locationSize;ee++)g(I.location+ee);t.bindBuffer(t.ARRAY_BUFFER,Xe);for(let ee=0;ee<I.locationSize;ee++)S(I.location+ee,le/I.locationSize,ze,ae,le*Q,le/I.locationSize*ee*Q,oe)}}else if(V!==void 0){const ae=V[O];if(ae!==void 0)switch(ae.length){case 2:t.vertexAttrib2fv(I.location,ae);break;case 3:t.vertexAttrib3fv(I.location,ae);break;case 4:t.vertexAttrib4fv(I.location,ae);break;default:t.vertexAttrib1fv(I.location,ae)}}}}v()}function A(){C();for(const N in i){const F=i[N];for(const q in F){const ie=F[q];for(const k in ie){const X=ie[k];for(const V in X)f(X[V].object),delete X[V];delete ie[k]}}delete i[N]}}function T(N){if(i[N.id]===void 0)return;const F=i[N.id];for(const q in F){const ie=F[q];for(const k in ie){const X=ie[k];for(const V in X)f(X[V].object),delete X[V];delete ie[k]}}delete i[N.id]}function w(N){for(const F in i){const q=i[F];for(const ie in q){const k=q[ie];if(k[N.id]===void 0)continue;const X=k[N.id];for(const V in X)f(X[V].object),delete X[V];delete k[N.id]}}}function _(N){for(const F in i){const q=i[F],ie=N.isInstancedMesh===!0?N.id:0,k=q[ie];if(k!==void 0){for(const X in k){const V=k[X];for(const O in V)f(V[O].object),delete V[O];delete k[X]}delete q[ie],Object.keys(q).length===0&&delete i[F]}}}function C(){P(),s=!0,a!==r&&(a=r,c(a.object))}function P(){r.geometry=null,r.program=null,r.wireframe=!1}return{setup:o,reset:C,resetDefaultState:P,dispose:A,releaseStatesOfGeometry:T,releaseStatesOfObject:_,releaseStatesOfProgram:w,initAttributes:E,enableAttribute:g,disableUnusedAttributes:v}}function ST(t,e,n){let i;function r(l){i=l}function a(l,c){t.drawArrays(i,l,c),n.update(c,i,1)}function s(l,c,f){f!==0&&(t.drawArraysInstanced(i,l,c,f),n.update(c,i,f))}function o(l,c,f){if(f===0)return;e.get("WEBGL_multi_draw").multiDrawArraysWEBGL(i,l,0,c,0,f);let u=0;for(let m=0;m<f;m++)u+=c[m];n.update(u,i,1)}this.setMode=r,this.render=a,this.renderInstances=s,this.renderMultiDraw=o}function MT(t,e,n,i){let r;function a(){if(r!==void 0)return r;if(e.has("EXT_texture_filter_anisotropic")===!0){const w=e.get("EXT_texture_filter_anisotropic");r=t.getParameter(w.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else r=0;return r}function s(w){return!(w!==Xn&&i.convert(w)!==t.getParameter(t.IMPLEMENTATION_COLOR_READ_FORMAT))}function o(w){const _=w===zi&&(e.has("EXT_color_buffer_half_float")||e.has("EXT_color_buffer_float"));return!(w!==Nn&&i.convert(w)!==t.getParameter(t.IMPLEMENTATION_COLOR_READ_TYPE)&&w!==ci&&!_)}function l(w){if(w==="highp"){if(t.getShaderPrecisionFormat(t.VERTEX_SHADER,t.HIGH_FLOAT).precision>0&&t.getShaderPrecisionFormat(t.FRAGMENT_SHADER,t.HIGH_FLOAT).precision>0)return"highp";w="mediump"}return w==="mediump"&&t.getShaderPrecisionFormat(t.VERTEX_SHADER,t.MEDIUM_FLOAT).precision>0&&t.getShaderPrecisionFormat(t.FRAGMENT_SHADER,t.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let c=n.precision!==void 0?n.precision:"highp";const f=l(c);f!==c&&(De("WebGLRenderer:",c,"not supported, using",f,"instead."),c=f);const h=n.logarithmicDepthBuffer===!0,u=n.reversedDepthBuffer===!0&&e.has("EXT_clip_control");n.reversedDepthBuffer===!0&&u===!1&&De("WebGLRenderer: Unable to use reversed depth buffer due to missing EXT_clip_control extension. Fallback to default depth buffer.");const m=t.getParameter(t.MAX_TEXTURE_IMAGE_UNITS),x=t.getParameter(t.MAX_VERTEX_TEXTURE_IMAGE_UNITS),E=t.getParameter(t.MAX_TEXTURE_SIZE),g=t.getParameter(t.MAX_CUBE_MAP_TEXTURE_SIZE),d=t.getParameter(t.MAX_VERTEX_ATTRIBS),v=t.getParameter(t.MAX_VERTEX_UNIFORM_VECTORS),S=t.getParameter(t.MAX_VARYING_VECTORS),M=t.getParameter(t.MAX_FRAGMENT_UNIFORM_VECTORS),A=t.getParameter(t.MAX_SAMPLES),T=t.getParameter(t.SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:a,getMaxPrecision:l,textureFormatReadable:s,textureTypeReadable:o,precision:c,logarithmicDepthBuffer:h,reversedDepthBuffer:u,maxTextures:m,maxVertexTextures:x,maxTextureSize:E,maxCubemapSize:g,maxAttributes:d,maxVertexUniforms:v,maxVaryings:S,maxFragmentUniforms:M,maxSamples:A,samples:T}}function ET(t){const e=this;let n=null,i=0,r=!1,a=!1;const s=new Dr,o=new Ie,l={value:null,needsUpdate:!1};this.uniform=l,this.numPlanes=0,this.numIntersection=0,this.init=function(h,u){const m=h.length!==0||u||i!==0||r;return r=u,i=h.length,m},this.beginShadows=function(){a=!0,f(null)},this.endShadows=function(){a=!1},this.setGlobalState=function(h,u){n=f(h,u,0)},this.setState=function(h,u,m){const x=h.clippingPlanes,E=h.clipIntersection,g=h.clipShadows,d=t.get(h);if(!r||x===null||x.length===0||a&&!g)a?f(null):c();else{const v=a?0:i,S=v*4;let M=d.clippingState||null;l.value=M,M=f(x,u,S,m);for(let A=0;A!==S;++A)M[A]=n[A];d.clippingState=M,this.numIntersection=E?this.numPlanes:0,this.numPlanes+=v}};function c(){l.value!==n&&(l.value=n,l.needsUpdate=i>0),e.numPlanes=i,e.numIntersection=0}function f(h,u,m,x){const E=h!==null?h.length:0;let g=null;if(E!==0){if(g=l.value,x!==!0||g===null){const d=m+E*4,v=u.matrixWorldInverse;o.getNormalMatrix(v),(g===null||g.length<d)&&(g=new Float32Array(d));for(let S=0,M=m;S!==E;++S,M+=4)s.copy(h[S]).applyMatrix4(v,o),s.normal.toArray(g,M),g[M+3]=s.constant}l.value=g,l.needsUpdate=!0}return e.numPlanes=E,e.numIntersection=0,g}}const cr=4,Wm=[.125,.215,.35,.446,.526,.582],Ur=20,bT=256,gs=new Uh,jm=new Qe;let Pu=null,Nu=0,Lu=0,Du=!1;const wT=new j;class Xm{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._sizeLods=[],this._sigmas=[],this._lodMeshes=[],this._backgroundBox=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._blurMaterial=null,this._ggxMaterial=null}fromScene(e,n=0,i=.1,r=100,a={}){const{size:s=256,position:o=wT}=a;Pu=this._renderer.getRenderTarget(),Nu=this._renderer.getActiveCubeFace(),Lu=this._renderer.getActiveMipmapLevel(),Du=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(s);const l=this._allocateTargets();return l.depthBuffer=!0,this._sceneToCubeUV(e,i,r,l,o),n>0&&this._blur(l,0,0,n),this._applyPMREM(l),this._cleanup(l),l}fromEquirectangular(e,n=null){return this._fromTexture(e,n)}fromCubemap(e,n=null){return this._fromTexture(e,n)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=Ym(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=qm(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose(),this._backgroundBox!==null&&(this._backgroundBox.geometry.dispose(),this._backgroundBox.material.dispose())}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._ggxMaterial!==null&&this._ggxMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodMeshes.length;e++)this._lodMeshes[e].geometry.dispose()}_cleanup(e){this._renderer.setRenderTarget(Pu,Nu,Lu),this._renderer.xr.enabled=Du,e.scissorTest=!1,_a(e,0,0,e.width,e.height)}_fromTexture(e,n){e.mapping===qr||e.mapping===$a?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),Pu=this._renderer.getRenderTarget(),Nu=this._renderer.getActiveCubeFace(),Lu=this._renderer.getActiveMipmapLevel(),Du=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;const i=n||this._allocateTargets();return this._textureToCubeUV(e,i),this._applyPMREM(i),this._cleanup(i),i}_allocateTargets(){const e=3*Math.max(this._cubeSize,112),n=4*this._cubeSize,i={magFilter:Jt,minFilter:Jt,generateMipmaps:!1,type:zi,format:Xn,colorSpace:Zl,depthBuffer:!1},r=$m(e,n,i);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==n){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=$m(e,n,i);const{_lodMax:a}=this;({lodMeshes:this._lodMeshes,sizeLods:this._sizeLods,sigmas:this._sigmas}=TT(a)),this._blurMaterial=CT(a,e,n),this._ggxMaterial=AT(a,e,n)}return r}_compileMaterial(e){const n=new _i(new Wi,e);this._renderer.compile(n,gs)}_sceneToCubeUV(e,n,i,r,a){const l=new Wn(90,1,n,i),c=[1,-1,1,1,1,1],f=[1,1,1,-1,-1,-1],h=this._renderer,u=h.autoClear,m=h.toneMapping;h.getClearColor(jm),h.toneMapping=hi,h.autoClear=!1,h.state.buffers.depth.getReversed()&&(h.setRenderTarget(r),h.clearDepth(),h.setRenderTarget(null)),this._backgroundBox===null&&(this._backgroundBox=new _i(new co,new Cx({name:"PMREM.Background",side:mn,depthWrite:!1,depthTest:!1})));const E=this._backgroundBox,g=E.material;let d=!1;const v=e.background;v?v.isColor&&(g.color.copy(v),e.background=null,d=!0):(g.color.copy(jm),d=!0);for(let S=0;S<6;S++){const M=S%3;M===0?(l.up.set(0,c[S],0),l.position.set(a.x,a.y,a.z),l.lookAt(a.x+f[S],a.y,a.z)):M===1?(l.up.set(0,0,c[S]),l.position.set(a.x,a.y,a.z),l.lookAt(a.x,a.y+f[S],a.z)):(l.up.set(0,c[S],0),l.position.set(a.x,a.y,a.z),l.lookAt(a.x,a.y,a.z+f[S]));const A=this._cubeSize;_a(r,M*A,S>2?A:0,A,A),h.setRenderTarget(r),d&&h.render(E,l),h.render(e,l)}h.toneMapping=m,h.autoClear=u,e.background=v}_textureToCubeUV(e,n){const i=this._renderer,r=e.mapping===qr||e.mapping===$a;r?(this._cubemapMaterial===null&&(this._cubemapMaterial=Ym()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=qm());const a=r?this._cubemapMaterial:this._equirectMaterial,s=this._lodMeshes[0];s.material=a;const o=a.uniforms;o.envMap.value=e;const l=this._cubeSize;_a(n,0,0,3*l,2*l),i.setRenderTarget(n),i.render(s,gs)}_applyPMREM(e){const n=this._renderer,i=n.autoClear;n.autoClear=!1;const r=this._lodMeshes.length;for(let a=1;a<r;a++)this._applyGGXFilter(e,a-1,a);n.autoClear=i}_applyGGXFilter(e,n,i){const r=this._renderer,a=this._pingPongRenderTarget,s=this._ggxMaterial,o=this._lodMeshes[i];o.material=s;const l=s.uniforms,c=i/(this._lodMeshes.length-1),f=n/(this._lodMeshes.length-1),h=Math.sqrt(c*c-f*f),u=0+c*1.25,m=h*u,{_lodMax:x}=this,E=this._sizeLods[i],g=3*E*(i>x-cr?i-x+cr:0),d=4*(this._cubeSize-E);l.envMap.value=e.texture,l.roughness.value=m,l.mipInt.value=x-n,_a(a,g,d,3*E,2*E),r.setRenderTarget(a),r.render(o,gs),l.envMap.value=a.texture,l.roughness.value=0,l.mipInt.value=x-i,_a(e,g,d,3*E,2*E),r.setRenderTarget(e),r.render(o,gs)}_blur(e,n,i,r,a){const s=this._pingPongRenderTarget;this._halfBlur(e,s,n,i,r,"latitudinal",a),this._halfBlur(s,e,i,i,r,"longitudinal",a)}_halfBlur(e,n,i,r,a,s,o){const l=this._renderer,c=this._blurMaterial;s!=="latitudinal"&&s!=="longitudinal"&&Ye("blur direction must be either latitudinal or longitudinal!");const f=3,h=this._lodMeshes[r];h.material=c;const u=c.uniforms,m=this._sizeLods[i]-1,x=isFinite(a)?Math.PI/(2*m):2*Math.PI/(2*Ur-1),E=a/x,g=isFinite(a)?1+Math.floor(f*E):Ur;g>Ur&&De(`sigmaRadians, ${a}, is too large and will clip, as it requested ${g} samples when the maximum is set to ${Ur}`);const d=[];let v=0;for(let w=0;w<Ur;++w){const _=w/E,C=Math.exp(-_*_/2);d.push(C),w===0?v+=C:w<g&&(v+=2*C)}for(let w=0;w<d.length;w++)d[w]=d[w]/v;u.envMap.value=e.texture,u.samples.value=g,u.weights.value=d,u.latitudinal.value=s==="latitudinal",o&&(u.poleAxis.value=o);const{_lodMax:S}=this;u.dTheta.value=x,u.mipInt.value=S-i;const M=this._sizeLods[r],A=3*M*(r>S-cr?r-S+cr:0),T=4*(this._cubeSize-M);_a(n,A,T,3*M,2*M),l.setRenderTarget(n),l.render(h,gs)}}function TT(t){const e=[],n=[],i=[];let r=t;const a=t-cr+1+Wm.length;for(let s=0;s<a;s++){const o=Math.pow(2,r);e.push(o);let l=1/o;s>t-cr?l=Wm[s-t+cr-1]:s===0&&(l=0),n.push(l);const c=1/(o-2),f=-c,h=1+c,u=[f,f,h,f,h,h,f,f,h,h,f,h],m=6,x=6,E=3,g=2,d=1,v=new Float32Array(E*x*m),S=new Float32Array(g*x*m),M=new Float32Array(d*x*m);for(let T=0;T<m;T++){const w=T%3*2/3-1,_=T>2?0:-1,C=[w,_,0,w+2/3,_,0,w+2/3,_+1,0,w,_,0,w+2/3,_+1,0,w,_+1,0];v.set(C,E*x*T),S.set(u,g*x*T);const P=[T,T,T,T,T,T];M.set(P,d*x*T)}const A=new Wi;A.setAttribute("position",new mi(v,E)),A.setAttribute("uv",new mi(S,g)),A.setAttribute("faceIndex",new mi(M,d)),i.push(new _i(A,null)),r>cr&&r--}return{lodMeshes:i,sizeLods:e,sigmas:n}}function $m(t,e,n){const i=new pi(t,e,n);return i.texture.mapping=Sc,i.texture.name="PMREM.cubeUv",i.scissorTest=!0,i}function _a(t,e,n,i,r){t.viewport.set(e,n,i,r),t.scissor.set(e,n,i,r)}function AT(t,e,n){return new Qn({name:"PMREMGGXConvolution",defines:{GGX_SAMPLES:bT,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/n,CUBEUV_MAX_MIP:`${t}.0`},uniforms:{envMap:{value:null},roughness:{value:0},mipInt:{value:0}},vertexShader:Ec(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float roughness;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359

			// Van der Corput radical inverse
			float radicalInverse_VdC(uint bits) {
				bits = (bits << 16u) | (bits >> 16u);
				bits = ((bits & 0x55555555u) << 1u) | ((bits & 0xAAAAAAAAu) >> 1u);
				bits = ((bits & 0x33333333u) << 2u) | ((bits & 0xCCCCCCCCu) >> 2u);
				bits = ((bits & 0x0F0F0F0Fu) << 4u) | ((bits & 0xF0F0F0F0u) >> 4u);
				bits = ((bits & 0x00FF00FFu) << 8u) | ((bits & 0xFF00FF00u) >> 8u);
				return float(bits) * 2.3283064365386963e-10; // / 0x100000000
			}

			// Hammersley sequence
			vec2 hammersley(uint i, uint N) {
				return vec2(float(i) / float(N), radicalInverse_VdC(i));
			}

			// GGX VNDF importance sampling (Eric Heitz 2018)
			// "Sampling the GGX Distribution of Visible Normals"
			// https://jcgt.org/published/0007/04/01/
			vec3 importanceSampleGGX_VNDF(vec2 Xi, vec3 V, float roughness) {
				float alpha = roughness * roughness;

				// Section 4.1: Orthonormal basis
				vec3 T1 = vec3(1.0, 0.0, 0.0);
				vec3 T2 = cross(V, T1);

				// Section 4.2: Parameterization of projected area
				float r = sqrt(Xi.x);
				float phi = 2.0 * PI * Xi.y;
				float t1 = r * cos(phi);
				float t2 = r * sin(phi);
				float s = 0.5 * (1.0 + V.z);
				t2 = (1.0 - s) * sqrt(1.0 - t1 * t1) + s * t2;

				// Section 4.3: Reprojection onto hemisphere
				vec3 Nh = t1 * T1 + t2 * T2 + sqrt(max(0.0, 1.0 - t1 * t1 - t2 * t2)) * V;

				// Section 3.4: Transform back to ellipsoid configuration
				return normalize(vec3(alpha * Nh.x, alpha * Nh.y, max(0.0, Nh.z)));
			}

			void main() {
				vec3 N = normalize(vOutputDirection);
				vec3 V = N; // Assume view direction equals normal for pre-filtering

				vec3 prefilteredColor = vec3(0.0);
				float totalWeight = 0.0;

				// For very low roughness, just sample the environment directly
				if (roughness < 0.001) {
					gl_FragColor = vec4(bilinearCubeUV(envMap, N, mipInt), 1.0);
					return;
				}

				// Tangent space basis for VNDF sampling
				vec3 up = abs(N.z) < 0.999 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
				vec3 tangent = normalize(cross(up, N));
				vec3 bitangent = cross(N, tangent);

				for(uint i = 0u; i < uint(GGX_SAMPLES); i++) {
					vec2 Xi = hammersley(i, uint(GGX_SAMPLES));

					// For PMREM, V = N, so in tangent space V is always (0, 0, 1)
					vec3 H_tangent = importanceSampleGGX_VNDF(Xi, vec3(0.0, 0.0, 1.0), roughness);

					// Transform H back to world space
					vec3 H = normalize(tangent * H_tangent.x + bitangent * H_tangent.y + N * H_tangent.z);
					vec3 L = normalize(2.0 * dot(V, H) * H - V);

					float NdotL = max(dot(N, L), 0.0);

					if(NdotL > 0.0) {
						// Sample environment at fixed mip level
						// VNDF importance sampling handles the distribution filtering
						vec3 sampleColor = bilinearCubeUV(envMap, L, mipInt);

						// Weight by NdotL for the split-sum approximation
						// VNDF PDF naturally accounts for the visible microfacet distribution
						prefilteredColor += sampleColor * NdotL;
						totalWeight += NdotL;
					}
				}

				if (totalWeight > 0.0) {
					prefilteredColor = prefilteredColor / totalWeight;
				}

				gl_FragColor = vec4(prefilteredColor, 1.0);
			}
		`,blending:Li,depthTest:!1,depthWrite:!1})}function CT(t,e,n){const i=new Float32Array(Ur),r=new j(0,1,0);return new Qn({name:"SphericalGaussianBlur",defines:{n:Ur,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/n,CUBEUV_MAX_MIP:`${t}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:i},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:r}},vertexShader:Ec(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:Li,depthTest:!1,depthWrite:!1})}function qm(){return new Qn({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:Ec(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:Li,depthTest:!1,depthWrite:!1})}function Ym(){return new Qn({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:Ec(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:Li,depthTest:!1,depthWrite:!1})}function Ec(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}class Fx extends pi{constructor(e=1,n={}){super(e,e,n),this.isWebGLCubeRenderTarget=!0;const i={width:e,height:e,depth:1},r=[i,i,i,i,i,i];this.texture=new Px(r),this._setTextureOptions(n),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(e,n){this.texture.type=n.type,this.texture.colorSpace=n.colorSpace,this.texture.generateMipmaps=n.generateMipmaps,this.texture.minFilter=n.minFilter,this.texture.magFilter=n.magFilter;const i={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},r=new co(5,5,5),a=new Qn({name:"CubemapFromEquirect",uniforms:Ya(i.uniforms),vertexShader:i.vertexShader,fragmentShader:i.fragmentShader,side:mn,blending:Li});a.uniforms.tEquirect.value=n;const s=new _i(r,a),o=n.minFilter;return n.minFilter===Br&&(n.minFilter=Jt),new IE(1,10,this).update(e,s),n.minFilter=o,s.geometry.dispose(),s.material.dispose(),this}clear(e,n=!0,i=!0,r=!0){const a=e.getRenderTarget();for(let s=0;s<6;s++)e.setRenderTarget(this,s),e.clear(n,i,r);e.setRenderTarget(a)}}function RT(t){let e=new WeakMap,n=new WeakMap,i=null;function r(u,m=!1){return u==null?null:m?s(u):a(u)}function a(u){if(u&&u.isTexture){const m=u.mapping;if(m===iu||m===ru)if(e.has(u)){const x=e.get(u).texture;return o(x,u.mapping)}else{const x=u.image;if(x&&x.height>0){const E=new Fx(x.height);return E.fromEquirectangularTexture(t,u),e.set(u,E),u.addEventListener("dispose",c),o(E.texture,u.mapping)}else return null}}return u}function s(u){if(u&&u.isTexture){const m=u.mapping,x=m===iu||m===ru,E=m===qr||m===$a;if(x||E){let g=n.get(u);const d=g!==void 0?g.texture.pmremVersion:0;if(u.isRenderTargetTexture&&u.pmremVersion!==d)return i===null&&(i=new Xm(t)),g=x?i.fromEquirectangular(u,g):i.fromCubemap(u,g),g.texture.pmremVersion=u.pmremVersion,n.set(u,g),g.texture;if(g!==void 0)return g.texture;{const v=u.image;return x&&v&&v.height>0||E&&v&&l(v)?(i===null&&(i=new Xm(t)),g=x?i.fromEquirectangular(u):i.fromCubemap(u),g.texture.pmremVersion=u.pmremVersion,n.set(u,g),u.addEventListener("dispose",f),g.texture):null}}}return u}function o(u,m){return m===iu?u.mapping=qr:m===ru&&(u.mapping=$a),u}function l(u){let m=0;const x=6;for(let E=0;E<x;E++)u[E]!==void 0&&m++;return m===x}function c(u){const m=u.target;m.removeEventListener("dispose",c);const x=e.get(m);x!==void 0&&(e.delete(m),x.dispose())}function f(u){const m=u.target;m.removeEventListener("dispose",f);const x=n.get(m);x!==void 0&&(n.delete(m),x.dispose())}function h(){e=new WeakMap,n=new WeakMap,i!==null&&(i.dispose(),i=null)}return{get:r,dispose:h}}function PT(t){const e={};function n(i){if(e[i]!==void 0)return e[i];const r=t.getExtension(i);return e[i]=r,r}return{has:function(i){return n(i)!==null},init:function(){n("EXT_color_buffer_float"),n("WEBGL_clip_cull_distance"),n("OES_texture_float_linear"),n("EXT_color_buffer_half_float"),n("WEBGL_multisampled_render_to_texture"),n("WEBGL_render_shared_exponent")},get:function(i){const r=n(i);return r===null&&Oa("WebGLRenderer: "+i+" extension not supported."),r}}}function NT(t,e,n,i){const r={},a=new WeakMap;function s(h){const u=h.target;u.index!==null&&e.remove(u.index);for(const x in u.attributes)e.remove(u.attributes[x]);u.removeEventListener("dispose",s),delete r[u.id];const m=a.get(u);m&&(e.remove(m),a.delete(u)),i.releaseStatesOfGeometry(u),u.isInstancedBufferGeometry===!0&&delete u._maxInstanceCount,n.memory.geometries--}function o(h,u){return r[u.id]===!0||(u.addEventListener("dispose",s),r[u.id]=!0,n.memory.geometries++),u}function l(h){const u=h.attributes;for(const m in u)e.update(u[m],t.ARRAY_BUFFER)}function c(h){const u=[],m=h.index,x=h.attributes.position;let E=0;if(x===void 0)return;if(m!==null){const v=m.array;E=m.version;for(let S=0,M=v.length;S<M;S+=3){const A=v[S+0],T=v[S+1],w=v[S+2];u.push(A,T,T,w,w,A)}}else{const v=x.array;E=x.version;for(let S=0,M=v.length/3-1;S<M;S+=3){const A=S+0,T=S+1,w=S+2;u.push(A,T,T,w,w,A)}}const g=new(x.count>=65535?Ax:Tx)(u,1);g.version=E;const d=a.get(h);d&&e.remove(d),a.set(h,g)}function f(h){const u=a.get(h);if(u){const m=h.index;m!==null&&u.version<m.version&&c(h)}else c(h);return a.get(h)}return{get:o,update:l,getWireframeAttribute:f}}function LT(t,e,n){let i;function r(h){i=h}let a,s;function o(h){a=h.type,s=h.bytesPerElement}function l(h,u){t.drawElements(i,u,a,h*s),n.update(u,i,1)}function c(h,u,m){m!==0&&(t.drawElementsInstanced(i,u,a,h*s,m),n.update(u,i,m))}function f(h,u,m){if(m===0)return;e.get("WEBGL_multi_draw").multiDrawElementsWEBGL(i,u,0,a,h,0,m);let E=0;for(let g=0;g<m;g++)E+=u[g];n.update(E,i,1)}this.setMode=r,this.setIndex=o,this.render=l,this.renderInstances=c,this.renderMultiDraw=f}function DT(t){const e={geometries:0,textures:0},n={frame:0,calls:0,triangles:0,points:0,lines:0};function i(a,s,o){switch(n.calls++,s){case t.TRIANGLES:n.triangles+=o*(a/3);break;case t.LINES:n.lines+=o*(a/2);break;case t.LINE_STRIP:n.lines+=o*(a-1);break;case t.LINE_LOOP:n.lines+=o*a;break;case t.POINTS:n.points+=o*a;break;default:Ye("WebGLInfo: Unknown draw mode:",s);break}}function r(){n.calls=0,n.triangles=0,n.points=0,n.lines=0}return{memory:e,render:n,programs:null,autoReset:!0,reset:r,update:i}}function IT(t,e,n){const i=new WeakMap,r=new Mt;function a(s,o,l){const c=s.morphTargetInfluences,f=o.morphAttributes.position||o.morphAttributes.normal||o.morphAttributes.color,h=f!==void 0?f.length:0;let u=i.get(o);if(u===void 0||u.count!==h){let P=function(){_.dispose(),i.delete(o),o.removeEventListener("dispose",P)};var m=P;u!==void 0&&u.texture.dispose();const x=o.morphAttributes.position!==void 0,E=o.morphAttributes.normal!==void 0,g=o.morphAttributes.color!==void 0,d=o.morphAttributes.position||[],v=o.morphAttributes.normal||[],S=o.morphAttributes.color||[];let M=0;x===!0&&(M=1),E===!0&&(M=2),g===!0&&(M=3);let A=o.attributes.position.count*M,T=1;A>e.maxTextureSize&&(T=Math.ceil(A/e.maxTextureSize),A=e.maxTextureSize);const w=new Float32Array(A*T*4*h),_=new Ex(w,A,T,h);_.type=ci,_.needsUpdate=!0;const C=M*4;for(let N=0;N<h;N++){const F=d[N],q=v[N],ie=S[N],k=A*T*4*N;for(let X=0;X<F.count;X++){const V=X*C;x===!0&&(r.fromBufferAttribute(F,X),w[k+V+0]=r.x,w[k+V+1]=r.y,w[k+V+2]=r.z,w[k+V+3]=0),E===!0&&(r.fromBufferAttribute(q,X),w[k+V+4]=r.x,w[k+V+5]=r.y,w[k+V+6]=r.z,w[k+V+7]=0),g===!0&&(r.fromBufferAttribute(ie,X),w[k+V+8]=r.x,w[k+V+9]=r.y,w[k+V+10]=r.z,w[k+V+11]=ie.itemSize===4?r.w:1)}}u={count:h,texture:_,size:new Ze(A,T)},i.set(o,u),o.addEventListener("dispose",P)}if(s.isInstancedMesh===!0&&s.morphTexture!==null)l.getUniforms().setValue(t,"morphTexture",s.morphTexture,n);else{let x=0;for(let g=0;g<c.length;g++)x+=c[g];const E=o.morphTargetsRelative?1:1-x;l.getUniforms().setValue(t,"morphTargetBaseInfluence",E),l.getUniforms().setValue(t,"morphTargetInfluences",c)}l.getUniforms().setValue(t,"morphTargetsTexture",u.texture,n),l.getUniforms().setValue(t,"morphTargetsTextureSize",u.size)}return{update:a}}function UT(t,e,n,i,r){let a=new WeakMap;function s(c){const f=r.render.frame,h=c.geometry,u=e.get(c,h);if(a.get(u)!==f&&(e.update(u),a.set(u,f)),c.isInstancedMesh&&(c.hasEventListener("dispose",l)===!1&&c.addEventListener("dispose",l),a.get(c)!==f&&(n.update(c.instanceMatrix,t.ARRAY_BUFFER),c.instanceColor!==null&&n.update(c.instanceColor,t.ARRAY_BUFFER),a.set(c,f))),c.isSkinnedMesh){const m=c.skeleton;a.get(m)!==f&&(m.update(),a.set(m,f))}return u}function o(){a=new WeakMap}function l(c){const f=c.target;f.removeEventListener("dispose",l),i.releaseStatesOfObject(f),n.remove(f.instanceMatrix),f.instanceColor!==null&&n.remove(f.instanceColor)}return{update:s,dispose:o}}const FT={[ox]:"LINEAR_TONE_MAPPING",[lx]:"REINHARD_TONE_MAPPING",[cx]:"CINEON_TONE_MAPPING",[ux]:"ACES_FILMIC_TONE_MAPPING",[fx]:"AGX_TONE_MAPPING",[hx]:"NEUTRAL_TONE_MAPPING",[dx]:"CUSTOM_TONE_MAPPING"};function OT(t,e,n,i,r,a){const s=new pi(e,n,{type:t,depthBuffer:r,stencilBuffer:a,samples:i?4:0,depthTexture:r?new qa(e,n):void 0}),o=new pi(e,n,{type:zi,depthBuffer:!1,stencilBuffer:!1}),l=new Wi;l.setAttribute("position",new Ii([-1,3,0,-1,-1,0,3,-1,0],3)),l.setAttribute("uv",new Ii([0,2,0,0,2,0],2));const c=new NE({uniforms:{tDiffuse:{value:null}},vertexShader:`
			precision highp float;

			uniform mat4 modelViewMatrix;
			uniform mat4 projectionMatrix;

			attribute vec3 position;
			attribute vec2 uv;

			varying vec2 vUv;

			void main() {
				vUv = uv;
				gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
			}`,fragmentShader:`
			precision highp float;

			uniform sampler2D tDiffuse;

			varying vec2 vUv;

			#include <tonemapping_pars_fragment>
			#include <colorspace_pars_fragment>

			void main() {
				gl_FragColor = texture2D( tDiffuse, vUv );

				#ifdef LINEAR_TONE_MAPPING
					gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );
				#elif defined( REINHARD_TONE_MAPPING )
					gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );
				#elif defined( CINEON_TONE_MAPPING )
					gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );
				#elif defined( ACES_FILMIC_TONE_MAPPING )
					gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );
				#elif defined( AGX_TONE_MAPPING )
					gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );
				#elif defined( NEUTRAL_TONE_MAPPING )
					gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );
				#elif defined( CUSTOM_TONE_MAPPING )
					gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );
				#endif

				#ifdef SRGB_TRANSFER
					gl_FragColor = sRGBTransferOETF( gl_FragColor );
				#endif
			}`,depthTest:!1,depthWrite:!1}),f=new _i(l,c),h=new Uh(-1,1,1,-1,0,1);let u=null,m=null,x=!1,E,g=null,d=[],v=!1;this.setSize=function(S,M){s.setSize(S,M),o.setSize(S,M);for(let A=0;A<d.length;A++){const T=d[A];T.setSize&&T.setSize(S,M)}},this.setEffects=function(S){d=S,v=d.length>0&&d[0].isRenderPass===!0;const M=s.width,A=s.height;for(let T=0;T<d.length;T++){const w=d[T];w.setSize&&w.setSize(M,A)}},this.begin=function(S,M){if(x||S.toneMapping===hi&&d.length===0)return!1;if(g=M,M!==null){const A=M.width,T=M.height;(s.width!==A||s.height!==T)&&this.setSize(A,T)}return v===!1&&S.setRenderTarget(s),E=S.toneMapping,S.toneMapping=hi,!0},this.hasRenderPass=function(){return v},this.end=function(S,M){S.toneMapping=E,x=!0;let A=s,T=o;for(let w=0;w<d.length;w++){const _=d[w];if(_.enabled!==!1&&(_.render(S,T,A,M),_.needsSwap!==!1)){const C=A;A=T,T=C}}if(u!==S.outputColorSpace||m!==S.toneMapping){u=S.outputColorSpace,m=S.toneMapping,c.defines={},We.getTransfer(u)===tt&&(c.defines.SRGB_TRANSFER="");const w=FT[m];w&&(c.defines[w]=""),c.needsUpdate=!0}c.uniforms.tDiffuse.value=A.texture,S.setRenderTarget(g),S.render(f,h),g=null,x=!1},this.isCompositing=function(){return x},this.dispose=function(){s.depthTexture&&s.depthTexture.dispose(),s.dispose(),o.dispose(),l.dispose(),c.dispose()}}const Ox=new an,vf=new qa(1,1),kx=new Ex,Bx=new oE,zx=new Px,Km=[],Zm=[],Qm=new Float32Array(16),Jm=new Float32Array(9),eg=new Float32Array(4);function ts(t,e,n){const i=t[0];if(i<=0||i>0)return t;const r=e*n;let a=Km[r];if(a===void 0&&(a=new Float32Array(r),Km[r]=a),e!==0){i.toArray(a,0);for(let s=1,o=0;s!==e;++s)o+=n,t[s].toArray(a,o)}return a}function Ut(t,e){if(t.length!==e.length)return!1;for(let n=0,i=t.length;n<i;n++)if(t[n]!==e[n])return!1;return!0}function Ft(t,e){for(let n=0,i=e.length;n<i;n++)t[n]=e[n]}function bc(t,e){let n=Zm[e];n===void 0&&(n=new Int32Array(e),Zm[e]=n);for(let i=0;i!==e;++i)n[i]=t.allocateTextureUnit();return n}function kT(t,e){const n=this.cache;n[0]!==e&&(t.uniform1f(this.addr,e),n[0]=e)}function BT(t,e){const n=this.cache;if(e.x!==void 0)(n[0]!==e.x||n[1]!==e.y)&&(t.uniform2f(this.addr,e.x,e.y),n[0]=e.x,n[1]=e.y);else{if(Ut(n,e))return;t.uniform2fv(this.addr,e),Ft(n,e)}}function zT(t,e){const n=this.cache;if(e.x!==void 0)(n[0]!==e.x||n[1]!==e.y||n[2]!==e.z)&&(t.uniform3f(this.addr,e.x,e.y,e.z),n[0]=e.x,n[1]=e.y,n[2]=e.z);else if(e.r!==void 0)(n[0]!==e.r||n[1]!==e.g||n[2]!==e.b)&&(t.uniform3f(this.addr,e.r,e.g,e.b),n[0]=e.r,n[1]=e.g,n[2]=e.b);else{if(Ut(n,e))return;t.uniform3fv(this.addr,e),Ft(n,e)}}function VT(t,e){const n=this.cache;if(e.x!==void 0)(n[0]!==e.x||n[1]!==e.y||n[2]!==e.z||n[3]!==e.w)&&(t.uniform4f(this.addr,e.x,e.y,e.z,e.w),n[0]=e.x,n[1]=e.y,n[2]=e.z,n[3]=e.w);else{if(Ut(n,e))return;t.uniform4fv(this.addr,e),Ft(n,e)}}function HT(t,e){const n=this.cache,i=e.elements;if(i===void 0){if(Ut(n,e))return;t.uniformMatrix2fv(this.addr,!1,e),Ft(n,e)}else{if(Ut(n,i))return;eg.set(i),t.uniformMatrix2fv(this.addr,!1,eg),Ft(n,i)}}function GT(t,e){const n=this.cache,i=e.elements;if(i===void 0){if(Ut(n,e))return;t.uniformMatrix3fv(this.addr,!1,e),Ft(n,e)}else{if(Ut(n,i))return;Jm.set(i),t.uniformMatrix3fv(this.addr,!1,Jm),Ft(n,i)}}function WT(t,e){const n=this.cache,i=e.elements;if(i===void 0){if(Ut(n,e))return;t.uniformMatrix4fv(this.addr,!1,e),Ft(n,e)}else{if(Ut(n,i))return;Qm.set(i),t.uniformMatrix4fv(this.addr,!1,Qm),Ft(n,i)}}function jT(t,e){const n=this.cache;n[0]!==e&&(t.uniform1i(this.addr,e),n[0]=e)}function XT(t,e){const n=this.cache;if(e.x!==void 0)(n[0]!==e.x||n[1]!==e.y)&&(t.uniform2i(this.addr,e.x,e.y),n[0]=e.x,n[1]=e.y);else{if(Ut(n,e))return;t.uniform2iv(this.addr,e),Ft(n,e)}}function $T(t,e){const n=this.cache;if(e.x!==void 0)(n[0]!==e.x||n[1]!==e.y||n[2]!==e.z)&&(t.uniform3i(this.addr,e.x,e.y,e.z),n[0]=e.x,n[1]=e.y,n[2]=e.z);else{if(Ut(n,e))return;t.uniform3iv(this.addr,e),Ft(n,e)}}function qT(t,e){const n=this.cache;if(e.x!==void 0)(n[0]!==e.x||n[1]!==e.y||n[2]!==e.z||n[3]!==e.w)&&(t.uniform4i(this.addr,e.x,e.y,e.z,e.w),n[0]=e.x,n[1]=e.y,n[2]=e.z,n[3]=e.w);else{if(Ut(n,e))return;t.uniform4iv(this.addr,e),Ft(n,e)}}function YT(t,e){const n=this.cache;n[0]!==e&&(t.uniform1ui(this.addr,e),n[0]=e)}function KT(t,e){const n=this.cache;if(e.x!==void 0)(n[0]!==e.x||n[1]!==e.y)&&(t.uniform2ui(this.addr,e.x,e.y),n[0]=e.x,n[1]=e.y);else{if(Ut(n,e))return;t.uniform2uiv(this.addr,e),Ft(n,e)}}function ZT(t,e){const n=this.cache;if(e.x!==void 0)(n[0]!==e.x||n[1]!==e.y||n[2]!==e.z)&&(t.uniform3ui(this.addr,e.x,e.y,e.z),n[0]=e.x,n[1]=e.y,n[2]=e.z);else{if(Ut(n,e))return;t.uniform3uiv(this.addr,e),Ft(n,e)}}function QT(t,e){const n=this.cache;if(e.x!==void 0)(n[0]!==e.x||n[1]!==e.y||n[2]!==e.z||n[3]!==e.w)&&(t.uniform4ui(this.addr,e.x,e.y,e.z,e.w),n[0]=e.x,n[1]=e.y,n[2]=e.z,n[3]=e.w);else{if(Ut(n,e))return;t.uniform4uiv(this.addr,e),Ft(n,e)}}function JT(t,e,n){const i=this.cache,r=n.allocateTextureUnit();i[0]!==r&&(t.uniform1i(this.addr,r),i[0]=r);let a;this.type===t.SAMPLER_2D_SHADOW?(vf.compareFunction=n.isReversedDepthBuffer()?Lh:Nh,a=vf):a=Ox,n.setTexture2D(e||a,r)}function e2(t,e,n){const i=this.cache,r=n.allocateTextureUnit();i[0]!==r&&(t.uniform1i(this.addr,r),i[0]=r),n.setTexture3D(e||Bx,r)}function t2(t,e,n){const i=this.cache,r=n.allocateTextureUnit();i[0]!==r&&(t.uniform1i(this.addr,r),i[0]=r),n.setTextureCube(e||zx,r)}function n2(t,e,n){const i=this.cache,r=n.allocateTextureUnit();i[0]!==r&&(t.uniform1i(this.addr,r),i[0]=r),n.setTexture2DArray(e||kx,r)}function i2(t){switch(t){case 5126:return kT;case 35664:return BT;case 35665:return zT;case 35666:return VT;case 35674:return HT;case 35675:return GT;case 35676:return WT;case 5124:case 35670:return jT;case 35667:case 35671:return XT;case 35668:case 35672:return $T;case 35669:case 35673:return qT;case 5125:return YT;case 36294:return KT;case 36295:return ZT;case 36296:return QT;case 35678:case 36198:case 36298:case 36306:case 35682:return JT;case 35679:case 36299:case 36307:return e2;case 35680:case 36300:case 36308:case 36293:return t2;case 36289:case 36303:case 36311:case 36292:return n2}}function r2(t,e){t.uniform1fv(this.addr,e)}function a2(t,e){const n=ts(e,this.size,2);t.uniform2fv(this.addr,n)}function s2(t,e){const n=ts(e,this.size,3);t.uniform3fv(this.addr,n)}function o2(t,e){const n=ts(e,this.size,4);t.uniform4fv(this.addr,n)}function l2(t,e){const n=ts(e,this.size,4);t.uniformMatrix2fv(this.addr,!1,n)}function c2(t,e){const n=ts(e,this.size,9);t.uniformMatrix3fv(this.addr,!1,n)}function u2(t,e){const n=ts(e,this.size,16);t.uniformMatrix4fv(this.addr,!1,n)}function d2(t,e){t.uniform1iv(this.addr,e)}function f2(t,e){t.uniform2iv(this.addr,e)}function h2(t,e){t.uniform3iv(this.addr,e)}function p2(t,e){t.uniform4iv(this.addr,e)}function m2(t,e){t.uniform1uiv(this.addr,e)}function g2(t,e){t.uniform2uiv(this.addr,e)}function _2(t,e){t.uniform3uiv(this.addr,e)}function x2(t,e){t.uniform4uiv(this.addr,e)}function v2(t,e,n){const i=this.cache,r=e.length,a=bc(n,r);Ut(i,a)||(t.uniform1iv(this.addr,a),Ft(i,a));let s;this.type===t.SAMPLER_2D_SHADOW?s=vf:s=Ox;for(let o=0;o!==r;++o)n.setTexture2D(e[o]||s,a[o])}function y2(t,e,n){const i=this.cache,r=e.length,a=bc(n,r);Ut(i,a)||(t.uniform1iv(this.addr,a),Ft(i,a));for(let s=0;s!==r;++s)n.setTexture3D(e[s]||Bx,a[s])}function S2(t,e,n){const i=this.cache,r=e.length,a=bc(n,r);Ut(i,a)||(t.uniform1iv(this.addr,a),Ft(i,a));for(let s=0;s!==r;++s)n.setTextureCube(e[s]||zx,a[s])}function M2(t,e,n){const i=this.cache,r=e.length,a=bc(n,r);Ut(i,a)||(t.uniform1iv(this.addr,a),Ft(i,a));for(let s=0;s!==r;++s)n.setTexture2DArray(e[s]||kx,a[s])}function E2(t){switch(t){case 5126:return r2;case 35664:return a2;case 35665:return s2;case 35666:return o2;case 35674:return l2;case 35675:return c2;case 35676:return u2;case 5124:case 35670:return d2;case 35667:case 35671:return f2;case 35668:case 35672:return h2;case 35669:case 35673:return p2;case 5125:return m2;case 36294:return g2;case 36295:return _2;case 36296:return x2;case 35678:case 36198:case 36298:case 36306:case 35682:return v2;case 35679:case 36299:case 36307:return y2;case 35680:case 36300:case 36308:case 36293:return S2;case 36289:case 36303:case 36311:case 36292:return M2}}class b2{constructor(e,n,i){this.id=e,this.addr=i,this.cache=[],this.type=n.type,this.setValue=i2(n.type)}}class w2{constructor(e,n,i){this.id=e,this.addr=i,this.cache=[],this.type=n.type,this.size=n.size,this.setValue=E2(n.type)}}class T2{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,n,i){const r=this.seq;for(let a=0,s=r.length;a!==s;++a){const o=r[a];o.setValue(e,n[o.id],i)}}}const Iu=/(\w+)(\])?(\[|\.)?/g;function tg(t,e){t.seq.push(e),t.map[e.id]=e}function A2(t,e,n){const i=t.name,r=i.length;for(Iu.lastIndex=0;;){const a=Iu.exec(i),s=Iu.lastIndex;let o=a[1];const l=a[2]==="]",c=a[3];if(l&&(o=o|0),c===void 0||c==="["&&s+2===r){tg(n,c===void 0?new b2(o,t,e):new w2(o,t,e));break}else{let h=n.map[o];h===void 0&&(h=new T2(o),tg(n,h)),n=h}}}class Sl{constructor(e,n){this.seq=[],this.map={};const i=e.getProgramParameter(n,e.ACTIVE_UNIFORMS);for(let s=0;s<i;++s){const o=e.getActiveUniform(n,s),l=e.getUniformLocation(n,o.name);A2(o,l,this)}const r=[],a=[];for(const s of this.seq)s.type===e.SAMPLER_2D_SHADOW||s.type===e.SAMPLER_CUBE_SHADOW||s.type===e.SAMPLER_2D_ARRAY_SHADOW?r.push(s):a.push(s);r.length>0&&(this.seq=r.concat(a))}setValue(e,n,i,r){const a=this.map[n];a!==void 0&&a.setValue(e,i,r)}setOptional(e,n,i){const r=n[i];r!==void 0&&this.setValue(e,i,r)}static upload(e,n,i,r){for(let a=0,s=n.length;a!==s;++a){const o=n[a],l=i[o.id];l.needsUpdate!==!1&&o.setValue(e,l.value,r)}}static seqWithValue(e,n){const i=[];for(let r=0,a=e.length;r!==a;++r){const s=e[r];s.id in n&&i.push(s)}return i}}function ng(t,e,n){const i=t.createShader(e);return t.shaderSource(i,n),t.compileShader(i),i}const C2=37297;let R2=0;function P2(t,e){const n=t.split(`
`),i=[],r=Math.max(e-6,0),a=Math.min(e+6,n.length);for(let s=r;s<a;s++){const o=s+1;i.push(`${o===e?">":" "} ${o}: ${n[s]}`)}return i.join(`
`)}const ig=new Ie;function N2(t){We._getMatrix(ig,We.workingColorSpace,t);const e=`mat3( ${ig.elements.map(n=>n.toFixed(4))} )`;switch(We.getTransfer(t)){case Ql:return[e,"LinearTransferOETF"];case tt:return[e,"sRGBTransferOETF"];default:return De("WebGLProgram: Unsupported color space: ",t),[e,"LinearTransferOETF"]}}function rg(t,e,n){const i=t.getShaderParameter(e,t.COMPILE_STATUS),a=(t.getShaderInfoLog(e)||"").trim();if(i&&a==="")return"";const s=/ERROR: 0:(\d+)/.exec(a);if(s){const o=parseInt(s[1]);return n.toUpperCase()+`

`+a+`

`+P2(t.getShaderSource(e),o)}else return a}function L2(t,e){const n=N2(e);return[`vec4 ${t}( vec4 value ) {`,`	return ${n[1]}( vec4( value.rgb * ${n[0]}, value.a ) );`,"}"].join(`
`)}const D2={[ox]:"Linear",[lx]:"Reinhard",[cx]:"Cineon",[ux]:"ACESFilmic",[fx]:"AgX",[hx]:"Neutral",[dx]:"Custom"};function I2(t,e){const n=D2[e];return n===void 0?(De("WebGLProgram: Unsupported toneMapping:",e),"vec3 "+t+"( vec3 color ) { return LinearToneMapping( color ); }"):"vec3 "+t+"( vec3 color ) { return "+n+"ToneMapping( color ); }"}const el=new j;function U2(){We.getLuminanceCoefficients(el);const t=el.x.toFixed(4),e=el.y.toFixed(4),n=el.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${t}, ${e}, ${n} );`,"	return dot( weights, rgb );","}"].join(`
`)}function F2(t){return[t.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",t.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(Es).join(`
`)}function O2(t){const e=[];for(const n in t){const i=t[n];i!==!1&&e.push("#define "+n+" "+i)}return e.join(`
`)}function k2(t,e){const n={},i=t.getProgramParameter(e,t.ACTIVE_ATTRIBUTES);for(let r=0;r<i;r++){const a=t.getActiveAttrib(e,r),s=a.name;let o=1;a.type===t.FLOAT_MAT2&&(o=2),a.type===t.FLOAT_MAT3&&(o=3),a.type===t.FLOAT_MAT4&&(o=4),n[s]={type:a.type,location:t.getAttribLocation(e,s),locationSize:o}}return n}function Es(t){return t!==""}function ag(t,e){const n=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return t.replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,n).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows)}function sg(t,e){return t.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}const B2=/^[ \t]*#include +<([\w\d./]+)>/gm;function yf(t){return t.replace(B2,V2)}const z2=new Map;function V2(t,e){let n=ke[e];if(n===void 0){const i=z2.get(e);if(i!==void 0)n=ke[i],De('WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',e,i);else throw new Error("THREE.WebGLProgram: Can not resolve #include <"+e+">")}return yf(n)}const H2=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function og(t){return t.replace(H2,G2)}function G2(t,e,n,i){let r="";for(let a=parseInt(e);a<parseInt(n);a++)r+=i.replace(/\[\s*i\s*\]/g,"[ "+a+" ]").replace(/UNROLLED_LOOP_INDEX/g,a);return r}function lg(t){let e=`precision ${t.precision} float;
	precision ${t.precision} int;
	precision ${t.precision} sampler2D;
	precision ${t.precision} samplerCube;
	precision ${t.precision} sampler3D;
	precision ${t.precision} sampler2DArray;
	precision ${t.precision} sampler2DShadow;
	precision ${t.precision} samplerCubeShadow;
	precision ${t.precision} sampler2DArrayShadow;
	precision ${t.precision} isampler2D;
	precision ${t.precision} isampler3D;
	precision ${t.precision} isamplerCube;
	precision ${t.precision} isampler2DArray;
	precision ${t.precision} usampler2D;
	precision ${t.precision} usampler3D;
	precision ${t.precision} usamplerCube;
	precision ${t.precision} usampler2DArray;
	`;return t.precision==="highp"?e+=`
#define HIGH_PRECISION`:t.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:t.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}const W2={[gl]:"SHADOWMAP_TYPE_PCF",[Ms]:"SHADOWMAP_TYPE_VSM"};function j2(t){return W2[t.shadowMapType]||"SHADOWMAP_TYPE_BASIC"}const X2={[qr]:"ENVMAP_TYPE_CUBE",[$a]:"ENVMAP_TYPE_CUBE",[Sc]:"ENVMAP_TYPE_CUBE_UV"};function $2(t){return t.envMap===!1?"ENVMAP_TYPE_CUBE":X2[t.envMapMode]||"ENVMAP_TYPE_CUBE"}const q2={[$a]:"ENVMAP_MODE_REFRACTION"};function Y2(t){return t.envMap===!1?"ENVMAP_MODE_REFLECTION":q2[t.envMapMode]||"ENVMAP_MODE_REFLECTION"}const K2={[sx]:"ENVMAP_BLENDING_MULTIPLY",[zM]:"ENVMAP_BLENDING_MIX",[VM]:"ENVMAP_BLENDING_ADD"};function Z2(t){return t.envMap===!1?"ENVMAP_BLENDING_NONE":K2[t.combine]||"ENVMAP_BLENDING_NONE"}function Q2(t){const e=t.envMapCubeUVHeight;if(e===null)return null;const n=Math.log2(e)-2,i=1/e;return{texelWidth:1/(3*Math.max(Math.pow(2,n),7*16)),texelHeight:i,maxMip:n}}function J2(t,e,n,i){const r=t.getContext(),a=n.defines;let s=n.vertexShader,o=n.fragmentShader;const l=j2(n),c=$2(n),f=Y2(n),h=Z2(n),u=Q2(n),m=F2(n),x=O2(a),E=r.createProgram();let g,d,v=n.glslVersion?"#version "+n.glslVersion+`
`:"";n.isRawShaderMaterial?(g=["#define SHADER_TYPE "+n.shaderType,"#define SHADER_NAME "+n.shaderName,x].filter(Es).join(`
`),g.length>0&&(g+=`
`),d=["#define SHADER_TYPE "+n.shaderType,"#define SHADER_NAME "+n.shaderName,x].filter(Es).join(`
`),d.length>0&&(d+=`
`)):(g=[lg(n),"#define SHADER_TYPE "+n.shaderType,"#define SHADER_NAME "+n.shaderName,x,n.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",n.batching?"#define USE_BATCHING":"",n.batchingColor?"#define USE_BATCHING_COLOR":"",n.instancing?"#define USE_INSTANCING":"",n.instancingColor?"#define USE_INSTANCING_COLOR":"",n.instancingMorph?"#define USE_INSTANCING_MORPH":"",n.useFog&&n.fog?"#define USE_FOG":"",n.useFog&&n.fogExp2?"#define FOG_EXP2":"",n.map?"#define USE_MAP":"",n.envMap?"#define USE_ENVMAP":"",n.envMap?"#define "+f:"",n.lightMap?"#define USE_LIGHTMAP":"",n.aoMap?"#define USE_AOMAP":"",n.bumpMap?"#define USE_BUMPMAP":"",n.normalMap?"#define USE_NORMALMAP":"",n.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",n.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",n.displacementMap?"#define USE_DISPLACEMENTMAP":"",n.emissiveMap?"#define USE_EMISSIVEMAP":"",n.anisotropy?"#define USE_ANISOTROPY":"",n.anisotropyMap?"#define USE_ANISOTROPYMAP":"",n.clearcoatMap?"#define USE_CLEARCOATMAP":"",n.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",n.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",n.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",n.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",n.specularMap?"#define USE_SPECULARMAP":"",n.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",n.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",n.roughnessMap?"#define USE_ROUGHNESSMAP":"",n.metalnessMap?"#define USE_METALNESSMAP":"",n.alphaMap?"#define USE_ALPHAMAP":"",n.alphaHash?"#define USE_ALPHAHASH":"",n.transmission?"#define USE_TRANSMISSION":"",n.transmissionMap?"#define USE_TRANSMISSIONMAP":"",n.thicknessMap?"#define USE_THICKNESSMAP":"",n.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",n.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",n.mapUv?"#define MAP_UV "+n.mapUv:"",n.alphaMapUv?"#define ALPHAMAP_UV "+n.alphaMapUv:"",n.lightMapUv?"#define LIGHTMAP_UV "+n.lightMapUv:"",n.aoMapUv?"#define AOMAP_UV "+n.aoMapUv:"",n.emissiveMapUv?"#define EMISSIVEMAP_UV "+n.emissiveMapUv:"",n.bumpMapUv?"#define BUMPMAP_UV "+n.bumpMapUv:"",n.normalMapUv?"#define NORMALMAP_UV "+n.normalMapUv:"",n.displacementMapUv?"#define DISPLACEMENTMAP_UV "+n.displacementMapUv:"",n.metalnessMapUv?"#define METALNESSMAP_UV "+n.metalnessMapUv:"",n.roughnessMapUv?"#define ROUGHNESSMAP_UV "+n.roughnessMapUv:"",n.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+n.anisotropyMapUv:"",n.clearcoatMapUv?"#define CLEARCOATMAP_UV "+n.clearcoatMapUv:"",n.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+n.clearcoatNormalMapUv:"",n.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+n.clearcoatRoughnessMapUv:"",n.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+n.iridescenceMapUv:"",n.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+n.iridescenceThicknessMapUv:"",n.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+n.sheenColorMapUv:"",n.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+n.sheenRoughnessMapUv:"",n.specularMapUv?"#define SPECULARMAP_UV "+n.specularMapUv:"",n.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+n.specularColorMapUv:"",n.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+n.specularIntensityMapUv:"",n.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+n.transmissionMapUv:"",n.thicknessMapUv?"#define THICKNESSMAP_UV "+n.thicknessMapUv:"",n.vertexTangents&&n.flatShading===!1?"#define USE_TANGENT":"",n.vertexNormals?"#define HAS_NORMAL":"",n.vertexColors?"#define USE_COLOR":"",n.vertexAlphas?"#define USE_COLOR_ALPHA":"",n.vertexUv1s?"#define USE_UV1":"",n.vertexUv2s?"#define USE_UV2":"",n.vertexUv3s?"#define USE_UV3":"",n.pointsUvs?"#define USE_POINTS_UV":"",n.flatShading?"#define FLAT_SHADED":"",n.skinning?"#define USE_SKINNING":"",n.morphTargets?"#define USE_MORPHTARGETS":"",n.morphNormals&&n.flatShading===!1?"#define USE_MORPHNORMALS":"",n.morphColors?"#define USE_MORPHCOLORS":"",n.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+n.morphTextureStride:"",n.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+n.morphTargetsCount:"",n.doubleSided?"#define DOUBLE_SIDED":"",n.flipSided?"#define FLIP_SIDED":"",n.shadowMapEnabled?"#define USE_SHADOWMAP":"",n.shadowMapEnabled?"#define "+l:"",n.sizeAttenuation?"#define USE_SIZEATTENUATION":"",n.numLightProbes>0?"#define USE_LIGHT_PROBES":"",n.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",n.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(Es).join(`
`),d=[lg(n),"#define SHADER_TYPE "+n.shaderType,"#define SHADER_NAME "+n.shaderName,x,n.useFog&&n.fog?"#define USE_FOG":"",n.useFog&&n.fogExp2?"#define FOG_EXP2":"",n.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",n.map?"#define USE_MAP":"",n.matcap?"#define USE_MATCAP":"",n.envMap?"#define USE_ENVMAP":"",n.envMap?"#define "+c:"",n.envMap?"#define "+f:"",n.envMap?"#define "+h:"",u?"#define CUBEUV_TEXEL_WIDTH "+u.texelWidth:"",u?"#define CUBEUV_TEXEL_HEIGHT "+u.texelHeight:"",u?"#define CUBEUV_MAX_MIP "+u.maxMip+".0":"",n.lightMap?"#define USE_LIGHTMAP":"",n.aoMap?"#define USE_AOMAP":"",n.bumpMap?"#define USE_BUMPMAP":"",n.normalMap?"#define USE_NORMALMAP":"",n.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",n.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",n.packedNormalMap?"#define USE_PACKED_NORMALMAP":"",n.emissiveMap?"#define USE_EMISSIVEMAP":"",n.anisotropy?"#define USE_ANISOTROPY":"",n.anisotropyMap?"#define USE_ANISOTROPYMAP":"",n.clearcoat?"#define USE_CLEARCOAT":"",n.clearcoatMap?"#define USE_CLEARCOATMAP":"",n.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",n.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",n.dispersion?"#define USE_DISPERSION":"",n.iridescence?"#define USE_IRIDESCENCE":"",n.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",n.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",n.specularMap?"#define USE_SPECULARMAP":"",n.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",n.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",n.roughnessMap?"#define USE_ROUGHNESSMAP":"",n.metalnessMap?"#define USE_METALNESSMAP":"",n.alphaMap?"#define USE_ALPHAMAP":"",n.alphaTest?"#define USE_ALPHATEST":"",n.alphaHash?"#define USE_ALPHAHASH":"",n.sheen?"#define USE_SHEEN":"",n.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",n.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",n.transmission?"#define USE_TRANSMISSION":"",n.transmissionMap?"#define USE_TRANSMISSIONMAP":"",n.thicknessMap?"#define USE_THICKNESSMAP":"",n.vertexTangents&&n.flatShading===!1?"#define USE_TANGENT":"",n.vertexColors||n.instancingColor?"#define USE_COLOR":"",n.vertexAlphas||n.batchingColor?"#define USE_COLOR_ALPHA":"",n.vertexUv1s?"#define USE_UV1":"",n.vertexUv2s?"#define USE_UV2":"",n.vertexUv3s?"#define USE_UV3":"",n.pointsUvs?"#define USE_POINTS_UV":"",n.gradientMap?"#define USE_GRADIENTMAP":"",n.flatShading?"#define FLAT_SHADED":"",n.doubleSided?"#define DOUBLE_SIDED":"",n.flipSided?"#define FLIP_SIDED":"",n.shadowMapEnabled?"#define USE_SHADOWMAP":"",n.shadowMapEnabled?"#define "+l:"",n.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",n.numLightProbes>0?"#define USE_LIGHT_PROBES":"",n.numLightProbeGrids>0?"#define USE_LIGHT_PROBES_GRID":"",n.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",n.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",n.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",n.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",n.toneMapping!==hi?"#define TONE_MAPPING":"",n.toneMapping!==hi?ke.tonemapping_pars_fragment:"",n.toneMapping!==hi?I2("toneMapping",n.toneMapping):"",n.dithering?"#define DITHERING":"",n.opaque?"#define OPAQUE":"",ke.colorspace_pars_fragment,L2("linearToOutputTexel",n.outputColorSpace),U2(),n.useDepthPacking?"#define DEPTH_PACKING "+n.depthPacking:"",`
`].filter(Es).join(`
`)),s=yf(s),s=ag(s,n),s=sg(s,n),o=yf(o),o=ag(o,n),o=sg(o,n),s=og(s),o=og(o),n.isRawShaderMaterial!==!0&&(v=`#version 300 es
`,g=[m,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+g,d=["#define varying in",n.glslVersion===Mm?"":"layout(location = 0) out highp vec4 pc_fragColor;",n.glslVersion===Mm?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+d);const S=v+g+s,M=v+d+o,A=ng(r,r.VERTEX_SHADER,S),T=ng(r,r.FRAGMENT_SHADER,M);r.attachShader(E,A),r.attachShader(E,T),n.index0AttributeName!==void 0?r.bindAttribLocation(E,0,n.index0AttributeName):n.hasPositionAttribute===!0&&r.bindAttribLocation(E,0,"position"),r.linkProgram(E);function w(N){if(t.debug.checkShaderErrors){const F=r.getProgramInfoLog(E)||"",q=r.getShaderInfoLog(A)||"",ie=r.getShaderInfoLog(T)||"",k=F.trim(),X=q.trim(),V=ie.trim();let O=!0,I=!0;if(r.getProgramParameter(E,r.LINK_STATUS)===!1)if(O=!1,typeof t.debug.onShaderError=="function")t.debug.onShaderError(r,E,A,T);else{const J=rg(r,A,"vertex"),ae=rg(r,T,"fragment");Ye("WebGLProgram: Shader Error "+r.getError()+" - VALIDATE_STATUS "+r.getProgramParameter(E,r.VALIDATE_STATUS)+`

Material Name: `+N.name+`
Material Type: `+N.type+`

Program Info Log: `+k+`
`+J+`
`+ae)}else k!==""?De("WebGLProgram: Program Info Log:",k):(X===""||V==="")&&(I=!1);I&&(N.diagnostics={runnable:O,programLog:k,vertexShader:{log:X,prefix:g},fragmentShader:{log:V,prefix:d}})}r.deleteShader(A),r.deleteShader(T),_=new Sl(r,E),C=k2(r,E)}let _;this.getUniforms=function(){return _===void 0&&w(this),_};let C;this.getAttributes=function(){return C===void 0&&w(this),C};let P=n.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return P===!1&&(P=r.getProgramParameter(E,C2)),P},this.destroy=function(){i.releaseStatesOfProgram(this),r.deleteProgram(E),this.program=void 0},this.type=n.shaderType,this.name=n.shaderName,this.id=R2++,this.cacheKey=e,this.usedTimes=1,this.program=E,this.vertexShader=A,this.fragmentShader=T,this}let eA=0;class tA{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e,n,i){const r=this._getShaderCacheForMaterial(e);return r.has(n)===!1&&(r.add(n),n.usedTimes++),r.has(i)===!1&&(r.add(i),i.usedTimes++),this}remove(e){const n=this.materialCache.get(e);for(const i of n)i.usedTimes--,i.usedTimes===0&&this.shaderCache.delete(i.code);return this.materialCache.delete(e),this}getVertexShaderStage(e){return this._getShaderStage(e.vertexShader)}getFragmentShaderStage(e){return this._getShaderStage(e.fragmentShader)}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){const n=this.materialCache;let i=n.get(e);return i===void 0&&(i=new Set,n.set(e,i)),i}_getShaderStage(e){const n=this.shaderCache;let i=n.get(e);return i===void 0&&(i=new nA(e),n.set(e,i)),i}}class nA{constructor(e){this.id=eA++,this.code=e,this.usedTimes=0}}function iA(t){return t===Yr||t===Yl||t===Kl}function rA(t,e,n,i,r,a){const s=new bx,o=new tA,l=new Set,c=[],f=new Map,h=i.logarithmicDepthBuffer;let u=i.precision;const m={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distance",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function x(_){return l.add(_),_===0?"uv":`uv${_}`}function E(_,C,P,N,F,q){const ie=N.fog,k=F.geometry,X=_.isMeshStandardMaterial||_.isMeshLambertMaterial||_.isMeshPhongMaterial?N.environment:null,V=_.isMeshStandardMaterial||_.isMeshLambertMaterial&&!_.envMap||_.isMeshPhongMaterial&&!_.envMap,O=e.get(_.envMap||X,V),I=O&&O.mapping===Sc?O.image.height:null,J=m[_.type];_.precision!==null&&(u=i.getMaxPrecision(_.precision),u!==_.precision&&De("WebGLProgram.getParameters:",_.precision,"not supported, using",u,"instead."));const ae=k.morphAttributes.position||k.morphAttributes.normal||k.morphAttributes.color,le=ae!==void 0?ae.length:0;let Be=0;k.morphAttributes.position!==void 0&&(Be=1),k.morphAttributes.normal!==void 0&&(Be=2),k.morphAttributes.color!==void 0&&(Be=3);let Xe,ze,Q,oe;if(J){const Ee=si[J];Xe=Ee.vertexShader,ze=Ee.fragmentShader}else{Xe=_.vertexShader,ze=_.fragmentShader;const Ee=o.getVertexShaderStage(_),vt=o.getFragmentShaderStage(_);o.update(_,Ee,vt),Q=Ee.id,oe=vt.id}const ee=t.getRenderTarget(),Pe=t.state.buffers.depth.getReversed(),Ue=F.isInstancedMesh===!0,Ne=F.isBatchedMesh===!0,Et=!!_.map,Ge=!!_.matcap,rt=!!O,Je=!!_.aoMap,$e=!!_.lightMap,At=!!_.bumpMap&&_.wireframe===!1,Lt=!!_.normalMap,Ot=!!_.displacementMap,Vt=!!_.emissiveMap,xt=!!_.metalnessMap,Ct=!!_.roughnessMap,D=_.anisotropy>0,ln=_.clearcoat>0,et=_.dispersion>0,R=_.iridescence>0,y=_.sheen>0,B=_.transmission>0,W=D&&!!_.anisotropyMap,K=ln&&!!_.clearcoatMap,ce=ln&&!!_.clearcoatNormalMap,de=ln&&!!_.clearcoatRoughnessMap,Z=R&&!!_.iridescenceMap,ne=R&&!!_.iridescenceThicknessMap,fe=y&&!!_.sheenColorMap,Te=y&&!!_.sheenRoughnessMap,me=!!_.specularMap,he=!!_.specularColorMap,Re=!!_.specularIntensityMap,Le=B&&!!_.transmissionMap,Fe=B&&!!_.thicknessMap,L=!!_.gradientMap,ue=!!_.alphaMap,te=_.alphaTest>0,pe=!!_.alphaHash,ve=!!_.extensions;let re=hi;_.toneMapped&&(ee===null||ee.isXRRenderTarget===!0)&&(re=t.toneMapping);const we={shaderID:J,shaderType:_.type,shaderName:_.name,vertexShader:Xe,fragmentShader:ze,defines:_.defines,customVertexShaderID:Q,customFragmentShaderID:oe,isRawShaderMaterial:_.isRawShaderMaterial===!0,glslVersion:_.glslVersion,precision:u,batching:Ne,batchingColor:Ne&&F._colorsTexture!==null,instancing:Ue,instancingColor:Ue&&F.instanceColor!==null,instancingMorph:Ue&&F.morphTexture!==null,outputColorSpace:ee===null?t.outputColorSpace:ee.isXRRenderTarget===!0?ee.texture.colorSpace:We.workingColorSpace,alphaToCoverage:!!_.alphaToCoverage,map:Et,matcap:Ge,envMap:rt,envMapMode:rt&&O.mapping,envMapCubeUVHeight:I,aoMap:Je,lightMap:$e,bumpMap:At,normalMap:Lt,displacementMap:Ot,emissiveMap:Vt,normalMapObjectSpace:Lt&&_.normalMapType===WM,normalMapTangentSpace:Lt&&_.normalMapType===vm,packedNormalMap:Lt&&_.normalMapType===vm&&iA(_.normalMap.format),metalnessMap:xt,roughnessMap:Ct,anisotropy:D,anisotropyMap:W,clearcoat:ln,clearcoatMap:K,clearcoatNormalMap:ce,clearcoatRoughnessMap:de,dispersion:et,iridescence:R,iridescenceMap:Z,iridescenceThicknessMap:ne,sheen:y,sheenColorMap:fe,sheenRoughnessMap:Te,specularMap:me,specularColorMap:he,specularIntensityMap:Re,transmission:B,transmissionMap:Le,thicknessMap:Fe,gradientMap:L,opaque:_.transparent===!1&&_.blending===Fa&&_.alphaToCoverage===!1,alphaMap:ue,alphaTest:te,alphaHash:pe,combine:_.combine,mapUv:Et&&x(_.map.channel),aoMapUv:Je&&x(_.aoMap.channel),lightMapUv:$e&&x(_.lightMap.channel),bumpMapUv:At&&x(_.bumpMap.channel),normalMapUv:Lt&&x(_.normalMap.channel),displacementMapUv:Ot&&x(_.displacementMap.channel),emissiveMapUv:Vt&&x(_.emissiveMap.channel),metalnessMapUv:xt&&x(_.metalnessMap.channel),roughnessMapUv:Ct&&x(_.roughnessMap.channel),anisotropyMapUv:W&&x(_.anisotropyMap.channel),clearcoatMapUv:K&&x(_.clearcoatMap.channel),clearcoatNormalMapUv:ce&&x(_.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:de&&x(_.clearcoatRoughnessMap.channel),iridescenceMapUv:Z&&x(_.iridescenceMap.channel),iridescenceThicknessMapUv:ne&&x(_.iridescenceThicknessMap.channel),sheenColorMapUv:fe&&x(_.sheenColorMap.channel),sheenRoughnessMapUv:Te&&x(_.sheenRoughnessMap.channel),specularMapUv:me&&x(_.specularMap.channel),specularColorMapUv:he&&x(_.specularColorMap.channel),specularIntensityMapUv:Re&&x(_.specularIntensityMap.channel),transmissionMapUv:Le&&x(_.transmissionMap.channel),thicknessMapUv:Fe&&x(_.thicknessMap.channel),alphaMapUv:ue&&x(_.alphaMap.channel),vertexTangents:!!k.attributes.tangent&&(Lt||D),vertexNormals:!!k.attributes.normal,vertexColors:_.vertexColors,vertexAlphas:_.vertexColors===!0&&!!k.attributes.color&&k.attributes.color.itemSize===4,pointsUvs:F.isPoints===!0&&!!k.attributes.uv&&(Et||ue),fog:!!ie,useFog:_.fog===!0,fogExp2:!!ie&&ie.isFogExp2,flatShading:_.wireframe===!1&&(_.flatShading===!0||k.attributes.normal===void 0&&Lt===!1&&(_.isMeshLambertMaterial||_.isMeshPhongMaterial||_.isMeshStandardMaterial||_.isMeshPhysicalMaterial)),sizeAttenuation:_.sizeAttenuation===!0,logarithmicDepthBuffer:h,reversedDepthBuffer:Pe,skinning:F.isSkinnedMesh===!0,hasPositionAttribute:k.attributes.position!==void 0,morphTargets:k.morphAttributes.position!==void 0,morphNormals:k.morphAttributes.normal!==void 0,morphColors:k.morphAttributes.color!==void 0,morphTargetsCount:le,morphTextureStride:Be,numDirLights:C.directional.length,numPointLights:C.point.length,numSpotLights:C.spot.length,numSpotLightMaps:C.spotLightMap.length,numRectAreaLights:C.rectArea.length,numHemiLights:C.hemi.length,numDirLightShadows:C.directionalShadowMap.length,numPointLightShadows:C.pointShadowMap.length,numSpotLightShadows:C.spotShadowMap.length,numSpotLightShadowsWithMaps:C.numSpotLightShadowsWithMaps,numLightProbes:C.numLightProbes,numLightProbeGrids:q.length,numClippingPlanes:a.numPlanes,numClipIntersection:a.numIntersection,dithering:_.dithering,shadowMapEnabled:t.shadowMap.enabled&&P.length>0,shadowMapType:t.shadowMap.type,toneMapping:re,decodeVideoTexture:Et&&_.map.isVideoTexture===!0&&We.getTransfer(_.map.colorSpace)===tt,decodeVideoTextureEmissive:Vt&&_.emissiveMap.isVideoTexture===!0&&We.getTransfer(_.emissiveMap.colorSpace)===tt,premultipliedAlpha:_.premultipliedAlpha,doubleSided:_.side===Ai,flipSided:_.side===mn,useDepthPacking:_.depthPacking>=0,depthPacking:_.depthPacking||0,index0AttributeName:_.index0AttributeName,extensionClipCullDistance:ve&&_.extensions.clipCullDistance===!0&&n.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(ve&&_.extensions.multiDraw===!0||Ne)&&n.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:n.has("KHR_parallel_shader_compile"),customProgramCacheKey:_.customProgramCacheKey()};return we.vertexUv1s=l.has(1),we.vertexUv2s=l.has(2),we.vertexUv3s=l.has(3),l.clear(),we}function g(_){const C=[];if(_.shaderID?C.push(_.shaderID):(C.push(_.customVertexShaderID),C.push(_.customFragmentShaderID)),_.defines!==void 0)for(const P in _.defines)C.push(P),C.push(_.defines[P]);return _.isRawShaderMaterial===!1&&(d(C,_),v(C,_),C.push(t.outputColorSpace)),C.push(_.customProgramCacheKey),C.join()}function d(_,C){_.push(C.precision),_.push(C.outputColorSpace),_.push(C.envMapMode),_.push(C.envMapCubeUVHeight),_.push(C.mapUv),_.push(C.alphaMapUv),_.push(C.lightMapUv),_.push(C.aoMapUv),_.push(C.bumpMapUv),_.push(C.normalMapUv),_.push(C.displacementMapUv),_.push(C.emissiveMapUv),_.push(C.metalnessMapUv),_.push(C.roughnessMapUv),_.push(C.anisotropyMapUv),_.push(C.clearcoatMapUv),_.push(C.clearcoatNormalMapUv),_.push(C.clearcoatRoughnessMapUv),_.push(C.iridescenceMapUv),_.push(C.iridescenceThicknessMapUv),_.push(C.sheenColorMapUv),_.push(C.sheenRoughnessMapUv),_.push(C.specularMapUv),_.push(C.specularColorMapUv),_.push(C.specularIntensityMapUv),_.push(C.transmissionMapUv),_.push(C.thicknessMapUv),_.push(C.combine),_.push(C.fogExp2),_.push(C.sizeAttenuation),_.push(C.morphTargetsCount),_.push(C.morphAttributeCount),_.push(C.numDirLights),_.push(C.numPointLights),_.push(C.numSpotLights),_.push(C.numSpotLightMaps),_.push(C.numHemiLights),_.push(C.numRectAreaLights),_.push(C.numDirLightShadows),_.push(C.numPointLightShadows),_.push(C.numSpotLightShadows),_.push(C.numSpotLightShadowsWithMaps),_.push(C.numLightProbes),_.push(C.shadowMapType),_.push(C.toneMapping),_.push(C.numClippingPlanes),_.push(C.numClipIntersection),_.push(C.depthPacking)}function v(_,C){s.disableAll(),C.instancing&&s.enable(0),C.instancingColor&&s.enable(1),C.instancingMorph&&s.enable(2),C.matcap&&s.enable(3),C.envMap&&s.enable(4),C.normalMapObjectSpace&&s.enable(5),C.normalMapTangentSpace&&s.enable(6),C.clearcoat&&s.enable(7),C.iridescence&&s.enable(8),C.alphaTest&&s.enable(9),C.vertexColors&&s.enable(10),C.vertexAlphas&&s.enable(11),C.vertexUv1s&&s.enable(12),C.vertexUv2s&&s.enable(13),C.vertexUv3s&&s.enable(14),C.vertexTangents&&s.enable(15),C.anisotropy&&s.enable(16),C.alphaHash&&s.enable(17),C.batching&&s.enable(18),C.dispersion&&s.enable(19),C.batchingColor&&s.enable(20),C.gradientMap&&s.enable(21),C.packedNormalMap&&s.enable(22),C.vertexNormals&&s.enable(23),_.push(s.mask),s.disableAll(),C.fog&&s.enable(0),C.useFog&&s.enable(1),C.flatShading&&s.enable(2),C.logarithmicDepthBuffer&&s.enable(3),C.reversedDepthBuffer&&s.enable(4),C.skinning&&s.enable(5),C.morphTargets&&s.enable(6),C.morphNormals&&s.enable(7),C.morphColors&&s.enable(8),C.premultipliedAlpha&&s.enable(9),C.shadowMapEnabled&&s.enable(10),C.doubleSided&&s.enable(11),C.flipSided&&s.enable(12),C.useDepthPacking&&s.enable(13),C.dithering&&s.enable(14),C.transmission&&s.enable(15),C.sheen&&s.enable(16),C.opaque&&s.enable(17),C.pointsUvs&&s.enable(18),C.decodeVideoTexture&&s.enable(19),C.decodeVideoTextureEmissive&&s.enable(20),C.alphaToCoverage&&s.enable(21),C.numLightProbeGrids>0&&s.enable(22),C.hasPositionAttribute&&s.enable(23),_.push(s.mask)}function S(_){const C=m[_.type];let P;if(C){const N=si[C];P=CE.clone(N.uniforms)}else P=_.uniforms;return P}function M(_,C){let P=f.get(C);return P!==void 0?++P.usedTimes:(P=new J2(t,C,_,r),c.push(P),f.set(C,P)),P}function A(_){if(--_.usedTimes===0){const C=c.indexOf(_);c[C]=c[c.length-1],c.pop(),f.delete(_.cacheKey),_.destroy()}}function T(_){o.remove(_)}function w(){o.dispose()}return{getParameters:E,getProgramCacheKey:g,getUniforms:S,acquireProgram:M,releaseProgram:A,releaseShaderCache:T,programs:c,dispose:w}}function aA(){let t=new WeakMap;function e(s){return t.has(s)}function n(s){let o=t.get(s);return o===void 0&&(o={},t.set(s,o)),o}function i(s){t.delete(s)}function r(s,o,l){t.get(s)[o]=l}function a(){t=new WeakMap}return{has:e,get:n,remove:i,update:r,dispose:a}}function sA(t,e){return t.groupOrder!==e.groupOrder?t.groupOrder-e.groupOrder:t.renderOrder!==e.renderOrder?t.renderOrder-e.renderOrder:t.material.id!==e.material.id?t.material.id-e.material.id:t.materialVariant!==e.materialVariant?t.materialVariant-e.materialVariant:t.z!==e.z?t.z-e.z:t.id-e.id}function cg(t,e){return t.groupOrder!==e.groupOrder?t.groupOrder-e.groupOrder:t.renderOrder!==e.renderOrder?t.renderOrder-e.renderOrder:t.z!==e.z?e.z-t.z:t.id-e.id}function ug(){const t=[];let e=0;const n=[],i=[],r=[];function a(){e=0,n.length=0,i.length=0,r.length=0}function s(u){let m=0;return u.isInstancedMesh&&(m+=2),u.isSkinnedMesh&&(m+=1),m}function o(u,m,x,E,g,d){let v=t[e];return v===void 0?(v={id:u.id,object:u,geometry:m,material:x,materialVariant:s(u),groupOrder:E,renderOrder:u.renderOrder,z:g,group:d},t[e]=v):(v.id=u.id,v.object=u,v.geometry=m,v.material=x,v.materialVariant=s(u),v.groupOrder=E,v.renderOrder=u.renderOrder,v.z=g,v.group=d),e++,v}function l(u,m,x,E,g,d){const v=o(u,m,x,E,g,d);x.transmission>0?i.push(v):x.transparent===!0?r.push(v):n.push(v)}function c(u,m,x,E,g,d){const v=o(u,m,x,E,g,d);x.transmission>0?i.unshift(v):x.transparent===!0?r.unshift(v):n.unshift(v)}function f(u,m,x){n.length>1&&n.sort(u||sA),i.length>1&&i.sort(m||cg),r.length>1&&r.sort(m||cg),x&&(n.reverse(),i.reverse(),r.reverse())}function h(){for(let u=e,m=t.length;u<m;u++){const x=t[u];if(x.id===null)break;x.id=null,x.object=null,x.geometry=null,x.material=null,x.group=null}}return{opaque:n,transmissive:i,transparent:r,init:a,push:l,unshift:c,finish:h,sort:f}}function oA(){let t=new WeakMap;function e(i,r){const a=t.get(i);let s;return a===void 0?(s=new ug,t.set(i,[s])):r>=a.length?(s=new ug,a.push(s)):s=a[r],s}function n(){t=new WeakMap}return{get:e,dispose:n}}function lA(){const t={};return{get:function(e){if(t[e.id]!==void 0)return t[e.id];let n;switch(e.type){case"DirectionalLight":n={direction:new j,color:new Qe};break;case"SpotLight":n={position:new j,direction:new j,color:new Qe,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":n={position:new j,color:new Qe,distance:0,decay:0};break;case"HemisphereLight":n={direction:new j,skyColor:new Qe,groundColor:new Qe};break;case"RectAreaLight":n={color:new Qe,position:new j,halfWidth:new j,halfHeight:new j};break}return t[e.id]=n,n}}}function cA(){const t={};return{get:function(e){if(t[e.id]!==void 0)return t[e.id];let n;switch(e.type){case"DirectionalLight":n={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Ze};break;case"SpotLight":n={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Ze};break;case"PointLight":n={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Ze,shadowCameraNear:1,shadowCameraFar:1e3};break}return t[e.id]=n,n}}}let uA=0;function dA(t,e){return(e.castShadow?2:0)-(t.castShadow?2:0)+(e.map?1:0)-(t.map?1:0)}function fA(t){const e=new lA,n=cA(),i={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let c=0;c<9;c++)i.probe.push(new j);const r=new j,a=new Nt,s=new Nt;function o(c){let f=0,h=0,u=0;for(let C=0;C<9;C++)i.probe[C].set(0,0,0);let m=0,x=0,E=0,g=0,d=0,v=0,S=0,M=0,A=0,T=0,w=0;c.sort(dA);for(let C=0,P=c.length;C<P;C++){const N=c[C],F=N.color,q=N.intensity,ie=N.distance;let k=null;if(N.shadow&&N.shadow.map&&(N.shadow.map.texture.format===Yr?k=N.shadow.map.texture:k=N.shadow.map.depthTexture||N.shadow.map.texture),N.isAmbientLight)f+=F.r*q,h+=F.g*q,u+=F.b*q;else if(N.isLightProbe){for(let X=0;X<9;X++)i.probe[X].addScaledVector(N.sh.coefficients[X],q);w++}else if(N.isDirectionalLight){const X=e.get(N);if(X.color.copy(N.color).multiplyScalar(N.intensity),N.castShadow){const V=N.shadow,O=n.get(N);O.shadowIntensity=V.intensity,O.shadowBias=V.bias,O.shadowNormalBias=V.normalBias,O.shadowRadius=V.radius,O.shadowMapSize=V.mapSize,i.directionalShadow[m]=O,i.directionalShadowMap[m]=k,i.directionalShadowMatrix[m]=N.shadow.matrix,v++}i.directional[m]=X,m++}else if(N.isSpotLight){const X=e.get(N);X.position.setFromMatrixPosition(N.matrixWorld),X.color.copy(F).multiplyScalar(q),X.distance=ie,X.coneCos=Math.cos(N.angle),X.penumbraCos=Math.cos(N.angle*(1-N.penumbra)),X.decay=N.decay,i.spot[E]=X;const V=N.shadow;if(N.map&&(i.spotLightMap[A]=N.map,A++,V.updateMatrices(N),N.castShadow&&T++),i.spotLightMatrix[E]=V.matrix,N.castShadow){const O=n.get(N);O.shadowIntensity=V.intensity,O.shadowBias=V.bias,O.shadowNormalBias=V.normalBias,O.shadowRadius=V.radius,O.shadowMapSize=V.mapSize,i.spotShadow[E]=O,i.spotShadowMap[E]=k,M++}E++}else if(N.isRectAreaLight){const X=e.get(N);X.color.copy(F).multiplyScalar(q),X.halfWidth.set(N.width*.5,0,0),X.halfHeight.set(0,N.height*.5,0),i.rectArea[g]=X,g++}else if(N.isPointLight){const X=e.get(N);if(X.color.copy(N.color).multiplyScalar(N.intensity),X.distance=N.distance,X.decay=N.decay,N.castShadow){const V=N.shadow,O=n.get(N);O.shadowIntensity=V.intensity,O.shadowBias=V.bias,O.shadowNormalBias=V.normalBias,O.shadowRadius=V.radius,O.shadowMapSize=V.mapSize,O.shadowCameraNear=V.camera.near,O.shadowCameraFar=V.camera.far,i.pointShadow[x]=O,i.pointShadowMap[x]=k,i.pointShadowMatrix[x]=N.shadow.matrix,S++}i.point[x]=X,x++}else if(N.isHemisphereLight){const X=e.get(N);X.skyColor.copy(N.color).multiplyScalar(q),X.groundColor.copy(N.groundColor).multiplyScalar(q),i.hemi[d]=X,d++}}g>0&&(t.has("OES_texture_float_linear")===!0?(i.rectAreaLTC1=ge.LTC_FLOAT_1,i.rectAreaLTC2=ge.LTC_FLOAT_2):(i.rectAreaLTC1=ge.LTC_HALF_1,i.rectAreaLTC2=ge.LTC_HALF_2)),i.ambient[0]=f,i.ambient[1]=h,i.ambient[2]=u;const _=i.hash;(_.directionalLength!==m||_.pointLength!==x||_.spotLength!==E||_.rectAreaLength!==g||_.hemiLength!==d||_.numDirectionalShadows!==v||_.numPointShadows!==S||_.numSpotShadows!==M||_.numSpotMaps!==A||_.numLightProbes!==w)&&(i.directional.length=m,i.spot.length=E,i.rectArea.length=g,i.point.length=x,i.hemi.length=d,i.directionalShadow.length=v,i.directionalShadowMap.length=v,i.pointShadow.length=S,i.pointShadowMap.length=S,i.spotShadow.length=M,i.spotShadowMap.length=M,i.directionalShadowMatrix.length=v,i.pointShadowMatrix.length=S,i.spotLightMatrix.length=M+A-T,i.spotLightMap.length=A,i.numSpotLightShadowsWithMaps=T,i.numLightProbes=w,_.directionalLength=m,_.pointLength=x,_.spotLength=E,_.rectAreaLength=g,_.hemiLength=d,_.numDirectionalShadows=v,_.numPointShadows=S,_.numSpotShadows=M,_.numSpotMaps=A,_.numLightProbes=w,i.version=uA++)}function l(c,f){let h=0,u=0,m=0,x=0,E=0;const g=f.matrixWorldInverse;for(let d=0,v=c.length;d<v;d++){const S=c[d];if(S.isDirectionalLight){const M=i.directional[h];M.direction.setFromMatrixPosition(S.matrixWorld),r.setFromMatrixPosition(S.target.matrixWorld),M.direction.sub(r),M.direction.transformDirection(g),h++}else if(S.isSpotLight){const M=i.spot[m];M.position.setFromMatrixPosition(S.matrixWorld),M.position.applyMatrix4(g),M.direction.setFromMatrixPosition(S.matrixWorld),r.setFromMatrixPosition(S.target.matrixWorld),M.direction.sub(r),M.direction.transformDirection(g),m++}else if(S.isRectAreaLight){const M=i.rectArea[x];M.position.setFromMatrixPosition(S.matrixWorld),M.position.applyMatrix4(g),s.identity(),a.copy(S.matrixWorld),a.premultiply(g),s.extractRotation(a),M.halfWidth.set(S.width*.5,0,0),M.halfHeight.set(0,S.height*.5,0),M.halfWidth.applyMatrix4(s),M.halfHeight.applyMatrix4(s),x++}else if(S.isPointLight){const M=i.point[u];M.position.setFromMatrixPosition(S.matrixWorld),M.position.applyMatrix4(g),u++}else if(S.isHemisphereLight){const M=i.hemi[E];M.direction.setFromMatrixPosition(S.matrixWorld),M.direction.transformDirection(g),E++}}}return{setup:o,setupView:l,state:i}}function dg(t){const e=new fA(t),n=[],i=[],r=[];function a(u){h.camera=u,n.length=0,i.length=0,r.length=0}function s(u){n.push(u)}function o(u){i.push(u)}function l(u){r.push(u)}function c(){e.setup(n)}function f(u){e.setupView(n,u)}const h={lightsArray:n,shadowsArray:i,lightProbeGridArray:r,camera:null,lights:e,transmissionRenderTarget:{},textureUnits:0};return{init:a,state:h,setupLights:c,setupLightsView:f,pushLight:s,pushShadow:o,pushLightProbeGrid:l}}function hA(t){let e=new WeakMap;function n(r,a=0){const s=e.get(r);let o;return s===void 0?(o=new dg(t),e.set(r,[o])):a>=s.length?(o=new dg(t),s.push(o)):o=s[a],o}function i(){e=new WeakMap}return{get:n,dispose:i}}const pA=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,mA=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ).rg;
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ).r;
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( max( 0.0, squared_mean - mean * mean ) );
	gl_FragColor = vec4( mean, std_dev, 0.0, 1.0 );
}`,gA=[new j(1,0,0),new j(-1,0,0),new j(0,1,0),new j(0,-1,0),new j(0,0,1),new j(0,0,-1)],_A=[new j(0,-1,0),new j(0,-1,0),new j(0,0,1),new j(0,0,-1),new j(0,-1,0),new j(0,-1,0)],fg=new Nt,_s=new j,Uu=new j;function xA(t,e,n){let i=new Rx;const r=new Ze,a=new Ze,s=new Mt,o=new LE,l=new DE,c={},f=n.maxTextureSize,h={[yr]:mn,[mn]:yr,[Ai]:Ai},u=new Qn({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new Ze},radius:{value:4}},vertexShader:pA,fragmentShader:mA}),m=u.clone();m.defines.HORIZONTAL_PASS=1;const x=new Wi;x.setAttribute("position",new mi(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const E=new _i(x,u),g=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=gl;let d=this.type;this.render=function(T,w,_){if(g.enabled===!1||g.autoUpdate===!1&&g.needsUpdate===!1||T.length===0)return;this.type===SM&&(De("WebGLShadowMap: PCFSoftShadowMap has been deprecated. Using PCFShadowMap instead."),this.type=gl);const C=t.getRenderTarget(),P=t.getActiveCubeFace(),N=t.getActiveMipmapLevel(),F=t.state;F.setBlending(Li),F.buffers.depth.getReversed()===!0?F.buffers.color.setClear(0,0,0,0):F.buffers.color.setClear(1,1,1,1),F.buffers.depth.setTest(!0),F.setScissorTest(!1);const q=d!==this.type;q&&w.traverse(function(ie){ie.material&&(Array.isArray(ie.material)?ie.material.forEach(k=>k.needsUpdate=!0):ie.material.needsUpdate=!0)});for(let ie=0,k=T.length;ie<k;ie++){const X=T[ie],V=X.shadow;if(V===void 0){De("WebGLShadowMap:",X,"has no shadow.");continue}if(V.autoUpdate===!1&&V.needsUpdate===!1)continue;r.copy(V.mapSize);const O=V.getFrameExtents();r.multiply(O),a.copy(V.mapSize),(r.x>f||r.y>f)&&(r.x>f&&(a.x=Math.floor(f/O.x),r.x=a.x*O.x,V.mapSize.x=a.x),r.y>f&&(a.y=Math.floor(f/O.y),r.y=a.y*O.y,V.mapSize.y=a.y));const I=t.state.buffers.depth.getReversed();if(V.camera._reversedDepth=I,V.map===null||q===!0){if(V.map!==null&&(V.map.depthTexture!==null&&(V.map.depthTexture.dispose(),V.map.depthTexture=null),V.map.dispose()),this.type===Ms){if(X.isPointLight){De("WebGLShadowMap: VSM shadow maps are not supported for PointLights. Use PCF or BasicShadowMap instead.");continue}V.map=new pi(r.x,r.y,{format:Yr,type:zi,minFilter:Jt,magFilter:Jt,generateMipmaps:!1}),V.map.texture.name=X.name+".shadowMap",V.map.depthTexture=new qa(r.x,r.y,ci),V.map.depthTexture.name=X.name+".shadowMapDepth",V.map.depthTexture.format=Vi,V.map.depthTexture.compareFunction=null,V.map.depthTexture.minFilter=Gt,V.map.depthTexture.magFilter=Gt}else X.isPointLight?(V.map=new Fx(r.x),V.map.depthTexture=new TE(r.x,gi)):(V.map=new pi(r.x,r.y),V.map.depthTexture=new qa(r.x,r.y,gi)),V.map.depthTexture.name=X.name+".shadowMap",V.map.depthTexture.format=Vi,this.type===gl?(V.map.depthTexture.compareFunction=I?Lh:Nh,V.map.depthTexture.minFilter=Jt,V.map.depthTexture.magFilter=Jt):(V.map.depthTexture.compareFunction=null,V.map.depthTexture.minFilter=Gt,V.map.depthTexture.magFilter=Gt);V.camera.updateProjectionMatrix()}const J=V.map.isWebGLCubeRenderTarget?6:1;for(let ae=0;ae<J;ae++){if(V.map.isWebGLCubeRenderTarget)t.setRenderTarget(V.map,ae),t.clear();else{ae===0&&(t.setRenderTarget(V.map),t.clear());const le=V.getViewport(ae);s.set(a.x*le.x,a.y*le.y,a.x*le.z,a.y*le.w),F.viewport(s)}if(X.isPointLight){const le=V.camera,Be=V.matrix,Xe=X.distance||le.far;Xe!==le.far&&(le.far=Xe,le.updateProjectionMatrix()),_s.setFromMatrixPosition(X.matrixWorld),le.position.copy(_s),Uu.copy(le.position),Uu.add(gA[ae]),le.up.copy(_A[ae]),le.lookAt(Uu),le.updateMatrixWorld(),Be.makeTranslation(-_s.x,-_s.y,-_s.z),fg.multiplyMatrices(le.projectionMatrix,le.matrixWorldInverse),V._frustum.setFromProjectionMatrix(fg,le.coordinateSystem,le.reversedDepth)}else V.updateMatrices(X);i=V.getFrustum(),M(w,_,V.camera,X,this.type)}V.isPointLightShadow!==!0&&this.type===Ms&&v(V,_),V.needsUpdate=!1}d=this.type,g.needsUpdate=!1,t.setRenderTarget(C,P,N)};function v(T,w){const _=e.update(E);u.defines.VSM_SAMPLES!==T.blurSamples&&(u.defines.VSM_SAMPLES=T.blurSamples,m.defines.VSM_SAMPLES=T.blurSamples,u.needsUpdate=!0,m.needsUpdate=!0),T.mapPass===null&&(T.mapPass=new pi(r.x,r.y,{format:Yr,type:zi})),u.uniforms.shadow_pass.value=T.map.depthTexture,u.uniforms.resolution.value=T.mapSize,u.uniforms.radius.value=T.radius,t.setRenderTarget(T.mapPass),t.clear(),t.renderBufferDirect(w,null,_,u,E,null),m.uniforms.shadow_pass.value=T.mapPass.texture,m.uniforms.resolution.value=T.mapSize,m.uniforms.radius.value=T.radius,t.setRenderTarget(T.map),t.clear(),t.renderBufferDirect(w,null,_,m,E,null)}function S(T,w,_,C){let P=null;const N=_.isPointLight===!0?T.customDistanceMaterial:T.customDepthMaterial;if(N!==void 0)P=N;else if(P=_.isPointLight===!0?l:o,t.localClippingEnabled&&w.clipShadows===!0&&Array.isArray(w.clippingPlanes)&&w.clippingPlanes.length!==0||w.displacementMap&&w.displacementScale!==0||w.alphaMap&&w.alphaTest>0||w.map&&w.alphaTest>0||w.alphaToCoverage===!0){const F=P.uuid,q=w.uuid;let ie=c[F];ie===void 0&&(ie={},c[F]=ie);let k=ie[q];k===void 0&&(k=P.clone(),ie[q]=k,w.addEventListener("dispose",A)),P=k}if(P.visible=w.visible,P.wireframe=w.wireframe,C===Ms?P.side=w.shadowSide!==null?w.shadowSide:w.side:P.side=w.shadowSide!==null?w.shadowSide:h[w.side],P.alphaMap=w.alphaMap,P.alphaTest=w.alphaToCoverage===!0?.5:w.alphaTest,P.map=w.map,P.clipShadows=w.clipShadows,P.clippingPlanes=w.clippingPlanes,P.clipIntersection=w.clipIntersection,P.displacementMap=w.displacementMap,P.displacementScale=w.displacementScale,P.displacementBias=w.displacementBias,P.wireframeLinewidth=w.wireframeLinewidth,P.linewidth=w.linewidth,_.isPointLight===!0&&P.isMeshDistanceMaterial===!0){const F=t.properties.get(P);F.light=_}return P}function M(T,w,_,C,P){if(T.visible===!1)return;if(T.layers.test(w.layers)&&(T.isMesh||T.isLine||T.isPoints)&&(T.castShadow||T.receiveShadow&&P===Ms)&&(!T.frustumCulled||i.intersectsObject(T))){T.modelViewMatrix.multiplyMatrices(_.matrixWorldInverse,T.matrixWorld);const q=e.update(T),ie=T.material;if(Array.isArray(ie)){const k=q.groups;for(let X=0,V=k.length;X<V;X++){const O=k[X],I=ie[O.materialIndex];if(I&&I.visible){const J=S(T,I,C,P);T.onBeforeShadow(t,T,w,_,q,J,O),t.renderBufferDirect(_,null,q,J,T,O),T.onAfterShadow(t,T,w,_,q,J,O)}}}else if(ie.visible){const k=S(T,ie,C,P);T.onBeforeShadow(t,T,w,_,q,k,null),t.renderBufferDirect(_,null,q,k,T,null),T.onAfterShadow(t,T,w,_,q,k,null)}}const F=T.children;for(let q=0,ie=F.length;q<ie;q++)M(F[q],w,_,C,P)}function A(T){T.target.removeEventListener("dispose",A);for(const _ in c){const C=c[_],P=T.target.uuid;P in C&&(C[P].dispose(),delete C[P])}}}function vA(t,e){function n(){let L=!1;const ue=new Mt;let te=null;const pe=new Mt(0,0,0,0);return{setMask:function(ve){te!==ve&&!L&&(t.colorMask(ve,ve,ve,ve),te=ve)},setLocked:function(ve){L=ve},setClear:function(ve,re,we,Ee,vt){vt===!0&&(ve*=Ee,re*=Ee,we*=Ee),ue.set(ve,re,we,Ee),pe.equals(ue)===!1&&(t.clearColor(ve,re,we,Ee),pe.copy(ue))},reset:function(){L=!1,te=null,pe.set(-1,0,0,0)}}}function i(){let L=!1,ue=!1,te=null,pe=null,ve=null;return{setReversed:function(re){if(ue!==re){const we=e.get("EXT_clip_control");re?we.clipControlEXT(we.LOWER_LEFT_EXT,we.ZERO_TO_ONE_EXT):we.clipControlEXT(we.LOWER_LEFT_EXT,we.NEGATIVE_ONE_TO_ONE_EXT),ue=re;const Ee=ve;ve=null,this.setClear(Ee)}},getReversed:function(){return ue},setTest:function(re){re?ee(t.DEPTH_TEST):Pe(t.DEPTH_TEST)},setMask:function(re){te!==re&&!L&&(t.depthMask(re),te=re)},setFunc:function(re){if(ue&&(re=eE[re]),pe!==re){switch(re){case Ld:t.depthFunc(t.NEVER);break;case Dd:t.depthFunc(t.ALWAYS);break;case Id:t.depthFunc(t.LESS);break;case Xa:t.depthFunc(t.LEQUAL);break;case Ud:t.depthFunc(t.EQUAL);break;case Fd:t.depthFunc(t.GEQUAL);break;case Od:t.depthFunc(t.GREATER);break;case kd:t.depthFunc(t.NOTEQUAL);break;default:t.depthFunc(t.LEQUAL)}pe=re}},setLocked:function(re){L=re},setClear:function(re){ve!==re&&(ve=re,ue&&(re=1-re),t.clearDepth(re))},reset:function(){L=!1,te=null,pe=null,ve=null,ue=!1}}}function r(){let L=!1,ue=null,te=null,pe=null,ve=null,re=null,we=null,Ee=null,vt=null;return{setTest:function(ot){L||(ot?ee(t.STENCIL_TEST):Pe(t.STENCIL_TEST))},setMask:function(ot){ue!==ot&&!L&&(t.stencilMask(ot),ue=ot)},setFunc:function(ot,Jn,ei){(te!==ot||pe!==Jn||ve!==ei)&&(t.stencilFunc(ot,Jn,ei),te=ot,pe=Jn,ve=ei)},setOp:function(ot,Jn,ei){(re!==ot||we!==Jn||Ee!==ei)&&(t.stencilOp(ot,Jn,ei),re=ot,we=Jn,Ee=ei)},setLocked:function(ot){L=ot},setClear:function(ot){vt!==ot&&(t.clearStencil(ot),vt=ot)},reset:function(){L=!1,ue=null,te=null,pe=null,ve=null,re=null,we=null,Ee=null,vt=null}}}const a=new n,s=new i,o=new r,l=new WeakMap,c=new WeakMap;let f={},h={},u={},m=new WeakMap,x=[],E=null,g=!1,d=null,v=null,S=null,M=null,A=null,T=null,w=null,_=new Qe(0,0,0),C=0,P=!1,N=null,F=null,q=null,ie=null,k=null;const X=t.getParameter(t.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let V=!1,O=0;const I=t.getParameter(t.VERSION);I.indexOf("WebGL")!==-1?(O=parseFloat(/^WebGL (\d)/.exec(I)[1]),V=O>=1):I.indexOf("OpenGL ES")!==-1&&(O=parseFloat(/^OpenGL ES (\d)/.exec(I)[1]),V=O>=2);let J=null,ae={};const le=t.getParameter(t.SCISSOR_BOX),Be=t.getParameter(t.VIEWPORT),Xe=new Mt().fromArray(le),ze=new Mt().fromArray(Be);function Q(L,ue,te,pe){const ve=new Uint8Array(4),re=t.createTexture();t.bindTexture(L,re),t.texParameteri(L,t.TEXTURE_MIN_FILTER,t.NEAREST),t.texParameteri(L,t.TEXTURE_MAG_FILTER,t.NEAREST);for(let we=0;we<te;we++)L===t.TEXTURE_3D||L===t.TEXTURE_2D_ARRAY?t.texImage3D(ue,0,t.RGBA,1,1,pe,0,t.RGBA,t.UNSIGNED_BYTE,ve):t.texImage2D(ue+we,0,t.RGBA,1,1,0,t.RGBA,t.UNSIGNED_BYTE,ve);return re}const oe={};oe[t.TEXTURE_2D]=Q(t.TEXTURE_2D,t.TEXTURE_2D,1),oe[t.TEXTURE_CUBE_MAP]=Q(t.TEXTURE_CUBE_MAP,t.TEXTURE_CUBE_MAP_POSITIVE_X,6),oe[t.TEXTURE_2D_ARRAY]=Q(t.TEXTURE_2D_ARRAY,t.TEXTURE_2D_ARRAY,1,1),oe[t.TEXTURE_3D]=Q(t.TEXTURE_3D,t.TEXTURE_3D,1,1),a.setClear(0,0,0,1),s.setClear(1),o.setClear(0),ee(t.DEPTH_TEST),s.setFunc(Xa),At(!1),Lt(mm),ee(t.CULL_FACE),Je(Li);function ee(L){f[L]!==!0&&(t.enable(L),f[L]=!0)}function Pe(L){f[L]!==!1&&(t.disable(L),f[L]=!1)}function Ue(L,ue){return u[L]!==ue?(t.bindFramebuffer(L,ue),u[L]=ue,L===t.DRAW_FRAMEBUFFER&&(u[t.FRAMEBUFFER]=ue),L===t.FRAMEBUFFER&&(u[t.DRAW_FRAMEBUFFER]=ue),!0):!1}function Ne(L,ue){let te=x,pe=!1;if(L){te=m.get(ue),te===void 0&&(te=[],m.set(ue,te));const ve=L.textures;if(te.length!==ve.length||te[0]!==t.COLOR_ATTACHMENT0){for(let re=0,we=ve.length;re<we;re++)te[re]=t.COLOR_ATTACHMENT0+re;te.length=ve.length,pe=!0}}else te[0]!==t.BACK&&(te[0]=t.BACK,pe=!0);pe&&t.drawBuffers(te)}function Et(L){return E!==L?(t.useProgram(L),E=L,!0):!1}const Ge={[Ir]:t.FUNC_ADD,[EM]:t.FUNC_SUBTRACT,[bM]:t.FUNC_REVERSE_SUBTRACT};Ge[wM]=t.MIN,Ge[TM]=t.MAX;const rt={[AM]:t.ZERO,[CM]:t.ONE,[RM]:t.SRC_COLOR,[Pd]:t.SRC_ALPHA,[UM]:t.SRC_ALPHA_SATURATE,[DM]:t.DST_COLOR,[NM]:t.DST_ALPHA,[PM]:t.ONE_MINUS_SRC_COLOR,[Nd]:t.ONE_MINUS_SRC_ALPHA,[IM]:t.ONE_MINUS_DST_COLOR,[LM]:t.ONE_MINUS_DST_ALPHA,[FM]:t.CONSTANT_COLOR,[OM]:t.ONE_MINUS_CONSTANT_COLOR,[kM]:t.CONSTANT_ALPHA,[BM]:t.ONE_MINUS_CONSTANT_ALPHA};function Je(L,ue,te,pe,ve,re,we,Ee,vt,ot){if(L===Li){g===!0&&(Pe(t.BLEND),g=!1);return}if(g===!1&&(ee(t.BLEND),g=!0),L!==MM){if(L!==d||ot!==P){if((v!==Ir||A!==Ir)&&(t.blendEquation(t.FUNC_ADD),v=Ir,A=Ir),ot)switch(L){case Fa:t.blendFuncSeparate(t.ONE,t.ONE_MINUS_SRC_ALPHA,t.ONE,t.ONE_MINUS_SRC_ALPHA);break;case gm:t.blendFunc(t.ONE,t.ONE);break;case _m:t.blendFuncSeparate(t.ZERO,t.ONE_MINUS_SRC_COLOR,t.ZERO,t.ONE);break;case xm:t.blendFuncSeparate(t.DST_COLOR,t.ONE_MINUS_SRC_ALPHA,t.ZERO,t.ONE);break;default:Ye("WebGLState: Invalid blending: ",L);break}else switch(L){case Fa:t.blendFuncSeparate(t.SRC_ALPHA,t.ONE_MINUS_SRC_ALPHA,t.ONE,t.ONE_MINUS_SRC_ALPHA);break;case gm:t.blendFuncSeparate(t.SRC_ALPHA,t.ONE,t.ONE,t.ONE);break;case _m:Ye("WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case xm:Ye("WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:Ye("WebGLState: Invalid blending: ",L);break}S=null,M=null,T=null,w=null,_.set(0,0,0),C=0,d=L,P=ot}return}ve=ve||ue,re=re||te,we=we||pe,(ue!==v||ve!==A)&&(t.blendEquationSeparate(Ge[ue],Ge[ve]),v=ue,A=ve),(te!==S||pe!==M||re!==T||we!==w)&&(t.blendFuncSeparate(rt[te],rt[pe],rt[re],rt[we]),S=te,M=pe,T=re,w=we),(Ee.equals(_)===!1||vt!==C)&&(t.blendColor(Ee.r,Ee.g,Ee.b,vt),_.copy(Ee),C=vt),d=L,P=!1}function $e(L,ue){L.side===Ai?Pe(t.CULL_FACE):ee(t.CULL_FACE);let te=L.side===mn;ue&&(te=!te),At(te),L.blending===Fa&&L.transparent===!1?Je(Li):Je(L.blending,L.blendEquation,L.blendSrc,L.blendDst,L.blendEquationAlpha,L.blendSrcAlpha,L.blendDstAlpha,L.blendColor,L.blendAlpha,L.premultipliedAlpha),s.setFunc(L.depthFunc),s.setTest(L.depthTest),s.setMask(L.depthWrite),a.setMask(L.colorWrite);const pe=L.stencilWrite;o.setTest(pe),pe&&(o.setMask(L.stencilWriteMask),o.setFunc(L.stencilFunc,L.stencilRef,L.stencilFuncMask),o.setOp(L.stencilFail,L.stencilZFail,L.stencilZPass)),Vt(L.polygonOffset,L.polygonOffsetFactor,L.polygonOffsetUnits),L.alphaToCoverage===!0?ee(t.SAMPLE_ALPHA_TO_COVERAGE):Pe(t.SAMPLE_ALPHA_TO_COVERAGE)}function At(L){N!==L&&(L?t.frontFace(t.CW):t.frontFace(t.CCW),N=L)}function Lt(L){L!==vM?(ee(t.CULL_FACE),L!==F&&(L===mm?t.cullFace(t.BACK):L===yM?t.cullFace(t.FRONT):t.cullFace(t.FRONT_AND_BACK))):Pe(t.CULL_FACE),F=L}function Ot(L){L!==q&&(V&&t.lineWidth(L),q=L)}function Vt(L,ue,te){L?(ee(t.POLYGON_OFFSET_FILL),(ie!==ue||k!==te)&&(ie=ue,k=te,s.getReversed()&&(ue=-ue),t.polygonOffset(ue,te))):Pe(t.POLYGON_OFFSET_FILL)}function xt(L){L?ee(t.SCISSOR_TEST):Pe(t.SCISSOR_TEST)}function Ct(L){L===void 0&&(L=t.TEXTURE0+X-1),J!==L&&(t.activeTexture(L),J=L)}function D(L,ue,te){te===void 0&&(J===null?te=t.TEXTURE0+X-1:te=J);let pe=ae[te];pe===void 0&&(pe={type:void 0,texture:void 0},ae[te]=pe),(pe.type!==L||pe.texture!==ue)&&(J!==te&&(t.activeTexture(te),J=te),t.bindTexture(L,ue||oe[L]),pe.type=L,pe.texture=ue)}function ln(){const L=ae[J];L!==void 0&&L.type!==void 0&&(t.bindTexture(L.type,null),L.type=void 0,L.texture=void 0)}function et(){try{t.compressedTexImage2D(...arguments)}catch(L){Ye("WebGLState:",L)}}function R(){try{t.compressedTexImage3D(...arguments)}catch(L){Ye("WebGLState:",L)}}function y(){try{t.texSubImage2D(...arguments)}catch(L){Ye("WebGLState:",L)}}function B(){try{t.texSubImage3D(...arguments)}catch(L){Ye("WebGLState:",L)}}function W(){try{t.compressedTexSubImage2D(...arguments)}catch(L){Ye("WebGLState:",L)}}function K(){try{t.compressedTexSubImage3D(...arguments)}catch(L){Ye("WebGLState:",L)}}function ce(){try{t.texStorage2D(...arguments)}catch(L){Ye("WebGLState:",L)}}function de(){try{t.texStorage3D(...arguments)}catch(L){Ye("WebGLState:",L)}}function Z(){try{t.texImage2D(...arguments)}catch(L){Ye("WebGLState:",L)}}function ne(){try{t.texImage3D(...arguments)}catch(L){Ye("WebGLState:",L)}}function fe(L){return h[L]!==void 0?h[L]:t.getParameter(L)}function Te(L,ue){h[L]!==ue&&(t.pixelStorei(L,ue),h[L]=ue)}function me(L){Xe.equals(L)===!1&&(t.scissor(L.x,L.y,L.z,L.w),Xe.copy(L))}function he(L){ze.equals(L)===!1&&(t.viewport(L.x,L.y,L.z,L.w),ze.copy(L))}function Re(L,ue){let te=c.get(ue);te===void 0&&(te=new WeakMap,c.set(ue,te));let pe=te.get(L);pe===void 0&&(pe=t.getUniformBlockIndex(ue,L.name),te.set(L,pe))}function Le(L,ue){const pe=c.get(ue).get(L);l.get(ue)!==pe&&(t.uniformBlockBinding(ue,pe,L.__bindingPointIndex),l.set(ue,pe))}function Fe(){t.disable(t.BLEND),t.disable(t.CULL_FACE),t.disable(t.DEPTH_TEST),t.disable(t.POLYGON_OFFSET_FILL),t.disable(t.SCISSOR_TEST),t.disable(t.STENCIL_TEST),t.disable(t.SAMPLE_ALPHA_TO_COVERAGE),t.blendEquation(t.FUNC_ADD),t.blendFunc(t.ONE,t.ZERO),t.blendFuncSeparate(t.ONE,t.ZERO,t.ONE,t.ZERO),t.blendColor(0,0,0,0),t.colorMask(!0,!0,!0,!0),t.clearColor(0,0,0,0),t.depthMask(!0),t.depthFunc(t.LESS),s.setReversed(!1),t.clearDepth(1),t.stencilMask(4294967295),t.stencilFunc(t.ALWAYS,0,4294967295),t.stencilOp(t.KEEP,t.KEEP,t.KEEP),t.clearStencil(0),t.cullFace(t.BACK),t.frontFace(t.CCW),t.polygonOffset(0,0),t.activeTexture(t.TEXTURE0),t.bindFramebuffer(t.FRAMEBUFFER,null),t.bindFramebuffer(t.DRAW_FRAMEBUFFER,null),t.bindFramebuffer(t.READ_FRAMEBUFFER,null),t.useProgram(null),t.lineWidth(1),t.scissor(0,0,t.canvas.width,t.canvas.height),t.viewport(0,0,t.canvas.width,t.canvas.height),t.pixelStorei(t.PACK_ALIGNMENT,4),t.pixelStorei(t.UNPACK_ALIGNMENT,4),t.pixelStorei(t.UNPACK_FLIP_Y_WEBGL,!1),t.pixelStorei(t.UNPACK_PREMULTIPLY_ALPHA_WEBGL,!1),t.pixelStorei(t.UNPACK_COLORSPACE_CONVERSION_WEBGL,t.BROWSER_DEFAULT_WEBGL),t.pixelStorei(t.PACK_ROW_LENGTH,0),t.pixelStorei(t.PACK_SKIP_PIXELS,0),t.pixelStorei(t.PACK_SKIP_ROWS,0),t.pixelStorei(t.UNPACK_ROW_LENGTH,0),t.pixelStorei(t.UNPACK_IMAGE_HEIGHT,0),t.pixelStorei(t.UNPACK_SKIP_PIXELS,0),t.pixelStorei(t.UNPACK_SKIP_ROWS,0),t.pixelStorei(t.UNPACK_SKIP_IMAGES,0),f={},h={},J=null,ae={},u={},m=new WeakMap,x=[],E=null,g=!1,d=null,v=null,S=null,M=null,A=null,T=null,w=null,_=new Qe(0,0,0),C=0,P=!1,N=null,F=null,q=null,ie=null,k=null,Xe.set(0,0,t.canvas.width,t.canvas.height),ze.set(0,0,t.canvas.width,t.canvas.height),a.reset(),s.reset(),o.reset()}return{buffers:{color:a,depth:s,stencil:o},enable:ee,disable:Pe,bindFramebuffer:Ue,drawBuffers:Ne,useProgram:Et,setBlending:Je,setMaterial:$e,setFlipSided:At,setCullFace:Lt,setLineWidth:Ot,setPolygonOffset:Vt,setScissorTest:xt,activeTexture:Ct,bindTexture:D,unbindTexture:ln,compressedTexImage2D:et,compressedTexImage3D:R,texImage2D:Z,texImage3D:ne,pixelStorei:Te,getParameter:fe,updateUBOMapping:Re,uniformBlockBinding:Le,texStorage2D:ce,texStorage3D:de,texSubImage2D:y,texSubImage3D:B,compressedTexSubImage2D:W,compressedTexSubImage3D:K,scissor:me,viewport:he,reset:Fe}}function yA(t,e,n,i,r,a,s){const o=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,l=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),c=new Ze,f=new WeakMap,h=new Set;let u;const m=new WeakMap;let x=!1;try{x=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function E(R,y){return x?new OffscreenCanvas(R,y):ec("canvas")}function g(R,y,B){let W=1;const K=et(R);if((K.width>B||K.height>B)&&(W=B/Math.max(K.width,K.height)),W<1)if(typeof HTMLImageElement<"u"&&R instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&R instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&R instanceof ImageBitmap||typeof VideoFrame<"u"&&R instanceof VideoFrame){const ce=Math.floor(W*K.width),de=Math.floor(W*K.height);u===void 0&&(u=E(ce,de));const Z=y?E(ce,de):u;return Z.width=ce,Z.height=de,Z.getContext("2d").drawImage(R,0,0,ce,de),De("WebGLRenderer: Texture has been resized from ("+K.width+"x"+K.height+") to ("+ce+"x"+de+")."),Z}else return"data"in R&&De("WebGLRenderer: Image in DataTexture is too big ("+K.width+"x"+K.height+")."),R;return R}function d(R){return R.generateMipmaps}function v(R){t.generateMipmap(R)}function S(R){return R.isWebGLCubeRenderTarget?t.TEXTURE_CUBE_MAP:R.isWebGL3DRenderTarget?t.TEXTURE_3D:R.isWebGLArrayRenderTarget||R.isCompressedArrayTexture?t.TEXTURE_2D_ARRAY:t.TEXTURE_2D}function M(R,y,B,W,K,ce=!1){if(R!==null){if(t[R]!==void 0)return t[R];De("WebGLRenderer: Attempt to use non-existing WebGL internal format '"+R+"'")}let de;W&&(de=e.get("EXT_texture_norm16"),de||De("WebGLRenderer: Unable to use normalized textures without EXT_texture_norm16 extension"));let Z=y;if(y===t.RED&&(B===t.FLOAT&&(Z=t.R32F),B===t.HALF_FLOAT&&(Z=t.R16F),B===t.UNSIGNED_BYTE&&(Z=t.R8),B===t.UNSIGNED_SHORT&&de&&(Z=de.R16_EXT),B===t.SHORT&&de&&(Z=de.R16_SNORM_EXT)),y===t.RED_INTEGER&&(B===t.UNSIGNED_BYTE&&(Z=t.R8UI),B===t.UNSIGNED_SHORT&&(Z=t.R16UI),B===t.UNSIGNED_INT&&(Z=t.R32UI),B===t.BYTE&&(Z=t.R8I),B===t.SHORT&&(Z=t.R16I),B===t.INT&&(Z=t.R32I)),y===t.RG&&(B===t.FLOAT&&(Z=t.RG32F),B===t.HALF_FLOAT&&(Z=t.RG16F),B===t.UNSIGNED_BYTE&&(Z=t.RG8),B===t.UNSIGNED_SHORT&&de&&(Z=de.RG16_EXT),B===t.SHORT&&de&&(Z=de.RG16_SNORM_EXT)),y===t.RG_INTEGER&&(B===t.UNSIGNED_BYTE&&(Z=t.RG8UI),B===t.UNSIGNED_SHORT&&(Z=t.RG16UI),B===t.UNSIGNED_INT&&(Z=t.RG32UI),B===t.BYTE&&(Z=t.RG8I),B===t.SHORT&&(Z=t.RG16I),B===t.INT&&(Z=t.RG32I)),y===t.RGB_INTEGER&&(B===t.UNSIGNED_BYTE&&(Z=t.RGB8UI),B===t.UNSIGNED_SHORT&&(Z=t.RGB16UI),B===t.UNSIGNED_INT&&(Z=t.RGB32UI),B===t.BYTE&&(Z=t.RGB8I),B===t.SHORT&&(Z=t.RGB16I),B===t.INT&&(Z=t.RGB32I)),y===t.RGBA_INTEGER&&(B===t.UNSIGNED_BYTE&&(Z=t.RGBA8UI),B===t.UNSIGNED_SHORT&&(Z=t.RGBA16UI),B===t.UNSIGNED_INT&&(Z=t.RGBA32UI),B===t.BYTE&&(Z=t.RGBA8I),B===t.SHORT&&(Z=t.RGBA16I),B===t.INT&&(Z=t.RGBA32I)),y===t.RGB&&(B===t.UNSIGNED_SHORT&&de&&(Z=de.RGB16_EXT),B===t.SHORT&&de&&(Z=de.RGB16_SNORM_EXT),B===t.UNSIGNED_INT_5_9_9_9_REV&&(Z=t.RGB9_E5),B===t.UNSIGNED_INT_10F_11F_11F_REV&&(Z=t.R11F_G11F_B10F)),y===t.RGBA){const ne=ce?Ql:We.getTransfer(K);B===t.FLOAT&&(Z=t.RGBA32F),B===t.HALF_FLOAT&&(Z=t.RGBA16F),B===t.UNSIGNED_BYTE&&(Z=ne===tt?t.SRGB8_ALPHA8:t.RGBA8),B===t.UNSIGNED_SHORT&&de&&(Z=de.RGBA16_EXT),B===t.SHORT&&de&&(Z=de.RGBA16_SNORM_EXT),B===t.UNSIGNED_SHORT_4_4_4_4&&(Z=t.RGBA4),B===t.UNSIGNED_SHORT_5_5_5_1&&(Z=t.RGB5_A1)}return(Z===t.R16F||Z===t.R32F||Z===t.RG16F||Z===t.RG32F||Z===t.RGBA16F||Z===t.RGBA32F)&&e.get("EXT_color_buffer_float"),Z}function A(R,y){let B;return R?y===null||y===gi||y===Qs?B=t.DEPTH24_STENCIL8:y===ci?B=t.DEPTH32F_STENCIL8:y===Zs&&(B=t.DEPTH24_STENCIL8,De("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):y===null||y===gi||y===Qs?B=t.DEPTH_COMPONENT24:y===ci?B=t.DEPTH_COMPONENT32F:y===Zs&&(B=t.DEPTH_COMPONENT16),B}function T(R,y){return d(R)===!0||R.isFramebufferTexture&&R.minFilter!==Gt&&R.minFilter!==Jt?Math.log2(Math.max(y.width,y.height))+1:R.mipmaps!==void 0&&R.mipmaps.length>0?R.mipmaps.length:R.isCompressedTexture&&Array.isArray(R.image)?y.mipmaps.length:1}function w(R){const y=R.target;y.removeEventListener("dispose",w),C(y),y.isVideoTexture&&f.delete(y),y.isHTMLTexture&&h.delete(y)}function _(R){const y=R.target;y.removeEventListener("dispose",_),N(y)}function C(R){const y=i.get(R);if(y.__webglInit===void 0)return;const B=R.source,W=m.get(B);if(W){const K=W[y.__cacheKey];K.usedTimes--,K.usedTimes===0&&P(R),Object.keys(W).length===0&&m.delete(B)}i.remove(R)}function P(R){const y=i.get(R);t.deleteTexture(y.__webglTexture);const B=R.source,W=m.get(B);delete W[y.__cacheKey],s.memory.textures--}function N(R){const y=i.get(R);if(R.depthTexture&&(R.depthTexture.dispose(),i.remove(R.depthTexture)),R.isWebGLCubeRenderTarget)for(let W=0;W<6;W++){if(Array.isArray(y.__webglFramebuffer[W]))for(let K=0;K<y.__webglFramebuffer[W].length;K++)t.deleteFramebuffer(y.__webglFramebuffer[W][K]);else t.deleteFramebuffer(y.__webglFramebuffer[W]);y.__webglDepthbuffer&&t.deleteRenderbuffer(y.__webglDepthbuffer[W])}else{if(Array.isArray(y.__webglFramebuffer))for(let W=0;W<y.__webglFramebuffer.length;W++)t.deleteFramebuffer(y.__webglFramebuffer[W]);else t.deleteFramebuffer(y.__webglFramebuffer);if(y.__webglDepthbuffer&&t.deleteRenderbuffer(y.__webglDepthbuffer),y.__webglMultisampledFramebuffer&&t.deleteFramebuffer(y.__webglMultisampledFramebuffer),y.__webglColorRenderbuffer)for(let W=0;W<y.__webglColorRenderbuffer.length;W++)y.__webglColorRenderbuffer[W]&&t.deleteRenderbuffer(y.__webglColorRenderbuffer[W]);y.__webglDepthRenderbuffer&&t.deleteRenderbuffer(y.__webglDepthRenderbuffer)}const B=R.textures;for(let W=0,K=B.length;W<K;W++){const ce=i.get(B[W]);ce.__webglTexture&&(t.deleteTexture(ce.__webglTexture),s.memory.textures--),i.remove(B[W])}i.remove(R)}let F=0;function q(){F=0}function ie(){return F}function k(R){F=R}function X(){const R=F;return R>=r.maxTextures&&De("WebGLTextures: Trying to use "+R+" texture units while this GPU supports only "+r.maxTextures),F+=1,R}function V(R){const y=[];return y.push(R.wrapS),y.push(R.wrapT),y.push(R.wrapR||0),y.push(R.magFilter),y.push(R.minFilter),y.push(R.anisotropy),y.push(R.internalFormat),y.push(R.format),y.push(R.type),y.push(R.generateMipmaps),y.push(R.premultiplyAlpha),y.push(R.flipY),y.push(R.unpackAlignment),y.push(R.colorSpace),y.join()}function O(R,y){const B=i.get(R);if(R.isVideoTexture&&D(R),R.isRenderTargetTexture===!1&&R.isExternalTexture!==!0&&R.version>0&&B.__version!==R.version){const W=R.image;if(W===null)De("WebGLRenderer: Texture marked for update but no image data found.");else if(W.complete===!1)De("WebGLRenderer: Texture marked for update but image is incomplete");else{Pe(B,R,y);return}}else R.isExternalTexture&&(B.__webglTexture=R.sourceTexture?R.sourceTexture:null);n.bindTexture(t.TEXTURE_2D,B.__webglTexture,t.TEXTURE0+y)}function I(R,y){const B=i.get(R);if(R.isRenderTargetTexture===!1&&R.version>0&&B.__version!==R.version){Pe(B,R,y);return}else R.isExternalTexture&&(B.__webglTexture=R.sourceTexture?R.sourceTexture:null);n.bindTexture(t.TEXTURE_2D_ARRAY,B.__webglTexture,t.TEXTURE0+y)}function J(R,y){const B=i.get(R);if(R.isRenderTargetTexture===!1&&R.version>0&&B.__version!==R.version){Pe(B,R,y);return}n.bindTexture(t.TEXTURE_3D,B.__webglTexture,t.TEXTURE0+y)}function ae(R,y){const B=i.get(R);if(R.isCubeDepthTexture!==!0&&R.version>0&&B.__version!==R.version){Ue(B,R,y);return}n.bindTexture(t.TEXTURE_CUBE_MAP,B.__webglTexture,t.TEXTURE0+y)}const le={[Bd]:t.REPEAT,[Pi]:t.CLAMP_TO_EDGE,[zd]:t.MIRRORED_REPEAT},Be={[Gt]:t.NEAREST,[HM]:t.NEAREST_MIPMAP_NEAREST,[Lo]:t.NEAREST_MIPMAP_LINEAR,[Jt]:t.LINEAR,[au]:t.LINEAR_MIPMAP_NEAREST,[Br]:t.LINEAR_MIPMAP_LINEAR},Xe={[jM]:t.NEVER,[KM]:t.ALWAYS,[XM]:t.LESS,[Nh]:t.LEQUAL,[$M]:t.EQUAL,[Lh]:t.GEQUAL,[qM]:t.GREATER,[YM]:t.NOTEQUAL};function ze(R,y){if(y.type===ci&&e.has("OES_texture_float_linear")===!1&&(y.magFilter===Jt||y.magFilter===au||y.magFilter===Lo||y.magFilter===Br||y.minFilter===Jt||y.minFilter===au||y.minFilter===Lo||y.minFilter===Br)&&De("WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),t.texParameteri(R,t.TEXTURE_WRAP_S,le[y.wrapS]),t.texParameteri(R,t.TEXTURE_WRAP_T,le[y.wrapT]),(R===t.TEXTURE_3D||R===t.TEXTURE_2D_ARRAY)&&t.texParameteri(R,t.TEXTURE_WRAP_R,le[y.wrapR]),t.texParameteri(R,t.TEXTURE_MAG_FILTER,Be[y.magFilter]),t.texParameteri(R,t.TEXTURE_MIN_FILTER,Be[y.minFilter]),y.compareFunction&&(t.texParameteri(R,t.TEXTURE_COMPARE_MODE,t.COMPARE_REF_TO_TEXTURE),t.texParameteri(R,t.TEXTURE_COMPARE_FUNC,Xe[y.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){if(y.magFilter===Gt||y.minFilter!==Lo&&y.minFilter!==Br||y.type===ci&&e.has("OES_texture_float_linear")===!1)return;if(y.anisotropy>1||i.get(y).__currentAnisotropy){const B=e.get("EXT_texture_filter_anisotropic");t.texParameterf(R,B.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(y.anisotropy,r.getMaxAnisotropy())),i.get(y).__currentAnisotropy=y.anisotropy}}}function Q(R,y){let B=!1;R.__webglInit===void 0&&(R.__webglInit=!0,y.addEventListener("dispose",w));const W=y.source;let K=m.get(W);K===void 0&&(K={},m.set(W,K));const ce=V(y);if(ce!==R.__cacheKey){K[ce]===void 0&&(K[ce]={texture:t.createTexture(),usedTimes:0},s.memory.textures++,B=!0),K[ce].usedTimes++;const de=K[R.__cacheKey];de!==void 0&&(K[R.__cacheKey].usedTimes--,de.usedTimes===0&&P(y)),R.__cacheKey=ce,R.__webglTexture=K[ce].texture}return B}function oe(R,y,B){return Math.floor(Math.floor(R/B)/y)}function ee(R,y,B,W){const ce=R.updateRanges;if(ce.length===0)n.texSubImage2D(t.TEXTURE_2D,0,0,0,y.width,y.height,B,W,y.data);else{ce.sort((Te,me)=>Te.start-me.start);let de=0;for(let Te=1;Te<ce.length;Te++){const me=ce[de],he=ce[Te],Re=me.start+me.count,Le=oe(he.start,y.width,4),Fe=oe(me.start,y.width,4);he.start<=Re+1&&Le===Fe&&oe(he.start+he.count-1,y.width,4)===Le?me.count=Math.max(me.count,he.start+he.count-me.start):(++de,ce[de]=he)}ce.length=de+1;const Z=n.getParameter(t.UNPACK_ROW_LENGTH),ne=n.getParameter(t.UNPACK_SKIP_PIXELS),fe=n.getParameter(t.UNPACK_SKIP_ROWS);n.pixelStorei(t.UNPACK_ROW_LENGTH,y.width);for(let Te=0,me=ce.length;Te<me;Te++){const he=ce[Te],Re=Math.floor(he.start/4),Le=Math.ceil(he.count/4),Fe=Re%y.width,L=Math.floor(Re/y.width),ue=Le,te=1;n.pixelStorei(t.UNPACK_SKIP_PIXELS,Fe),n.pixelStorei(t.UNPACK_SKIP_ROWS,L),n.texSubImage2D(t.TEXTURE_2D,0,Fe,L,ue,te,B,W,y.data)}R.clearUpdateRanges(),n.pixelStorei(t.UNPACK_ROW_LENGTH,Z),n.pixelStorei(t.UNPACK_SKIP_PIXELS,ne),n.pixelStorei(t.UNPACK_SKIP_ROWS,fe)}}function Pe(R,y,B){let W=t.TEXTURE_2D;(y.isDataArrayTexture||y.isCompressedArrayTexture)&&(W=t.TEXTURE_2D_ARRAY),y.isData3DTexture&&(W=t.TEXTURE_3D);const K=Q(R,y),ce=y.source;n.bindTexture(W,R.__webglTexture,t.TEXTURE0+B);const de=i.get(ce);if(ce.version!==de.__version||K===!0){if(n.activeTexture(t.TEXTURE0+B),(typeof ImageBitmap<"u"&&y.image instanceof ImageBitmap)===!1){const te=We.getPrimaries(We.workingColorSpace),pe=y.colorSpace===sr?null:We.getPrimaries(y.colorSpace),ve=y.colorSpace===sr||te===pe?t.NONE:t.BROWSER_DEFAULT_WEBGL;n.pixelStorei(t.UNPACK_FLIP_Y_WEBGL,y.flipY),n.pixelStorei(t.UNPACK_PREMULTIPLY_ALPHA_WEBGL,y.premultiplyAlpha),n.pixelStorei(t.UNPACK_COLORSPACE_CONVERSION_WEBGL,ve)}n.pixelStorei(t.UNPACK_ALIGNMENT,y.unpackAlignment);let ne=g(y.image,!1,r.maxTextureSize);ne=ln(y,ne);const fe=a.convert(y.format,y.colorSpace),Te=a.convert(y.type);let me=M(y.internalFormat,fe,Te,y.normalized,y.colorSpace,y.isVideoTexture);ze(W,y);let he;const Re=y.mipmaps,Le=y.isVideoTexture!==!0,Fe=de.__version===void 0||K===!0,L=ce.dataReady,ue=T(y,ne);if(y.isDepthTexture)me=A(y.format===zr,y.type),Fe&&(Le?n.texStorage2D(t.TEXTURE_2D,1,me,ne.width,ne.height):n.texImage2D(t.TEXTURE_2D,0,me,ne.width,ne.height,0,fe,Te,null));else if(y.isDataTexture)if(Re.length>0){Le&&Fe&&n.texStorage2D(t.TEXTURE_2D,ue,me,Re[0].width,Re[0].height);for(let te=0,pe=Re.length;te<pe;te++)he=Re[te],Le?L&&n.texSubImage2D(t.TEXTURE_2D,te,0,0,he.width,he.height,fe,Te,he.data):n.texImage2D(t.TEXTURE_2D,te,me,he.width,he.height,0,fe,Te,he.data);y.generateMipmaps=!1}else Le?(Fe&&n.texStorage2D(t.TEXTURE_2D,ue,me,ne.width,ne.height),L&&ee(y,ne,fe,Te)):n.texImage2D(t.TEXTURE_2D,0,me,ne.width,ne.height,0,fe,Te,ne.data);else if(y.isCompressedTexture)if(y.isCompressedArrayTexture){Le&&Fe&&n.texStorage3D(t.TEXTURE_2D_ARRAY,ue,me,Re[0].width,Re[0].height,ne.depth);for(let te=0,pe=Re.length;te<pe;te++)if(he=Re[te],y.format!==Xn)if(fe!==null)if(Le){if(L)if(y.layerUpdates.size>0){const ve=Gm(he.width,he.height,y.format,y.type);for(const re of y.layerUpdates){const we=he.data.subarray(re*ve/he.data.BYTES_PER_ELEMENT,(re+1)*ve/he.data.BYTES_PER_ELEMENT);n.compressedTexSubImage3D(t.TEXTURE_2D_ARRAY,te,0,0,re,he.width,he.height,1,fe,we)}y.clearLayerUpdates()}else n.compressedTexSubImage3D(t.TEXTURE_2D_ARRAY,te,0,0,0,he.width,he.height,ne.depth,fe,he.data)}else n.compressedTexImage3D(t.TEXTURE_2D_ARRAY,te,me,he.width,he.height,ne.depth,0,he.data,0,0);else De("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else Le?L&&n.texSubImage3D(t.TEXTURE_2D_ARRAY,te,0,0,0,he.width,he.height,ne.depth,fe,Te,he.data):n.texImage3D(t.TEXTURE_2D_ARRAY,te,me,he.width,he.height,ne.depth,0,fe,Te,he.data)}else{Le&&Fe&&n.texStorage2D(t.TEXTURE_2D,ue,me,Re[0].width,Re[0].height);for(let te=0,pe=Re.length;te<pe;te++)he=Re[te],y.format!==Xn?fe!==null?Le?L&&n.compressedTexSubImage2D(t.TEXTURE_2D,te,0,0,he.width,he.height,fe,he.data):n.compressedTexImage2D(t.TEXTURE_2D,te,me,he.width,he.height,0,he.data):De("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):Le?L&&n.texSubImage2D(t.TEXTURE_2D,te,0,0,he.width,he.height,fe,Te,he.data):n.texImage2D(t.TEXTURE_2D,te,me,he.width,he.height,0,fe,Te,he.data)}else if(y.isDataArrayTexture)if(Le){if(Fe&&n.texStorage3D(t.TEXTURE_2D_ARRAY,ue,me,ne.width,ne.height,ne.depth),L)if(y.layerUpdates.size>0){const te=Gm(ne.width,ne.height,y.format,y.type);for(const pe of y.layerUpdates){const ve=ne.data.subarray(pe*te/ne.data.BYTES_PER_ELEMENT,(pe+1)*te/ne.data.BYTES_PER_ELEMENT);n.texSubImage3D(t.TEXTURE_2D_ARRAY,0,0,0,pe,ne.width,ne.height,1,fe,Te,ve)}y.clearLayerUpdates()}else n.texSubImage3D(t.TEXTURE_2D_ARRAY,0,0,0,0,ne.width,ne.height,ne.depth,fe,Te,ne.data)}else n.texImage3D(t.TEXTURE_2D_ARRAY,0,me,ne.width,ne.height,ne.depth,0,fe,Te,ne.data);else if(y.isData3DTexture)Le?(Fe&&n.texStorage3D(t.TEXTURE_3D,ue,me,ne.width,ne.height,ne.depth),L&&n.texSubImage3D(t.TEXTURE_3D,0,0,0,0,ne.width,ne.height,ne.depth,fe,Te,ne.data)):n.texImage3D(t.TEXTURE_3D,0,me,ne.width,ne.height,ne.depth,0,fe,Te,ne.data);else if(y.isFramebufferTexture){if(Fe)if(Le)n.texStorage2D(t.TEXTURE_2D,ue,me,ne.width,ne.height);else{let te=ne.width,pe=ne.height;for(let ve=0;ve<ue;ve++)n.texImage2D(t.TEXTURE_2D,ve,me,te,pe,0,fe,Te,null),te>>=1,pe>>=1}}else if(y.isHTMLTexture){if("texElementImage2D"in t){const te=t.canvas;if(te.hasAttribute("layoutsubtree")||te.setAttribute("layoutsubtree","true"),ne.parentNode!==te){te.appendChild(ne),h.add(y),te.onpaint=pe=>{const ve=pe.changedElements;for(const re of h)ve.includes(re.image)&&(re.needsUpdate=!0)},te.requestPaint();return}if(t.texElementImage2D.length===3)t.texElementImage2D(t.TEXTURE_2D,t.RGBA8,ne);else{const ve=t.RGBA,re=t.RGBA,we=t.UNSIGNED_BYTE;t.texElementImage2D(t.TEXTURE_2D,0,ve,re,we,ne)}t.texParameteri(t.TEXTURE_2D,t.TEXTURE_MIN_FILTER,t.LINEAR),t.texParameteri(t.TEXTURE_2D,t.TEXTURE_WRAP_S,t.CLAMP_TO_EDGE),t.texParameteri(t.TEXTURE_2D,t.TEXTURE_WRAP_T,t.CLAMP_TO_EDGE)}}else if(Re.length>0){if(Le&&Fe){const te=et(Re[0]);n.texStorage2D(t.TEXTURE_2D,ue,me,te.width,te.height)}for(let te=0,pe=Re.length;te<pe;te++)he=Re[te],Le?L&&n.texSubImage2D(t.TEXTURE_2D,te,0,0,fe,Te,he):n.texImage2D(t.TEXTURE_2D,te,me,fe,Te,he);y.generateMipmaps=!1}else if(Le){if(Fe){const te=et(ne);n.texStorage2D(t.TEXTURE_2D,ue,me,te.width,te.height)}L&&n.texSubImage2D(t.TEXTURE_2D,0,0,0,fe,Te,ne)}else n.texImage2D(t.TEXTURE_2D,0,me,fe,Te,ne);d(y)&&v(W),de.__version=ce.version,y.onUpdate&&y.onUpdate(y)}R.__version=y.version}function Ue(R,y,B){if(y.image.length!==6)return;const W=Q(R,y),K=y.source;n.bindTexture(t.TEXTURE_CUBE_MAP,R.__webglTexture,t.TEXTURE0+B);const ce=i.get(K);if(K.version!==ce.__version||W===!0){n.activeTexture(t.TEXTURE0+B);const de=We.getPrimaries(We.workingColorSpace),Z=y.colorSpace===sr?null:We.getPrimaries(y.colorSpace),ne=y.colorSpace===sr||de===Z?t.NONE:t.BROWSER_DEFAULT_WEBGL;n.pixelStorei(t.UNPACK_FLIP_Y_WEBGL,y.flipY),n.pixelStorei(t.UNPACK_PREMULTIPLY_ALPHA_WEBGL,y.premultiplyAlpha),n.pixelStorei(t.UNPACK_ALIGNMENT,y.unpackAlignment),n.pixelStorei(t.UNPACK_COLORSPACE_CONVERSION_WEBGL,ne);const fe=y.isCompressedTexture||y.image[0].isCompressedTexture,Te=y.image[0]&&y.image[0].isDataTexture,me=[];for(let re=0;re<6;re++)!fe&&!Te?me[re]=g(y.image[re],!0,r.maxCubemapSize):me[re]=Te?y.image[re].image:y.image[re],me[re]=ln(y,me[re]);const he=me[0],Re=a.convert(y.format,y.colorSpace),Le=a.convert(y.type),Fe=M(y.internalFormat,Re,Le,y.normalized,y.colorSpace),L=y.isVideoTexture!==!0,ue=ce.__version===void 0||W===!0,te=K.dataReady;let pe=T(y,he);ze(t.TEXTURE_CUBE_MAP,y);let ve;if(fe){L&&ue&&n.texStorage2D(t.TEXTURE_CUBE_MAP,pe,Fe,he.width,he.height);for(let re=0;re<6;re++){ve=me[re].mipmaps;for(let we=0;we<ve.length;we++){const Ee=ve[we];y.format!==Xn?Re!==null?L?te&&n.compressedTexSubImage2D(t.TEXTURE_CUBE_MAP_POSITIVE_X+re,we,0,0,Ee.width,Ee.height,Re,Ee.data):n.compressedTexImage2D(t.TEXTURE_CUBE_MAP_POSITIVE_X+re,we,Fe,Ee.width,Ee.height,0,Ee.data):De("WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):L?te&&n.texSubImage2D(t.TEXTURE_CUBE_MAP_POSITIVE_X+re,we,0,0,Ee.width,Ee.height,Re,Le,Ee.data):n.texImage2D(t.TEXTURE_CUBE_MAP_POSITIVE_X+re,we,Fe,Ee.width,Ee.height,0,Re,Le,Ee.data)}}}else{if(ve=y.mipmaps,L&&ue){ve.length>0&&pe++;const re=et(me[0]);n.texStorage2D(t.TEXTURE_CUBE_MAP,pe,Fe,re.width,re.height)}for(let re=0;re<6;re++)if(Te){L?te&&n.texSubImage2D(t.TEXTURE_CUBE_MAP_POSITIVE_X+re,0,0,0,me[re].width,me[re].height,Re,Le,me[re].data):n.texImage2D(t.TEXTURE_CUBE_MAP_POSITIVE_X+re,0,Fe,me[re].width,me[re].height,0,Re,Le,me[re].data);for(let we=0;we<ve.length;we++){const vt=ve[we].image[re].image;L?te&&n.texSubImage2D(t.TEXTURE_CUBE_MAP_POSITIVE_X+re,we+1,0,0,vt.width,vt.height,Re,Le,vt.data):n.texImage2D(t.TEXTURE_CUBE_MAP_POSITIVE_X+re,we+1,Fe,vt.width,vt.height,0,Re,Le,vt.data)}}else{L?te&&n.texSubImage2D(t.TEXTURE_CUBE_MAP_POSITIVE_X+re,0,0,0,Re,Le,me[re]):n.texImage2D(t.TEXTURE_CUBE_MAP_POSITIVE_X+re,0,Fe,Re,Le,me[re]);for(let we=0;we<ve.length;we++){const Ee=ve[we];L?te&&n.texSubImage2D(t.TEXTURE_CUBE_MAP_POSITIVE_X+re,we+1,0,0,Re,Le,Ee.image[re]):n.texImage2D(t.TEXTURE_CUBE_MAP_POSITIVE_X+re,we+1,Fe,Re,Le,Ee.image[re])}}}d(y)&&v(t.TEXTURE_CUBE_MAP),ce.__version=K.version,y.onUpdate&&y.onUpdate(y)}R.__version=y.version}function Ne(R,y,B,W,K,ce){const de=a.convert(B.format,B.colorSpace),Z=a.convert(B.type),ne=M(B.internalFormat,de,Z,B.normalized,B.colorSpace),fe=i.get(y),Te=i.get(B);if(Te.__renderTarget=y,!fe.__hasExternalTextures){const me=Math.max(1,y.width>>ce),he=Math.max(1,y.height>>ce);K===t.TEXTURE_3D||K===t.TEXTURE_2D_ARRAY?n.texImage3D(K,ce,ne,me,he,y.depth,0,de,Z,null):n.texImage2D(K,ce,ne,me,he,0,de,Z,null)}n.bindFramebuffer(t.FRAMEBUFFER,R),Ct(y)?o.framebufferTexture2DMultisampleEXT(t.FRAMEBUFFER,W,K,Te.__webglTexture,0,xt(y)):(K===t.TEXTURE_2D||K>=t.TEXTURE_CUBE_MAP_POSITIVE_X&&K<=t.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&t.framebufferTexture2D(t.FRAMEBUFFER,W,K,Te.__webglTexture,ce),n.bindFramebuffer(t.FRAMEBUFFER,null)}function Et(R,y,B){if(t.bindRenderbuffer(t.RENDERBUFFER,R),y.depthBuffer){const W=y.depthTexture,K=W&&W.isDepthTexture?W.type:null,ce=A(y.stencilBuffer,K),de=y.stencilBuffer?t.DEPTH_STENCIL_ATTACHMENT:t.DEPTH_ATTACHMENT;Ct(y)?o.renderbufferStorageMultisampleEXT(t.RENDERBUFFER,xt(y),ce,y.width,y.height):B?t.renderbufferStorageMultisample(t.RENDERBUFFER,xt(y),ce,y.width,y.height):t.renderbufferStorage(t.RENDERBUFFER,ce,y.width,y.height),t.framebufferRenderbuffer(t.FRAMEBUFFER,de,t.RENDERBUFFER,R)}else{const W=y.textures;for(let K=0;K<W.length;K++){const ce=W[K],de=a.convert(ce.format,ce.colorSpace),Z=a.convert(ce.type),ne=M(ce.internalFormat,de,Z,ce.normalized,ce.colorSpace);Ct(y)?o.renderbufferStorageMultisampleEXT(t.RENDERBUFFER,xt(y),ne,y.width,y.height):B?t.renderbufferStorageMultisample(t.RENDERBUFFER,xt(y),ne,y.width,y.height):t.renderbufferStorage(t.RENDERBUFFER,ne,y.width,y.height)}}t.bindRenderbuffer(t.RENDERBUFFER,null)}function Ge(R,y,B){const W=y.isWebGLCubeRenderTarget===!0;if(n.bindFramebuffer(t.FRAMEBUFFER,R),!(y.depthTexture&&y.depthTexture.isDepthTexture))throw new Error("THREE.WebGLTextures: renderTarget.depthTexture must be an instance of THREE.DepthTexture.");const K=i.get(y.depthTexture);if(K.__renderTarget=y,(!K.__webglTexture||y.depthTexture.image.width!==y.width||y.depthTexture.image.height!==y.height)&&(y.depthTexture.image.width=y.width,y.depthTexture.image.height=y.height,y.depthTexture.needsUpdate=!0),W){if(K.__webglInit===void 0&&(K.__webglInit=!0,y.depthTexture.addEventListener("dispose",w)),K.__webglTexture===void 0){K.__webglTexture=t.createTexture(),n.bindTexture(t.TEXTURE_CUBE_MAP,K.__webglTexture),ze(t.TEXTURE_CUBE_MAP,y.depthTexture);const fe=a.convert(y.depthTexture.format),Te=a.convert(y.depthTexture.type);let me;y.depthTexture.format===Vi?me=t.DEPTH_COMPONENT24:y.depthTexture.format===zr&&(me=t.DEPTH24_STENCIL8);for(let he=0;he<6;he++)t.texImage2D(t.TEXTURE_CUBE_MAP_POSITIVE_X+he,0,me,y.width,y.height,0,fe,Te,null)}}else O(y.depthTexture,0);const ce=K.__webglTexture,de=xt(y),Z=W?t.TEXTURE_CUBE_MAP_POSITIVE_X+B:t.TEXTURE_2D,ne=y.depthTexture.format===zr?t.DEPTH_STENCIL_ATTACHMENT:t.DEPTH_ATTACHMENT;if(y.depthTexture.format===Vi)Ct(y)?o.framebufferTexture2DMultisampleEXT(t.FRAMEBUFFER,ne,Z,ce,0,de):t.framebufferTexture2D(t.FRAMEBUFFER,ne,Z,ce,0);else if(y.depthTexture.format===zr)Ct(y)?o.framebufferTexture2DMultisampleEXT(t.FRAMEBUFFER,ne,Z,ce,0,de):t.framebufferTexture2D(t.FRAMEBUFFER,ne,Z,ce,0);else throw new Error("THREE.WebGLTextures: Unknown depthTexture format.")}function rt(R){const y=i.get(R),B=R.isWebGLCubeRenderTarget===!0;if(y.__boundDepthTexture!==R.depthTexture){const W=R.depthTexture;if(y.__depthDisposeCallback&&y.__depthDisposeCallback(),W){const K=()=>{delete y.__boundDepthTexture,delete y.__depthDisposeCallback,W.removeEventListener("dispose",K)};W.addEventListener("dispose",K),y.__depthDisposeCallback=K}y.__boundDepthTexture=W}if(R.depthTexture&&!y.__autoAllocateDepthBuffer)if(B)for(let W=0;W<6;W++)Ge(y.__webglFramebuffer[W],R,W);else{const W=R.texture.mipmaps;W&&W.length>0?Ge(y.__webglFramebuffer[0],R,0):Ge(y.__webglFramebuffer,R,0)}else if(B){y.__webglDepthbuffer=[];for(let W=0;W<6;W++)if(n.bindFramebuffer(t.FRAMEBUFFER,y.__webglFramebuffer[W]),y.__webglDepthbuffer[W]===void 0)y.__webglDepthbuffer[W]=t.createRenderbuffer(),Et(y.__webglDepthbuffer[W],R,!1);else{const K=R.stencilBuffer?t.DEPTH_STENCIL_ATTACHMENT:t.DEPTH_ATTACHMENT,ce=y.__webglDepthbuffer[W];t.bindRenderbuffer(t.RENDERBUFFER,ce),t.framebufferRenderbuffer(t.FRAMEBUFFER,K,t.RENDERBUFFER,ce)}}else{const W=R.texture.mipmaps;if(W&&W.length>0?n.bindFramebuffer(t.FRAMEBUFFER,y.__webglFramebuffer[0]):n.bindFramebuffer(t.FRAMEBUFFER,y.__webglFramebuffer),y.__webglDepthbuffer===void 0)y.__webglDepthbuffer=t.createRenderbuffer(),Et(y.__webglDepthbuffer,R,!1);else{const K=R.stencilBuffer?t.DEPTH_STENCIL_ATTACHMENT:t.DEPTH_ATTACHMENT,ce=y.__webglDepthbuffer;t.bindRenderbuffer(t.RENDERBUFFER,ce),t.framebufferRenderbuffer(t.FRAMEBUFFER,K,t.RENDERBUFFER,ce)}}n.bindFramebuffer(t.FRAMEBUFFER,null)}function Je(R,y,B){const W=i.get(R);y!==void 0&&Ne(W.__webglFramebuffer,R,R.texture,t.COLOR_ATTACHMENT0,t.TEXTURE_2D,0),B!==void 0&&rt(R)}function $e(R){const y=R.texture,B=i.get(R),W=i.get(y);R.addEventListener("dispose",_);const K=R.textures,ce=R.isWebGLCubeRenderTarget===!0,de=K.length>1;if(de||(W.__webglTexture===void 0&&(W.__webglTexture=t.createTexture()),W.__version=y.version,s.memory.textures++),ce){B.__webglFramebuffer=[];for(let Z=0;Z<6;Z++)if(y.mipmaps&&y.mipmaps.length>0){B.__webglFramebuffer[Z]=[];for(let ne=0;ne<y.mipmaps.length;ne++)B.__webglFramebuffer[Z][ne]=t.createFramebuffer()}else B.__webglFramebuffer[Z]=t.createFramebuffer()}else{if(y.mipmaps&&y.mipmaps.length>0){B.__webglFramebuffer=[];for(let Z=0;Z<y.mipmaps.length;Z++)B.__webglFramebuffer[Z]=t.createFramebuffer()}else B.__webglFramebuffer=t.createFramebuffer();if(de)for(let Z=0,ne=K.length;Z<ne;Z++){const fe=i.get(K[Z]);fe.__webglTexture===void 0&&(fe.__webglTexture=t.createTexture(),s.memory.textures++)}if(R.samples>0&&Ct(R)===!1){B.__webglMultisampledFramebuffer=t.createFramebuffer(),B.__webglColorRenderbuffer=[],n.bindFramebuffer(t.FRAMEBUFFER,B.__webglMultisampledFramebuffer);for(let Z=0;Z<K.length;Z++){const ne=K[Z];B.__webglColorRenderbuffer[Z]=t.createRenderbuffer(),t.bindRenderbuffer(t.RENDERBUFFER,B.__webglColorRenderbuffer[Z]);const fe=a.convert(ne.format,ne.colorSpace),Te=a.convert(ne.type),me=M(ne.internalFormat,fe,Te,ne.normalized,ne.colorSpace,R.isXRRenderTarget===!0),he=xt(R);t.renderbufferStorageMultisample(t.RENDERBUFFER,he,me,R.width,R.height),t.framebufferRenderbuffer(t.FRAMEBUFFER,t.COLOR_ATTACHMENT0+Z,t.RENDERBUFFER,B.__webglColorRenderbuffer[Z])}t.bindRenderbuffer(t.RENDERBUFFER,null),R.depthBuffer&&(B.__webglDepthRenderbuffer=t.createRenderbuffer(),Et(B.__webglDepthRenderbuffer,R,!0)),n.bindFramebuffer(t.FRAMEBUFFER,null)}}if(ce){n.bindTexture(t.TEXTURE_CUBE_MAP,W.__webglTexture),ze(t.TEXTURE_CUBE_MAP,y);for(let Z=0;Z<6;Z++)if(y.mipmaps&&y.mipmaps.length>0)for(let ne=0;ne<y.mipmaps.length;ne++)Ne(B.__webglFramebuffer[Z][ne],R,y,t.COLOR_ATTACHMENT0,t.TEXTURE_CUBE_MAP_POSITIVE_X+Z,ne);else Ne(B.__webglFramebuffer[Z],R,y,t.COLOR_ATTACHMENT0,t.TEXTURE_CUBE_MAP_POSITIVE_X+Z,0);d(y)&&v(t.TEXTURE_CUBE_MAP),n.unbindTexture()}else if(de){for(let Z=0,ne=K.length;Z<ne;Z++){const fe=K[Z],Te=i.get(fe);let me=t.TEXTURE_2D;(R.isWebGL3DRenderTarget||R.isWebGLArrayRenderTarget)&&(me=R.isWebGL3DRenderTarget?t.TEXTURE_3D:t.TEXTURE_2D_ARRAY),n.bindTexture(me,Te.__webglTexture),ze(me,fe),Ne(B.__webglFramebuffer,R,fe,t.COLOR_ATTACHMENT0+Z,me,0),d(fe)&&v(me)}n.unbindTexture()}else{let Z=t.TEXTURE_2D;if((R.isWebGL3DRenderTarget||R.isWebGLArrayRenderTarget)&&(Z=R.isWebGL3DRenderTarget?t.TEXTURE_3D:t.TEXTURE_2D_ARRAY),n.bindTexture(Z,W.__webglTexture),ze(Z,y),y.mipmaps&&y.mipmaps.length>0)for(let ne=0;ne<y.mipmaps.length;ne++)Ne(B.__webglFramebuffer[ne],R,y,t.COLOR_ATTACHMENT0,Z,ne);else Ne(B.__webglFramebuffer,R,y,t.COLOR_ATTACHMENT0,Z,0);d(y)&&v(Z),n.unbindTexture()}R.depthBuffer&&rt(R)}function At(R){const y=R.textures;for(let B=0,W=y.length;B<W;B++){const K=y[B];if(d(K)){const ce=S(R),de=i.get(K).__webglTexture;n.bindTexture(ce,de),v(ce),n.unbindTexture()}}}const Lt=[],Ot=[];function Vt(R){if(R.samples>0){if(Ct(R)===!1){const y=R.textures,B=R.width,W=R.height;let K=t.COLOR_BUFFER_BIT;const ce=R.stencilBuffer?t.DEPTH_STENCIL_ATTACHMENT:t.DEPTH_ATTACHMENT,de=i.get(R),Z=y.length>1;if(Z)for(let fe=0;fe<y.length;fe++)n.bindFramebuffer(t.FRAMEBUFFER,de.__webglMultisampledFramebuffer),t.framebufferRenderbuffer(t.FRAMEBUFFER,t.COLOR_ATTACHMENT0+fe,t.RENDERBUFFER,null),n.bindFramebuffer(t.FRAMEBUFFER,de.__webglFramebuffer),t.framebufferTexture2D(t.DRAW_FRAMEBUFFER,t.COLOR_ATTACHMENT0+fe,t.TEXTURE_2D,null,0);n.bindFramebuffer(t.READ_FRAMEBUFFER,de.__webglMultisampledFramebuffer);const ne=R.texture.mipmaps;ne&&ne.length>0?n.bindFramebuffer(t.DRAW_FRAMEBUFFER,de.__webglFramebuffer[0]):n.bindFramebuffer(t.DRAW_FRAMEBUFFER,de.__webglFramebuffer);for(let fe=0;fe<y.length;fe++){if(R.resolveDepthBuffer&&(R.depthBuffer&&(K|=t.DEPTH_BUFFER_BIT),R.stencilBuffer&&R.resolveStencilBuffer&&(K|=t.STENCIL_BUFFER_BIT)),Z){t.framebufferRenderbuffer(t.READ_FRAMEBUFFER,t.COLOR_ATTACHMENT0,t.RENDERBUFFER,de.__webglColorRenderbuffer[fe]);const Te=i.get(y[fe]).__webglTexture;t.framebufferTexture2D(t.DRAW_FRAMEBUFFER,t.COLOR_ATTACHMENT0,t.TEXTURE_2D,Te,0)}t.blitFramebuffer(0,0,B,W,0,0,B,W,K,t.NEAREST),l===!0&&(Lt.length=0,Ot.length=0,Lt.push(t.COLOR_ATTACHMENT0+fe),R.depthBuffer&&R.resolveDepthBuffer===!1&&(Lt.push(ce),Ot.push(ce),t.invalidateFramebuffer(t.DRAW_FRAMEBUFFER,Ot)),t.invalidateFramebuffer(t.READ_FRAMEBUFFER,Lt))}if(n.bindFramebuffer(t.READ_FRAMEBUFFER,null),n.bindFramebuffer(t.DRAW_FRAMEBUFFER,null),Z)for(let fe=0;fe<y.length;fe++){n.bindFramebuffer(t.FRAMEBUFFER,de.__webglMultisampledFramebuffer),t.framebufferRenderbuffer(t.FRAMEBUFFER,t.COLOR_ATTACHMENT0+fe,t.RENDERBUFFER,de.__webglColorRenderbuffer[fe]);const Te=i.get(y[fe]).__webglTexture;n.bindFramebuffer(t.FRAMEBUFFER,de.__webglFramebuffer),t.framebufferTexture2D(t.DRAW_FRAMEBUFFER,t.COLOR_ATTACHMENT0+fe,t.TEXTURE_2D,Te,0)}n.bindFramebuffer(t.DRAW_FRAMEBUFFER,de.__webglMultisampledFramebuffer)}else if(R.depthBuffer&&R.resolveDepthBuffer===!1&&l){const y=R.stencilBuffer?t.DEPTH_STENCIL_ATTACHMENT:t.DEPTH_ATTACHMENT;t.invalidateFramebuffer(t.DRAW_FRAMEBUFFER,[y])}}}function xt(R){return Math.min(r.maxSamples,R.samples)}function Ct(R){const y=i.get(R);return R.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&y.__useRenderToTexture!==!1}function D(R){const y=s.render.frame;f.get(R)!==y&&(f.set(R,y),R.update())}function ln(R,y){const B=R.colorSpace,W=R.format,K=R.type;return R.isCompressedTexture===!0||R.isVideoTexture===!0||B!==Zl&&B!==sr&&(We.getTransfer(B)===tt?(W!==Xn||K!==Nn)&&De("WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):Ye("WebGLTextures: Unsupported texture color space:",B)),y}function et(R){return typeof HTMLImageElement<"u"&&R instanceof HTMLImageElement?(c.width=R.naturalWidth||R.width,c.height=R.naturalHeight||R.height):typeof VideoFrame<"u"&&R instanceof VideoFrame?(c.width=R.displayWidth,c.height=R.displayHeight):(c.width=R.width,c.height=R.height),c}this.allocateTextureUnit=X,this.resetTextureUnits=q,this.getTextureUnits=ie,this.setTextureUnits=k,this.setTexture2D=O,this.setTexture2DArray=I,this.setTexture3D=J,this.setTextureCube=ae,this.rebindTextures=Je,this.setupRenderTarget=$e,this.updateRenderTargetMipmap=At,this.updateMultisampleRenderTarget=Vt,this.setupDepthRenderbuffer=rt,this.setupFrameBufferTexture=Ne,this.useMultisampledRTT=Ct,this.isReversedDepthBuffer=function(){return n.buffers.depth.getReversed()}}function SA(t,e){function n(i,r=sr){let a;const s=We.getTransfer(r);if(i===Nn)return t.UNSIGNED_BYTE;if(i===Th)return t.UNSIGNED_SHORT_4_4_4_4;if(i===Ah)return t.UNSIGNED_SHORT_5_5_5_1;if(i===_x)return t.UNSIGNED_INT_5_9_9_9_REV;if(i===xx)return t.UNSIGNED_INT_10F_11F_11F_REV;if(i===mx)return t.BYTE;if(i===gx)return t.SHORT;if(i===Zs)return t.UNSIGNED_SHORT;if(i===wh)return t.INT;if(i===gi)return t.UNSIGNED_INT;if(i===ci)return t.FLOAT;if(i===zi)return t.HALF_FLOAT;if(i===vx)return t.ALPHA;if(i===yx)return t.RGB;if(i===Xn)return t.RGBA;if(i===Vi)return t.DEPTH_COMPONENT;if(i===zr)return t.DEPTH_STENCIL;if(i===Sx)return t.RED;if(i===Ch)return t.RED_INTEGER;if(i===Yr)return t.RG;if(i===Rh)return t.RG_INTEGER;if(i===Ph)return t.RGBA_INTEGER;if(i===_l||i===xl||i===vl||i===yl)if(s===tt)if(a=e.get("WEBGL_compressed_texture_s3tc_srgb"),a!==null){if(i===_l)return a.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(i===xl)return a.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(i===vl)return a.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(i===yl)return a.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(a=e.get("WEBGL_compressed_texture_s3tc"),a!==null){if(i===_l)return a.COMPRESSED_RGB_S3TC_DXT1_EXT;if(i===xl)return a.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(i===vl)return a.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(i===yl)return a.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(i===Vd||i===Hd||i===Gd||i===Wd)if(a=e.get("WEBGL_compressed_texture_pvrtc"),a!==null){if(i===Vd)return a.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(i===Hd)return a.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(i===Gd)return a.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(i===Wd)return a.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(i===jd||i===Xd||i===$d||i===qd||i===Yd||i===Yl||i===Kd)if(a=e.get("WEBGL_compressed_texture_etc"),a!==null){if(i===jd||i===Xd)return s===tt?a.COMPRESSED_SRGB8_ETC2:a.COMPRESSED_RGB8_ETC2;if(i===$d)return s===tt?a.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:a.COMPRESSED_RGBA8_ETC2_EAC;if(i===qd)return a.COMPRESSED_R11_EAC;if(i===Yd)return a.COMPRESSED_SIGNED_R11_EAC;if(i===Yl)return a.COMPRESSED_RG11_EAC;if(i===Kd)return a.COMPRESSED_SIGNED_RG11_EAC}else return null;if(i===Zd||i===Qd||i===Jd||i===ef||i===tf||i===nf||i===rf||i===af||i===sf||i===of||i===lf||i===cf||i===uf||i===df)if(a=e.get("WEBGL_compressed_texture_astc"),a!==null){if(i===Zd)return s===tt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:a.COMPRESSED_RGBA_ASTC_4x4_KHR;if(i===Qd)return s===tt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:a.COMPRESSED_RGBA_ASTC_5x4_KHR;if(i===Jd)return s===tt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:a.COMPRESSED_RGBA_ASTC_5x5_KHR;if(i===ef)return s===tt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:a.COMPRESSED_RGBA_ASTC_6x5_KHR;if(i===tf)return s===tt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:a.COMPRESSED_RGBA_ASTC_6x6_KHR;if(i===nf)return s===tt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:a.COMPRESSED_RGBA_ASTC_8x5_KHR;if(i===rf)return s===tt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:a.COMPRESSED_RGBA_ASTC_8x6_KHR;if(i===af)return s===tt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:a.COMPRESSED_RGBA_ASTC_8x8_KHR;if(i===sf)return s===tt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:a.COMPRESSED_RGBA_ASTC_10x5_KHR;if(i===of)return s===tt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:a.COMPRESSED_RGBA_ASTC_10x6_KHR;if(i===lf)return s===tt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:a.COMPRESSED_RGBA_ASTC_10x8_KHR;if(i===cf)return s===tt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:a.COMPRESSED_RGBA_ASTC_10x10_KHR;if(i===uf)return s===tt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:a.COMPRESSED_RGBA_ASTC_12x10_KHR;if(i===df)return s===tt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:a.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(i===ff||i===hf||i===pf)if(a=e.get("EXT_texture_compression_bptc"),a!==null){if(i===ff)return s===tt?a.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:a.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(i===hf)return a.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(i===pf)return a.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(i===mf||i===gf||i===Kl||i===_f)if(a=e.get("EXT_texture_compression_rgtc"),a!==null){if(i===mf)return a.COMPRESSED_RED_RGTC1_EXT;if(i===gf)return a.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(i===Kl)return a.COMPRESSED_RED_GREEN_RGTC2_EXT;if(i===_f)return a.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return i===Qs?t.UNSIGNED_INT_24_8:t[i]!==void 0?t[i]:null}return{convert:n}}const MA=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,EA=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class bA{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,n){if(this.texture===null){const i=new Nx(e.texture);(e.depthNear!==n.depthNear||e.depthFar!==n.depthFar)&&(this.depthNear=e.depthNear,this.depthFar=e.depthFar),this.texture=i}}getMesh(e){if(this.texture!==null&&this.mesh===null){const n=e.cameras[0].viewport,i=new Qn({vertexShader:MA,fragmentShader:EA,uniforms:{depthColor:{value:this.texture},depthWidth:{value:n.z},depthHeight:{value:n.w}}});this.mesh=new _i(new uo(20,20),i)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class wA extends ea{constructor(e,n){super();const i=this;let r=null,a=1,s=null,o="local-floor",l=1,c=null,f=null,h=null,u=null,m=null,x=null;const E=typeof XRWebGLBinding<"u",g=new bA,d={},v=n.getContextAttributes();let S=null,M=null;const A=[],T=[],w=new Ze;let _=null;const C=new Wn;C.viewport=new Mt;const P=new Wn;P.viewport=new Mt;const N=[C,P],F=new UE;let q=null,ie=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(Q){let oe=A[Q];return oe===void 0&&(oe=new hu,A[Q]=oe),oe.getTargetRaySpace()},this.getControllerGrip=function(Q){let oe=A[Q];return oe===void 0&&(oe=new hu,A[Q]=oe),oe.getGripSpace()},this.getHand=function(Q){let oe=A[Q];return oe===void 0&&(oe=new hu,A[Q]=oe),oe.getHandSpace()};function k(Q){const oe=T.indexOf(Q.inputSource);if(oe===-1)return;const ee=A[oe];ee!==void 0&&(ee.update(Q.inputSource,Q.frame,c||s),ee.dispatchEvent({type:Q.type,data:Q.inputSource}))}function X(){r.removeEventListener("select",k),r.removeEventListener("selectstart",k),r.removeEventListener("selectend",k),r.removeEventListener("squeeze",k),r.removeEventListener("squeezestart",k),r.removeEventListener("squeezeend",k),r.removeEventListener("end",X),r.removeEventListener("inputsourceschange",V);for(let Q=0;Q<A.length;Q++){const oe=T[Q];oe!==null&&(T[Q]=null,A[Q].disconnect(oe))}q=null,ie=null,g.reset();for(const Q in d)delete d[Q];e.setRenderTarget(S),m=null,u=null,h=null,r=null,M=null,ze.stop(),i.isPresenting=!1,e.setPixelRatio(_),e.setSize(w.width,w.height,!1),i.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(Q){a=Q,i.isPresenting===!0&&De("WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(Q){o=Q,i.isPresenting===!0&&De("WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return c||s},this.setReferenceSpace=function(Q){c=Q},this.getBaseLayer=function(){return u!==null?u:m},this.getBinding=function(){return h===null&&E&&(h=new XRWebGLBinding(r,n)),h},this.getFrame=function(){return x},this.getSession=function(){return r},this.setSession=async function(Q){if(r=Q,r!==null){if(S=e.getRenderTarget(),r.addEventListener("select",k),r.addEventListener("selectstart",k),r.addEventListener("selectend",k),r.addEventListener("squeeze",k),r.addEventListener("squeezestart",k),r.addEventListener("squeezeend",k),r.addEventListener("end",X),r.addEventListener("inputsourceschange",V),v.xrCompatible!==!0&&await n.makeXRCompatible(),_=e.getPixelRatio(),e.getSize(w),E&&"createProjectionLayer"in XRWebGLBinding.prototype){let ee=null,Pe=null,Ue=null;v.depth&&(Ue=v.stencil?n.DEPTH24_STENCIL8:n.DEPTH_COMPONENT24,ee=v.stencil?zr:Vi,Pe=v.stencil?Qs:gi);const Ne={colorFormat:n.RGBA8,depthFormat:Ue,scaleFactor:a};h=this.getBinding(),u=h.createProjectionLayer(Ne),r.updateRenderState({layers:[u]}),e.setPixelRatio(1),e.setSize(u.textureWidth,u.textureHeight,!1),M=new pi(u.textureWidth,u.textureHeight,{format:Xn,type:Nn,depthTexture:new qa(u.textureWidth,u.textureHeight,Pe,void 0,void 0,void 0,void 0,void 0,void 0,ee),stencilBuffer:v.stencil,colorSpace:e.outputColorSpace,samples:v.antialias?4:0,resolveDepthBuffer:u.ignoreDepthValues===!1,resolveStencilBuffer:u.ignoreDepthValues===!1})}else{const ee={antialias:v.antialias,alpha:!0,depth:v.depth,stencil:v.stencil,framebufferScaleFactor:a};m=new XRWebGLLayer(r,n,ee),r.updateRenderState({baseLayer:m}),e.setPixelRatio(1),e.setSize(m.framebufferWidth,m.framebufferHeight,!1),M=new pi(m.framebufferWidth,m.framebufferHeight,{format:Xn,type:Nn,colorSpace:e.outputColorSpace,stencilBuffer:v.stencil,resolveDepthBuffer:m.ignoreDepthValues===!1,resolveStencilBuffer:m.ignoreDepthValues===!1})}M.isXRRenderTarget=!0,this.setFoveation(l),c=null,s=await r.requestReferenceSpace(o),ze.setContext(r),ze.start(),i.isPresenting=!0,i.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(r!==null)return r.environmentBlendMode},this.getDepthTexture=function(){return g.getDepthTexture()};function V(Q){for(let oe=0;oe<Q.removed.length;oe++){const ee=Q.removed[oe],Pe=T.indexOf(ee);Pe>=0&&(T[Pe]=null,A[Pe].disconnect(ee))}for(let oe=0;oe<Q.added.length;oe++){const ee=Q.added[oe];let Pe=T.indexOf(ee);if(Pe===-1){for(let Ne=0;Ne<A.length;Ne++)if(Ne>=T.length){T.push(ee),Pe=Ne;break}else if(T[Ne]===null){T[Ne]=ee,Pe=Ne;break}if(Pe===-1)break}const Ue=A[Pe];Ue&&Ue.connect(ee)}}const O=new j,I=new j;function J(Q,oe,ee){O.setFromMatrixPosition(oe.matrixWorld),I.setFromMatrixPosition(ee.matrixWorld);const Pe=O.distanceTo(I),Ue=oe.projectionMatrix.elements,Ne=ee.projectionMatrix.elements,Et=Ue[14]/(Ue[10]-1),Ge=Ue[14]/(Ue[10]+1),rt=(Ue[9]+1)/Ue[5],Je=(Ue[9]-1)/Ue[5],$e=(Ue[8]-1)/Ue[0],At=(Ne[8]+1)/Ne[0],Lt=Et*$e,Ot=Et*At,Vt=Pe/(-$e+At),xt=Vt*-$e;if(oe.matrixWorld.decompose(Q.position,Q.quaternion,Q.scale),Q.translateX(xt),Q.translateZ(Vt),Q.matrixWorld.compose(Q.position,Q.quaternion,Q.scale),Q.matrixWorldInverse.copy(Q.matrixWorld).invert(),Ue[10]===-1)Q.projectionMatrix.copy(oe.projectionMatrix),Q.projectionMatrixInverse.copy(oe.projectionMatrixInverse);else{const Ct=Et+Vt,D=Ge+Vt,ln=Lt-xt,et=Ot+(Pe-xt),R=rt*Ge/D*Ct,y=Je*Ge/D*Ct;Q.projectionMatrix.makePerspective(ln,et,R,y,Ct,D),Q.projectionMatrixInverse.copy(Q.projectionMatrix).invert()}}function ae(Q,oe){oe===null?Q.matrixWorld.copy(Q.matrix):Q.matrixWorld.multiplyMatrices(oe.matrixWorld,Q.matrix),Q.matrixWorldInverse.copy(Q.matrixWorld).invert()}this.updateCamera=function(Q){if(r===null)return;let oe=Q.near,ee=Q.far;g.texture!==null&&(g.depthNear>0&&(oe=g.depthNear),g.depthFar>0&&(ee=g.depthFar)),F.near=P.near=C.near=oe,F.far=P.far=C.far=ee,(q!==F.near||ie!==F.far)&&(r.updateRenderState({depthNear:F.near,depthFar:F.far}),q=F.near,ie=F.far),F.layers.mask=Q.layers.mask|6,C.layers.mask=F.layers.mask&-5,P.layers.mask=F.layers.mask&-3;const Pe=Q.parent,Ue=F.cameras;ae(F,Pe);for(let Ne=0;Ne<Ue.length;Ne++)ae(Ue[Ne],Pe);Ue.length===2?J(F,C,P):F.projectionMatrix.copy(C.projectionMatrix),le(Q,F,Pe)};function le(Q,oe,ee){ee===null?Q.matrix.copy(oe.matrixWorld):(Q.matrix.copy(ee.matrixWorld),Q.matrix.invert(),Q.matrix.multiply(oe.matrixWorld)),Q.matrix.decompose(Q.position,Q.quaternion,Q.scale),Q.updateMatrixWorld(!0),Q.projectionMatrix.copy(oe.projectionMatrix),Q.projectionMatrixInverse.copy(oe.projectionMatrixInverse),Q.isPerspectiveCamera&&(Q.fov=xf*2*Math.atan(1/Q.projectionMatrix.elements[5]),Q.zoom=1)}this.getCamera=function(){return F},this.getFoveation=function(){if(!(u===null&&m===null))return l},this.setFoveation=function(Q){l=Q,u!==null&&(u.fixedFoveation=Q),m!==null&&m.fixedFoveation!==void 0&&(m.fixedFoveation=Q)},this.hasDepthSensing=function(){return g.texture!==null},this.getDepthSensingMesh=function(){return g.getMesh(F)},this.getCameraTexture=function(Q){return d[Q]};let Be=null;function Xe(Q,oe){if(f=oe.getViewerPose(c||s),x=oe,f!==null){const ee=f.views;m!==null&&(e.setRenderTargetFramebuffer(M,m.framebuffer),e.setRenderTarget(M));let Pe=!1;ee.length!==F.cameras.length&&(F.cameras.length=0,Pe=!0);for(let Ge=0;Ge<ee.length;Ge++){const rt=ee[Ge];let Je=null;if(m!==null)Je=m.getViewport(rt);else{const At=h.getViewSubImage(u,rt);Je=At.viewport,Ge===0&&(e.setRenderTargetTextures(M,At.colorTexture,At.depthStencilTexture),e.setRenderTarget(M))}let $e=N[Ge];$e===void 0&&($e=new Wn,$e.layers.enable(Ge),$e.viewport=new Mt,N[Ge]=$e),$e.matrix.fromArray(rt.transform.matrix),$e.matrix.decompose($e.position,$e.quaternion,$e.scale),$e.projectionMatrix.fromArray(rt.projectionMatrix),$e.projectionMatrixInverse.copy($e.projectionMatrix).invert(),$e.viewport.set(Je.x,Je.y,Je.width,Je.height),Ge===0&&(F.matrix.copy($e.matrix),F.matrix.decompose(F.position,F.quaternion,F.scale)),Pe===!0&&F.cameras.push($e)}const Ue=r.enabledFeatures;if(Ue&&Ue.includes("depth-sensing")&&r.depthUsage=="gpu-optimized"&&E){h=i.getBinding();const Ge=h.getDepthInformation(ee[0]);Ge&&Ge.isValid&&Ge.texture&&g.init(Ge,r.renderState)}if(Ue&&Ue.includes("camera-access")&&E){e.state.unbindTexture(),h=i.getBinding();for(let Ge=0;Ge<ee.length;Ge++){const rt=ee[Ge].camera;if(rt){let Je=d[rt];Je||(Je=new Nx,d[rt]=Je);const $e=h.getCameraImage(rt);Je.sourceTexture=$e}}}}for(let ee=0;ee<A.length;ee++){const Pe=T[ee],Ue=A[ee];Pe!==null&&Ue!==void 0&&Ue.update(Pe,oe,c||s)}Be&&Be(Q,oe),oe.detectedPlanes&&i.dispatchEvent({type:"planesdetected",data:oe}),x=null}const ze=new Ix;ze.setAnimationLoop(Xe),this.setAnimationLoop=function(Q){Be=Q},this.dispose=function(){}}}const TA=new Nt,Vx=new Ie;Vx.set(-1,0,0,0,1,0,0,0,1);function AA(t,e){function n(g,d){g.matrixAutoUpdate===!0&&g.updateMatrix(),d.value.copy(g.matrix)}function i(g,d){d.color.getRGB(g.fogColor.value,Lx(t)),d.isFog?(g.fogNear.value=d.near,g.fogFar.value=d.far):d.isFogExp2&&(g.fogDensity.value=d.density)}function r(g,d,v,S,M){d.isNodeMaterial?d.uniformsNeedUpdate=!1:d.isMeshBasicMaterial?a(g,d):d.isMeshLambertMaterial?(a(g,d),d.envMap&&(g.envMapIntensity.value=d.envMapIntensity)):d.isMeshToonMaterial?(a(g,d),h(g,d)):d.isMeshPhongMaterial?(a(g,d),f(g,d),d.envMap&&(g.envMapIntensity.value=d.envMapIntensity)):d.isMeshStandardMaterial?(a(g,d),u(g,d),d.isMeshPhysicalMaterial&&m(g,d,M)):d.isMeshMatcapMaterial?(a(g,d),x(g,d)):d.isMeshDepthMaterial?a(g,d):d.isMeshDistanceMaterial?(a(g,d),E(g,d)):d.isMeshNormalMaterial?a(g,d):d.isLineBasicMaterial?(s(g,d),d.isLineDashedMaterial&&o(g,d)):d.isPointsMaterial?l(g,d,v,S):d.isSpriteMaterial?c(g,d):d.isShadowMaterial?(g.color.value.copy(d.color),g.opacity.value=d.opacity):d.isShaderMaterial&&(d.uniformsNeedUpdate=!1)}function a(g,d){g.opacity.value=d.opacity,d.color&&g.diffuse.value.copy(d.color),d.emissive&&g.emissive.value.copy(d.emissive).multiplyScalar(d.emissiveIntensity),d.map&&(g.map.value=d.map,n(d.map,g.mapTransform)),d.alphaMap&&(g.alphaMap.value=d.alphaMap,n(d.alphaMap,g.alphaMapTransform)),d.bumpMap&&(g.bumpMap.value=d.bumpMap,n(d.bumpMap,g.bumpMapTransform),g.bumpScale.value=d.bumpScale,d.side===mn&&(g.bumpScale.value*=-1)),d.normalMap&&(g.normalMap.value=d.normalMap,n(d.normalMap,g.normalMapTransform),g.normalScale.value.copy(d.normalScale),d.side===mn&&g.normalScale.value.negate()),d.displacementMap&&(g.displacementMap.value=d.displacementMap,n(d.displacementMap,g.displacementMapTransform),g.displacementScale.value=d.displacementScale,g.displacementBias.value=d.displacementBias),d.emissiveMap&&(g.emissiveMap.value=d.emissiveMap,n(d.emissiveMap,g.emissiveMapTransform)),d.specularMap&&(g.specularMap.value=d.specularMap,n(d.specularMap,g.specularMapTransform)),d.alphaTest>0&&(g.alphaTest.value=d.alphaTest);const v=e.get(d),S=v.envMap,M=v.envMapRotation;S&&(g.envMap.value=S,g.envMapRotation.value.setFromMatrix4(TA.makeRotationFromEuler(M)).transpose(),S.isCubeTexture&&S.isRenderTargetTexture===!1&&g.envMapRotation.value.premultiply(Vx),g.reflectivity.value=d.reflectivity,g.ior.value=d.ior,g.refractionRatio.value=d.refractionRatio),d.lightMap&&(g.lightMap.value=d.lightMap,g.lightMapIntensity.value=d.lightMapIntensity,n(d.lightMap,g.lightMapTransform)),d.aoMap&&(g.aoMap.value=d.aoMap,g.aoMapIntensity.value=d.aoMapIntensity,n(d.aoMap,g.aoMapTransform))}function s(g,d){g.diffuse.value.copy(d.color),g.opacity.value=d.opacity,d.map&&(g.map.value=d.map,n(d.map,g.mapTransform))}function o(g,d){g.dashSize.value=d.dashSize,g.totalSize.value=d.dashSize+d.gapSize,g.scale.value=d.scale}function l(g,d,v,S){g.diffuse.value.copy(d.color),g.opacity.value=d.opacity,g.size.value=d.size*v,g.scale.value=S*.5,d.map&&(g.map.value=d.map,n(d.map,g.uvTransform)),d.alphaMap&&(g.alphaMap.value=d.alphaMap,n(d.alphaMap,g.alphaMapTransform)),d.alphaTest>0&&(g.alphaTest.value=d.alphaTest)}function c(g,d){g.diffuse.value.copy(d.color),g.opacity.value=d.opacity,g.rotation.value=d.rotation,d.map&&(g.map.value=d.map,n(d.map,g.mapTransform)),d.alphaMap&&(g.alphaMap.value=d.alphaMap,n(d.alphaMap,g.alphaMapTransform)),d.alphaTest>0&&(g.alphaTest.value=d.alphaTest)}function f(g,d){g.specular.value.copy(d.specular),g.shininess.value=Math.max(d.shininess,1e-4)}function h(g,d){d.gradientMap&&(g.gradientMap.value=d.gradientMap)}function u(g,d){g.metalness.value=d.metalness,d.metalnessMap&&(g.metalnessMap.value=d.metalnessMap,n(d.metalnessMap,g.metalnessMapTransform)),g.roughness.value=d.roughness,d.roughnessMap&&(g.roughnessMap.value=d.roughnessMap,n(d.roughnessMap,g.roughnessMapTransform)),d.envMap&&(g.envMapIntensity.value=d.envMapIntensity)}function m(g,d,v){g.ior.value=d.ior,d.sheen>0&&(g.sheenColor.value.copy(d.sheenColor).multiplyScalar(d.sheen),g.sheenRoughness.value=d.sheenRoughness,d.sheenColorMap&&(g.sheenColorMap.value=d.sheenColorMap,n(d.sheenColorMap,g.sheenColorMapTransform)),d.sheenRoughnessMap&&(g.sheenRoughnessMap.value=d.sheenRoughnessMap,n(d.sheenRoughnessMap,g.sheenRoughnessMapTransform))),d.clearcoat>0&&(g.clearcoat.value=d.clearcoat,g.clearcoatRoughness.value=d.clearcoatRoughness,d.clearcoatMap&&(g.clearcoatMap.value=d.clearcoatMap,n(d.clearcoatMap,g.clearcoatMapTransform)),d.clearcoatRoughnessMap&&(g.clearcoatRoughnessMap.value=d.clearcoatRoughnessMap,n(d.clearcoatRoughnessMap,g.clearcoatRoughnessMapTransform)),d.clearcoatNormalMap&&(g.clearcoatNormalMap.value=d.clearcoatNormalMap,n(d.clearcoatNormalMap,g.clearcoatNormalMapTransform),g.clearcoatNormalScale.value.copy(d.clearcoatNormalScale),d.side===mn&&g.clearcoatNormalScale.value.negate())),d.dispersion>0&&(g.dispersion.value=d.dispersion),d.iridescence>0&&(g.iridescence.value=d.iridescence,g.iridescenceIOR.value=d.iridescenceIOR,g.iridescenceThicknessMinimum.value=d.iridescenceThicknessRange[0],g.iridescenceThicknessMaximum.value=d.iridescenceThicknessRange[1],d.iridescenceMap&&(g.iridescenceMap.value=d.iridescenceMap,n(d.iridescenceMap,g.iridescenceMapTransform)),d.iridescenceThicknessMap&&(g.iridescenceThicknessMap.value=d.iridescenceThicknessMap,n(d.iridescenceThicknessMap,g.iridescenceThicknessMapTransform))),d.transmission>0&&(g.transmission.value=d.transmission,g.transmissionSamplerMap.value=v.texture,g.transmissionSamplerSize.value.set(v.width,v.height),d.transmissionMap&&(g.transmissionMap.value=d.transmissionMap,n(d.transmissionMap,g.transmissionMapTransform)),g.thickness.value=d.thickness,d.thicknessMap&&(g.thicknessMap.value=d.thicknessMap,n(d.thicknessMap,g.thicknessMapTransform)),g.attenuationDistance.value=d.attenuationDistance,g.attenuationColor.value.copy(d.attenuationColor)),d.anisotropy>0&&(g.anisotropyVector.value.set(d.anisotropy*Math.cos(d.anisotropyRotation),d.anisotropy*Math.sin(d.anisotropyRotation)),d.anisotropyMap&&(g.anisotropyMap.value=d.anisotropyMap,n(d.anisotropyMap,g.anisotropyMapTransform))),g.specularIntensity.value=d.specularIntensity,g.specularColor.value.copy(d.specularColor),d.specularColorMap&&(g.specularColorMap.value=d.specularColorMap,n(d.specularColorMap,g.specularColorMapTransform)),d.specularIntensityMap&&(g.specularIntensityMap.value=d.specularIntensityMap,n(d.specularIntensityMap,g.specularIntensityMapTransform))}function x(g,d){d.matcap&&(g.matcap.value=d.matcap)}function E(g,d){const v=e.get(d).light;g.referencePosition.value.setFromMatrixPosition(v.matrixWorld),g.nearDistance.value=v.shadow.camera.near,g.farDistance.value=v.shadow.camera.far}return{refreshFogUniforms:i,refreshMaterialUniforms:r}}function CA(t,e,n,i){let r={},a={},s=[];const o=t.getParameter(t.MAX_UNIFORM_BUFFER_BINDINGS);function l(M,A){const T=A.program;i.uniformBlockBinding(M,T)}function c(M,A){let T=r[M.id];T===void 0&&(g(M),T=f(M),r[M.id]=T,M.addEventListener("dispose",v));const w=A.program;i.updateUBOMapping(M,w);const _=e.render.frame;a[M.id]!==_&&(u(M),a[M.id]=_)}function f(M){const A=h();M.__bindingPointIndex=A;const T=t.createBuffer(),w=M.__size,_=M.usage;return t.bindBuffer(t.UNIFORM_BUFFER,T),t.bufferData(t.UNIFORM_BUFFER,w,_),t.bindBuffer(t.UNIFORM_BUFFER,null),t.bindBufferBase(t.UNIFORM_BUFFER,A,T),T}function h(){for(let M=0;M<o;M++)if(s.indexOf(M)===-1)return s.push(M),M;return Ye("WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function u(M){const A=r[M.id],T=M.uniforms,w=M.__cache;t.bindBuffer(t.UNIFORM_BUFFER,A);for(let _=0,C=T.length;_<C;_++){const P=T[_];if(Array.isArray(P))for(let N=0,F=P.length;N<F;N++)m(P[N],_,N,w);else m(P,_,0,w)}t.bindBuffer(t.UNIFORM_BUFFER,null)}function m(M,A,T,w){if(E(M,A,T,w)===!0){const _=M.__offset,C=M.value;if(Array.isArray(C)){let P=0;for(let N=0;N<C.length;N++){const F=C[N],q=d(F);x(F,M.__data,P),typeof F!="number"&&typeof F!="boolean"&&!F.isMatrix3&&!ArrayBuffer.isView(F)&&(P+=q.storage/Float32Array.BYTES_PER_ELEMENT)}}else x(C,M.__data,0);t.bufferSubData(t.UNIFORM_BUFFER,_,M.__data)}}function x(M,A,T){typeof M=="number"||typeof M=="boolean"?A[0]=M:M.isMatrix3?(A[0]=M.elements[0],A[1]=M.elements[1],A[2]=M.elements[2],A[3]=0,A[4]=M.elements[3],A[5]=M.elements[4],A[6]=M.elements[5],A[7]=0,A[8]=M.elements[6],A[9]=M.elements[7],A[10]=M.elements[8],A[11]=0):ArrayBuffer.isView(M)?A.set(new M.constructor(M.buffer,M.byteOffset,A.length)):M.toArray(A,T)}function E(M,A,T,w){const _=M.value,C=A+"_"+T;if(w[C]===void 0)return typeof _=="number"||typeof _=="boolean"?w[C]=_:ArrayBuffer.isView(_)?w[C]=_.slice():w[C]=_.clone(),!0;{const P=w[C];if(typeof _=="number"||typeof _=="boolean"){if(P!==_)return w[C]=_,!0}else{if(ArrayBuffer.isView(_))return!0;if(P.equals(_)===!1)return P.copy(_),!0}}return!1}function g(M){const A=M.uniforms;let T=0;const w=16;for(let C=0,P=A.length;C<P;C++){const N=Array.isArray(A[C])?A[C]:[A[C]];for(let F=0,q=N.length;F<q;F++){const ie=N[F],k=Array.isArray(ie.value)?ie.value:[ie.value];for(let X=0,V=k.length;X<V;X++){const O=k[X],I=d(O),J=T%w,ae=J%I.boundary,le=J+ae;T+=ae,le!==0&&w-le<I.storage&&(T+=w-le),ie.__data=new Float32Array(I.storage/Float32Array.BYTES_PER_ELEMENT),ie.__offset=T,T+=I.storage}}}const _=T%w;return _>0&&(T+=w-_),M.__size=T,M.__cache={},this}function d(M){const A={boundary:0,storage:0};return typeof M=="number"||typeof M=="boolean"?(A.boundary=4,A.storage=4):M.isVector2?(A.boundary=8,A.storage=8):M.isVector3||M.isColor?(A.boundary=16,A.storage=12):M.isVector4?(A.boundary=16,A.storage=16):M.isMatrix3?(A.boundary=48,A.storage=48):M.isMatrix4?(A.boundary=64,A.storage=64):M.isTexture?De("WebGLRenderer: Texture samplers can not be part of an uniforms group."):ArrayBuffer.isView(M)?(A.boundary=16,A.storage=M.byteLength):De("WebGLRenderer: Unsupported uniform value type.",M),A}function v(M){const A=M.target;A.removeEventListener("dispose",v);const T=s.indexOf(A.__bindingPointIndex);s.splice(T,1),t.deleteBuffer(r[A.id]),delete r[A.id],delete a[A.id]}function S(){for(const M in r)t.deleteBuffer(r[M]);s=[],r={},a={}}return{bind:l,update:c,dispose:S}}const RA=new Uint16Array([12469,15057,12620,14925,13266,14620,13807,14376,14323,13990,14545,13625,14713,13328,14840,12882,14931,12528,14996,12233,15039,11829,15066,11525,15080,11295,15085,10976,15082,10705,15073,10495,13880,14564,13898,14542,13977,14430,14158,14124,14393,13732,14556,13410,14702,12996,14814,12596,14891,12291,14937,11834,14957,11489,14958,11194,14943,10803,14921,10506,14893,10278,14858,9960,14484,14039,14487,14025,14499,13941,14524,13740,14574,13468,14654,13106,14743,12678,14818,12344,14867,11893,14889,11509,14893,11180,14881,10751,14852,10428,14812,10128,14765,9754,14712,9466,14764,13480,14764,13475,14766,13440,14766,13347,14769,13070,14786,12713,14816,12387,14844,11957,14860,11549,14868,11215,14855,10751,14825,10403,14782,10044,14729,9651,14666,9352,14599,9029,14967,12835,14966,12831,14963,12804,14954,12723,14936,12564,14917,12347,14900,11958,14886,11569,14878,11247,14859,10765,14828,10401,14784,10011,14727,9600,14660,9289,14586,8893,14508,8533,15111,12234,15110,12234,15104,12216,15092,12156,15067,12010,15028,11776,14981,11500,14942,11205,14902,10752,14861,10393,14812,9991,14752,9570,14682,9252,14603,8808,14519,8445,14431,8145,15209,11449,15208,11451,15202,11451,15190,11438,15163,11384,15117,11274,15055,10979,14994,10648,14932,10343,14871,9936,14803,9532,14729,9218,14645,8742,14556,8381,14461,8020,14365,7603,15273,10603,15272,10607,15267,10619,15256,10631,15231,10614,15182,10535,15118,10389,15042,10167,14963,9787,14883,9447,14800,9115,14710,8665,14615,8318,14514,7911,14411,7507,14279,7198,15314,9675,15313,9683,15309,9712,15298,9759,15277,9797,15229,9773,15166,9668,15084,9487,14995,9274,14898,8910,14800,8539,14697,8234,14590,7790,14479,7409,14367,7067,14178,6621,15337,8619,15337,8631,15333,8677,15325,8769,15305,8871,15264,8940,15202,8909,15119,8775,15022,8565,14916,8328,14804,8009,14688,7614,14569,7287,14448,6888,14321,6483,14088,6171,15350,7402,15350,7419,15347,7480,15340,7613,15322,7804,15287,7973,15229,8057,15148,8012,15046,7846,14933,7611,14810,7357,14682,7069,14552,6656,14421,6316,14251,5948,14007,5528,15356,5942,15356,5977,15353,6119,15348,6294,15332,6551,15302,6824,15249,7044,15171,7122,15070,7050,14949,6861,14818,6611,14679,6349,14538,6067,14398,5651,14189,5311,13935,4958,15359,4123,15359,4153,15356,4296,15353,4646,15338,5160,15311,5508,15263,5829,15188,6042,15088,6094,14966,6001,14826,5796,14678,5543,14527,5287,14377,4985,14133,4586,13869,4257,15360,1563,15360,1642,15358,2076,15354,2636,15341,3350,15317,4019,15273,4429,15203,4732,15105,4911,14981,4932,14836,4818,14679,4621,14517,4386,14359,4156,14083,3795,13808,3437,15360,122,15360,137,15358,285,15355,636,15344,1274,15322,2177,15281,2765,15215,3223,15120,3451,14995,3569,14846,3567,14681,3466,14511,3305,14344,3121,14037,2800,13753,2467,15360,0,15360,1,15359,21,15355,89,15346,253,15325,479,15287,796,15225,1148,15133,1492,15008,1749,14856,1882,14685,1886,14506,1783,14324,1608,13996,1398,13702,1183]);let ri=null;function PA(){return ri===null&&(ri=new ME(RA,16,16,Yr,zi),ri.name="DFG_LUT",ri.minFilter=Jt,ri.magFilter=Jt,ri.wrapS=Pi,ri.wrapT=Pi,ri.generateMipmaps=!1,ri.needsUpdate=!0),ri}class NA{constructor(e={}){const{canvas:n=QM(),context:i=null,depth:r=!0,stencil:a=!1,alpha:s=!1,antialias:o=!1,premultipliedAlpha:l=!0,preserveDrawingBuffer:c=!1,powerPreference:f="default",failIfMajorPerformanceCaveat:h=!1,reversedDepthBuffer:u=!1,outputBufferType:m=Nn}=e;this.isWebGLRenderer=!0;let x;if(i!==null){if(typeof WebGLRenderingContext<"u"&&i instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");x=i.getContextAttributes().alpha}else x=s;const E=m,g=new Set([Ph,Rh,Ch]),d=new Set([Nn,gi,Zs,Qs,Th,Ah]),v=new Uint32Array(4),S=new Int32Array(4),M=new j;let A=null,T=null;const w=[],_=[];let C=null;this.domElement=n,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=hi,this.toneMappingExposure=1,this.transmissionResolutionScale=1;const P=this;let N=!1,F=null,q=null,ie=null,k=null;this._outputColorSpace=Cn;let X=0,V=0,O=null,I=-1,J=null;const ae=new Mt,le=new Mt;let Be=null;const Xe=new Qe(0);let ze=0,Q=n.width,oe=n.height,ee=1,Pe=null,Ue=null;const Ne=new Mt(0,0,Q,oe),Et=new Mt(0,0,Q,oe);let Ge=!1;const rt=new Rx;let Je=!1,$e=!1;const At=new Nt,Lt=new j,Ot=new Mt,Vt={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let xt=!1;function Ct(){return O===null?ee:1}let D=i;function ln(b,U){return n.getContext(b,U)}try{const b={alpha:!0,depth:r,stencil:a,antialias:o,premultipliedAlpha:l,preserveDrawingBuffer:c,powerPreference:f,failIfMajorPerformanceCaveat:h};if("setAttribute"in n&&n.setAttribute("data-engine",`three.js r${bh}`),n.addEventListener("webglcontextlost",vt,!1),n.addEventListener("webglcontextrestored",ot,!1),n.addEventListener("webglcontextcreationerror",Jn,!1),D===null){const U="webgl2";if(D=ln(U,b),D===null)throw ln(U)?new Error("THREE.WebGLRenderer: Error creating WebGL context with your selected attributes."):new Error("THREE.WebGLRenderer: Error creating WebGL context.")}}catch(b){throw Ye("WebGLRenderer: "+b.message),b}let et,R,y,B,W,K,ce,de,Z,ne,fe,Te,me,he,Re,Le,Fe,L,ue,te,pe,ve,re;function we(){et=new PT(D),et.init(),pe=new SA(D,et),R=new MT(D,et,e,pe),y=new vA(D,et),R.reversedDepthBuffer&&u&&y.buffers.depth.setReversed(!0),q=D.createFramebuffer(),ie=D.createFramebuffer(),k=D.createFramebuffer(),B=new DT(D),W=new aA,K=new yA(D,et,y,W,R,pe,B),ce=new RT(P),de=new OE(D),ve=new yT(D,de),Z=new NT(D,de,B,ve),ne=new UT(D,Z,de,ve,B),L=new IT(D,R,K),Re=new ET(W),fe=new rA(P,ce,et,R,ve,Re),Te=new AA(P,W),me=new oA,he=new hA(et),Fe=new vT(P,ce,y,ne,x,l),Le=new xA(P,ne,R),re=new CA(D,B,R,y),ue=new ST(D,et,B),te=new LT(D,et,B),B.programs=fe.programs,P.capabilities=R,P.extensions=et,P.properties=W,P.renderLists=me,P.shadowMap=Le,P.state=y,P.info=B}we(),E!==Nn&&(C=new OT(E,n.width,n.height,o,r,a));const Ee=new wA(P,D);this.xr=Ee,this.getContext=function(){return D},this.getContextAttributes=function(){return D.getContextAttributes()},this.forceContextLoss=function(){const b=et.get("WEBGL_lose_context");b&&b.loseContext()},this.forceContextRestore=function(){const b=et.get("WEBGL_lose_context");b&&b.restoreContext()},this.getPixelRatio=function(){return ee},this.setPixelRatio=function(b){b!==void 0&&(ee=b,this.setSize(Q,oe,!1))},this.getSize=function(b){return b.set(Q,oe)},this.setSize=function(b,U,$=!0){if(Ee.isPresenting){De("WebGLRenderer: Can't change size while VR device is presenting.");return}Q=b,oe=U,n.width=Math.floor(b*ee),n.height=Math.floor(U*ee),$===!0&&(n.style.width=b+"px",n.style.height=U+"px"),C!==null&&C.setSize(n.width,n.height),this.setViewport(0,0,b,U)},this.getDrawingBufferSize=function(b){return b.set(Q*ee,oe*ee).floor()},this.setDrawingBufferSize=function(b,U,$){Q=b,oe=U,ee=$,n.width=Math.floor(b*$),n.height=Math.floor(U*$),this.setViewport(0,0,b,U)},this.setEffects=function(b){if(E===Nn){Ye("WebGLRenderer: setEffects() requires outputBufferType set to HalfFloatType or FloatType.");return}if(b){for(let U=0;U<b.length;U++)if(b[U].isOutputPass===!0){De("WebGLRenderer: OutputPass is not needed in setEffects(). Tone mapping and color space conversion are applied automatically.");break}}C.setEffects(b||[])},this.getCurrentViewport=function(b){return b.copy(ae)},this.getViewport=function(b){return b.copy(Ne)},this.setViewport=function(b,U,$,H){b.isVector4?Ne.set(b.x,b.y,b.z,b.w):Ne.set(b,U,$,H),y.viewport(ae.copy(Ne).multiplyScalar(ee).round())},this.getScissor=function(b){return b.copy(Et)},this.setScissor=function(b,U,$,H){b.isVector4?Et.set(b.x,b.y,b.z,b.w):Et.set(b,U,$,H),y.scissor(le.copy(Et).multiplyScalar(ee).round())},this.getScissorTest=function(){return Ge},this.setScissorTest=function(b){y.setScissorTest(Ge=b)},this.setOpaqueSort=function(b){Pe=b},this.setTransparentSort=function(b){Ue=b},this.getClearColor=function(b){return b.copy(Fe.getClearColor())},this.setClearColor=function(){Fe.setClearColor(...arguments)},this.getClearAlpha=function(){return Fe.getClearAlpha()},this.setClearAlpha=function(){Fe.setClearAlpha(...arguments)},this.clear=function(b=!0,U=!0,$=!0){let H=0;if(b){let G=!1;if(O!==null){const xe=O.texture.format;G=g.has(xe)}if(G){const xe=O.texture.type,Se=d.has(xe),_e=Fe.getClearColor(),be=Fe.getClearAlpha(),Ae=_e.r,Oe=_e.g,Ve=_e.b;Se?(v[0]=Ae,v[1]=Oe,v[2]=Ve,v[3]=be,D.clearBufferuiv(D.COLOR,0,v)):(S[0]=Ae,S[1]=Oe,S[2]=Ve,S[3]=be,D.clearBufferiv(D.COLOR,0,S))}else H|=D.COLOR_BUFFER_BIT}U&&(H|=D.DEPTH_BUFFER_BIT,this.state.buffers.depth.setMask(!0)),$&&(H|=D.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),H!==0&&D.clear(H)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.setNodesHandler=function(b){b.setRenderer(this),F=b},this.dispose=function(){n.removeEventListener("webglcontextlost",vt,!1),n.removeEventListener("webglcontextrestored",ot,!1),n.removeEventListener("webglcontextcreationerror",Jn,!1),Fe.dispose(),me.dispose(),he.dispose(),W.dispose(),ce.dispose(),ne.dispose(),ve.dispose(),re.dispose(),fe.dispose(),Ee.dispose(),Ee.removeEventListener("sessionstart",Hh),Ee.removeEventListener("sessionend",Gh),wr.stop()};function vt(b){b.preventDefault(),bm("WebGLRenderer: Context Lost."),N=!0}function ot(){bm("WebGLRenderer: Context Restored."),N=!1;const b=B.autoReset,U=Le.enabled,$=Le.autoUpdate,H=Le.needsUpdate,G=Le.type;we(),B.autoReset=b,Le.enabled=U,Le.autoUpdate=$,Le.needsUpdate=H,Le.type=G}function Jn(b){Ye("WebGLRenderer: A WebGL context could not be created. Reason: ",b.statusMessage)}function ei(b){const U=b.target;U.removeEventListener("dispose",ei),Hx(U)}function Hx(b){Gx(b),W.remove(b)}function Gx(b){const U=W.get(b).programs;U!==void 0&&(U.forEach(function($){fe.releaseProgram($)}),b.isShaderMaterial&&fe.releaseShaderCache(b))}this.renderBufferDirect=function(b,U,$,H,G,xe){U===null&&(U=Vt);const Se=G.isMesh&&G.matrixWorld.determinantAffine()<0,_e=Xx(b,U,$,H,G);y.setMaterial(H,Se);let be=$.index,Ae=1;if(H.wireframe===!0){if(be=Z.getWireframeAttribute($),be===void 0)return;Ae=2}const Oe=$.drawRange,Ve=$.attributes.position;let Ce=Oe.start*Ae,it=(Oe.start+Oe.count)*Ae;xe!==null&&(Ce=Math.max(Ce,xe.start*Ae),it=Math.min(it,(xe.start+xe.count)*Ae)),be!==null?(Ce=Math.max(Ce,0),it=Math.min(it,be.count)):Ve!=null&&(Ce=Math.max(Ce,0),it=Math.min(it,Ve.count));const bt=it-Ce;if(bt<0||bt===1/0)return;ve.setup(G,H,_e,$,be);let yt,at=ue;if(be!==null&&(yt=de.get(be),at=te,at.setIndex(yt)),G.isMesh)H.wireframe===!0?(y.setLineWidth(H.wireframeLinewidth*Ct()),at.setMode(D.LINES)):at.setMode(D.TRIANGLES);else if(G.isLine){let Xt=H.linewidth;Xt===void 0&&(Xt=1),y.setLineWidth(Xt*Ct()),G.isLineSegments?at.setMode(D.LINES):G.isLineLoop?at.setMode(D.LINE_LOOP):at.setMode(D.LINE_STRIP)}else G.isPoints?at.setMode(D.POINTS):G.isSprite&&at.setMode(D.TRIANGLES);if(G.isBatchedMesh)if(et.get("WEBGL_multi_draw"))at.renderMultiDraw(G._multiDrawStarts,G._multiDrawCounts,G._multiDrawCount);else{const Xt=G._multiDrawStarts,ye=G._multiDrawCounts,gn=G._multiDrawCount,qe=be?de.get(be).bytesPerElement:1,Tn=W.get(H).currentProgram.getUniforms();for(let ti=0;ti<gn;ti++)Tn.setValue(D,"_gl_DrawID",ti),at.render(Xt[ti]/qe,ye[ti])}else if(G.isInstancedMesh)at.renderInstances(Ce,bt,G.count);else if($.isInstancedBufferGeometry){const Xt=$._maxInstanceCount!==void 0?$._maxInstanceCount:1/0,ye=Math.min($.instanceCount,Xt);at.renderInstances(Ce,bt,ye)}else at.render(Ce,bt)};function Vh(b,U,$){b.transparent===!0&&b.side===Ai&&b.forceSinglePass===!1?(b.side=mn,b.needsUpdate=!0,ho(b,U,$),b.side=yr,b.needsUpdate=!0,ho(b,U,$),b.side=Ai):ho(b,U,$)}this.compile=function(b,U,$=null){$===null&&($=b),T=he.get($),T.init(U),_.push(T),$.traverseVisible(function(G){G.isLight&&G.layers.test(U.layers)&&(T.pushLight(G),G.castShadow&&T.pushShadow(G))}),b!==$&&b.traverseVisible(function(G){G.isLight&&G.layers.test(U.layers)&&(T.pushLight(G),G.castShadow&&T.pushShadow(G))}),T.setupLights();const H=new Set;return b.traverse(function(G){if(!(G.isMesh||G.isPoints||G.isLine||G.isSprite))return;const xe=G.material;if(xe)if(Array.isArray(xe))for(let Se=0;Se<xe.length;Se++){const _e=xe[Se];Vh(_e,$,G),H.add(_e)}else Vh(xe,$,G),H.add(xe)}),T=_.pop(),H},this.compileAsync=function(b,U,$=null){const H=this.compile(b,U,$);return new Promise(G=>{function xe(){if(H.forEach(function(Se){W.get(Se).currentProgram.isReady()&&H.delete(Se)}),H.size===0){G(b);return}setTimeout(xe,10)}et.get("KHR_parallel_shader_compile")!==null?xe():setTimeout(xe,10)})};let Tc=null;function Wx(b){Tc&&Tc(b)}function Hh(){wr.stop()}function Gh(){wr.start()}const wr=new Ix;wr.setAnimationLoop(Wx),typeof self<"u"&&wr.setContext(self),this.setAnimationLoop=function(b){Tc=b,Ee.setAnimationLoop(b),b===null?wr.stop():wr.start()},Ee.addEventListener("sessionstart",Hh),Ee.addEventListener("sessionend",Gh),this.render=function(b,U){if(U!==void 0&&U.isCamera!==!0){Ye("WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(N===!0)return;F!==null&&F.renderStart(b,U);const $=Ee.enabled===!0&&Ee.isPresenting===!0,H=C!==null&&(O===null||$)&&C.begin(P,O);if(b.matrixWorldAutoUpdate===!0&&b.updateMatrixWorld(),U.parent===null&&U.matrixWorldAutoUpdate===!0&&U.updateMatrixWorld(),Ee.enabled===!0&&Ee.isPresenting===!0&&(C===null||C.isCompositing()===!1)&&(Ee.cameraAutoUpdate===!0&&Ee.updateCamera(U),U=Ee.getCamera()),b.isScene===!0&&b.onBeforeRender(P,b,U,O),T=he.get(b,_.length),T.init(U),T.state.textureUnits=K.getTextureUnits(),_.push(T),At.multiplyMatrices(U.projectionMatrix,U.matrixWorldInverse),rt.setFromProjectionMatrix(At,ui,U.reversedDepth),$e=this.localClippingEnabled,Je=Re.init(this.clippingPlanes,$e),A=me.get(b,w.length),A.init(),w.push(A),Ee.enabled===!0&&Ee.isPresenting===!0){const Se=P.xr.getDepthSensingMesh();Se!==null&&Ac(Se,U,-1/0,P.sortObjects)}Ac(b,U,0,P.sortObjects),A.finish(),P.sortObjects===!0&&A.sort(Pe,Ue,U.reversedDepth),xt=Ee.enabled===!1||Ee.isPresenting===!1||Ee.hasDepthSensing()===!1,xt&&Fe.addToRenderList(A,b),this.info.render.frame++,this.info.autoReset===!0&&this.info.reset(),Je===!0&&Re.beginShadows();const G=T.state.shadowsArray;if(Le.render(G,b,U),Je===!0&&Re.endShadows(),(H&&C.hasRenderPass())===!1){const Se=A.opaque,_e=A.transmissive;if(T.setupLights(),U.isArrayCamera){const be=U.cameras;if(_e.length>0)for(let Ae=0,Oe=be.length;Ae<Oe;Ae++){const Ve=be[Ae];jh(Se,_e,b,Ve)}xt&&Fe.render(b);for(let Ae=0,Oe=be.length;Ae<Oe;Ae++){const Ve=be[Ae];Wh(A,b,Ve,Ve.viewport)}}else _e.length>0&&jh(Se,_e,b,U),xt&&Fe.render(b),Wh(A,b,U)}O!==null&&V===0&&(K.updateMultisampleRenderTarget(O),K.updateRenderTargetMipmap(O)),H&&C.end(P),b.isScene===!0&&b.onAfterRender(P,b,U),ve.resetDefaultState(),I=-1,J=null,_.pop(),_.length>0?(T=_[_.length-1],K.setTextureUnits(T.state.textureUnits),Je===!0&&Re.setGlobalState(P.clippingPlanes,T.state.camera)):T=null,w.pop(),w.length>0?A=w[w.length-1]:A=null,F!==null&&F.renderEnd()};function Ac(b,U,$,H){if(b.visible===!1)return;if(b.layers.test(U.layers)){if(b.isGroup)$=b.renderOrder;else if(b.isLOD)b.autoUpdate===!0&&b.update(U);else if(b.isLightProbeGrid)T.pushLightProbeGrid(b);else if(b.isLight)T.pushLight(b),b.castShadow&&T.pushShadow(b);else if(b.isSprite){if(!b.frustumCulled||rt.intersectsSprite(b)){H&&Ot.setFromMatrixPosition(b.matrixWorld).applyMatrix4(At);const Se=ne.update(b),_e=b.material;_e.visible&&A.push(b,Se,_e,$,Ot.z,null)}}else if((b.isMesh||b.isLine||b.isPoints)&&(!b.frustumCulled||rt.intersectsObject(b))){const Se=ne.update(b),_e=b.material;if(H&&(b.boundingSphere!==void 0?(b.boundingSphere===null&&b.computeBoundingSphere(),Ot.copy(b.boundingSphere.center)):(Se.boundingSphere===null&&Se.computeBoundingSphere(),Ot.copy(Se.boundingSphere.center)),Ot.applyMatrix4(b.matrixWorld).applyMatrix4(At)),Array.isArray(_e)){const be=Se.groups;for(let Ae=0,Oe=be.length;Ae<Oe;Ae++){const Ve=be[Ae],Ce=_e[Ve.materialIndex];Ce&&Ce.visible&&A.push(b,Se,Ce,$,Ot.z,Ve)}}else _e.visible&&A.push(b,Se,_e,$,Ot.z,null)}}const xe=b.children;for(let Se=0,_e=xe.length;Se<_e;Se++)Ac(xe[Se],U,$,H)}function Wh(b,U,$,H){const{opaque:G,transmissive:xe,transparent:Se}=b;T.setupLightsView($),Je===!0&&Re.setGlobalState(P.clippingPlanes,$),H&&y.viewport(ae.copy(H)),G.length>0&&fo(G,U,$),xe.length>0&&fo(xe,U,$),Se.length>0&&fo(Se,U,$),y.buffers.depth.setTest(!0),y.buffers.depth.setMask(!0),y.buffers.color.setMask(!0),y.setPolygonOffset(!1)}function jh(b,U,$,H){if(($.isScene===!0?$.overrideMaterial:null)!==null)return;if(T.state.transmissionRenderTarget[H.id]===void 0){const Ce=et.has("EXT_color_buffer_half_float")||et.has("EXT_color_buffer_float");T.state.transmissionRenderTarget[H.id]=new pi(1,1,{generateMipmaps:!0,type:Ce?zi:Nn,minFilter:Br,samples:Math.max(4,R.samples),stencilBuffer:a,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:We.workingColorSpace})}const xe=T.state.transmissionRenderTarget[H.id],Se=H.viewport||ae;xe.setSize(Se.z*P.transmissionResolutionScale,Se.w*P.transmissionResolutionScale);const _e=P.getRenderTarget(),be=P.getActiveCubeFace(),Ae=P.getActiveMipmapLevel();P.setRenderTarget(xe),P.getClearColor(Xe),ze=P.getClearAlpha(),ze<1&&P.setClearColor(16777215,.5),P.clear(),xt&&Fe.render($);const Oe=P.toneMapping;P.toneMapping=hi;const Ve=H.viewport;if(H.viewport!==void 0&&(H.viewport=void 0),T.setupLightsView(H),Je===!0&&Re.setGlobalState(P.clippingPlanes,H),fo(b,$,H),K.updateMultisampleRenderTarget(xe),K.updateRenderTargetMipmap(xe),et.has("WEBGL_multisampled_render_to_texture")===!1){let Ce=!1;for(let it=0,bt=U.length;it<bt;it++){const yt=U[it],{object:at,geometry:Xt,material:ye,group:gn}=yt;if(ye.side===Ai&&at.layers.test(H.layers)){const qe=ye.side;ye.side=mn,ye.needsUpdate=!0,Xh(at,$,H,Xt,ye,gn),ye.side=qe,ye.needsUpdate=!0,Ce=!0}}Ce===!0&&(K.updateMultisampleRenderTarget(xe),K.updateRenderTargetMipmap(xe))}P.setRenderTarget(_e,be,Ae),P.setClearColor(Xe,ze),Ve!==void 0&&(H.viewport=Ve),P.toneMapping=Oe}function fo(b,U,$){const H=U.isScene===!0?U.overrideMaterial:null;for(let G=0,xe=b.length;G<xe;G++){const Se=b[G],{object:_e,geometry:be,group:Ae}=Se;let Oe=Se.material;Oe.allowOverride===!0&&H!==null&&(Oe=H),_e.layers.test($.layers)&&Xh(_e,U,$,be,Oe,Ae)}}function Xh(b,U,$,H,G,xe){b.onBeforeRender(P,U,$,H,G,xe),b.modelViewMatrix.multiplyMatrices($.matrixWorldInverse,b.matrixWorld),b.normalMatrix.getNormalMatrix(b.modelViewMatrix),G.onBeforeRender(P,U,$,H,b,xe),G.transparent===!0&&G.side===Ai&&G.forceSinglePass===!1?(G.side=mn,G.needsUpdate=!0,P.renderBufferDirect($,U,H,G,b,xe),G.side=yr,G.needsUpdate=!0,P.renderBufferDirect($,U,H,G,b,xe),G.side=Ai):P.renderBufferDirect($,U,H,G,b,xe),b.onAfterRender(P,U,$,H,G,xe)}function ho(b,U,$){U.isScene!==!0&&(U=Vt);const H=W.get(b),G=T.state.lights,xe=T.state.shadowsArray,Se=G.state.version,_e=fe.getParameters(b,G.state,xe,U,$,T.state.lightProbeGridArray),be=fe.getProgramCacheKey(_e);let Ae=H.programs;H.environment=b.isMeshStandardMaterial||b.isMeshLambertMaterial||b.isMeshPhongMaterial?U.environment:null,H.fog=U.fog;const Oe=b.isMeshStandardMaterial||b.isMeshLambertMaterial&&!b.envMap||b.isMeshPhongMaterial&&!b.envMap;H.envMap=ce.get(b.envMap||H.environment,Oe),H.envMapRotation=H.environment!==null&&b.envMap===null?U.environmentRotation:b.envMapRotation,Ae===void 0&&(b.addEventListener("dispose",ei),Ae=new Map,H.programs=Ae);let Ve=Ae.get(be);if(Ve!==void 0){if(H.currentProgram===Ve&&H.lightsStateVersion===Se)return qh(b,_e),Ve}else _e.uniforms=fe.getUniforms(b),F!==null&&b.isNodeMaterial&&F.build(b,$,_e),b.onBeforeCompile(_e,P),Ve=fe.acquireProgram(_e,be),Ae.set(be,Ve),H.uniforms=_e.uniforms;const Ce=H.uniforms;return(!b.isShaderMaterial&&!b.isRawShaderMaterial||b.clipping===!0)&&(Ce.clippingPlanes=Re.uniform),qh(b,_e),H.needsLights=qx(b),H.lightsStateVersion=Se,H.needsLights&&(Ce.ambientLightColor.value=G.state.ambient,Ce.lightProbe.value=G.state.probe,Ce.directionalLights.value=G.state.directional,Ce.directionalLightShadows.value=G.state.directionalShadow,Ce.spotLights.value=G.state.spot,Ce.spotLightShadows.value=G.state.spotShadow,Ce.rectAreaLights.value=G.state.rectArea,Ce.ltc_1.value=G.state.rectAreaLTC1,Ce.ltc_2.value=G.state.rectAreaLTC2,Ce.pointLights.value=G.state.point,Ce.pointLightShadows.value=G.state.pointShadow,Ce.hemisphereLights.value=G.state.hemi,Ce.directionalShadowMatrix.value=G.state.directionalShadowMatrix,Ce.spotLightMatrix.value=G.state.spotLightMatrix,Ce.spotLightMap.value=G.state.spotLightMap,Ce.pointShadowMatrix.value=G.state.pointShadowMatrix),H.lightProbeGrid=T.state.lightProbeGridArray.length>0,H.currentProgram=Ve,H.uniformsList=null,Ve}function $h(b){if(b.uniformsList===null){const U=b.currentProgram.getUniforms();b.uniformsList=Sl.seqWithValue(U.seq,b.uniforms)}return b.uniformsList}function qh(b,U){const $=W.get(b);$.outputColorSpace=U.outputColorSpace,$.batching=U.batching,$.batchingColor=U.batchingColor,$.instancing=U.instancing,$.instancingColor=U.instancingColor,$.instancingMorph=U.instancingMorph,$.skinning=U.skinning,$.morphTargets=U.morphTargets,$.morphNormals=U.morphNormals,$.morphColors=U.morphColors,$.morphTargetsCount=U.morphTargetsCount,$.numClippingPlanes=U.numClippingPlanes,$.numIntersection=U.numClipIntersection,$.vertexAlphas=U.vertexAlphas,$.vertexTangents=U.vertexTangents,$.toneMapping=U.toneMapping}function jx(b,U){if(b.length===0)return null;if(b.length===1)return b[0].texture!==null?b[0]:null;M.setFromMatrixPosition(U.matrixWorld);for(let $=0,H=b.length;$<H;$++){const G=b[$];if(G.texture!==null&&G.boundingBox.containsPoint(M))return G}return null}function Xx(b,U,$,H,G){U.isScene!==!0&&(U=Vt),K.resetTextureUnits();const xe=U.fog,Se=H.isMeshStandardMaterial||H.isMeshLambertMaterial||H.isMeshPhongMaterial?U.environment:null,_e=O===null?P.outputColorSpace:O.isXRRenderTarget===!0?O.texture.colorSpace:We.workingColorSpace,be=H.isMeshStandardMaterial||H.isMeshLambertMaterial&&!H.envMap||H.isMeshPhongMaterial&&!H.envMap,Ae=ce.get(H.envMap||Se,be),Oe=H.vertexColors===!0&&!!$.attributes.color&&$.attributes.color.itemSize===4,Ve=!!$.attributes.tangent&&(!!H.normalMap||H.anisotropy>0),Ce=!!$.morphAttributes.position,it=!!$.morphAttributes.normal,bt=!!$.morphAttributes.color;let yt=hi;H.toneMapped&&(O===null||O.isXRRenderTarget===!0)&&(yt=P.toneMapping);const at=$.morphAttributes.position||$.morphAttributes.normal||$.morphAttributes.color,Xt=at!==void 0?at.length:0,ye=W.get(H),gn=T.state.lights;if(Je===!0&&($e===!0||b!==J)){const lt=b===J&&H.id===I;Re.setState(H,b,lt)}let qe=!1;H.version===ye.__version?(ye.needsLights&&ye.lightsStateVersion!==gn.state.version||ye.outputColorSpace!==_e||G.isBatchedMesh&&ye.batching===!1||!G.isBatchedMesh&&ye.batching===!0||G.isBatchedMesh&&ye.batchingColor===!0&&G.colorTexture===null||G.isBatchedMesh&&ye.batchingColor===!1&&G.colorTexture!==null||G.isInstancedMesh&&ye.instancing===!1||!G.isInstancedMesh&&ye.instancing===!0||G.isSkinnedMesh&&ye.skinning===!1||!G.isSkinnedMesh&&ye.skinning===!0||G.isInstancedMesh&&ye.instancingColor===!0&&G.instanceColor===null||G.isInstancedMesh&&ye.instancingColor===!1&&G.instanceColor!==null||G.isInstancedMesh&&ye.instancingMorph===!0&&G.morphTexture===null||G.isInstancedMesh&&ye.instancingMorph===!1&&G.morphTexture!==null||ye.envMap!==Ae||H.fog===!0&&ye.fog!==xe||ye.numClippingPlanes!==void 0&&(ye.numClippingPlanes!==Re.numPlanes||ye.numIntersection!==Re.numIntersection)||ye.vertexAlphas!==Oe||ye.vertexTangents!==Ve||ye.morphTargets!==Ce||ye.morphNormals!==it||ye.morphColors!==bt||ye.toneMapping!==yt||ye.morphTargetsCount!==Xt||!!ye.lightProbeGrid!=T.state.lightProbeGridArray.length>0)&&(qe=!0):(qe=!0,ye.__version=H.version);let Tn=ye.currentProgram;qe===!0&&(Tn=ho(H,U,G),F&&H.isNodeMaterial&&F.onUpdateProgram(H,Tn,ye));let ti=!1,ji=!1,ta=!1;const st=Tn.getUniforms(),wt=ye.uniforms;if(y.useProgram(Tn.program)&&(ti=!0,ji=!0,ta=!0),H.id!==I&&(I=H.id,ji=!0),ye.needsLights){const lt=jx(T.state.lightProbeGridArray,G);ye.lightProbeGrid!==lt&&(ye.lightProbeGrid=lt,ji=!0)}if(ti||J!==b){y.buffers.depth.getReversed()&&b.reversedDepth!==!0&&(b._reversedDepth=!0,b.updateProjectionMatrix()),st.setValue(D,"projectionMatrix",b.projectionMatrix),st.setValue(D,"viewMatrix",b.matrixWorldInverse);const $i=st.map.cameraPosition;$i!==void 0&&$i.setValue(D,Lt.setFromMatrixPosition(b.matrixWorld)),R.logarithmicDepthBuffer&&st.setValue(D,"logDepthBufFC",2/(Math.log(b.far+1)/Math.LN2)),(H.isMeshPhongMaterial||H.isMeshToonMaterial||H.isMeshLambertMaterial||H.isMeshBasicMaterial||H.isMeshStandardMaterial||H.isShaderMaterial)&&st.setValue(D,"isOrthographic",b.isOrthographicCamera===!0),J!==b&&(J=b,ji=!0,ta=!0)}if(ye.needsLights&&(gn.state.directionalShadowMap.length>0&&st.setValue(D,"directionalShadowMap",gn.state.directionalShadowMap,K),gn.state.spotShadowMap.length>0&&st.setValue(D,"spotShadowMap",gn.state.spotShadowMap,K),gn.state.pointShadowMap.length>0&&st.setValue(D,"pointShadowMap",gn.state.pointShadowMap,K)),G.isSkinnedMesh){st.setOptional(D,G,"bindMatrix"),st.setOptional(D,G,"bindMatrixInverse");const lt=G.skeleton;lt&&(lt.boneTexture===null&&lt.computeBoneTexture(),st.setValue(D,"boneTexture",lt.boneTexture,K))}G.isBatchedMesh&&(st.setOptional(D,G,"batchingTexture"),st.setValue(D,"batchingTexture",G._matricesTexture,K),st.setOptional(D,G,"batchingIdTexture"),st.setValue(D,"batchingIdTexture",G._indirectTexture,K),st.setOptional(D,G,"batchingColorTexture"),G._colorsTexture!==null&&st.setValue(D,"batchingColorTexture",G._colorsTexture,K));const Xi=$.morphAttributes;if((Xi.position!==void 0||Xi.normal!==void 0||Xi.color!==void 0)&&L.update(G,$,Tn),(ji||ye.receiveShadow!==G.receiveShadow)&&(ye.receiveShadow=G.receiveShadow,st.setValue(D,"receiveShadow",G.receiveShadow)),(H.isMeshStandardMaterial||H.isMeshLambertMaterial||H.isMeshPhongMaterial)&&H.envMap===null&&U.environment!==null&&(wt.envMapIntensity.value=U.environmentIntensity),wt.dfgLUT!==void 0&&(wt.dfgLUT.value=PA()),ji){if(st.setValue(D,"toneMappingExposure",P.toneMappingExposure),ye.needsLights&&$x(wt,ta),xe&&H.fog===!0&&Te.refreshFogUniforms(wt,xe),Te.refreshMaterialUniforms(wt,H,ee,oe,T.state.transmissionRenderTarget[b.id]),ye.needsLights&&ye.lightProbeGrid){const lt=ye.lightProbeGrid;wt.probesSH.value=lt.texture,wt.probesMin.value.copy(lt.boundingBox.min),wt.probesMax.value.copy(lt.boundingBox.max),wt.probesResolution.value.copy(lt.resolution)}Sl.upload(D,$h(ye),wt,K)}if(H.isShaderMaterial&&H.uniformsNeedUpdate===!0&&(Sl.upload(D,$h(ye),wt,K),H.uniformsNeedUpdate=!1),H.isSpriteMaterial&&st.setValue(D,"center",G.center),st.setValue(D,"modelViewMatrix",G.modelViewMatrix),st.setValue(D,"normalMatrix",G.normalMatrix),st.setValue(D,"modelMatrix",G.matrixWorld),H.uniformsGroups!==void 0){const lt=H.uniformsGroups;for(let $i=0,na=lt.length;$i<na;$i++){const Yh=lt[$i];re.update(Yh,Tn),re.bind(Yh,Tn)}}return Tn}function $x(b,U){b.ambientLightColor.needsUpdate=U,b.lightProbe.needsUpdate=U,b.directionalLights.needsUpdate=U,b.directionalLightShadows.needsUpdate=U,b.pointLights.needsUpdate=U,b.pointLightShadows.needsUpdate=U,b.spotLights.needsUpdate=U,b.spotLightShadows.needsUpdate=U,b.rectAreaLights.needsUpdate=U,b.hemisphereLights.needsUpdate=U}function qx(b){return b.isMeshLambertMaterial||b.isMeshToonMaterial||b.isMeshPhongMaterial||b.isMeshStandardMaterial||b.isShadowMaterial||b.isShaderMaterial&&b.lights===!0}this.getActiveCubeFace=function(){return X},this.getActiveMipmapLevel=function(){return V},this.getRenderTarget=function(){return O},this.setRenderTargetTextures=function(b,U,$){const H=W.get(b);H.__autoAllocateDepthBuffer=b.resolveDepthBuffer===!1,H.__autoAllocateDepthBuffer===!1&&(H.__useRenderToTexture=!1),W.get(b.texture).__webglTexture=U,W.get(b.depthTexture).__webglTexture=H.__autoAllocateDepthBuffer?void 0:$,H.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(b,U){const $=W.get(b);$.__webglFramebuffer=U,$.__useDefaultFramebuffer=U===void 0},this.setRenderTarget=function(b,U=0,$=0){O=b,X=U,V=$;let H=null,G=!1,xe=!1;if(b){const _e=W.get(b);if(_e.__useDefaultFramebuffer!==void 0){y.bindFramebuffer(D.FRAMEBUFFER,_e.__webglFramebuffer),ae.copy(b.viewport),le.copy(b.scissor),Be=b.scissorTest,y.viewport(ae),y.scissor(le),y.setScissorTest(Be),I=-1;return}else if(_e.__webglFramebuffer===void 0)K.setupRenderTarget(b);else if(_e.__hasExternalTextures)K.rebindTextures(b,W.get(b.texture).__webglTexture,W.get(b.depthTexture).__webglTexture);else if(b.depthBuffer){const Oe=b.depthTexture;if(_e.__boundDepthTexture!==Oe){if(Oe!==null&&W.has(Oe)&&(b.width!==Oe.image.width||b.height!==Oe.image.height))throw new Error("THREE.WebGLRenderer: Attached DepthTexture is initialized to the incorrect size.");K.setupDepthRenderbuffer(b)}}const be=b.texture;(be.isData3DTexture||be.isDataArrayTexture||be.isCompressedArrayTexture)&&(xe=!0);const Ae=W.get(b).__webglFramebuffer;b.isWebGLCubeRenderTarget?(Array.isArray(Ae[U])?H=Ae[U][$]:H=Ae[U],G=!0):b.samples>0&&K.useMultisampledRTT(b)===!1?H=W.get(b).__webglMultisampledFramebuffer:Array.isArray(Ae)?H=Ae[$]:H=Ae,ae.copy(b.viewport),le.copy(b.scissor),Be=b.scissorTest}else ae.copy(Ne).multiplyScalar(ee).floor(),le.copy(Et).multiplyScalar(ee).floor(),Be=Ge;if($!==0&&(H=q),y.bindFramebuffer(D.FRAMEBUFFER,H)&&y.drawBuffers(b,H),y.viewport(ae),y.scissor(le),y.setScissorTest(Be),G){const _e=W.get(b.texture);D.framebufferTexture2D(D.FRAMEBUFFER,D.COLOR_ATTACHMENT0,D.TEXTURE_CUBE_MAP_POSITIVE_X+U,_e.__webglTexture,$)}else if(xe){const _e=U;for(let be=0;be<b.textures.length;be++){const Ae=W.get(b.textures[be]);D.framebufferTextureLayer(D.FRAMEBUFFER,D.COLOR_ATTACHMENT0+be,Ae.__webglTexture,$,_e)}}else if(b!==null&&$!==0){const _e=W.get(b.texture);D.framebufferTexture2D(D.FRAMEBUFFER,D.COLOR_ATTACHMENT0,D.TEXTURE_2D,_e.__webglTexture,$)}I=-1},this.readRenderTargetPixels=function(b,U,$,H,G,xe,Se,_e=0){if(!(b&&b.isWebGLRenderTarget)){Ye("WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let be=W.get(b).__webglFramebuffer;if(b.isWebGLCubeRenderTarget&&Se!==void 0&&(be=be[Se]),be){y.bindFramebuffer(D.FRAMEBUFFER,be);try{const Ae=b.textures[_e],Oe=Ae.format,Ve=Ae.type;if(b.textures.length>1&&D.readBuffer(D.COLOR_ATTACHMENT0+_e),!R.textureFormatReadable(Oe)){Ye("WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!R.textureTypeReadable(Ve)){Ye("WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}U>=0&&U<=b.width-H&&$>=0&&$<=b.height-G&&D.readPixels(U,$,H,G,pe.convert(Oe),pe.convert(Ve),xe)}finally{const Ae=O!==null?W.get(O).__webglFramebuffer:null;y.bindFramebuffer(D.FRAMEBUFFER,Ae)}}},this.readRenderTargetPixelsAsync=async function(b,U,$,H,G,xe,Se,_e=0){if(!(b&&b.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let be=W.get(b).__webglFramebuffer;if(b.isWebGLCubeRenderTarget&&Se!==void 0&&(be=be[Se]),be)if(U>=0&&U<=b.width-H&&$>=0&&$<=b.height-G){y.bindFramebuffer(D.FRAMEBUFFER,be);const Ae=b.textures[_e],Oe=Ae.format,Ve=Ae.type;if(b.textures.length>1&&D.readBuffer(D.COLOR_ATTACHMENT0+_e),!R.textureFormatReadable(Oe))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!R.textureTypeReadable(Ve))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");const Ce=D.createBuffer();D.bindBuffer(D.PIXEL_PACK_BUFFER,Ce),D.bufferData(D.PIXEL_PACK_BUFFER,xe.byteLength,D.STREAM_READ),D.readPixels(U,$,H,G,pe.convert(Oe),pe.convert(Ve),0);const it=O!==null?W.get(O).__webglFramebuffer:null;y.bindFramebuffer(D.FRAMEBUFFER,it);const bt=D.fenceSync(D.SYNC_GPU_COMMANDS_COMPLETE,0);return D.flush(),await JM(D,bt,4),D.bindBuffer(D.PIXEL_PACK_BUFFER,Ce),D.getBufferSubData(D.PIXEL_PACK_BUFFER,0,xe),D.deleteBuffer(Ce),D.deleteSync(bt),xe}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(b,U=null,$=0){const H=Math.pow(2,-$),G=Math.floor(b.image.width*H),xe=Math.floor(b.image.height*H),Se=U!==null?U.x:0,_e=U!==null?U.y:0;K.setTexture2D(b,0),D.copyTexSubImage2D(D.TEXTURE_2D,$,0,0,Se,_e,G,xe),y.unbindTexture()},this.copyTextureToTexture=function(b,U,$=null,H=null,G=0,xe=0){let Se,_e,be,Ae,Oe,Ve,Ce,it,bt;const yt=b.isCompressedTexture?b.mipmaps[xe]:b.image;if($!==null)Se=$.max.x-$.min.x,_e=$.max.y-$.min.y,be=$.isBox3?$.max.z-$.min.z:1,Ae=$.min.x,Oe=$.min.y,Ve=$.isBox3?$.min.z:0;else{const wt=Math.pow(2,-G);Se=Math.floor(yt.width*wt),_e=Math.floor(yt.height*wt),b.isDataArrayTexture?be=yt.depth:b.isData3DTexture?be=Math.floor(yt.depth*wt):be=1,Ae=0,Oe=0,Ve=0}H!==null?(Ce=H.x,it=H.y,bt=H.z):(Ce=0,it=0,bt=0);const at=pe.convert(U.format),Xt=pe.convert(U.type);let ye;U.isData3DTexture?(K.setTexture3D(U,0),ye=D.TEXTURE_3D):U.isDataArrayTexture||U.isCompressedArrayTexture?(K.setTexture2DArray(U,0),ye=D.TEXTURE_2D_ARRAY):(K.setTexture2D(U,0),ye=D.TEXTURE_2D),y.activeTexture(D.TEXTURE0),y.pixelStorei(D.UNPACK_FLIP_Y_WEBGL,U.flipY),y.pixelStorei(D.UNPACK_PREMULTIPLY_ALPHA_WEBGL,U.premultiplyAlpha),y.pixelStorei(D.UNPACK_ALIGNMENT,U.unpackAlignment);const gn=y.getParameter(D.UNPACK_ROW_LENGTH),qe=y.getParameter(D.UNPACK_IMAGE_HEIGHT),Tn=y.getParameter(D.UNPACK_SKIP_PIXELS),ti=y.getParameter(D.UNPACK_SKIP_ROWS),ji=y.getParameter(D.UNPACK_SKIP_IMAGES);y.pixelStorei(D.UNPACK_ROW_LENGTH,yt.width),y.pixelStorei(D.UNPACK_IMAGE_HEIGHT,yt.height),y.pixelStorei(D.UNPACK_SKIP_PIXELS,Ae),y.pixelStorei(D.UNPACK_SKIP_ROWS,Oe),y.pixelStorei(D.UNPACK_SKIP_IMAGES,Ve);const ta=b.isDataArrayTexture||b.isData3DTexture,st=U.isDataArrayTexture||U.isData3DTexture;if(b.isDepthTexture){const wt=W.get(b),Xi=W.get(U),lt=W.get(wt.__renderTarget),$i=W.get(Xi.__renderTarget);y.bindFramebuffer(D.READ_FRAMEBUFFER,lt.__webglFramebuffer),y.bindFramebuffer(D.DRAW_FRAMEBUFFER,$i.__webglFramebuffer);for(let na=0;na<be;na++)ta&&(D.framebufferTextureLayer(D.READ_FRAMEBUFFER,D.COLOR_ATTACHMENT0,W.get(b).__webglTexture,G,Ve+na),D.framebufferTextureLayer(D.DRAW_FRAMEBUFFER,D.COLOR_ATTACHMENT0,W.get(U).__webglTexture,xe,bt+na)),D.blitFramebuffer(Ae,Oe,Se,_e,Ce,it,Se,_e,D.DEPTH_BUFFER_BIT,D.NEAREST);y.bindFramebuffer(D.READ_FRAMEBUFFER,null),y.bindFramebuffer(D.DRAW_FRAMEBUFFER,null)}else if(G!==0||b.isRenderTargetTexture||W.has(b)){const wt=W.get(b),Xi=W.get(U);y.bindFramebuffer(D.READ_FRAMEBUFFER,ie),y.bindFramebuffer(D.DRAW_FRAMEBUFFER,k);for(let lt=0;lt<be;lt++)ta?D.framebufferTextureLayer(D.READ_FRAMEBUFFER,D.COLOR_ATTACHMENT0,wt.__webglTexture,G,Ve+lt):D.framebufferTexture2D(D.READ_FRAMEBUFFER,D.COLOR_ATTACHMENT0,D.TEXTURE_2D,wt.__webglTexture,G),st?D.framebufferTextureLayer(D.DRAW_FRAMEBUFFER,D.COLOR_ATTACHMENT0,Xi.__webglTexture,xe,bt+lt):D.framebufferTexture2D(D.DRAW_FRAMEBUFFER,D.COLOR_ATTACHMENT0,D.TEXTURE_2D,Xi.__webglTexture,xe),G!==0?D.blitFramebuffer(Ae,Oe,Se,_e,Ce,it,Se,_e,D.COLOR_BUFFER_BIT,D.NEAREST):st?D.copyTexSubImage3D(ye,xe,Ce,it,bt+lt,Ae,Oe,Se,_e):D.copyTexSubImage2D(ye,xe,Ce,it,Ae,Oe,Se,_e);y.bindFramebuffer(D.READ_FRAMEBUFFER,null),y.bindFramebuffer(D.DRAW_FRAMEBUFFER,null)}else st?b.isDataTexture||b.isData3DTexture?D.texSubImage3D(ye,xe,Ce,it,bt,Se,_e,be,at,Xt,yt.data):U.isCompressedArrayTexture?D.compressedTexSubImage3D(ye,xe,Ce,it,bt,Se,_e,be,at,yt.data):D.texSubImage3D(ye,xe,Ce,it,bt,Se,_e,be,at,Xt,yt):b.isDataTexture?D.texSubImage2D(D.TEXTURE_2D,xe,Ce,it,Se,_e,at,Xt,yt.data):b.isCompressedTexture?D.compressedTexSubImage2D(D.TEXTURE_2D,xe,Ce,it,yt.width,yt.height,at,yt.data):D.texSubImage2D(D.TEXTURE_2D,xe,Ce,it,Se,_e,at,Xt,yt);y.pixelStorei(D.UNPACK_ROW_LENGTH,gn),y.pixelStorei(D.UNPACK_IMAGE_HEIGHT,qe),y.pixelStorei(D.UNPACK_SKIP_PIXELS,Tn),y.pixelStorei(D.UNPACK_SKIP_ROWS,ti),y.pixelStorei(D.UNPACK_SKIP_IMAGES,ji),xe===0&&U.generateMipmaps&&D.generateMipmap(ye),y.unbindTexture()},this.initRenderTarget=function(b){W.get(b).__webglFramebuffer===void 0&&K.setupRenderTarget(b)},this.initTexture=function(b){b.isCubeTexture?K.setTextureCube(b,0):b.isData3DTexture?K.setTexture3D(b,0):b.isDataArrayTexture||b.isCompressedArrayTexture?K.setTexture2DArray(b,0):K.setTexture2D(b,0),y.unbindTexture()},this.resetState=function(){X=0,V=0,O=null,y.reset(),ve.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return ui}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;const n=this.getContext();n.drawingBufferColorSpace=We._getDrawingBufferColorSpace(e),n.unpackColorSpace=We._getUnpackColorSpace()}}const LA=`
void main() {
  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}
`,DA=`
precision highp float;

uniform float uTime, uAttenuation, uLineThickness;
uniform float uBaseRadius, uRadiusStep, uScaleRate;
uniform float uOpacity, uNoiseAmount, uRotation, uRingGap;
uniform float uFadeIn, uFadeOut;
uniform float uMouseInfluence, uHoverAmount, uHoverScale, uParallax, uBurst;
uniform vec2 uResolution, uMouse;
uniform vec3 uColor, uColorTwo;
uniform int uRingCount;

const float HP = 1.5707963;
const float CYCLE = 3.45;

float fade(float t) {
  return t < uFadeIn ? smoothstep(0.0, uFadeIn, t) : 1.0 - smoothstep(uFadeOut, CYCLE - 0.2, t);
}

float ring(vec2 p, float ri, float cut, float t0, float px) {
  float t = mod(uTime + t0, CYCLE);
  float r = ri + t / CYCLE * uScaleRate;
  float d = abs(length(p) - r);
  float a = atan(abs(p.y), abs(p.x)) / HP;
  float th = max(1.0 - a, 0.5) * px * uLineThickness;
  float h = (1.0 - smoothstep(th, th * 1.5, d)) + 1.0;
  d += pow(cut * a, 3.0) * r;
  return h * exp(-uAttenuation * d) * fade(t);
}

void main() {
  float px = 1.0 / min(uResolution.x, uResolution.y);
  vec2 p = (gl_FragCoord.xy - 0.5 * uResolution.xy) * px;
  float cr = cos(uRotation), sr = sin(uRotation);
  p = mat2(cr, -sr, sr, cr) * p;
  p -= uMouse * uMouseInfluence;
  float sc = mix(1.0, uHoverScale, uHoverAmount) + uBurst * 0.3;
  p /= sc;
  vec3 c = vec3(0.0);
  float rcf = max(float(uRingCount) - 1.0, 1.0);
  for (int i = 0; i < 10; i++) {
    if (i >= uRingCount) break;
    float fi = float(i);
    vec2 pr = p - fi * uParallax * uMouse;
    vec3 rc = mix(uColor, uColorTwo, fi / rcf);
    c = mix(c, rc, vec3(ring(pr, uBaseRadius + fi * uRadiusStep, pow(uRingGap, fi), i == 0 ? 0.0 : 2.95 * fi, px)));
  }
  c *= 1.0 + uBurst * 2.0;
  float n = fract(sin(dot(gl_FragCoord.xy + uTime * 100.0, vec2(12.9898, 78.233))) * 43758.5453);
  c += (n - 0.5) * uNoiseAmount;
  gl_FragColor = vec4(c, max(c.r, max(c.g, c.b)) * uOpacity);
}
`;function IA({color:t="#00d4ff",colorTwo:e="#0066cc",speed:n=1,ringCount:i=7,attenuation:r=8,lineThickness:a=2,baseRadius:s=.35,radiusStep:o=.1,scaleRate:l=.1,opacity:c=1,blur:f=0,noiseAmount:h=.06,rotation:u=0,ringGap:m=1.5,fadeIn:x=.7,fadeOut:E=.5,followMouse:g=!0,mouseInfluence:d=.15,hoverScale:v=1.1,parallax:S=.04,clickBurst:M=!0}){const A=z.useRef(null),T=z.useRef(null),w=z.useRef([0,0]),_=z.useRef([0,0]),C=z.useRef(0),P=z.useRef(!1),N=z.useRef(0);return T.current={color:t,colorTwo:e,speed:n,ringCount:i,attenuation:r,lineThickness:a,baseRadius:s,radiusStep:o,scaleRate:l,opacity:c,noiseAmount:h,rotation:u,ringGap:m,fadeIn:x,fadeOut:E,followMouse:g,mouseInfluence:d,hoverScale:v,parallax:S,clickBurst:M},z.useEffect(()=>{const F=A.current;if(!F)return;let q;try{q=new NA({alpha:!0,antialias:!0})}catch{return}q.setClearColor(0,0),F.appendChild(q.domElement);const ie=new mE,k=new Uh(-.5,.5,.5,-.5,.1,10);k.position.z=1;const X={uTime:{value:0},uAttenuation:{value:0},uResolution:{value:new Ze},uColor:{value:new Qe},uColorTwo:{value:new Qe},uLineThickness:{value:0},uBaseRadius:{value:0},uRadiusStep:{value:0},uScaleRate:{value:0},uRingCount:{value:0},uOpacity:{value:1},uNoiseAmount:{value:0},uRotation:{value:0},uRingGap:{value:1.5},uFadeIn:{value:.5},uFadeOut:{value:.75},uMouse:{value:new Ze},uMouseInfluence:{value:0},uHoverAmount:{value:0},uHoverScale:{value:1},uParallax:{value:0},uBurst:{value:0}},V=new Qn({vertexShader:LA,fragmentShader:DA,uniforms:X,transparent:!0}),O=new _i(new uo(1,1),V);ie.add(O);const I=()=>{const oe=F.clientWidth,ee=F.clientHeight,Pe=Math.min(window.devicePixelRatio,2);q.setSize(oe,ee),q.setPixelRatio(Pe),X.uResolution.value.set(oe*Pe,ee*Pe)};I(),window.addEventListener("resize",I);const J=new ResizeObserver(I);J.observe(F);const ae=oe=>{const ee=F.getBoundingClientRect();w.current[0]=(oe.clientX-ee.left)/ee.width-.5,w.current[1]=-((oe.clientY-ee.top)/ee.height-.5)},le=()=>{P.current=!0},Be=()=>{P.current=!1,w.current[0]=0,w.current[1]=0},Xe=()=>{N.current=1};F.addEventListener("mousemove",ae),F.addEventListener("mouseenter",le),F.addEventListener("mouseleave",Be),F.addEventListener("click",Xe);let ze;const Q=oe=>{ze=requestAnimationFrame(Q);const ee=T.current;_.current[0]+=(w.current[0]-_.current[0])*.08,_.current[1]+=(w.current[1]-_.current[1])*.08,C.current+=((P.current?1:0)-C.current)*.08,N.current*=.95,N.current<.001&&(N.current=0),X.uTime.value=oe*.001*ee.speed,X.uAttenuation.value=ee.attenuation,X.uColor.value.set(ee.color),X.uColorTwo.value.set(ee.colorTwo),X.uLineThickness.value=ee.lineThickness,X.uBaseRadius.value=ee.baseRadius,X.uRadiusStep.value=ee.radiusStep,X.uScaleRate.value=ee.scaleRate,X.uRingCount.value=ee.ringCount,X.uOpacity.value=ee.opacity,X.uNoiseAmount.value=ee.noiseAmount,X.uRotation.value=ee.rotation*Math.PI/180,X.uRingGap.value=ee.ringGap,X.uFadeIn.value=ee.fadeIn,X.uFadeOut.value=ee.fadeOut,X.uMouse.value.set(_.current[0],_.current[1]),X.uMouseInfluence.value=ee.followMouse?ee.mouseInfluence:0,X.uHoverAmount.value=C.current,X.uHoverScale.value=ee.hoverScale,X.uParallax.value=ee.parallax,X.uBurst.value=ee.clickBurst?N.current:0,q.render(ie,k)};return ze=requestAnimationFrame(Q),()=>{cancelAnimationFrame(ze),window.removeEventListener("resize",I),J.disconnect(),F.removeEventListener("mousemove",ae),F.removeEventListener("mouseenter",le),F.removeEventListener("mouseleave",Be),F.removeEventListener("click",Xe),F.contains(q.domElement)&&F.removeChild(q.domElement),q.dispose(),V.dispose()}},[]),p.jsx("div",{ref:A,className:"magic-rings-container",style:f>0?{filter:`blur(${f}px)`}:void 0})}function UA({className:t,style:e}){return p.jsx("img",{src:"/uploads/PHOTO-2026-07-16-20-33-03-removebg-preview_imgupscaler.ai_General_2K-Photoroom.png",alt:"Dove Ice Gel Pack",className:t,style:e,draggable:!1})}const tl={Timer:cM,Droplets:rM,RotateCcw:nx,Award:K_,Shield:li,Zap:rx,Thermometer:lM,Globe:Z_,Users:ix,Leaf:Q_},FA=Array.from({length:22},(t,e)=>({id:e,left:`${(e*4.7+2)%100}%`,delay:`${e*.45%9}s`,duration:`${7+e%5}s`,size:`${2+e%3}px`}));function OA(){z.useEffect(()=>{const t=new IntersectionObserver(e=>e.forEach(n=>n.isIntersecting&&n.target.classList.add("visible")),{threshold:.07});return document.querySelectorAll(".section-reveal").forEach(e=>t.observe(e)),()=>t.disconnect()},[])}const hg=[{from:"#0d4a8a",to:"#0db2e8"},{from:"#0a4a60",to:"#06b6d4"},{from:"#0a4a3e",to:"#14b8a6"},{from:"#1a3a6a",to:"#2e7ce0"}];function kA({product:t,index:e}){const n=hg[e%hg.length],i=!!t.image;return p.jsxs("div",{className:"section-reveal light-card rounded-2xl overflow-hidden group flex flex-col",style:{transitionDelay:`${e*.08}s`},children:[p.jsxs("div",{className:"relative overflow-hidden",style:{aspectRatio:"4/3"},children:[i?p.jsx("img",{src:t.image,alt:t.name,className:"w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"}):p.jsxs("div",{className:"w-full h-full flex flex-col items-center justify-center gap-3 relative",style:{background:`linear-gradient(135deg, ${n.from} 0%, ${n.to} 100%)`},children:[p.jsx("div",{className:"absolute inset-0 opacity-[0.06]",style:{backgroundImage:"linear-gradient(rgba(255,255,255,1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,1) 1px, transparent 1px)",backgroundSize:"20px 20px"}}),p.jsxs("div",{className:"relative z-10 flex flex-col items-center gap-2",children:[p.jsxs("div",{className:"w-20 h-14 rounded-xl border-2 border-white/40 flex items-center justify-center bg-white/10 backdrop-blur-sm shadow-xl",style:{animation:"gpCardPulse 2.5s ease-in-out infinite"},children:[p.jsx("div",{className:"gp-card-grid",style:{position:"absolute",inset:6,display:"grid",gridTemplateColumns:"repeat(5,1fr)",gridTemplateRows:"repeat(4,1fr)",gap:2},children:Array.from({length:20}).map((r,a)=>p.jsx("div",{className:"gp-card-cell rounded-[2px]"},a))}),p.jsx("span",{className:"relative z-10 font-display font-black text-white/90 text-xs tracking-widest",children:"DOVE"})]}),p.jsx("span",{className:"text-2xl",children:t.icon})]}),p.jsxs("div",{className:"relative z-10 flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/15 border border-white/25 backdrop-blur-sm",children:[p.jsx(aM,{className:"w-3.5 h-3.5 text-white/80"}),p.jsx("span",{className:"text-white/80 text-xs font-semibold tracking-wide",children:"Add Product Photo"})]})]}),p.jsx("span",{className:"absolute top-3 right-3 px-2.5 py-1 rounded-full text-xs font-bold bg-white/20 text-white backdrop-blur-sm border border-white/25 shadow",children:t.tag})]}),p.jsxs("div",{className:"p-5 flex flex-col flex-1",children:[p.jsx("h3",{className:"font-display font-bold text-[#0d2a5a] text-lg mb-1.5",children:t.name}),p.jsx("p",{className:"text-[#3d5a7a] text-sm leading-relaxed mb-3 flex-1",children:t.desc}),p.jsxs("div",{className:"flex items-center gap-2 flex-wrap pt-3 border-t border-[#dae6f5]",children:[p.jsx("span",{className:"text-[#1a56a0]/60 text-sm font-semibold uppercase tracking-wider",children:"Sizes:"}),p.jsx("span",{className:"text-[#2a6aaa] text-sm",children:t.sizes})]})]})]})}function pg(){var S,M,A,T;const t=br(),{hero:e,stats:n,big_stats:i,services:r,home_applications:a,testimonials:s,home_products:o,about_snippets:l,about_page:c,site:f,home_sections:h,values:u,features:m,certifications:x}=t,[E,g]=z.useState(!1),[d,v]=z.useState(0);return OA(),z.useEffect(()=>{const w=setTimeout(()=>g(!0),80);return()=>clearTimeout(w)},[]),z.useEffect(()=>{const w=setInterval(()=>{v(_=>(_+1)%s.length)},5e3);return()=>clearInterval(w)},[s.length]),p.jsxs("div",{className:"light-page",children:[p.jsxs("section",{className:"relative min-h-screen flex items-center overflow-hidden",style:{background:"#030c1e"},children:[p.jsx("div",{className:"snow-container",children:FA.map(w=>p.jsx("div",{className:"snowflake",style:{left:w.left,width:w.size,height:w.size,animationDelay:w.delay,animationDuration:w.duration}},w.id))}),p.jsx("div",{className:"absolute inset-0 z-0",children:p.jsx(IA,{color:"#00d4ff",colorTwo:"#0055aa",ringCount:8,attenuation:7,lineThickness:2.5,baseRadius:.28,radiusStep:.12,scaleRate:.12,opacity:.88,noiseAmount:.05,ringGap:1.6,fadeIn:.65,fadeOut:.55,speed:.85,followMouse:!0,mouseInfluence:.18,hoverScale:1.12,parallax:.05,clickBurst:!0})}),p.jsx("div",{className:"absolute inset-0 z-[1] pointer-events-none",style:{background:"linear-gradient(105deg, rgba(3,12,30,0.96) 0%, rgba(3,12,30,0.80) 38%, rgba(3,12,30,0.35) 62%, rgba(3,12,30,0.1) 100%)"}}),p.jsx("div",{className:"absolute bottom-0 left-0 right-0 h-36 z-[1] pointer-events-none",style:{background:"linear-gradient(to bottom, transparent, #030c1e)"}}),p.jsx("div",{className:`absolute right-0 top-0 bottom-0 w-full md:w-[48%] lg:w-[50%] z-[2] hidden md:flex items-center justify-center pointer-events-none transition-all duration-1200 ${E?"opacity-100 translate-x-0":"opacity-0 translate-x-12"}`,children:p.jsxs("div",{className:"relative hero-float",style:{width:"min(520px, 82vw)"},children:[[{size:9,top:"8%",left:"18%",delay:"0s",dur:"6.2s"},{size:6,top:"14%",left:"72%",delay:"1.1s",dur:"5.4s"},{size:13,top:"22%",left:"5%",delay:"0.4s",dur:"7.8s"},{size:7,top:"38%",left:"88%",delay:"2.3s",dur:"6s"},{size:5,top:"55%",left:"12%",delay:"1.7s",dur:"5s"},{size:10,top:"60%",left:"80%",delay:"0.9s",dur:"8.1s"},{size:8,top:"72%",left:"30%",delay:"3s",dur:"6.6s"},{size:5,top:"78%",left:"65%",delay:"1.5s",dur:"5.7s"},{size:12,top:"85%",left:"48%",delay:"2.8s",dur:"7.2s"},{size:6,top:"90%",left:"10%",delay:"0.2s",dur:"6.9s"},{size:4,top:"48%",left:"95%",delay:"3.5s",dur:"5.2s"},{size:9,top:"30%",left:"58%",delay:"2.1s",dur:"8.4s"}].map((w,_)=>p.jsx("span",{className:"bubble",style:{width:w.size,height:w.size,top:w.top,left:w.left,"--dur":w.dur,"--delay":w.delay}},_)),p.jsx("div",{className:"absolute inset-0 flex items-center justify-center -z-10 pointer-events-none",children:p.jsx("div",{className:"hero-glow"})}),p.jsx("div",{className:"absolute -bottom-5 left-1/2 -translate-x-1/2 w-3/5 h-10 blur-3xl rounded-full -z-10",style:{background:"radial-gradient(ellipse, rgba(30,100,220,0.22), transparent 70%)"}}),p.jsx(UA,{className:"relative z-[1] w-full h-auto select-none block"})]})}),p.jsx("div",{className:`relative z-10 max-w-7xl mx-auto px-6 w-full pt-28 pb-20 transition-all duration-1000 ${E?"opacity-100 translate-y-0":"opacity-0 translate-y-8"}`,children:p.jsxs("div",{className:"max-w-3xl mx-auto md:mx-0 text-center md:text-left md:max-w-[52%]",children:[p.jsxs("div",{className:"inline-flex items-center gap-2 px-4 py-1.5 rounded-full glass-card text-ice-300 text-xs font-semibold mb-6 border border-ice-500/20",children:[p.jsx("span",{className:"w-1.5 h-1.5 rounded-full bg-ice-400 animate-pulse"}),e.badge_text]}),p.jsxs("h1",{className:"font-display text-5xl lg:text-[4.6rem] font-bold leading-[1.04] text-white mb-5",children:[e.headline_line1,p.jsx("br",{}),p.jsx("span",{className:"gradient-text text-glow",children:e.headline_line2}),p.jsx("br",{}),e.headline_line3,p.jsx("br",{}),p.jsx("span",{className:"gradient-text",children:e.headline_line4})]}),p.jsx("p",{className:"text-ice-100/70 text-lg leading-relaxed mb-7 max-w-lg mx-auto md:mx-0",dangerouslySetInnerHTML:{__html:e.subheadline}}),p.jsx("div",{className:"flex gap-7 mb-7 justify-center md:justify-start",children:n.map(({icon:w,value:_,label:C,color:P})=>{const N=tl[w]||li;return p.jsxs("div",{className:"text-center",children:[p.jsx(N,{className:`w-4 h-4 ${P} mx-auto mb-1`}),p.jsx("div",{className:`font-display font-bold text-xl ${P}`,children:_}),p.jsx("div",{className:"text-ice-300/50 text-xs",children:C})]},C)})}),p.jsxs("div",{className:"flex flex-wrap gap-3 mb-6 justify-center md:justify-start",children:[p.jsxs(Qt,{to:"/products",className:"glow-button inline-flex items-center gap-2 px-7 py-3.5 rounded-xl bg-ice-500 text-white font-bold text-sm shadow-lg shadow-ice-500/35 hover:bg-ice-400 transition-colors",children:[e.btn_products_text," ",p.jsx(Ti,{className:"w-4 h-4"})]}),p.jsx("a",{href:f.whatsapp_number,target:"_blank",rel:"noopener noreferrer",className:"inline-flex items-center gap-2 px-7 py-3.5 rounded-xl bg-green-500/18 border border-green-500/35 text-green-300 font-bold text-sm hover:bg-green-500/28 transition-colors",children:e.btn_whatsapp_text})]}),p.jsx("div",{className:"flex flex-wrap gap-2 justify-center md:justify-start",children:r.map(({icon:w,text:_})=>{const C=tl[w]||li;return p.jsxs("span",{className:"inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium text-ice-300 bg-ice-500/10 border border-ice-500/20",children:[p.jsx(C,{className:"w-3.5 h-3.5"})," ",_]},_)})})]})}),p.jsxs("div",{className:"absolute bottom-8 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center gap-1 text-ice-400/40 animate-bounce",children:[p.jsx("span",{className:"text-xs font-medium",children:"Scroll"}),p.jsx(tM,{className:"w-4 h-4"})]})]}),p.jsx("section",{className:"py-12 border-y border-[#c5ddf5] light-section-blue",children:p.jsx("div",{className:"max-w-7xl mx-auto px-6",children:p.jsx("div",{className:"grid grid-cols-2 lg:grid-cols-4 gap-6",children:i.map((w,_)=>p.jsxs("div",{className:"section-reveal text-center",style:{transitionDelay:`${_*.08}s`},children:[p.jsx("div",{className:"font-display text-5xl lg:text-6xl font-bold gradient-text-dark mb-1.5",children:w.value}),p.jsx("div",{className:"text-[#0d2a5a] font-semibold text-base",children:w.label}),p.jsx("div",{className:"text-[#5a7a9a] text-sm mt-1",children:w.sub})]},w.label))})})}),p.jsx("section",{className:"py-16",style:{background:"linear-gradient(180deg, #04101e 0%, #030c1e 100%)"},children:p.jsx("div",{className:"max-w-7xl mx-auto px-6",children:p.jsxs("div",{className:"grid lg:grid-cols-2 gap-12 items-center",children:[p.jsxs("div",{className:"section-reveal",children:[p.jsx("div",{className:"inline-flex items-center gap-2 px-4 py-1.5 rounded-full glass-card text-ice-400 text-sm font-semibold mb-5",children:h.about_badge}),p.jsxs("h2",{className:"font-display text-4xl lg:text-5xl font-bold text-white mb-5 leading-tight",children:[c.about_intro_title,p.jsx("br",{}),p.jsx("span",{className:"gradient-text",children:c.about_intro_highlight})]}),p.jsx("p",{className:"text-ice-200/60 text-lg leading-relaxed mb-4",children:c.about_intro_p1}),p.jsx("p",{className:"text-ice-200/45 text-lg leading-relaxed mb-6",children:c.about_intro_p2}),p.jsxs("div",{className:"flex flex-wrap gap-3",children:[p.jsxs(Qt,{to:"/about",className:"glow-button inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-ice-500 text-white font-bold text-sm hover:bg-ice-400 transition-colors",children:["Learn More ",p.jsx(Ti,{className:"w-4 h-4"})]}),p.jsx(Qt,{to:"/contact",className:"inline-flex items-center gap-2 px-6 py-3 rounded-xl border-2 border-ice-500/30 text-ice-300 font-bold text-sm hover:bg-ice-500/10 transition-colors",children:"Contact Us"})]})]}),p.jsx("div",{className:"section-reveal",children:p.jsx("div",{className:"grid grid-cols-2 gap-4",children:l.map(({title:w,desc:_,icon:C},P)=>{const N=tl[C]||li;return p.jsxs("div",{className:"glass-card rounded-2xl p-5",style:{animationDelay:`${P*.1}s`},children:[p.jsx("div",{className:"w-10 h-10 rounded-xl bg-ice-500/15 flex items-center justify-center mb-3",children:p.jsx(N,{className:"w-5 h-5 text-ice-400"})}),p.jsx("div",{className:"text-white font-semibold text-base mb-1",children:w}),p.jsx("div",{className:"text-ice-200/50 text-sm leading-relaxed",children:_})]},w)})})})]})})}),p.jsx("section",{className:"py-16 light-section-blue",children:p.jsxs("div",{className:"max-w-7xl mx-auto px-6",children:[p.jsxs("div",{className:"text-center mb-10 section-reveal",children:[p.jsx("div",{className:"light-badge mb-4",children:h.products_badge}),p.jsxs("h2",{className:"font-display text-4xl lg:text-5xl font-bold light-heading mb-3",children:[h.products_title_line1," ",p.jsx("span",{className:"gradient-text-dark",children:h.products_title_line2})]}),p.jsx("p",{className:"light-body-text-soft text-lg max-w-2xl mx-auto",children:h.products_sub})]}),p.jsx("div",{className:"grid md:grid-cols-2 lg:grid-cols-4 gap-5 mb-8",children:o.map((w,_)=>p.jsx(kA,{product:w,index:_},w.name))}),p.jsx("div",{className:"text-center section-reveal",children:p.jsxs(Qt,{to:"/products",className:"glow-button inline-flex items-center gap-2 px-8 py-3.5 rounded-xl bg-ice-500 text-white font-bold text-sm shadow-lg shadow-ice-500/30 hover:bg-ice-400 transition-colors",children:[h.products_btn," ",p.jsx(Ti,{className:"w-4 h-4"})]})})]})}),p.jsx("section",{className:"py-16",style:{background:"linear-gradient(180deg, #030c1e 0%, #04101e 100%)"},children:p.jsxs("div",{className:"max-w-7xl mx-auto px-6",children:[p.jsxs("div",{className:"text-center mb-10 section-reveal",children:[p.jsx("div",{className:"inline-flex items-center gap-2 px-4 py-1.5 rounded-full glass-card text-ice-400 text-sm font-semibold mb-4",children:h.applications_badge}),p.jsxs("h2",{className:"font-display text-4xl lg:text-5xl font-bold text-white mb-3",children:[h.applications_title_line1," ",p.jsx("span",{className:"gradient-text",children:h.applications_title_line2})]}),p.jsx("p",{className:"text-ice-200/50 text-lg max-w-2xl mx-auto",children:h.applications_sub})]}),p.jsx("div",{className:"grid md:grid-cols-2 lg:grid-cols-3 gap-5",children:a.map((w,_)=>p.jsxs("div",{className:"section-reveal glass-card rounded-2xl p-6 flex gap-4 items-start",style:{transitionDelay:`${_*.07}s`},children:[p.jsx("div",{className:"text-3xl flex-shrink-0",children:w.icon}),p.jsxs("div",{children:[p.jsx("h3",{className:"font-display font-semibold text-white text-lg mb-1",children:w.title}),p.jsx("p",{className:"text-ice-200/50 text-sm leading-relaxed",children:w.desc})]})]},w.title))}),p.jsx("div",{className:"text-center mt-8 section-reveal",children:p.jsxs(Qt,{to:"/applications",className:"inline-flex items-center gap-2 px-6 py-3 rounded-xl border-2 border-ice-500/30 text-ice-300 font-bold text-sm hover:bg-ice-500/10 transition-colors",children:[h.applications_btn," ",p.jsx(Ti,{className:"w-4 h-4"})]})})]})}),p.jsxs("section",{className:"py-10 relative overflow-hidden light-section-blue-deep",children:[p.jsx("div",{className:"absolute inset-0 pointer-events-none opacity-[0.04]",style:{backgroundImage:"radial-gradient(circle, rgba(26,86,160,1) 1px, transparent 1px)",backgroundSize:"28px 28px"}}),p.jsxs("div",{className:"max-w-5xl mx-auto px-6",children:[p.jsxs("div",{className:"text-center mb-10 section-reveal",children:[p.jsx("div",{className:"light-badge mb-4",children:h.testimonials_badge}),p.jsxs("h2",{className:"font-display text-4xl lg:text-5xl font-bold light-heading",children:[h.testimonials_title_line1," ",p.jsx("span",{className:"gradient-text-dark",children:h.testimonials_title_line2})]})]}),p.jsxs("div",{className:"section-reveal",children:[p.jsxs("div",{className:"light-card rounded-3xl p-8 lg:p-10 text-center relative overflow-hidden mb-6",children:[p.jsx("div",{className:"absolute top-6 left-8 text-[#1a56a0]/15",children:p.jsx(oM,{className:"w-16 h-16"})}),p.jsx("div",{className:"flex justify-center mb-4",children:Array.from({length:((S=s[d])==null?void 0:S.rating)||5}).map((w,_)=>p.jsx(hm,{className:"w-5 h-5 text-amber-400 fill-amber-400"},_))}),p.jsxs("p",{className:"text-[#3d5a7a] text-lg leading-relaxed max-w-2xl mx-auto mb-6 italic",children:['"',(M=s[d])==null?void 0:M.text,'"']}),p.jsxs("div",{children:[p.jsx("div",{className:"font-display font-bold text-[#0d2a5a] text-lg",children:(A=s[d])==null?void 0:A.name}),p.jsx("div",{className:"text-[#1a56a0]/65 text-sm mt-0.5",children:(T=s[d])==null?void 0:T.role})]})]}),p.jsx("div",{className:"flex justify-center gap-2",children:s.map((w,_)=>p.jsx("button",{onClick:()=>v(_),className:`h-2 rounded-full transition-all duration-300 ${_===d?"w-8 bg-[#1a56a0]":"w-2 bg-[#1a56a0]/25 hover:bg-[#1a56a0]/45"}`},_))})]}),p.jsx("div",{className:"grid md:grid-cols-2 gap-4 mt-8",children:s.slice(0,2).map((w,_)=>p.jsxs("div",{className:"section-reveal light-card rounded-2xl p-5",style:{transitionDelay:`${_*.1}s`},children:[p.jsx("div",{className:"flex gap-1 mb-3",children:Array.from({length:w.rating}).map((C,P)=>p.jsx(hm,{className:"w-3.5 h-3.5 text-amber-400 fill-amber-400"},P))}),p.jsxs("p",{className:"text-[#5a7a9a] text-sm leading-relaxed mb-3 italic line-clamp-3",children:['"',w.text,'"']}),p.jsx("div",{className:"text-[#0d2a5a] font-semibold text-sm",children:w.name}),p.jsx("div",{className:"text-[#1a56a0]/55 text-sm",children:w.role})]},_))})]})]}),p.jsx("section",{className:"py-10 light-section-blue",children:p.jsxs("div",{className:"max-w-7xl mx-auto px-6",children:[p.jsxs("div",{className:"text-center mb-10 section-reveal",children:[p.jsx("div",{className:"light-badge mb-4",children:c.values_badge}),p.jsxs("h2",{className:"font-display text-4xl lg:text-5xl font-bold light-heading mb-3",children:[c.values_title.split("Us Forward")[0],p.jsx("span",{className:"gradient-text-dark",children:"Us Forward"})]})]}),p.jsx("div",{className:"grid md:grid-cols-2 lg:grid-cols-4 gap-5",children:u.map((w,_)=>{const C=tl[w.icon]||li;return p.jsxs("div",{className:"section-reveal light-card rounded-2xl p-6 group",style:{transitionDelay:`${_*.08}s`},children:[p.jsx("div",{className:`w-12 h-12 rounded-xl bg-gradient-to-br ${w.color} flex items-center justify-center mb-4 shadow-lg group-hover:scale-110 transition-transform`,children:p.jsx(C,{className:"w-6 h-6 text-white"})}),p.jsx("h3",{className:"font-display font-semibold text-[#0d2a5a] text-base mb-2",children:w.title}),p.jsx("p",{className:"text-[#5a7a9a] text-sm leading-relaxed",children:w.desc})]},w.title)})})]})}),p.jsx("section",{className:"py-16",style:{background:"#030c1e"},children:p.jsxs("div",{className:"max-w-5xl mx-auto px-6",children:[p.jsxs("div",{className:"text-center mb-10 section-reveal",children:[p.jsxs("h2",{className:"font-display text-4xl lg:text-5xl font-bold text-white mb-3",children:[c.features_title.split("Standards")[0],p.jsx("span",{className:"gradient-text",children:"Standards"})]}),p.jsx("p",{className:"text-ice-200/60 text-lg max-w-2xl mx-auto",children:c.features_sub})]}),p.jsx("div",{className:"section-reveal",children:p.jsx("div",{className:"grid md:grid-cols-2 gap-3",children:m.map((w,_)=>p.jsxs("div",{className:"flex items-start gap-3 glass-card rounded-xl px-4 py-3",children:[p.jsx(ql,{className:"w-5 h-5 text-ice-400 mt-0.5 flex-shrink-0"}),p.jsx("span",{className:"text-ice-200/70 text-sm leading-relaxed",children:w.text})]},w.id||_))})})]})}),p.jsx("section",{className:"py-14 light-section-blue",children:p.jsx("div",{className:"max-w-5xl mx-auto px-6",children:p.jsx("div",{className:"grid grid-cols-2 md:grid-cols-4 gap-4 section-reveal",children:x.map(w=>p.jsxs("div",{className:"light-card rounded-2xl py-5 px-4 text-center",children:[p.jsx("div",{className:"w-10 h-10 rounded-xl bg-[#e8f2fc] border border-[#c5ddf5] flex items-center justify-center mx-auto mb-3",children:p.jsx(li,{className:"w-5 h-5 text-[#1a56a0]"})}),p.jsx("div",{className:"text-[#0d2a5a] font-semibold text-sm",children:w.name})]},w.name))})})}),p.jsx("section",{className:"py-16 relative overflow-hidden light-section-white",children:p.jsxs("div",{className:"max-w-4xl mx-auto px-6 text-center section-reveal",children:[p.jsxs("h2",{className:"font-display text-4xl lg:text-5xl font-bold light-heading mb-4",children:[e.cta_headline.split(e.cta_title_highlight)[0],p.jsx("span",{className:"gradient-text-dark",children:e.cta_title_highlight})]}),p.jsx("p",{className:"light-body-text-soft text-lg mb-8 max-w-2xl mx-auto",children:e.cta_sub}),p.jsxs("div",{className:"flex flex-wrap gap-4 justify-center",children:[p.jsxs("a",{href:f.whatsapp_number,target:"_blank",rel:"noopener noreferrer",className:"glow-button inline-flex items-center gap-2 px-8 py-3.5 rounded-xl bg-green-500 text-white font-bold text-sm shadow-lg shadow-green-500/30 hover:bg-green-400 transition-colors",children:[e.cta_btn_whatsapp," ",p.jsx(Ti,{className:"w-4 h-4"})]}),p.jsx(Qt,{to:"/contact",className:"light-btn-outline",children:e.cta_btn_quote})]})]})})]})}const BA=14,zA=10,VA=6;function wc(){const t=z.useMemo(()=>Array.from({length:BA}).map((i,r)=>({left:`${r*97%100}%`,size:2+r*7%4,delay:`${r*1.3%8}s`,dur:`${7+r*5%6}s`})),[]),e=z.useMemo(()=>Array.from({length:zA}).map((i,r)=>({left:`${10+r*83%80}%`,top:`${15+r*61%70}%`,size:4+r*9%6,delay:`${r*.7%4}s`,dur:`${2.5+r*3%3}s`})),[]),n=z.useMemo(()=>Array.from({length:VA}).map((i,r)=>({left:`${8+r*29%84}%`,bottom:"0",size:6+r*11%14,delay:`${r*1.1%5}s`,dur:`${5+r*4%5}s`})),[]);return p.jsxs(p.Fragment,{children:[p.jsx("div",{className:"snow-container","aria-hidden":!0,children:t.map((i,r)=>p.jsx("span",{className:"snowflake",style:{left:i.left,width:i.size,height:i.size,animationDelay:i.delay,animationDuration:i.dur}},`s${r}`))}),p.jsx("div",{className:"hero-sparkles","aria-hidden":!0,children:e.map((i,r)=>p.jsx("span",{className:"hero-sparkle",style:{left:i.left,top:i.top,width:i.size,height:i.size,animationDelay:i.delay,animationDuration:i.dur}},`sp${r}`))}),p.jsx("div",{className:"hero-bubbles","aria-hidden":!0,children:n.map((i,r)=>p.jsx("span",{className:"bubble",style:{left:i.left,bottom:i.bottom,width:i.size,height:i.size,"--dur":i.dur,"--delay":i.delay}},`b${r}`))}),p.jsx("div",{className:"hero-wave","aria-hidden":!0,children:p.jsx("svg",{viewBox:"0 0 1440 120",preserveAspectRatio:"none",children:p.jsx("path",{className:"hero-wave-path",d:"M0,60 C240,100 480,20 720,60 C960,100 1200,20 1440,60 L1440,120 L0,120 Z"})})})]})}function HA({variant:t,accentFrom:e,accentTo:n}){return p.jsxs("div",{className:"product-card group cursor-pointer",children:[p.jsx("div",{className:"product-card-img-wrap",children:t.image?p.jsx("img",{src:t.image,alt:t.name,className:"product-card-img"}):p.jsxs("div",{className:"product-card-placeholder",children:[p.jsxs("div",{className:"gp-card-pack",style:{"--c1":e,"--c2":n},children:[p.jsx("div",{className:"gp-card-grid",children:Array.from({length:20}).map((i,r)=>p.jsx("div",{className:"gp-card-cell"},r))}),p.jsx("div",{className:"gp-card-label",children:"DOVE"}),p.jsx("div",{className:"gp-card-shimmer"})]}),p.jsx("span",{className:"product-card-add-label",children:"Add Image"})]})}),p.jsx("div",{className:"product-card-caption",children:t.name})]})}function GA({cat:t,whatsapp:e,products_page:n}){return p.jsxs("div",{className:"cat-section",children:[p.jsxs("div",{className:"cat-header",children:[p.jsx("div",{className:"cat-accent-line",style:{background:`linear-gradient(90deg, ${t.accent_from}, ${t.accent_to})`}}),p.jsx("h2",{className:"cat-title",children:t.title}),p.jsx("p",{className:"cat-description",children:t.description}),p.jsx("div",{className:"cat-specs",children:t.specs.map(i=>p.jsx("span",{className:"cat-spec-pill",style:{borderColor:`${t.accent_from}40`,color:t.accent_from},children:i},i))})]}),p.jsx("div",{className:"product-grid",children:t.variants.map(i=>p.jsx(HA,{variant:i,accentFrom:t.accent_from,accentTo:t.accent_to},i.name))}),p.jsxs("div",{className:"cat-cta-row",children:[p.jsxs("a",{href:`${e}?text=I'm interested in ${encodeURIComponent(t.title)}`,target:"_blank",rel:"noopener noreferrer",className:"cat-cta-wa",children:[p.jsx(Eh,{className:"w-4 h-4"})," ",n.btn_whatsapp]}),p.jsxs(Qt,{to:"/contact",className:"cat-cta-quote",children:[n.btn_quote," ",p.jsx(Ti,{className:"w-4 h-4"})]})]})]})}function WA(){z.useEffect(()=>{const t=new IntersectionObserver(e=>e.forEach(n=>n.isIntersecting&&n.target.classList.add("visible")),{threshold:.06});return document.querySelectorAll(".section-reveal").forEach(e=>t.observe(e)),()=>t.disconnect()},[])}function jA(){var o;const t=br(),{product_categories:e,site:n,products_page:i}=t,[r,a]=z.useState(((o=e[0])==null?void 0:o.id)||"pouches");WA();const s=e.find(l=>l.id===r)||e[0];return p.jsxs("div",{className:"products-page",children:[p.jsxs("section",{className:"products-hero section-reveal",children:[p.jsx("div",{className:"products-hero-grid-bg"}),p.jsx(wc,{}),p.jsxs("div",{className:"products-hero-inner relative z-[3]",children:[p.jsx("div",{className:"products-hero-tag",children:i.hero_badge}),p.jsxs("h1",{className:"products-hero-title",children:[i.hero_title_line1,p.jsx("br",{}),p.jsx("span",{className:"gradient-text",children:i.hero_title_line2})]}),p.jsx("p",{className:"products-hero-sub",children:i.hero_sub})]})]}),p.jsx("div",{className:"cat-tabs-bar",children:p.jsx("div",{className:"cat-tabs-inner",children:e.map(l=>p.jsxs("button",{onClick:()=>a(l.id),className:`cat-tab ${r===l.id?"cat-tab--active":""}`,children:[l.label,r===l.id&&p.jsx(nM,{className:"w-3.5 h-3.5 rotate-90"})]},l.id))})}),p.jsx("section",{className:"products-content section-reveal",children:s&&p.jsx(GA,{cat:s,whatsapp:n.whatsapp_number,products_page:i},s.id)}),p.jsx("section",{className:"all-cats-strip section-reveal",children:p.jsxs("div",{className:"all-cats-inner",children:[p.jsx("div",{className:"all-cats-title",children:i.strip_title}),p.jsx("div",{className:"all-cats-grid",children:e.map(l=>p.jsxs("button",{onClick:()=>{a(l.id),window.scrollTo({top:0,behavior:"smooth"})},className:`all-cat-card ${r===l.id?"all-cat-card--active":""}`,style:{"--accent":l.accent_from},children:[p.jsx("div",{className:"all-cat-dot",style:{background:`linear-gradient(135deg, ${l.accent_from}, ${l.accent_to})`}}),p.jsx("div",{className:"all-cat-label",children:l.label}),p.jsxs("div",{className:"all-cat-count",children:[l.variants.length," variant",l.variants.length>1?"s":""]})]},l.id))})]})})]})}const mg={Shield:li,Zap:rx,RotateCcw:nx,Globe:Z_,Award:K_,Users:ix,Leaf:Q_};function XA(){z.useEffect(()=>{const t=new IntersectionObserver(e=>e.forEach(n=>n.isIntersecting&&n.target.classList.add("visible")),{threshold:.08});return document.querySelectorAll(".section-reveal").forEach(e=>t.observe(e)),()=>t.disconnect()},[])}function $A(){const{about_page:t,about_stats:e,milestones:n,values:i,features:r,certifications:a}=br();return XA(),p.jsxs("div",{style:{background:"#030c1e",minHeight:"100vh"},children:[p.jsxs("section",{className:"relative pt-36 pb-28 overflow-hidden",style:{background:"radial-gradient(ellipse 80% 70% at 50% 40%, rgba(13,178,232,0.09) 0%, transparent 65%), linear-gradient(135deg, #030c1e 0%, #071528 60%, #0a1d38 100%)"},children:[p.jsx("div",{className:"absolute inset-0 pointer-events-none opacity-[0.022]",style:{backgroundImage:"linear-gradient(rgba(56,201,247,1) 1px, transparent 1px), linear-gradient(90deg, rgba(56,201,247,1) 1px, transparent 1px)",backgroundSize:"60px 60px"}}),p.jsx(wc,{}),p.jsxs("div",{className:"max-w-4xl mx-auto px-6 text-center section-reveal relative z-[3]",children:[p.jsx("div",{className:"inline-flex items-center gap-2 px-4 py-1.5 rounded-full glass-card text-ice-400 text-xs font-semibold mb-7 sm:mb-5",children:t.hero_badge}),p.jsxs("h1",{className:"font-display text-[2.5rem] sm:text-5xl lg:text-7xl font-bold text-white mb-8 sm:mb-6 leading-[1.12] lg:leading-tight",children:[t.hero_title_line1,p.jsx("br",{}),p.jsx("span",{className:"gradient-text",children:t.hero_title_line2})," ",t.hero_title_line3]}),p.jsx("p",{className:"text-ice-100/68 text-base sm:text-xl leading-relaxed max-w-xl sm:max-w-2xl mx-auto mb-8",children:t.hero_sub}),p.jsxs("div",{className:"flex flex-wrap gap-4 justify-center",children:[p.jsxs(Qt,{to:"/products",className:"glow-button inline-flex items-center gap-2 px-7 py-3.5 rounded-xl bg-ice-500 text-white font-bold text-sm shadow-lg shadow-ice-500/30 hover:bg-ice-400 transition-colors",children:[t.btn_products," ",p.jsx(Ti,{className:"w-4 h-4"})]}),p.jsx(Qt,{to:"/contact",className:"inline-flex items-center gap-2 px-7 py-3.5 rounded-xl glass-card border border-ice-500/20 text-ice-200 font-semibold text-sm hover:text-white transition-colors",children:t.btn_contact})]})]})]}),p.jsx("section",{className:"py-16",style:{background:"#ffffff"},children:p.jsx("div",{className:"max-w-7xl mx-auto px-6",children:p.jsx("div",{className:"grid grid-cols-2 lg:grid-cols-4 gap-6",children:e.map(({value:s,label:o,icon:l},c)=>{const f=mg[l]||li;return p.jsxs("div",{className:"section-reveal text-center group",style:{transitionDelay:`${c*.08}s`},children:[p.jsx("div",{className:"inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-[#e8f2fc] border border-[#c5ddf5] mb-4 group-hover:bg-[#d8e8f5] transition-colors mx-auto",children:p.jsx(f,{className:"w-7 h-7 text-[#1a56a0]"})}),p.jsx("div",{className:"font-display text-4xl font-bold gradient-text-dark mb-1",children:s}),p.jsx("div",{className:"text-[#0d2a5a] font-semibold text-sm",children:o})]},o)})})})}),p.jsx("section",{className:"py-28",style:{background:"#030c1e"},children:p.jsxs("div",{className:"max-w-7xl mx-auto px-6",children:[p.jsxs("div",{className:"text-center mb-16 section-reveal",children:[p.jsx("div",{className:"inline-flex items-center gap-2 px-4 py-1.5 rounded-full glass-card text-ice-400 text-xs font-semibold mb-4",children:t.story_badge}),p.jsxs("h2",{className:"font-display text-4xl lg:text-5xl font-bold text-white mb-3",children:[t.story_title.split("Innovation")[0],p.jsx("span",{className:"gradient-text",children:"Innovation"})]})]}),p.jsxs("div",{className:"relative max-w-3xl mx-auto",children:[p.jsx("div",{className:"absolute left-6 lg:left-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-ice-500/50 via-ice-500/30 to-transparent"}),n.map((s,o)=>p.jsxs("div",{className:`section-reveal relative flex gap-8 mb-10 ${o%2===0?"lg:flex-row":"lg:flex-row-reverse"}`,style:{transitionDelay:`${o*.1}s`},children:[p.jsx("div",{className:"absolute left-4 lg:left-1/2 lg:-translate-x-1/2 top-2 w-4 h-4 rounded-full bg-ice-500 border-2 border-ice-300/40 shadow-lg shadow-ice-500/40 z-10"}),p.jsx("div",{className:"hidden lg:block w-1/2 flex-shrink-0"}),p.jsxs("div",{className:`ml-10 lg:ml-0 lg:w-1/2 glass-card rounded-2xl p-5 ${o%2===0?"lg:pr-8":"lg:pl-8"}`,children:[p.jsx("div",{className:"inline-block px-3 py-1 rounded-full bg-ice-500/15 border border-ice-500/25 text-ice-400 text-xs font-bold mb-2",children:s.year}),p.jsx("h3",{className:"font-display font-semibold text-white text-base mb-1",children:s.title}),p.jsx("p",{className:"text-ice-200/60 text-sm leading-relaxed",children:s.desc})]})]},s.year))]})]})}),p.jsx("section",{className:"py-16",style:{background:"#ffffff"},children:p.jsxs("div",{className:"max-w-7xl mx-auto px-6",children:[p.jsxs("div",{className:"text-center mb-14 section-reveal",children:[p.jsx("div",{className:"light-badge mb-4",children:t.values_badge}),p.jsxs("h2",{className:"font-display text-4xl font-bold text-[#0d2a5a] mb-3",children:[t.values_title.split("Us Forward")[0],p.jsx("span",{className:"gradient-text-dark",children:"Us Forward"})]})]}),p.jsx("div",{className:"grid md:grid-cols-2 lg:grid-cols-4 gap-5",children:i.map((s,o)=>{const l=mg[s.icon]||li;return p.jsxs("div",{className:"section-reveal light-card rounded-2xl p-6 group",style:{transitionDelay:`${o*.08}s`},children:[p.jsx("div",{className:`w-12 h-12 rounded-xl bg-gradient-to-br ${s.color} flex items-center justify-center mb-4 shadow-lg group-hover:scale-110 transition-transform`,children:p.jsx(l,{className:"w-6 h-6 text-white"})}),p.jsx("h3",{className:"font-display font-semibold text-[#0d2a5a] text-base mb-2",children:s.title}),p.jsx("p",{className:"text-[#5a7a9a] text-sm leading-relaxed",children:s.desc})]},s.title)})})]})}),p.jsx("section",{className:"py-16",style:{background:"#030c1e"},children:p.jsxs("div",{className:"max-w-5xl mx-auto px-6",children:[p.jsxs("div",{className:"text-center mb-12 section-reveal",children:[p.jsxs("h2",{className:"font-display text-4xl font-bold text-white mb-3",children:[t.features_title.split("Standards")[0],p.jsx("span",{className:"gradient-text",children:"Standards"})]}),p.jsx("p",{className:"text-ice-200/60 text-base max-w-xl mx-auto",children:t.features_sub})]}),p.jsx("div",{className:"section-reveal",children:p.jsx("div",{className:"grid md:grid-cols-2 gap-3",children:r.map((s,o)=>p.jsxs("div",{className:"flex items-start gap-3 glass-card rounded-xl px-4 py-3",children:[p.jsx(ql,{className:"w-4 h-4 text-ice-400 mt-0.5 flex-shrink-0"}),p.jsx("span",{className:"text-ice-200/70 text-sm leading-relaxed",children:s.text})]},s.id||o))})})]})}),p.jsx("section",{className:"py-16",style:{background:"#ffffff"},children:p.jsx("div",{className:"max-w-5xl mx-auto px-6",children:p.jsx("div",{className:"grid grid-cols-2 md:grid-cols-4 gap-4 section-reveal",children:a.map(s=>p.jsxs("div",{className:"light-card rounded-2xl py-5 px-4 text-center",children:[p.jsx("div",{className:"w-10 h-10 rounded-xl bg-[#e8f2fc] border border-[#c5ddf5] flex items-center justify-center mx-auto mb-3",children:p.jsx(li,{className:"w-5 h-5 text-[#1a56a0]"})}),p.jsx("div",{className:"text-[#0d2a5a] font-semibold text-sm",children:s.name})]},s.name))})})}),p.jsx("section",{className:"py-14",style:{background:"linear-gradient(135deg, #071528 0%, #0a2040 100%)"},children:p.jsxs("div",{className:"max-w-3xl mx-auto px-6 text-center section-reveal",children:[p.jsxs("h2",{className:"font-display text-3xl lg:text-4xl font-bold text-white mb-4",children:[t.cta_headline.split("Dove Gel Packs")[0],p.jsx("span",{className:"gradient-text",children:"Dove Gel Packs"})]}),p.jsx("p",{className:"text-ice-200/60 text-lg mb-8",children:t.cta_sub}),p.jsxs("div",{className:"flex flex-wrap gap-4 justify-center",children:[p.jsxs(Qt,{to:"/contact",className:"glow-button inline-flex items-center gap-2 px-8 py-3.5 rounded-xl bg-ice-500 text-white font-bold text-sm shadow-lg shadow-ice-500/30 hover:bg-ice-400 transition-colors",children:[t.cta_btn_contact," ",p.jsx(Ti,{className:"w-4 h-4"})]}),p.jsx(Qt,{to:"/products",className:"inline-flex items-center gap-2 px-8 py-3.5 rounded-xl glass-card border border-ice-500/20 text-ice-200 font-semibold text-sm hover:text-white transition-colors",children:t.cta_btn_products})]})]})})]})}function qA(){z.useEffect(()=>{const t=new IntersectionObserver(e=>e.forEach(n=>n.isIntersecting&&n.target.classList.add("visible")),{threshold:.08});return document.querySelectorAll(".section-reveal").forEach(e=>t.observe(e)),()=>t.disconnect()},[])}function YA(){const t=br(),{site:e,contact_page:n,faqs:i}=t,[r,a]=z.useState({name:"",email:"",company:"",phone:"",subject:"",message:""}),[s,o]=z.useState(!1),[l,c]=z.useState(!1);qA();const f=u=>{u.preventDefault(),c(!0),setTimeout(()=>{c(!1),o(!0),a({name:"",email:"",company:"",phone:"",subject:"",message:""}),setTimeout(()=>o(!1),5e3)},1200)},h=[{icon:J_,label:"Email",value:e.email,href:`mailto:${e.email}`},{icon:tx,label:"Phone",value:e.phone,href:e.phone_href},{icon:ex,label:n.service_area_label,value:n.service_area_value,href:null},{icon:iM,label:n.response_time_label,value:n.response_time_value,href:null}];return p.jsxs("div",{className:"light-page",children:[p.jsxs("section",{className:"relative pt-32 pb-16 overflow-hidden",style:{background:"radial-gradient(ellipse 70% 60% at 50% 50%, rgba(13,178,232,0.09) 0%, transparent 65%), linear-gradient(135deg, #030c1e 0%, #071528 60%, #0a1d38 100%)"},children:[p.jsx("div",{className:"absolute inset-0 pointer-events-none opacity-[0.022]",style:{backgroundImage:"linear-gradient(rgba(56,201,247,1) 1px, transparent 1px), linear-gradient(90deg, rgba(56,201,247,1) 1px, transparent 1px)",backgroundSize:"60px 60px"}}),p.jsx(wc,{}),p.jsxs("div",{className:"max-w-3xl mx-auto px-6 text-center section-reveal relative z-[3]",children:[p.jsx("div",{className:"inline-flex items-center gap-2 px-4 py-1.5 rounded-full glass-card text-ice-400 text-xs font-semibold mb-5",children:n.hero_badge}),p.jsxs("h1",{className:"font-display text-5xl lg:text-6xl font-bold text-white mb-5 leading-tight",children:[n.hero_title_line1,p.jsx("br",{}),p.jsx("span",{className:"gradient-text",children:n.hero_title_line2})]}),p.jsx("p",{className:"text-ice-200/65 text-lg leading-relaxed",children:n.hero_sub})]})]}),p.jsx("section",{className:"py-16 max-w-7xl mx-auto px-6 light-section-white",children:p.jsxs("div",{className:"grid lg:grid-cols-5 gap-10",children:[p.jsxs("div",{className:"lg:col-span-2 space-y-5 section-reveal",children:[p.jsxs("a",{href:e.whatsapp_number,target:"_blank",rel:"noopener noreferrer",className:"flex items-center gap-4 light-card rounded-2xl p-5 group",children:[p.jsx("div",{className:"w-12 h-12 rounded-xl bg-green-500/15 flex items-center justify-center flex-shrink-0 group-hover:bg-green-500/25 transition-colors",children:p.jsx(Eh,{className:"w-6 h-6 text-green-600"})}),p.jsxs("div",{className:"flex-1 min-w-0",children:[p.jsx("div",{className:"text-[#0d2a5a] font-semibold text-sm",children:n.whatsapp_card_title}),p.jsx("div",{className:"text-green-700/75 text-xs mt-0.5",children:n.whatsapp_card_sub})]}),p.jsx(fm,{className:"w-4 h-4 text-green-600/50 rotate-45 group-hover:text-green-600 transition-colors flex-shrink-0"})]}),h.map(({icon:u,label:m,value:x,href:E})=>p.jsxs("div",{className:"flex items-center gap-4 light-card rounded-2xl p-4",children:[p.jsx("div",{className:"w-10 h-10 rounded-xl bg-[#e8f2fc] flex items-center justify-center flex-shrink-0",children:p.jsx(u,{className:"w-5 h-5 text-[#1a56a0]"})}),p.jsxs("div",{children:[p.jsx("div",{className:"text-[#5a7a9a] text-xs font-medium",children:m}),E?p.jsx("a",{href:E,className:"font-medium text-sm mt-0.5 text-[#1a56a0] hover:opacity-70 transition-opacity",children:x}):p.jsx("div",{className:"text-[#0d2a5a] font-medium text-sm mt-0.5",children:x})]})]},m)),p.jsxs("div",{className:"light-card rounded-2xl p-5",children:[p.jsx("h4",{className:"font-display font-semibold text-[#0d2a5a] text-sm mb-3",children:n.help_heading}),p.jsx("ul",{className:"space-y-2",children:n.help_items.map(u=>p.jsxs("li",{className:"flex items-center gap-2 text-[#5a7a9a] text-xs",children:[p.jsx(ql,{className:"w-3.5 h-3.5 text-[#1a56a0] flex-shrink-0"}),u]},u))})]})]}),p.jsx("div",{className:"lg:col-span-3 section-reveal",children:p.jsxs("form",{onSubmit:f,className:"light-card rounded-3xl p-8 space-y-5",children:[p.jsxs("div",{children:[p.jsx("h2",{className:"font-display font-bold text-[#0d2a5a] text-2xl mb-1",children:n.form_title}),p.jsx("p",{className:"text-[#5a7a9a] text-sm",children:n.form_sub})]}),p.jsxs("div",{className:"grid sm:grid-cols-2 gap-4",children:[p.jsxs("div",{children:[p.jsx("label",{className:"light-input-label",children:n.form_name_label}),p.jsx("input",{type:"text",required:!0,value:r.name,onChange:u=>a({...r,name:u.target.value}),placeholder:n.form_name_ph,className:"light-input"})]}),p.jsxs("div",{children:[p.jsx("label",{className:"light-input-label",children:n.form_email_label}),p.jsx("input",{type:"email",required:!0,value:r.email,onChange:u=>a({...r,email:u.target.value}),placeholder:n.form_email_ph,className:"light-input"})]})]}),p.jsxs("div",{className:"grid sm:grid-cols-2 gap-4",children:[p.jsxs("div",{children:[p.jsx("label",{className:"light-input-label",children:n.form_company_label}),p.jsx("input",{type:"text",value:r.company,onChange:u=>a({...r,company:u.target.value}),placeholder:n.form_company_ph,className:"light-input"})]}),p.jsxs("div",{children:[p.jsx("label",{className:"light-input-label",children:n.form_phone_label}),p.jsx("input",{type:"tel",value:r.phone,onChange:u=>a({...r,phone:u.target.value}),placeholder:n.form_phone_ph,className:"light-input"})]})]}),p.jsxs("div",{children:[p.jsx("label",{className:"light-input-label",children:n.form_subject_label}),p.jsxs("select",{required:!0,value:r.subject,onChange:u=>a({...r,subject:u.target.value}),className:"light-input",style:{color:r.subject?"#0d2a5a":"#9ab0c8"},children:[p.jsx("option",{value:"",disabled:!0,children:"Select a subject"}),n.form_subjects.map(u=>p.jsx("option",{value:u.value,children:u.label},u.value))]})]}),p.jsxs("div",{children:[p.jsx("label",{className:"light-input-label",children:n.form_message_label}),p.jsx("textarea",{required:!0,rows:5,value:r.message,onChange:u=>a({...r,message:u.target.value}),placeholder:n.form_message_ph,className:"light-input resize-none"})]}),p.jsx("button",{type:"submit",disabled:l,className:"glow-button w-full py-4 rounded-xl bg-ice-500 text-white font-bold text-sm hover:bg-ice-400 transition-all disabled:opacity-70 flex items-center justify-center gap-2 shadow-lg shadow-ice-500/25",children:l?p.jsxs(p.Fragment,{children:[p.jsx("span",{className:"w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin"})," ",n.form_btn_sending]}):s?p.jsxs(p.Fragment,{children:[p.jsx(ql,{className:"w-4 h-4"})," ",n.form_btn_sent]}):p.jsxs(p.Fragment,{children:[p.jsx(fm,{className:"w-4 h-4"})," ",n.form_btn_send]})}),s&&p.jsx("div",{className:"text-center py-2 px-4 rounded-xl bg-green-50 border border-green-200 text-green-700 text-sm",children:n.form_success_msg})]})})]})}),p.jsxs("section",{className:"py-16 max-w-7xl mx-auto px-6 light-section-blue",children:[p.jsx("div",{className:"text-center mb-10 section-reveal",children:p.jsxs("h2",{className:"font-display text-3xl font-bold light-heading mb-2",children:[n.faq_title_line1," ",p.jsx("span",{className:"gradient-text-dark",children:n.faq_title_line2})]})}),p.jsx("div",{className:"grid md:grid-cols-2 gap-5",children:i.map((u,m)=>p.jsxs("div",{className:"section-reveal light-card rounded-2xl p-5",style:{transitionDelay:`${m*.08}s`},children:[p.jsx("h4",{className:"font-display font-semibold text-[#0d2a5a] text-sm mb-2",children:u.q}),p.jsx("p",{className:"text-[#5a7a9a] text-sm leading-relaxed",children:u.a})]},u.id||m))})]}),p.jsxs("section",{className:"py-14 text-center section-reveal light-section-white",children:[p.jsx("p",{className:"text-[#5a7a9a] text-sm mb-4",children:n.cta_text}),p.jsx(Qt,{to:"/products",className:"light-btn-outline",children:n.cta_btn})]})]})}function KA(){z.useEffect(()=>{const t=new IntersectionObserver(e=>e.forEach(n=>n.isIntersecting&&n.target.classList.add("visible")),{threshold:.08});return document.querySelectorAll(".section-reveal").forEach(e=>t.observe(e)),()=>t.disconnect()},[])}function ZA(){const{applications:t,applications_page:e}=br();return KA(),p.jsxs("div",{className:"light-page",children:[p.jsxs("section",{className:"relative pt-32 pb-20 overflow-hidden",style:{background:"radial-gradient(ellipse 70% 60% at 50% 50%, rgba(13,178,232,0.09) 0%, transparent 65%), linear-gradient(135deg, #030c1e 0%, #071528 60%, #0a1d38 100%)"},children:[p.jsx("div",{className:"absolute inset-0 pointer-events-none opacity-[0.022]",style:{backgroundImage:"linear-gradient(rgba(56,201,247,1) 1px, transparent 1px), linear-gradient(90deg, rgba(56,201,247,1) 1px, transparent 1px)",backgroundSize:"60px 60px"}}),p.jsx(wc,{}),p.jsxs("div",{className:"max-w-3xl mx-auto px-6 text-center section-reveal relative z-[3]",children:[p.jsx("div",{className:"inline-flex items-center gap-2 px-4 py-1.5 rounded-full glass-card text-ice-400 text-xs font-semibold mb-5",children:e.hero_badge}),p.jsxs("h1",{className:"font-display text-5xl lg:text-6xl font-bold text-white mb-5 leading-tight",children:[e.hero_title_line1,p.jsx("br",{}),p.jsx("span",{className:"gradient-text",children:e.hero_title_line2})]}),p.jsx("p",{className:"text-ice-200/65 text-lg leading-relaxed",children:e.hero_sub})]})]}),p.jsx("section",{className:"py-16",style:{background:"#ffffff"},children:p.jsx("div",{className:"max-w-7xl mx-auto px-6",children:p.jsx("div",{className:"grid md:grid-cols-2 lg:grid-cols-3 gap-7",children:t.map((n,i)=>p.jsxs("div",{className:"section-reveal light-card rounded-2xl overflow-hidden group",style:{transitionDelay:`${i*.07}s`},children:[p.jsxs("div",{className:"relative h-52 overflow-hidden",children:[p.jsx("img",{src:n.img,alt:n.title,className:"w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"}),p.jsx("div",{className:"absolute inset-0 bg-gradient-to-t from-[#e8f2fc]/90 via-[#e8f2fc]/20 to-transparent"}),p.jsx("span",{className:"absolute top-4 right-4 px-3 py-1 rounded-full bg-[#1a56a0]/15 border border-[#1a56a0]/25 text-[#1a56a0] text-xs font-bold backdrop-blur-sm",children:n.tag})]}),p.jsxs("div",{className:"p-6",children:[p.jsx("h3",{className:"font-display font-bold text-[#0d2a5a] text-lg mb-2",children:n.title}),p.jsx("p",{className:"text-[#5a7a9a] text-sm leading-relaxed mb-4",children:n.description}),p.jsx("div",{className:"flex flex-wrap gap-1.5",children:n.details.map(r=>p.jsx("span",{className:"px-2.5 py-1 rounded-full bg-[#e8f2fc] border border-[#c5ddf5] text-[#1a56a0] text-xs",children:r},r))})]})]},n.id||n.title))})})}),p.jsx("section",{className:"py-14 text-center section-reveal",style:{background:"linear-gradient(180deg, #e8f2fc 0%, #d8e8f5 100%)"},children:p.jsxs("div",{className:"max-w-3xl mx-auto px-6",children:[p.jsx("h2",{className:"font-display text-3xl font-bold text-[#0d2a5a] mb-4",children:e.cta_headline}),p.jsx("p",{className:"text-[#5a7a9a] mb-8 max-w-md mx-auto text-sm",children:e.cta_sub}),p.jsxs("div",{className:"flex flex-wrap gap-4 justify-center",children:[p.jsxs(Qt,{to:"/contact",className:"glow-button inline-flex items-center gap-2 px-7 py-3.5 rounded-xl bg-ice-500 text-white font-bold text-sm shadow-lg shadow-ice-500/30 hover:bg-ice-400 transition-colors",children:[e.cta_btn_contact," ",p.jsx(Ti,{className:"w-4 h-4"})]}),p.jsx(Qt,{to:"/products",className:"inline-flex items-center gap-2 px-7 py-3.5 rounded-xl border-2 border-[#1a56a0]/30 text-[#1a56a0] font-bold text-sm hover:bg-[#1a56a0]/10 transition-colors",children:e.cta_btn_products})]})]})})]})}function QA(){return p.jsx(fM,{children:p.jsxs(WS,{children:[p.jsx(hM,{}),p.jsxs(yS,{children:[p.jsx(Lr,{path:"/",element:p.jsx(pg,{})}),p.jsx(Lr,{path:"/products",element:p.jsx(jA,{})}),p.jsx(Lr,{path:"/applications",element:p.jsx(ZA,{})}),p.jsx(Lr,{path:"/about",element:p.jsx($A,{})}),p.jsx(Lr,{path:"/contact",element:p.jsx(YA,{})}),p.jsx(Lr,{path:"*",element:p.jsx(pg,{})})]}),p.jsx(_M,{}),p.jsx(xM,{})]})})}C_(document.getElementById("root")).render(p.jsx(z.StrictMode,{children:p.jsx(QA,{})}));
