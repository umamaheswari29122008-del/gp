<?php
require_once __DIR__ . '/core.php';
cors();
check_token();

$db     = get_db();
$method = $_SERVER['REQUEST_METHOD'];

if ($method !== 'POST') json_out(['error' => 'POST only'], 405);

$b = body();
$a = $b['action'] ?? '';

// ── Categories ────────────────────────────────────────────────────────────────
if ($a === 'save_category') {
    $id    = trim($b['id'] ?? '');
    $label = $b['label'] ?? '';
    $title = $b['title'] ?? '';
    $desc  = $b['description'] ?? '';
    $af    = $b['accent_from'] ?? '#1e7ec8';
    $at    = $b['accent_to'] ?? '#0db2e8';
    $specs = json_encode(array_filter(array_map('trim', $b['specs'] ?? [])));
    $ord   = (int)($b['sort_order'] ?? 0);
    if (!$id) json_out(['error' => 'id required'], 400);

    $exists = $db->prepare("SELECT id FROM product_categories WHERE id=?");
    $exists->execute([$id]);
    if ($exists->fetch()) {
        $db->prepare("UPDATE product_categories SET label=?,title=?,description=?,accent_from=?,accent_to=?,specs=?,sort_order=? WHERE id=?")
            ->execute([$label,$title,$desc,$af,$at,$specs,$ord,$id]);
    } else {
        $db->prepare("INSERT INTO product_categories (id,label,title,description,accent_from,accent_to,specs,sort_order) VALUES (?,?,?,?,?,?,?,?)")
            ->execute([$id,$label,$title,$desc,$af,$at,$specs,$ord]);
    }
    json_out(['ok' => true]);
}

if ($a === 'delete_category') {
    $id = $b['id'] ?? '';
    $db->prepare("DELETE FROM product_variants WHERE category_id=?")->execute([$id]);
    $db->prepare("DELETE FROM product_categories WHERE id=?")->execute([$id]);
    json_out(['ok' => true]);
}

// ── Variants ──────────────────────────────────────────────────────────────────
if ($a === 'save_variant') {
    $vid  = (int)($b['id'] ?? 0);
    $cid  = $b['category_id'] ?? '';
    $name = $b['name'] ?? '';
    $img  = $b['image'] ?? '';
    $ord  = (int)($b['sort_order'] ?? 0);
    if ($vid) {
        $db->prepare("UPDATE product_variants SET name=?,image=?,sort_order=? WHERE id=?")->execute([$name,$img,$ord,$vid]);
    } else {
        $db->prepare("INSERT INTO product_variants (category_id,name,image,sort_order) VALUES (?,?,?,?)")->execute([$cid,$name,$img,$ord]);
        $vid = (int)$db->lastInsertId();
    }
    $row = $db->prepare("SELECT * FROM product_variants WHERE id=?"); $row->execute([$vid]);
    json_out($row->fetch());
}

if ($a === 'delete_variant') {
    $db->prepare("DELETE FROM product_variants WHERE id=?")->execute([(int)($b['id'] ?? 0)]);
    json_out(['ok' => true]);
}

// ── Applications ──────────────────────────────────────────────────────────────
if ($a === 'save_application') {
    $id      = (int)($b['id'] ?? 0);
    $title   = $b['title'] ?? '';
    $desc    = $b['description'] ?? '';
    $img     = $b['img'] ?? '';
    $tag     = $b['tag'] ?? '';
    $details = json_encode(array_filter(array_map('trim', $b['details'] ?? [])));
    $ord     = (int)($b['sort_order'] ?? 0);
    if ($id) {
        $db->prepare("UPDATE applications SET title=?,description=?,img=?,tag=?,details=?,sort_order=? WHERE id=?")
            ->execute([$title,$desc,$img,$tag,$details,$ord,$id]);
    } else {
        $db->prepare("INSERT INTO applications (title,description,img,tag,details,sort_order) VALUES (?,?,?,?,?,?)")
            ->execute([$title,$desc,$img,$tag,$details,$ord]);
        $id = (int)$db->lastInsertId();
    }
    $row = $db->prepare("SELECT * FROM applications WHERE id=?"); $row->execute([$id]);
    $r = $row->fetch(); $r['details'] = json_decode($r['details'], true);
    json_out($r);
}

if ($a === 'delete_application') {
    $db->prepare("DELETE FROM applications WHERE id=?")->execute([(int)($b['id'] ?? 0)]);
    json_out(['ok' => true]);
}

json_out(['error' => 'Unknown action'], 400);
