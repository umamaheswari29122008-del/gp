<?php
require_once __DIR__ . '/core.php';
cors();
check_token();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_out(['error' => 'POST only'], 405);
if (empty($_FILES['file'])) json_out(['error' => 'No file'], 400);

$file = $_FILES['file'];
if ($file['error'] !== UPLOAD_ERR_OK) json_out(['error' => 'Upload error ' . $file['error']], 400);
if ($file['size'] > 8 * 1024 * 1024) json_out(['error' => 'Max 8MB'], 400);

$finfo = new finfo(FILEINFO_MIME_TYPE);
$mime  = $finfo->file($file['tmp_name']);
$exts  = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/gif'=>'gif','image/svg+xml'=>'svg'];
if (!isset($exts[$mime])) json_out(['error' => 'Images only'], 400);

if (!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR, 0755, true);

$fname = bin2hex(random_bytes(12)) . '.' . $exts[$mime];
$dest  = UPLOAD_DIR . $fname;

if (!move_uploaded_file($file['tmp_name'], $dest)) json_out(['error' => 'Save failed'], 500);

$proto = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$host  = $_SERVER['HTTP_HOST'] ?? 'localhost';
json_out(['url' => $proto . '://' . $host . '/uploads/' . $fname]);
