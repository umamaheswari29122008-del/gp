<?php
require_once __DIR__ . '/core.php';
cors();

$db     = get_db();
$method = $_SERVER['REQUEST_METHOD'];

// ── Public GET: return all site content ───────────────────────────────────────
if ($method === 'GET') {
    $srows = $db->query("SELECT key, value FROM settings")->fetchAll();
    $settings = [];
    foreach ($srows as $r) $settings[$r['key']] = $r['value'];

    $hp = $db->query("SELECT * FROM home_products ORDER BY sort_order")->fetchAll();

    $cats = $db->query("SELECT * FROM product_categories ORDER BY sort_order")->fetchAll();
    $vars = $db->query("SELECT * FROM product_variants ORDER BY sort_order")->fetchAll();
    foreach ($cats as &$cat) {
        $cat['specs'] = json_decode($cat['specs'] ?? '[]', true) ?: [];
        $cat['variants'] = array_values(array_filter($vars, fn($v) => $v['category_id'] === $cat['id']));
    }
    unset($cat);

    $tests  = $db->query("SELECT * FROM testimonials ORDER BY sort_order")->fetchAll();
    $faqs   = $db->query("SELECT * FROM faqs ORDER BY sort_order")->fetchAll();
    $happs  = $db->query("SELECT * FROM home_applications ORDER BY sort_order")->fetchAll();
    $miles  = $db->query("SELECT * FROM milestones ORDER BY sort_order")->fetchAll();

    $apps = $db->query("SELECT * FROM applications ORDER BY sort_order")->fetchAll();
    foreach ($apps as &$a) $a['details'] = json_decode($a['details'] ?? '[]', true) ?: [];
    unset($a);

    json_out([
        'settings'          => $settings,
        'home_products'     => $hp,
        'product_categories'=> $cats,
        'testimonials'      => $tests,
        'faqs'              => $faqs,
        'home_applications' => $happs,
        'applications'      => $apps,
        'milestones'        => $miles,
    ]);
}

// ── Protected POST: update settings ──────────────────────────────────────────
if ($method === 'POST') {
    check_token();
    $b = body();
    $safe_keys = ['logo_url','site_name','tagline','whatsapp_number','whatsapp_channel','email','phone','phone_href','address','footer_tagline','facebook_url','instagram_url','linkedin_url','hero_badge_text','hero_headline_line1','hero_headline_line2','hero_headline_line3','hero_headline_line4','hero_subheadline','hero_btn_products_text','hero_btn_whatsapp_text','hero_cta_headline','hero_cta_sub','hero_cta_btn_whatsapp','hero_cta_btn_quote','about_hero_title_line1','about_hero_title_line2','about_hero_title_line3','about_hero_sub','about_story_title','about_values_title','about_features_title','about_features_sub','about_cta_headline','about_cta_sub','about_intro_title','about_intro_highlight','about_intro_p1','about_intro_p2','contact_hero_title_line1','contact_hero_title_line2','contact_hero_sub','contact_help_items'];
    $st = $db->prepare("INSERT INTO settings (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value");
    foreach ($b as $k => $v) {
        if (in_array($k, $safe_keys, true)) {
            $st->execute([$k, is_array($v) ? json_encode($v) : (string)$v]);
        }
    }
    json_out(['ok' => true]);
}
