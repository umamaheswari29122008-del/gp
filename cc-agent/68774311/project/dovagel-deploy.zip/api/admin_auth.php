<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';

header('Content-Type: application/json; charset=utf-8');
cors_headers();

$db     = get_db();
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';
session_start_safe();

// Check if any admin exists
if ($action === 'setup_status') {
    $count = $db->query("SELECT COUNT(*) FROM admins")->fetchColumn();
    json_response(['needs_setup' => $count == 0]);
}

// First-time setup
if ($action === 'setup' && $method === 'POST') {
    $count = $db->query("SELECT COUNT(*) FROM admins")->fetchColumn();
    if ($count > 0) json_response(['error' => 'Admin account already exists'], 403);
    $body = get_json_body();
    $username = trim($body['username'] ?? '');
    $password = $body['password'] ?? '';
    if (strlen($username) < 3) json_response(['error' => 'Username must be at least 3 characters'], 400);
    if (strlen($password) < 8) json_response(['error' => 'Password must be at least 8 characters'], 400);
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $db->prepare("INSERT INTO admins (username, password_hash) VALUES (?, ?)")->execute([$username, $hash]);
    $id = $db->lastInsertId();
    $_SESSION['admin_id'] = $id;
    $_SESSION['admin_username'] = $username;
    json_response(['ok' => true, 'username' => $username]);
}

// Login
if ($action === 'login' && $method === 'POST') {
    $body = get_json_body();
    $username = trim($body['username'] ?? '');
    $password = $body['password'] ?? '';
    $stmt = $db->prepare("SELECT * FROM admins WHERE username = ?");
    $stmt->execute([$username]);
    $admin = $stmt->fetch();
    if (!$admin || !password_verify($password, $admin['password_hash'])) {
        json_response(['error' => 'Invalid username or password'], 401);
    }
    $_SESSION['admin_id'] = $admin['id'];
    $_SESSION['admin_username'] = $admin['username'];
    json_response(['ok' => true, 'username' => $admin['username']]);
}

// Logout
if ($action === 'logout' && $method === 'POST') {
    session_destroy();
    json_response(['ok' => true]);
}

// Session check
if ($action === 'me' && $method === 'GET') {
    if (is_logged_in()) {
        json_response(['logged_in' => true, 'username' => $_SESSION['admin_username'] ?? '']);
    } else {
        json_response(['logged_in' => false]);
    }
}

// Change password
if ($action === 'change_password' && $method === 'POST') {
    require_auth();
    $body = get_json_body();
    $current = $body['current_password'] ?? '';
    $new = $body['new_password'] ?? '';
    if (strlen($new) < 8) json_response(['error' => 'New password must be at least 8 characters'], 400);
    $stmt = $db->prepare("SELECT * FROM admins WHERE id = ?");
    $stmt->execute([$_SESSION['admin_id']]);
    $admin = $stmt->fetch();
    if (!$admin || !password_verify($current, $admin['password_hash'])) {
        json_response(['error' => 'Current password is incorrect'], 401);
    }
    $db->prepare("UPDATE admins SET password_hash = ? WHERE id = ?")->execute([password_hash($new, PASSWORD_DEFAULT), $admin['id']]);
    json_response(['ok' => true]);
}

json_response(['error' => 'Unknown action'], 400);
