<?php
require_once __DIR__ . '/core.php';
cors();

$db     = get_db();
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

// ── Is setup needed? ──────────────────────────────────────────────────────────
if ($action === 'status') {
    $count = (int)$db->query("SELECT COUNT(*) FROM admins")->fetchColumn();
    json_out(['needs_setup' => $count === 0]);
}

// ── First-time setup ──────────────────────────────────────────────────────────
if ($action === 'setup' && $method === 'POST') {
    $count = (int)$db->query("SELECT COUNT(*) FROM admins")->fetchColumn();
    if ($count > 0) json_out(['error' => 'Admin already exists. Please login.'], 403);

    $b = body();
    $username = trim($b['username'] ?? '');
    $password = $b['password'] ?? '';

    if (strlen($username) < 3)  json_out(['error' => 'Username must be at least 3 characters'], 400);
    if (strlen($password) < 6)  json_out(['error' => 'Password must be at least 6 characters'], 400);

    $hash = password_hash($password, PASSWORD_DEFAULT);
    $db->prepare("INSERT INTO admins (username, password_hash) VALUES (?, ?)")->execute([$username, $hash]);
    $id = (int)$db->lastInsertId();
    json_out(['token' => make_token($id), 'username' => $username]);
}

// ── Login ─────────────────────────────────────────────────────────────────────
if ($action === 'login' && $method === 'POST') {
    $b = body();
    $username = trim($b['username'] ?? '');
    $password = $b['password'] ?? '';

    $st = $db->prepare("SELECT * FROM admins WHERE username = ?");
    $st->execute([$username]);
    $admin = $st->fetch();

    if (!$admin || !password_verify($password, $admin['password_hash'])) {
        json_out(['error' => 'Wrong username or password'], 401);
    }

    json_out(['token' => make_token((int)$admin['id']), 'username' => $admin['username']]);
}

// ── Validate token ────────────────────────────────────────────────────────────
if ($action === 'validate') {
    $token = trim($_SERVER['HTTP_X_AUTH_TOKEN'] ?? '');
    if (!$token) json_out(['ok' => false]);
    $db->exec("DELETE FROM tokens WHERE expires_at < datetime('now')");
    $row = $db->prepare("SELECT admin_id FROM tokens WHERE token = ?");
    $row->execute([$token]);
    json_out(['ok' => (bool)$row->fetch()]);
}

// ── Logout ────────────────────────────────────────────────────────────────────
if ($action === 'logout' && $method === 'POST') {
    $token = trim($_SERVER['HTTP_X_AUTH_TOKEN'] ?? '');
    if ($token) $db->prepare("DELETE FROM tokens WHERE token = ?")->execute([$token]);
    json_out(['ok' => true]);
}

// ── Change password ───────────────────────────────────────────────────────────
if ($action === 'change_password' && $method === 'POST') {
    check_token();
    $b = body();
    $old = $b['old_password'] ?? '';
    $new = $b['new_password'] ?? '';
    if (strlen($new) < 6) json_out(['error' => 'New password must be at least 6 characters'], 400);

    $token = trim($_SERVER['HTTP_X_AUTH_TOKEN'] ?? '');
    $row = $db->prepare("SELECT a.* FROM admins a JOIN tokens t ON t.admin_id = a.id WHERE t.token = ?");
    $row->execute([$token]);
    $admin = $row->fetch();
    if (!$admin || !password_verify($old, $admin['password_hash'])) {
        json_out(['error' => 'Current password is incorrect'], 401);
    }
    $db->prepare("UPDATE admins SET password_hash = ? WHERE id = ?")
        ->execute([password_hash($new, PASSWORD_DEFAULT), $admin['id']]);
    json_out(['ok' => true]);
}

json_out(['error' => 'Unknown action'], 400);
